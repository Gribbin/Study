create TYPE Ty_BatchExecOrder AS OBJECT
(
    BrokerID CHAR(10),  --经纪公司代码
    InvestorID CHAR(12),  --投资者代码
    InstrumentID CHAR(30),  --合约代码
    ExecOrderRef CHAR(12),  --执行宣告引用
    UserID CHAR(15),  --用户代码
    Volume NUMBER(20),  --数量
    RequestID NUMBER(10),  --请求编号
    BusinessUnit CHAR(20),  --业务单元
    OffsetFlag CHAR(1),  --开平标志
    HedgeFlag CHAR(1),  --投机套保标志
    ActionType CHAR(1),  --执行类型
    PosiDirection CHAR(1),  --保留头寸申请的持仓方向
    ReservePositionFlag CHAR(1),  --期权行权后是否保留期货头寸的标记
    CloseFlag CHAR(1),  --期权行权后生成的头寸是否自动平仓
    ExecOrderLocalID CHAR(12),  --本地执行宣告编号
    ExchangeID CHAR(8),  --交易所代码
    ParticipantID CHAR(10),  --会员代码
    ClientID CHAR(10),  --客户代码
    ExchangeInstID CHAR(30),  --合约在交易所的代码
    TraderID CHAR(20),  --交易所交易员代码
    InstallID NUMBER(2),  --安装编号
    OrderSubmitStatus CHAR(1),  --执行宣告提交状态
    NotifySequence NUMBER(8),  --报单提示序号
    TradingDay CHAR(8),  --交易日
    SettlementID NUMBER(3),  --结算编号
    ExecOrderSysID CHAR(20),  --执行宣告编号
    InsertDate CHAR(8),  --报单日期
    InsertTime CHAR(8),  --插入时间
    CancelTime CHAR(8),  --撤销时间
    ExecResult CHAR(1),  --执行结果
    ClearingPartID CHAR(10),  --结算会员编号
    SequenceNo NUMBER(8),  --序号
    FrontID NUMBER(10),  --前置编号
    SessionID NUMBER(10),  --会话编号
    UserProductInfo CHAR(10),  --用户端产品信息
    StatusMsg VARCHAR2(80),  --状态信息
    ActiveUserID CHAR(15),  --操作用户代码
    BrokerExecOrderSeq NUMBER(8),  --经纪公司报单编号

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_BatchExecOrder RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

