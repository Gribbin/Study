create TYPE Ty_CFFEXDelivery AS OBJECT
(
    TradingDay CHAR(8),  --交易日
    ExchangeID CHAR(8),  --交易所代码
    ParticipantID CHAR(10),  --会员代码
    ExchangeInstID CHAR(30),  --合约代码
    SettlePartID CHAR(10),  --结算会员号
    AccountID CHAR(14),  --资金账号
    CurrencyID CHAR(3),  --资金账号币种
    SettlePartAbbr CHAR(8),  --结算会员简称
    Property VARCHAR2(2048),  --属性
    SettlementPrice NUMBER(19,10),  --交割结算价
    BuyAmt NUMBER(20),  --买入量
    SellAmt NUMBER(20),  --卖出量
    TransFee NUMBER(22,6),  --交割手续费

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_CFFEXDelivery RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

