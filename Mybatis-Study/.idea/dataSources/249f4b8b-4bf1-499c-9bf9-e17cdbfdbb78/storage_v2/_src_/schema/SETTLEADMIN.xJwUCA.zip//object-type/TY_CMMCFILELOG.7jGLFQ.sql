create TYPE Ty_CMMCFileLog AS OBJECT
(
    BrokerID CHAR(10),  --经纪公司代码
    TradingDay CHAR(8),  --交易日
    FileFlag NUMBER(1),  --统一开户文件标识
    SequenceNo NUMBER(8),  --序号
    TradingTime CHAR(8),  --操作时间
    LogLevel CHAR(32),  --日志级别
    Memo CHAR(160),  --日志

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_CMMCFileLog RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

