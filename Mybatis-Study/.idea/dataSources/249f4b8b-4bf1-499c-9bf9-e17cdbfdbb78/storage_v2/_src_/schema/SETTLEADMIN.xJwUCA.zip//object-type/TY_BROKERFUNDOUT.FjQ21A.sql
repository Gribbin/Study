create TYPE Ty_BrokerFundOUT AS OBJECT
(
    SettleTaskID CHAR(16),  --结算任务ID
    TradingDay CHAR(8),  --交易日
    BrokerID CHAR(10),  --经纪公司代码
    ExchangeID CHAR(8),  --交易所代码
    AccountID CHAR(14),  --资金账号
    CurrencyID CHAR(3),  --资金账号币种
    Deposit NUMBER(22,6),  --存款额
    LastDeposit NUMBER(22,6),  --昨日存款额
    Remain NUMBER(22,6),  --结算准备金余额
    Prepa NUMBER(22,6),  --开仓准备金
    WithdrawQuota NUMBER(22,6),  --提款限额
    FundOut NUMBER(22,6),  --出金金额
    FundIn NUMBER(22,6),  --入金金额
    Mortgage NUMBER(22,6),  --质押金额
    Margin NUMBER(22,6),  --保证金总额
    SMargin NUMBER(22,6),  --投机保证金
    HMargin NUMBER(22,6),  --保值保证金
    DelivMargin NUMBER(22,6),  --交割保证金
    ExchMargin NUMBER(22,6),  --交易所保证金总额
    ExchSMargin NUMBER(22,6),  --交易所投机保证金
    ExchHMargin NUMBER(22,6),  --交易所保值保证金
    ExchDelivMargin NUMBER(22,6),  --交易所交割保证金
    CloseProfit NUMBER(22,6),  --平仓盈亏
    PositionProfit NUMBER(22,6),  --持仓盈亏
    Actual NUMBER(22,6),  --当日盈亏
    FloatProfit NUMBER(22,6),  --浮动盈亏
    TransFee NUMBER(22,6),  --交易手续费
    DelivFee NUMBER(22,6),  --交割手续费
    SettlementFee NUMBER(22,6),  --结算手续费
    TransferPosFee NUMBER(22,6),  --移仓手续费
    StrikeFee NUMBER(22,6),  --执行手续费
    PerformFee NUMBER(22,6),  --履约手续费
    ExchTransFee NUMBER(22,6),  --交易所交易手续费
    ExchDelivFee NUMBER(22,6),  --交易所交割手续费
    ExchSettlementFee NUMBER(22,6),  --交易所结算手续费
    ExchTransferPosFee NUMBER(22,6),  --交易所移仓手续费
    ExchStrikeFee NUMBER(22,6),  --交易所执行手续费
    ExchPerformFee NUMBER(22,6),  --交易所履约手续费
    OptPremiumIncome NUMBER(22,6),  --期权权利金收入
    OptPremiumPay NUMBER(22,6),  --期权权利金支出
    OptStrikeProfit NUMBER(22,6),  --期权执行盈亏

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_BrokerFundOUT RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

