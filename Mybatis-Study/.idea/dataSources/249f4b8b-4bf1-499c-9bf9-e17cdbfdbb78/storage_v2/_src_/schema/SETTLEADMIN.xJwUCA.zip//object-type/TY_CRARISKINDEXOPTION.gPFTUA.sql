create TYPE Ty_CRARiskIndexOption AS OBJECT
(
    BrokerID CHAR(10),  --经纪商代码
    RiskFactorID NUMBER(8),  --风险因素ID
    RiskIndexID NUMBER(8),  --风险指标ID
    RiskIndexOptionID NUMBER(8),  --风险指标项ID
    RiskIndexOptionName VARCHAR2(50),  --名称
    RiskIndexOptionDesc VARCHAR2(120),  --说明
    RiskIndexOptionScore NUMBER(8),  --分类评分
    IsAddItem CHAR(1),  --是否附加项

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_CRARiskIndexOption RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

