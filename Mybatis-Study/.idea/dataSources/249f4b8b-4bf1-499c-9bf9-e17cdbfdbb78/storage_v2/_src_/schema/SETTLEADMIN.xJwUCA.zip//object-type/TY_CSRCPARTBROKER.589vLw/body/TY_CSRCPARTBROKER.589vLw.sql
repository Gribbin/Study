create TYPE BODY Ty_CSRCPartBroker IS

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_CSRCPartBroker RETURN SELF AS RESULT IS
  BEGIN
    RETURN;
  END;

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2 IS
    l_string VARCHAR2(4000);
  BEGIN
    l_string:='ty_CSRCPartBroker('
      || 'BrokerID=>' || '''' || trim(BrokerID) || '''' --经纪公司代码
      || ',ParticipantID=>' || '''' || trim(ParticipantID) || '''' --会员代码
      || ',Password=>' || '''' || trim(Password) || '''' --密码
      || ',OrgSystem=>' || '''' || trim(OrgSystem) || '''' --原有系统代码
      || ',UAPassword=>' || '''' || trim(UAPassword) || '''' --统一开户密码
      || ',UOAAutoSend=>' || '''' || trim(UOAAutoSend) || '''' --统一开户申请自动发送
      || ',UOAInterval=>' || '''' || trim(UOAInterval) || '''' --自动发送间隔（分钟）
      || ',SETTParticipantID=>' || '''' || trim(SETTParticipantID) || '''' --结算会员代码
      || ')';


    RETURN l_string;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN NULL;
  END;



END;
/

