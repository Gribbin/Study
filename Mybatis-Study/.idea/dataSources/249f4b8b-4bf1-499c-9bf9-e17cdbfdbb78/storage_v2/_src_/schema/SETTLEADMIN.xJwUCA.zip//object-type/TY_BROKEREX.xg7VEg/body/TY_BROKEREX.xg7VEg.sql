create TYPE BODY Ty_BrokerEx IS

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_BrokerEx RETURN SELF AS RESULT IS
  BEGIN
    RETURN;
  END;

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2 IS
    l_string VARCHAR2(4000);
  BEGIN
    l_string:='ty_BrokerEx('
      || 'BrokerID=>' || '''' || trim(BrokerID) || '''' --经纪公司代码
      || ',Corporation=>' || '''' || trim(Corporation) || '''' --法人代表
      || ',LinkMan=>' || '''' || trim(LinkMan) || '''' --联系人
      || ',Fax=>' || '''' || trim(Fax) || '''' --传真
      || ',Telephone=>' || '''' || trim(Telephone) || '''' --联系电话
      || ',Email=>' || '''' || trim(Email) || '''' --电子邮件
      || ',Address=>' || '''' || trim(Address) || '''' --联系地址
      || ',ZipCode=>' || '''' || trim(ZipCode) || '''' --邮政编码
      || ',Website=>' || '''' || trim(Website) || '''' --网站地址
      || ',CompanyCode=>' || '''' || trim(CompanyCode) || '''' --企业代码
      || ',TaxNo=>' || '''' || trim(TaxNo) || '''' --税务登记号
      || ',LicenseNo=>' || '''' || trim(LicenseNo) || '''' --营业执照号
      || ',OpenDate=>' || '''' || trim(OpenDate) || '''' --开户日期
      || ',CancleDate=>' || '''' || trim(CancleDate) || '''' --销户日期
      || ',BrokerFlag=>' || '''' || trim(BrokerFlag) || '''' --状态
      || ',BrokerDNS=>' || '''' || trim(BrokerDNS) || '''' --访问域名
      || ',BrokerDNS2=>' || '''' || trim(BrokerDNS2) || '''' --备份访问域名
      || ',SMTP=>' || '''' || trim(SMTP) || '''' --电邮服务器地址
      || ',EmailUser=>' || '''' || trim(EmailUser) || '''' --电邮用户名
      || ',EmailPassword=>' || '''' || trim(EmailPassword) || '''' --电邮密码
      || ',IsSMTPLogin=>' || '''' || trim(IsSMTPLogin) || '''' --SMTP是否需要身份验证
      || ')';


    RETURN l_string;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN NULL;
  END;



END;
/

