create TYPE BODY Ty_CffexCombRule IS

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_CffexCombRule RETURN SELF AS RESULT IS
  BEGIN
    RETURN;
  END;

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2 IS
    l_string VARCHAR2(4000);
  BEGIN
    l_string:='ty_CffexCombRule('
      || 'TradingDay=>' || '''' || trim(TradingDay) || '''' --交易日
      || ',BrokerID=>' || '''' || trim(BrokerID) || '''' --经纪公司代码
      || ',ExchangeID=>' || '''' || trim(ExchangeID) || '''' --交易所代码
      || ',RulePrdTyp=>' || '''' || trim(RulePrdTyp) || '''' --策略产品类型
      || ',ProdGroup=>' || '''' || trim(ProdGroup) || '''' --策略产品
      || ',RuleName=>' || '''' || trim(RuleName) || '''' --策略名称
      || ',RuleID=>' || '''' || trim(RuleID) || '''' --策略类型
      || ',HedgeFlag=>' || '''' || trim(HedgeFlag) || '''' --交易类型
      || ',TradRole=>' || '''' || trim(TradRole) || '''' --交易角色
      || ',ComMargin=>' || '''' || trim(ComMargin) || '''' --组合保证金标准
      || ',ComInstrid=>' || '''' || trim(ComInstrid) || '''' --合约组号
      || ',InstrID=>' || '''' || trim(InstrID) || '''' --合约
      || ',Direction=>' || '''' || trim(Direction) || '''' --合约买卖方向
      || ',Ration=>' || NVL(to_char(Ration),'NULL')--合约持仓比例
      || ')';


    RETURN l_string;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN NULL;
  END;



END;
/

