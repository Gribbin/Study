create TYPE Ty_BrokerUserQueryRight AS OBJECT
(
    BrokerID CHAR(10),  --经纪公司代码
    UserRange CHAR(1),  --操作员范围
    UserID CHAR(15),  --操作员代码
    TimeSpan CHAR(8),  --时间跨度
    BeginTime CHAR(8),  --查询开始时间
    EndTime CHAR(8),  --查询结束时间
    IsActive NUMBER(1),  --是否启用
    OperatorID CHAR(64),  --录入员代码
    OperateDate CHAR(8),  --录入日期
    OperateTime CHAR(8),  --录入时间

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_BrokerUserQueryRight RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

