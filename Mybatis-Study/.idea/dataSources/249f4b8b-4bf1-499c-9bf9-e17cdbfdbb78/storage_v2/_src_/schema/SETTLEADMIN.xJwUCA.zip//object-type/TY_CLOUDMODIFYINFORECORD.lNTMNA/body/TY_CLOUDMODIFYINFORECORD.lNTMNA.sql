create TYPE BODY Ty_CloudModifyInfoRecord IS

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_CloudModifyInfoRecord RETURN SELF AS RESULT IS
  BEGIN
    RETURN;
  END;

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2 IS
    l_string VARCHAR2(4000);
  BEGIN
    l_string:='ty_CloudModifyInfoRecord('
      || 'SequenceNo=>' || NVL(to_char(SequenceNo),'NULL')--序号
      || ',BrokerID=>' || '''' || trim(BrokerID) || '''' --经纪公司代码
      || ',ProcessID=>' || '''' || trim(ProcessID) || '''' --业务流水号
      || ',ProcessType=>' || '''' || trim(ProcessType) || '''' --流程功能类型
      || ',InvestorID=>' || '''' || trim(InvestorID) || '''' --投资者代码
      || ',InvestorName=>' || '''' || trim(InvestorName) || '''' --投资者名称
      || ',IdentifiedCardNo=>' || '''' || trim(IdentifiedCardNo) || '''' --证件号码
      || ',IdentifiedCardType=>' || '''' || trim(IdentifiedCardType) || '''' --证件类型
      || ',CompanyID=>' || '''' || trim(CompanyID) || '''' --期货公司统一编码
      || ',OperatorID=>' || '''' || trim(OperatorID) || '''' --操作员代码
      || ',OperateDate=>' || '''' || trim(OperateDate) || '''' --操作日期
      || ',OperateTime=>' || '''' || trim(OperateTime) || '''' --操作时间
      || ')';


    RETURN l_string;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN NULL;
  END;



END;
/

