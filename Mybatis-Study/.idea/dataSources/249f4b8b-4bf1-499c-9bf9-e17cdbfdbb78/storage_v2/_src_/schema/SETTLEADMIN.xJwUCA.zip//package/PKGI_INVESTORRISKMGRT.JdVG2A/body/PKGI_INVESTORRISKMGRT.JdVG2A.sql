create PACKAGE BODY PKGI_InvestorRiskMgrt  IS
  /*************************************************************************
  $spDesc 人员黑名单列表查询
  *************************************************************************/
  PROCEDURE up_QryCRAPersonBlackList
  (
     i_tyCRAPersonBlackList IN TY_CRAPERSONBLACKLIST  --人员黑名单查询条件
    ,i_tyPage IN  TY_PAGE  --分页信息
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_curCRAPersonBlackList OUT NOCOPY PKGS_DATATYPE.TYPEREFCURSOR  --查询结果游标
    ,o_nCount OUT PKGS_DATATYPE.STY_COUNT  --记录数
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_InvestorRiskMgrt.up_QryCRAPersonBlackList';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '人员黑名单列表查询';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '客户风险等级管理', '人员黑名单列表查询');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_InvestorRiskMgrt.up_QryCRAPersonBlackList(' ||
                           i_tyCRAPersonBlackList.uf_toString()
                      || ',' ||
                           i_tyPage.uf_toString()
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_curCRAPersonBlackList'
                      || ',' ||
                        'o_nCount'
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_InvestorRiskMgrt.up_QryCRAPersonBlackList(
                               i_tyCRAPersonBlackList
                              ,i_tyPage
                              ,i_chLanguage
                              ,o_curCRAPersonBlackList
                              ,o_nCount
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_QryCRAPersonBlackList;

  /*************************************************************************
  $spDesc 人员黑名单新增
  *************************************************************************/
  PROCEDURE up_InsCRAPersonBlackList
  (
     i_tytCRAPersonBlackList IN TYT_CRAPERSONBLACKLIST  --新增人员黑名单列表
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_InvestorRiskMgrt.up_InsCRAPersonBlackList';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '人员黑名单新增';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '客户风险等级管理', '人员黑名单新增');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_InvestorRiskMgrt.up_InsCRAPersonBlackList(' ||
                           PKGS_Tyt2STRING.uf_Tyt2String(i_tytCRAPersonBlackList)
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_InvestorRiskMgrt.up_InsCRAPersonBlackList(
                               i_tytCRAPersonBlackList
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_InsCRAPersonBlackList;

  /*************************************************************************
  $spDesc 人员黑名单修改
  *************************************************************************/
  PROCEDURE up_UpdCRAPersonBlackList
  (
     i_tyCRAPersonBlackList IN TY_CRAPERSONBLACKLIST  --人员黑名单更新条件
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_InvestorRiskMgrt.up_UpdCRAPersonBlackList';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '人员黑名单修改';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '客户风险等级管理', '人员黑名单修改');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_InvestorRiskMgrt.up_UpdCRAPersonBlackList(' ||
                           i_tyCRAPersonBlackList.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_InvestorRiskMgrt.up_UpdCRAPersonBlackList(
                               i_tyCRAPersonBlackList
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_UpdCRAPersonBlackList;

  /*************************************************************************
  $spDesc 人员黑名单删除
  *************************************************************************/
  PROCEDURE up_DelCRAPersonBlackList
  (
     i_tyCRAPersonBlackList IN TY_CRAPERSONBLACKLIST  --人员黑名单
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_InvestorRiskMgrt.up_DelCRAPersonBlackList';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '人员黑名单删除';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '客户风险等级管理', '人员黑名单删除');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_InvestorRiskMgrt.up_DelCRAPersonBlackList(' ||
                           i_tyCRAPersonBlackList.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_InvestorRiskMgrt.up_DelCRAPersonBlackList(
                               i_tyCRAPersonBlackList
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_DelCRAPersonBlackList;

  /*************************************************************************
  $spDesc 地域黑名单查询
  *************************************************************************/
  PROCEDURE up_QryCRAAreaBlackList
  (
     i_tyCRAAreaBlackList IN TY_CRAAREABLACKLIST  --地域黑名单查询条件
    ,i_tyPage IN  TY_PAGE  --分页信息
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_curCRAAreaBlackList OUT NOCOPY PKGS_DATATYPE.TYPEREFCURSOR  --查询结果游标
    ,o_nCount OUT PKGS_DATATYPE.STY_COUNT  --记录数
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_InvestorRiskMgrt.up_QryCRAAreaBlackList';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '地域黑名单查询';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '客户风险等级管理', '地域黑名单查询');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_InvestorRiskMgrt.up_QryCRAAreaBlackList(' ||
                           i_tyCRAAreaBlackList.uf_toString()
                      || ',' ||
                           i_tyPage.uf_toString()
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_curCRAAreaBlackList'
                      || ',' ||
                        'o_nCount'
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_InvestorRiskMgrt.up_QryCRAAreaBlackList(
                               i_tyCRAAreaBlackList
                              ,i_tyPage
                              ,i_chLanguage
                              ,o_curCRAAreaBlackList
                              ,o_nCount
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_QryCRAAreaBlackList;

  /*************************************************************************
  $spDesc 地域黑名单新增
  *************************************************************************/
  PROCEDURE up_InsCRAAreaBlackList
  (
     i_tytCRAAreaBlackList IN TYT_CRAAREABLACKLIST  --新增地域黑名单列表
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_InvestorRiskMgrt.up_InsCRAAreaBlackList';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '地域黑名单新增';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '客户风险等级管理', '地域黑名单新增');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_InvestorRiskMgrt.up_InsCRAAreaBlackList(' ||
                           PKGS_Tyt2STRING.uf_Tyt2String(i_tytCRAAreaBlackList)
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_InvestorRiskMgrt.up_InsCRAAreaBlackList(
                               i_tytCRAAreaBlackList
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_InsCRAAreaBlackList;

  /*************************************************************************
  $spDesc 地域黑名单修改
  *************************************************************************/
  PROCEDURE up_UpdCRAAreaBlackList
  (
     i_tyCRAAreaBlackList IN TY_CRAAREABLACKLIST  --地域黑名单更新条件
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_InvestorRiskMgrt.up_UpdCRAAreaBlackList';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '地域黑名单修改';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '客户风险等级管理', '地域黑名单修改');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_InvestorRiskMgrt.up_UpdCRAAreaBlackList(' ||
                           i_tyCRAAreaBlackList.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_InvestorRiskMgrt.up_UpdCRAAreaBlackList(
                               i_tyCRAAreaBlackList
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_UpdCRAAreaBlackList;

  /*************************************************************************
  $spDesc 地域黑名单删除
  *************************************************************************/
  PROCEDURE up_DelCRAAreaBlackList
  (
     i_tyCRAAreaBlackList IN TY_CRAAREABLACKLIST  --地域黑名单
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_InvestorRiskMgrt.up_DelCRAAreaBlackList';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '地域黑名单删除';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '客户风险等级管理', '地域黑名单删除');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_InvestorRiskMgrt.up_DelCRAAreaBlackList(' ||
                           i_tyCRAAreaBlackList.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_InvestorRiskMgrt.up_DelCRAAreaBlackList(
                               i_tyCRAAreaBlackList
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_DelCRAAreaBlackList;

  /*************************************************************************
  $spDesc 识别黑名单用户
  *************************************************************************/
  PROCEDURE up_RecCRABlackListedPerson
  (
     i_tyRecogCRABLPerson IN TY_RECOGCRABLPERSON  --黑名单客户识别参数
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_InvestorRiskMgrt.up_RecCRABlackListedPerson';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '识别黑名单用户';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '客户风险等级管理', '识别黑名单用户');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_InvestorRiskMgrt.up_RecCRABlackListedPerson(' ||
                           i_tyRecogCRABLPerson.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_InvestorRiskMgrt.up_RecCRABlackListedPerson(
                               i_tyRecogCRABLPerson
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_RecCRABlackListedPerson;

  /*************************************************************************
  $spDesc 人员黑名单客户查询
  *************************************************************************/
  PROCEDURE up_QryCRAPBLPerson
  (
     i_tyQueryCRAPBLPerson IN TY_QUERYCRAPBLPERSON  --黑名单客户查询条件
    ,i_tyPage IN  TY_PAGE  --分页信息
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_curResultCRAPBLPerson OUT NOCOPY PKGS_DATATYPE.TYPEREFCURSOR  --查询结果游标
    ,o_nCount OUT PKGS_DATATYPE.STY_COUNT  --记录数
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_InvestorRiskMgrt.up_QryCRAPBLPerson';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '人员黑名单客户查询';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '客户风险等级管理', '人员黑名单客户查询');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_InvestorRiskMgrt.up_QryCRAPBLPerson(' ||
                           i_tyQueryCRAPBLPerson.uf_toString()
                      || ',' ||
                           i_tyPage.uf_toString()
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_curResultCRAPBLPerson'
                      || ',' ||
                        'o_nCount'
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_InvestorRiskMgrt.up_QryCRAPBLPerson(
                               i_tyQueryCRAPBLPerson
                              ,i_tyPage
                              ,i_chLanguage
                              ,o_curResultCRAPBLPerson
                              ,o_nCount
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_QryCRAPBLPerson;

  /*************************************************************************
  $spDesc 人员黑名单客户新增
  *************************************************************************/
  PROCEDURE up_InsCRAPBLPerson
  (
     i_tyCRAPersonBlackListPerson IN TY_CRAPERSONBLACKLISTPERSON  --新增地域黑名单列表
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_InvestorRiskMgrt.up_InsCRAPBLPerson';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '人员黑名单客户新增';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '客户风险等级管理', '人员黑名单客户新增');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_InvestorRiskMgrt.up_InsCRAPBLPerson(' ||
                           i_tyCRAPersonBlackListPerson.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_InvestorRiskMgrt.up_InsCRAPBLPerson(
                               i_tyCRAPersonBlackListPerson
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_InsCRAPBLPerson;

  /*************************************************************************
  $spDesc 人员黑名单客户修改
  *************************************************************************/
  PROCEDURE up_UpdCRAPBLPerson
  (
     i_tyUpdateCRAPBLPerson IN TY_UPDATECRAPBLPERSON  --地域黑名单更新条件
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_InvestorRiskMgrt.up_UpdCRAPBLPerson';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '人员黑名单客户修改';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '客户风险等级管理', '人员黑名单客户修改');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_InvestorRiskMgrt.up_UpdCRAPBLPerson(' ||
                           i_tyUpdateCRAPBLPerson.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_InvestorRiskMgrt.up_UpdCRAPBLPerson(
                               i_tyUpdateCRAPBLPerson
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_UpdCRAPBLPerson;

  /*************************************************************************
  $spDesc 人员黑名单客户删除
  *************************************************************************/
  PROCEDURE up_DelCRAPBLPerson
  (
     i_tyCRAPersonBlackListPerson IN TY_CRAPERSONBLACKLISTPERSON  --地域黑名单
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_InvestorRiskMgrt.up_DelCRAPBLPerson';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '人员黑名单客户删除';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '客户风险等级管理', '人员黑名单客户删除');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_InvestorRiskMgrt.up_DelCRAPBLPerson(' ||
                           i_tyCRAPersonBlackListPerson.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_InvestorRiskMgrt.up_DelCRAPBLPerson(
                               i_tyCRAPersonBlackListPerson
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_DelCRAPBLPerson;

  /*************************************************************************
  $spDesc 地域黑名单客户查询
  *************************************************************************/
  PROCEDURE up_QryCRAABLPerson
  (
     i_tyQueryCRAABLPerson IN TY_QUERYCRAABLPERSON  --黑名单客户查询条件
    ,i_tyPage IN  TY_PAGE  --分页信息
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_curResultCRAABLPerson OUT NOCOPY PKGS_DATATYPE.TYPEREFCURSOR  --查询结果游标
    ,o_nCount OUT PKGS_DATATYPE.STY_COUNT  --记录数
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_InvestorRiskMgrt.up_QryCRAABLPerson';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '地域黑名单客户查询';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '客户风险等级管理', '地域黑名单客户查询');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_InvestorRiskMgrt.up_QryCRAABLPerson(' ||
                           i_tyQueryCRAABLPerson.uf_toString()
                      || ',' ||
                           i_tyPage.uf_toString()
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_curResultCRAABLPerson'
                      || ',' ||
                        'o_nCount'
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_InvestorRiskMgrt.up_QryCRAABLPerson(
                               i_tyQueryCRAABLPerson
                              ,i_tyPage
                              ,i_chLanguage
                              ,o_curResultCRAABLPerson
                              ,o_nCount
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_QryCRAABLPerson;

  /*************************************************************************
  $spDesc 地域黑名单客户新增
  *************************************************************************/
  PROCEDURE up_InsCRAABLPerson
  (
     i_tyCRAAreaBlackListPerson IN TY_CRAAREABLACKLISTPERSON  --新增地域黑名单列表
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_InvestorRiskMgrt.up_InsCRAABLPerson';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '地域黑名单客户新增';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '客户风险等级管理', '地域黑名单客户新增');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_InvestorRiskMgrt.up_InsCRAABLPerson(' ||
                           i_tyCRAAreaBlackListPerson.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_InvestorRiskMgrt.up_InsCRAABLPerson(
                               i_tyCRAAreaBlackListPerson
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_InsCRAABLPerson;

  /*************************************************************************
  $spDesc 地域黑名单客户修改
  *************************************************************************/
  PROCEDURE up_UpdCRAABLPerson
  (
     i_tyUpdateCRAABLPerson IN TY_UPDATECRAABLPERSON  --地域黑名单更新条件
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_InvestorRiskMgrt.up_UpdCRAABLPerson';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '地域黑名单客户修改';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '客户风险等级管理', '地域黑名单客户修改');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_InvestorRiskMgrt.up_UpdCRAABLPerson(' ||
                           i_tyUpdateCRAABLPerson.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_InvestorRiskMgrt.up_UpdCRAABLPerson(
                               i_tyUpdateCRAABLPerson
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_UpdCRAABLPerson;

  /*************************************************************************
  $spDesc 地域黑名单客户删除
  *************************************************************************/
  PROCEDURE up_DelCRAABLPerson
  (
     i_tyCRAAreaBlackListPerson IN TY_CRAAREABLACKLISTPERSON  --地域黑名单
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_InvestorRiskMgrt.up_DelCRAABLPerson';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '地域黑名单客户删除';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '客户风险等级管理', '地域黑名单客户删除');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_InvestorRiskMgrt.up_DelCRAABLPerson(' ||
                           i_tyCRAAreaBlackListPerson.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_InvestorRiskMgrt.up_DelCRAABLPerson(
                               i_tyCRAAreaBlackListPerson
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_DelCRAABLPerson;

  /*************************************************************************
  $spDesc 风险因素查询
  *************************************************************************/
  PROCEDURE up_QryCRARiskFactor
  (
     i_BrokerID IN PKGS_DATATYPE.STY_BROKERID  --经纪公司代码
    ,i_tyPage IN  TY_PAGE  --分页信息
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_curCRARiskFactor OUT NOCOPY PKGS_DATATYPE.TYPEREFCURSOR  --查询结果游标
    ,o_nCount OUT PKGS_DATATYPE.STY_COUNT  --记录数
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_InvestorRiskMgrt.up_QryCRARiskFactor';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '风险因素查询';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '客户风险等级管理', '风险因素查询');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_InvestorRiskMgrt.up_QryCRARiskFactor(' ||
                           '''' || trim(i_BrokerID) || ''''
                      || ',' ||
                           i_tyPage.uf_toString()
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_curCRARiskFactor'
                      || ',' ||
                        'o_nCount'
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_InvestorRiskMgrt.up_QryCRARiskFactor(
                               i_BrokerID
                              ,i_tyPage
                              ,i_chLanguage
                              ,o_curCRARiskFactor
                              ,o_nCount
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_QryCRARiskFactor;

  /*************************************************************************
  $spDesc 风险因素更新
  *************************************************************************/
  PROCEDURE up_UpdCRARiskFactor
  (
     io_tytCRARiskFactor IN OUT NOCOPY TYT_CRARISKFACTOR  --风险因素
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_InvestorRiskMgrt.up_UpdCRARiskFactor';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '风险因素更新';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '客户风险等级管理', '风险因素更新');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_InvestorRiskMgrt.up_UpdCRARiskFactor(' ||
                           PKGS_Tyt2STRING.uf_Tyt2String(io_tytCRARiskFactor)
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_InvestorRiskMgrt.up_UpdCRARiskFactor(
                               io_tytCRARiskFactor
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_UpdCRARiskFactor;

  /*************************************************************************
  $spDesc 风险因素对应风险指标查询
  *************************************************************************/
  PROCEDURE up_QryCRARiskIndex
  (
     i_tyCRARiskIndex IN TY_CRARISKINDEX  --风险指标查询条件
    ,i_tyPage IN  TY_PAGE  --分页信息
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_curCRARiskIndex OUT NOCOPY PKGS_DATATYPE.TYPEREFCURSOR  --查询结果游标
    ,o_nCount OUT PKGS_DATATYPE.STY_COUNT  --记录数
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_InvestorRiskMgrt.up_QryCRARiskIndex';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '风险因素对应风险指标查询';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '客户风险等级管理', '风险因素对应风险指标查询');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_InvestorRiskMgrt.up_QryCRARiskIndex(' ||
                           i_tyCRARiskIndex.uf_toString()
                      || ',' ||
                           i_tyPage.uf_toString()
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_curCRARiskIndex'
                      || ',' ||
                        'o_nCount'
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_InvestorRiskMgrt.up_QryCRARiskIndex(
                               i_tyCRARiskIndex
                              ,i_tyPage
                              ,i_chLanguage
                              ,o_curCRARiskIndex
                              ,o_nCount
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_QryCRARiskIndex;

  /*************************************************************************
  $spDesc 风险指标更新,因涉及到权重汇总校验,必须批量更新
  *************************************************************************/
  PROCEDURE up_UpdCRARiskIndex
  (
     io_tytCRARiskIndex IN OUT NOCOPY TYT_CRARISKINDEX  --风险指标
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_InvestorRiskMgrt.up_UpdCRARiskIndex';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '风险指标更新,因涉及到权重汇总校验,必须批量更新';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '客户风险等级管理', '风险指标更新,因涉及到权重汇总校验,必须批量更新');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_InvestorRiskMgrt.up_UpdCRARiskIndex(' ||
                           PKGS_Tyt2STRING.uf_Tyt2String(io_tytCRARiskIndex)
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_InvestorRiskMgrt.up_UpdCRARiskIndex(
                               io_tytCRARiskIndex
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_UpdCRARiskIndex;

  /*************************************************************************
  $spDesc 风险因素与指标提交
  *************************************************************************/
  PROCEDURE up_CommitCRARiskFI
  (
     i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_InvestorRiskMgrt.up_CommitCRARiskFI';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '风险因素与指标提交';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '客户风险等级管理', '风险因素与指标提交');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_InvestorRiskMgrt.up_CommitCRARiskFI(' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_InvestorRiskMgrt.up_CommitCRARiskFI(
                               i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_CommitCRARiskFI;

  /*************************************************************************
  $spDesc 风险指标对应风险指标项查询
  *************************************************************************/
  PROCEDURE up_QryCRARiskIndexOption
  (
     i_tyQueryCRARiskIndexOption IN TY_QUERYCRARISKINDEXOPTION  --风险指标项查询条件
    ,i_tyPage IN  TY_PAGE  --分页信息
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_curResultCRARiskIndexOption OUT NOCOPY PKGS_DATATYPE.TYPEREFCURSOR  --查询结果游标
    ,o_nCount OUT PKGS_DATATYPE.STY_COUNT  --记录数
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_InvestorRiskMgrt.up_QryCRARiskIndexOption';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '风险指标对应风险指标项查询';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '客户风险等级管理', '风险指标对应风险指标项查询');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_InvestorRiskMgrt.up_QryCRARiskIndexOption(' ||
                           i_tyQueryCRARiskIndexOption.uf_toString()
                      || ',' ||
                           i_tyPage.uf_toString()
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_curResultCRARiskIndexOption'
                      || ',' ||
                        'o_nCount'
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_InvestorRiskMgrt.up_QryCRARiskIndexOption(
                               i_tyQueryCRARiskIndexOption
                              ,i_tyPage
                              ,i_chLanguage
                              ,o_curResultCRARiskIndexOption
                              ,o_nCount
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_QryCRARiskIndexOption;

  /*************************************************************************
  $spDesc 风险指标项更新
  *************************************************************************/
  PROCEDURE up_UpdCRARiskIndexOption
  (
     io_tytResultCRARiskIndexOption IN OUT NOCOPY TYT_RESULTCRARISKINDEXOPTION  --风险指标
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_InvestorRiskMgrt.up_UpdCRARiskIndexOption';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '风险指标项更新';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '客户风险等级管理', '风险指标项更新');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_InvestorRiskMgrt.up_UpdCRARiskIndexOption(' ||
                           PKGS_Tyt2STRINGEx.uf_Tyt2String(io_tytResultCRARiskIndexOption)
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_InvestorRiskMgrt.up_UpdCRARiskIndexOption(
                               io_tytResultCRARiskIndexOption
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_UpdCRARiskIndexOption;

  /*************************************************************************
  $spDesc 风险权重查询
  *************************************************************************/
  PROCEDURE up_QryCRARiskWeight
  (
     i_tyQueryCRARiskWeight IN TY_QUERYCRARISKWEIGHT  --风险权重查询
    ,i_tyPage IN  TY_PAGE  --分页信息
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_curResultCRARiskWeight OUT NOCOPY PKGS_DATATYPE.TYPEREFCURSOR  --查询结果游标
    ,o_nCount OUT PKGS_DATATYPE.STY_COUNT  --记录数
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_InvestorRiskMgrt.up_QryCRARiskWeight';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '风险权重查询';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '客户风险等级管理', '风险权重查询');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_InvestorRiskMgrt.up_QryCRARiskWeight(' ||
                           i_tyQueryCRARiskWeight.uf_toString()
                      || ',' ||
                           i_tyPage.uf_toString()
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_curResultCRARiskWeight'
                      || ',' ||
                        'o_nCount'
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_InvestorRiskMgrt.up_QryCRARiskWeight(
                               i_tyQueryCRARiskWeight
                              ,i_tyPage
                              ,i_chLanguage
                              ,o_curResultCRARiskWeight
                              ,o_nCount
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_QryCRARiskWeight;

  /*************************************************************************
  $spDesc 风险权重更新
  *************************************************************************/
  PROCEDURE up_UpdCRARiskWeight
  (
     io_tyResultCRARiskWeight IN OUT NOCOPY TYT_RESULTCRARISKWEIGHT  --风险权重
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_InvestorRiskMgrt.up_UpdCRARiskWeight';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '风险权重更新';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '客户风险等级管理', '风险权重更新');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_InvestorRiskMgrt.up_UpdCRARiskWeight(' ||
                           PKGS_Tyt2STRINGEx.uf_Tyt2String(io_tyResultCRARiskWeight)
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_InvestorRiskMgrt.up_UpdCRARiskWeight(
                               io_tyResultCRARiskWeight
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_UpdCRARiskWeight;

  /*************************************************************************
  $spDesc 风险等级查询
  *************************************************************************/
  PROCEDURE up_QryCRARiskLevel
  (
     i_tyCRARiskLevel IN TY_CRARISKLEVEL  --查询条件
    ,i_tyPage IN  TY_PAGE  --分页信息
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_curCRARiskLevel OUT NOCOPY PKGS_DATATYPE.TYPEREFCURSOR  --查询结果游标
    ,o_nCount OUT PKGS_DATATYPE.STY_COUNT  --记录数
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_InvestorRiskMgrt.up_QryCRARiskLevel';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '风险等级查询';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '客户风险等级管理', '风险等级查询');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_InvestorRiskMgrt.up_QryCRARiskLevel(' ||
                           i_tyCRARiskLevel.uf_toString()
                      || ',' ||
                           i_tyPage.uf_toString()
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_curCRARiskLevel'
                      || ',' ||
                        'o_nCount'
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_InvestorRiskMgrt.up_QryCRARiskLevel(
                               i_tyCRARiskLevel
                              ,i_tyPage
                              ,i_chLanguage
                              ,o_curCRARiskLevel
                              ,o_nCount
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_QryCRARiskLevel;

  /*************************************************************************
  $spDesc 风险等级更新
  *************************************************************************/
  PROCEDURE up_UpdCRARiskLevel
  (
     i_tytCRARiskLevel IN TYT_CRARISKLEVEL  --风险等级
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_InvestorRiskMgrt.up_UpdCRARiskLevel';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '风险等级更新';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '客户风险等级管理', '风险等级更新');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_InvestorRiskMgrt.up_UpdCRARiskLevel(' ||
                           PKGS_Tyt2STRING.uf_Tyt2String(i_tytCRARiskLevel)
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_InvestorRiskMgrt.up_UpdCRARiskLevel(
                               i_tytCRARiskLevel
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_UpdCRARiskLevel;

  /*************************************************************************
  $spDesc 风险等级删除
  *************************************************************************/
  PROCEDURE up_DelCRARiskLevel
  (
     i_tytCRARiskLevel IN TYT_CRARISKLEVEL  --风险等级表
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_InvestorRiskMgrt.up_DelCRARiskLevel';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '风险等级删除';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '客户风险等级管理', '风险等级删除');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_InvestorRiskMgrt.up_DelCRARiskLevel(' ||
                           PKGS_Tyt2STRING.uf_Tyt2String(i_tytCRARiskLevel)
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_InvestorRiskMgrt.up_DelCRARiskLevel(
                               i_tytCRARiskLevel
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_DelCRARiskLevel;

  /*************************************************************************
  $spDesc 风险等级新增
  *************************************************************************/
  PROCEDURE up_InsCRARiskLevel
  (
     i_tytCRARiskLevel IN TYT_CRARISKLEVEL  --风险等级表
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_InvestorRiskMgrt.up_InsCRARiskLevel';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '风险等级新增';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '客户风险等级管理', '风险等级新增');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_InvestorRiskMgrt.up_InsCRARiskLevel(' ||
                           PKGS_Tyt2STRING.uf_Tyt2String(i_tytCRARiskLevel)
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_InvestorRiskMgrt.up_InsCRARiskLevel(
                               i_tytCRARiskLevel
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_InsCRARiskLevel;

  /*************************************************************************
  $spDesc 风险等级提交
  *************************************************************************/
  PROCEDURE up_CommitCRARiskLevel
  (
     i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_InvestorRiskMgrt.up_CommitCRARiskLevel';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '风险等级提交';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '客户风险等级管理', '风险等级提交');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_InvestorRiskMgrt.up_CommitCRARiskLevel(' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_InvestorRiskMgrt.up_CommitCRARiskLevel(
                               i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_CommitCRARiskLevel;

  /*************************************************************************
  $spDesc 风险评级查询
  *************************************************************************/
  PROCEDURE up_QryCRAInvestorRisk
  (
     i_tyQueryCRAInvestorRisk IN TY_QUERYCRAINVESTORRISK  --投资者匹配条件
    ,i_tyPage IN  TY_PAGE  --分页信息
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_curResultCRAInvestorRisk OUT NOCOPY PKGS_DATATYPE.TYPEREFCURSOR  --查询结果游标
    ,o_nCount OUT PKGS_DATATYPE.STY_COUNT  --记录数
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_InvestorRiskMgrt.up_QryCRAInvestorRisk';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '风险评级查询';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '客户风险等级管理', '风险评级查询');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_InvestorRiskMgrt.up_QryCRAInvestorRisk(' ||
                           i_tyQueryCRAInvestorRisk.uf_toString()
                      || ',' ||
                           i_tyPage.uf_toString()
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_curResultCRAInvestorRisk'
                      || ',' ||
                        'o_nCount'
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_InvestorRiskMgrt.up_QryCRAInvestorRisk(
                               i_tyQueryCRAInvestorRisk
                              ,i_tyPage
                              ,i_chLanguage
                              ,o_curResultCRAInvestorRisk
                              ,o_nCount
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_QryCRAInvestorRisk;

  /*************************************************************************
  $spDesc 直接定级查询
  *************************************************************************/
  PROCEDURE up_QryCRAManualRating
  (
     i_tyQueryCRAManualRating IN TY_QUERYCRAMANUALRATING  --投资者匹配条件
    ,i_tyPage IN  TY_PAGE  --分页信息
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_curResultCRAManualRating OUT NOCOPY PKGS_DATATYPE.TYPEREFCURSOR  --查询结果游标
    ,o_nCount OUT PKGS_DATATYPE.STY_COUNT  --记录数
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_InvestorRiskMgrt.up_QryCRAManualRating';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '直接定级查询';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '客户风险等级管理', '直接定级查询');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_InvestorRiskMgrt.up_QryCRAManualRating(' ||
                           i_tyQueryCRAManualRating.uf_toString()
                      || ',' ||
                           i_tyPage.uf_toString()
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_curResultCRAManualRating'
                      || ',' ||
                        'o_nCount'
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_InvestorRiskMgrt.up_QryCRAManualRating(
                               i_tyQueryCRAManualRating
                              ,i_tyPage
                              ,i_chLanguage
                              ,o_curResultCRAManualRating
                              ,o_nCount
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_QryCRAManualRating;

  /*************************************************************************
  $spDesc 风险评级明细查询
  *************************************************************************/
  PROCEDURE up_QryCRARiskDetail
  (
     i_tyCRAInvestorRiskDetail IN TY_CRAINVESTORRISKDETAIL  --投资者匹配条件
    ,i_tyPage IN  TY_PAGE  --分页信息
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_curResultCRARiskDetail OUT NOCOPY PKGS_DATATYPE.TYPEREFCURSOR  --查询结果游标
    ,o_nCount OUT PKGS_DATATYPE.STY_COUNT  --记录数
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_InvestorRiskMgrt.up_QryCRARiskDetail';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '风险评级明细查询';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '客户风险等级管理', '风险评级明细查询');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_InvestorRiskMgrt.up_QryCRARiskDetail(' ||
                           i_tyCRAInvestorRiskDetail.uf_toString()
                      || ',' ||
                           i_tyPage.uf_toString()
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_curResultCRARiskDetail'
                      || ',' ||
                        'o_nCount'
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_InvestorRiskMgrt.up_QryCRARiskDetail(
                               i_tyCRAInvestorRiskDetail
                              ,i_tyPage
                              ,i_chLanguage
                              ,o_curResultCRARiskDetail
                              ,o_nCount
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_QryCRARiskDetail;

  /*************************************************************************
  $spDesc 投资者批量评级,对所有匹配投资者批量评级
  *************************************************************************/
  PROCEDURE up_UpdCRAInvestorRisks
  (
     i_tyQueryCRAInvestorRisk IN TY_QUERYCRAINVESTORRISK  --投资者匹配条件
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_InvestorRiskMgrt.up_UpdCRAInvestorRisks';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '投资者批量评级,对所有匹配投资者批量评级';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '客户风险等级管理', '投资者批量评级,对所有匹配投资者批量评级');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_InvestorRiskMgrt.up_UpdCRAInvestorRisks(' ||
                           i_tyQueryCRAInvestorRisk.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_InvestorRiskMgrt.up_UpdCRAInvestorRisks(
                               i_tyQueryCRAInvestorRisk
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_UpdCRAInvestorRisks;

  /*************************************************************************
  $spDesc 投资者批量直接定级,对所有匹配投资者批量直接定级
  *************************************************************************/
  PROCEDURE up_UpdCRAManualRating
  (
     i_tyQueryCRAManualRating IN TY_QUERYCRAMANUALRATING  --投资者匹配条件
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_InvestorRiskMgrt.up_UpdCRAManualRating';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '投资者批量直接定级,对所有匹配投资者批量直接定级';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '客户风险等级管理', '投资者批量直接定级,对所有匹配投资者批量直接定级');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_InvestorRiskMgrt.up_UpdCRAManualRating(' ||
                           i_tyQueryCRAManualRating.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_InvestorRiskMgrt.up_UpdCRAManualRating(
                               i_tyQueryCRAManualRating
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_UpdCRAManualRating;

  /*************************************************************************
  $spDesc 投资者风险评级
  *************************************************************************/
  PROCEDURE up_UpdCRAInvestorRisk
  (
     io_tytCRAInvestorRisk IN OUT NOCOPY TYT_CRAINVESTORRISK  --投资者风险评级
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_InvestorRiskMgrt.up_UpdCRAInvestorRisk';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '投资者风险评级';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '客户风险等级管理', '投资者风险评级');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_InvestorRiskMgrt.up_UpdCRAInvestorRisk(' ||
                           PKGS_Tyt2STRING.uf_Tyt2String(io_tytCRAInvestorRisk)
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_InvestorRiskMgrt.up_UpdCRAInvestorRisk(
                               io_tytCRAInvestorRisk
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_UpdCRAInvestorRisk;

  /*************************************************************************
  $spDesc 投资者风险评级
  *************************************************************************/
  PROCEDURE up_UpdO_CRAInvestorRisk
  (
     io_tyCRAInvestorRisk IN OUT TY_O_CRAINVESTORRISK  --投资者风险评级
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_InvestorRiskMgrt.up_UpdO_CRAInvestorRisk';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '投资者风险评级';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '客户风险等级管理', '投资者风险评级');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_InvestorRiskMgrt.up_UpdO_CRAInvestorRisk(' ||
                           io_tyCRAInvestorRisk.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_InvestorRiskMgrt.up_UpdO_CRAInvestorRisk(
                               io_tyCRAInvestorRisk
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_UpdO_CRAInvestorRisk;

  /*************************************************************************
  $spDesc 创建客户风险评分复核流水
  *************************************************************************/
  PROCEDURE up_InsCRACheckHis
  (
     io_tyCRACheckHis IN OUT NOCOPY TY_CRACHECKHIS  --复核流水类型
    ,i_operate IN PKGS_DATATYPE.STY_ENUMCHAR  --复核执行操作
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_InvestorRiskMgrt.up_InsCRACheckHis';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '创建客户风险评分复核流水';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '客户风险等级管理', '创建客户风险评分复核流水');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_InvestorRiskMgrt.up_InsCRACheckHis(' ||
                           io_tyCRACheckHis.uf_toString()
                      || ',' ||
                           '''' || trim(i_operate) || ''''
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_InvestorRiskMgrt.up_InsCRACheckHis(
                               io_tyCRACheckHis
                              ,i_operate
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_InsCRACheckHis;

  /*************************************************************************
  $spDesc 将复核信息更新到最终表
  *************************************************************************/
  PROCEDURE up_InsCRATarget
  (
     io_tyCRACheckHis IN OUT NOCOPY TY_CRACHECKHIS  --复核流水类型
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_InvestorRiskMgrt.up_InsCRATarget';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '将复核信息更新到最终表';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '客户风险等级管理', '将复核信息更新到最终表');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_InvestorRiskMgrt.up_InsCRATarget(' ||
                           io_tyCRACheckHis.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_InvestorRiskMgrt.up_InsCRATarget(
                               io_tyCRACheckHis
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_InsCRATarget;

  /*************************************************************************
  $spDesc 将最终表的审核信息删除
  *************************************************************************/
  PROCEDURE up_DelCRATarget
  (
     io_tyCRACheckHis IN OUT NOCOPY TY_CRACHECKHIS  --复核流水类型
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_InvestorRiskMgrt.up_DelCRATarget';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '将最终表的审核信息删除';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '客户风险等级管理', '将最终表的审核信息删除');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_InvestorRiskMgrt.up_DelCRATarget(' ||
                           io_tyCRACheckHis.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_InvestorRiskMgrt.up_DelCRATarget(
                               io_tyCRACheckHis
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_DelCRATarget;

  /*************************************************************************
  $spDesc 查询待审核的记录
  *************************************************************************/
  PROCEDURE up_QueryCRACheckHis
  (
     i_tyQueryCRACheckHis IN TY_QUERYCRACHECKHIS  --查询条件
    ,i_tyPage IN  TY_PAGE  --分页信息
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_curCRACheckHis OUT NOCOPY PKGS_DATATYPE.TYPEREFCURSOR  --查询结果游标
    ,o_nCount OUT PKGS_DATATYPE.STY_COUNT  --记录数
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_InvestorRiskMgrt.up_QueryCRACheckHis';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '查询待审核的记录';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '客户风险等级管理', '查询待审核的记录');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_InvestorRiskMgrt.up_QueryCRACheckHis(' ||
                           i_tyQueryCRACheckHis.uf_toString()
                      || ',' ||
                           i_tyPage.uf_toString()
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_curCRACheckHis'
                      || ',' ||
                        'o_nCount'
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_InvestorRiskMgrt.up_QueryCRACheckHis(
                               i_tyQueryCRACheckHis
                              ,i_tyPage
                              ,i_chLanguage
                              ,o_curCRACheckHis
                              ,o_nCount
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_QueryCRACheckHis;

  /*************************************************************************
  $spDesc 查询客户风险评分明细中间表
  *************************************************************************/
  PROCEDURE up_QryO_CRARiskDetail
  (
     i_tyCRACheckHis IN TY_CRACHECKHIS  --查询条件
    ,i_tyPage IN  TY_PAGE  --分页信息
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_curCRACheckDetail OUT NOCOPY PKGS_DATATYPE.TYPEREFCURSOR  --查询结果游标
    ,o_nCount OUT PKGS_DATATYPE.STY_COUNT  --记录数
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_InvestorRiskMgrt.up_QryO_CRARiskDetail';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '查询客户风险评分明细中间表';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '客户风险等级管理', '查询客户风险评分明细中间表');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_InvestorRiskMgrt.up_QryO_CRARiskDetail(' ||
                           i_tyCRACheckHis.uf_toString()
                      || ',' ||
                           i_tyPage.uf_toString()
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_curCRACheckDetail'
                      || ',' ||
                        'o_nCount'
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_InvestorRiskMgrt.up_QryO_CRARiskDetail(
                               i_tyCRACheckHis
                              ,i_tyPage
                              ,i_chLanguage
                              ,o_curCRACheckDetail
                              ,o_nCount
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_QryO_CRARiskDetail;

  /*************************************************************************
  $spDesc 查询客户风险评分审核流水
  *************************************************************************/
  PROCEDURE up_QueryCRACheckHiss
  (
     i_tyCRACheckHis IN TY_CRACHECKHIS  --查询条件
    ,i_tyPage IN  TY_PAGE  --分页信息
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_curCRACheckHiss OUT NOCOPY PKGS_DATATYPE.TYPEREFCURSOR  --查询结果游标
    ,o_nCount OUT PKGS_DATATYPE.STY_COUNT  --记录数
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_InvestorRiskMgrt.up_QueryCRACheckHiss';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '查询客户风险评分审核流水';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '客户风险等级管理', '查询客户风险评分审核流水');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_InvestorRiskMgrt.up_QueryCRACheckHiss(' ||
                           i_tyCRACheckHis.uf_toString()
                      || ',' ||
                           i_tyPage.uf_toString()
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_curCRACheckHiss'
                      || ',' ||
                        'o_nCount'
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_InvestorRiskMgrt.up_QueryCRACheckHiss(
                               i_tyCRACheckHis
                              ,i_tyPage
                              ,i_chLanguage
                              ,o_curCRACheckHiss
                              ,o_nCount
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_QueryCRACheckHiss;

  /*************************************************************************
  $spDesc 逐级审核同意
  *************************************************************************/
  PROCEDURE up_CRAApproveCheckHisByLevel
  (
     io_tytCRACheckHis IN OUT TYT_CRACHECKHIS  --客户风险评分审核流水表
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_InvestorRiskMgrt.up_CRAApproveCheckHisByLevel';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '逐级审核同意';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '客户风险等级管理', '逐级审核同意');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_InvestorRiskMgrt.up_CRAApproveCheckHisByLevel(' ||
                           PKGS_Tyt2STRING.uf_Tyt2String(io_tytCRACheckHis)
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_InvestorRiskMgrt.up_CRAApproveCheckHisByLevel(
                               io_tytCRACheckHis
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_CRAApproveCheckHisByLevel;

  /*************************************************************************
  $spDesc 跨级审核同意
  *************************************************************************/
  PROCEDURE up_CRAApproveCheckHisSkipLevel
  (
     io_tytCRACheckHis IN OUT TYT_CRACHECKHIS  --客户风险评分审核流水表
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_InvestorRiskMgrt.up_CRAApproveCheckHisSkipLevel';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '跨级审核同意';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '客户风险等级管理', '跨级审核同意');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_InvestorRiskMgrt.up_CRAApproveCheckHisSkipLevel(' ||
                           PKGS_Tyt2STRING.uf_Tyt2String(io_tytCRACheckHis)
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_InvestorRiskMgrt.up_CRAApproveCheckHisSkipLevel(
                               io_tytCRACheckHis
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_CRAApproveCheckHisSkipLevel;

  /*************************************************************************
  $spDesc 审核驳回
  *************************************************************************/
  PROCEDURE up_CRABackCheckHis
  (
     io_tytCRACheckHis IN OUT TYT_CRACHECKHIS  --客户风险评分审核流水表
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_InvestorRiskMgrt.up_CRABackCheckHis';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '审核驳回';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '客户风险等级管理', '审核驳回');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_InvestorRiskMgrt.up_CRABackCheckHis(' ||
                           PKGS_Tyt2STRING.uf_Tyt2String(io_tytCRACheckHis)
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_InvestorRiskMgrt.up_CRABackCheckHis(
                               io_tytCRACheckHis
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_CRABackCheckHis;

  /*************************************************************************
  $spDesc 重新审核
  *************************************************************************/
  PROCEDURE up_CRAReCheckHis
  (
     io_tytCRACheckHis IN OUT TYT_CRACHECKHIS  --客户风险评分审核流水表
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_InvestorRiskMgrt.up_CRAReCheckHis';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '重新审核';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '客户风险等级管理', '重新审核');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_InvestorRiskMgrt.up_CRAReCheckHis(' ||
                           PKGS_Tyt2STRING.uf_Tyt2String(io_tytCRACheckHis)
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_InvestorRiskMgrt.up_CRAReCheckHis(
                               io_tytCRACheckHis
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_CRAReCheckHis;

  /*************************************************************************
  $spDesc 投资者身份信息识别查询
  *************************************************************************/
  PROCEDURE up_QueryAmlInvestor
  (
     i_tyQueryAmlInvestor IN TY_QUERYAMLINVESTOR  --投资者身份信息识别查询条件
    ,i_tyPage IN  TY_PAGE  --分页信息
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_curAmlInvestor OUT NOCOPY PKGS_DATATYPE.TYPEREFCURSOR  --查询结果游标
    ,o_nCount OUT PKGS_DATATYPE.STY_COUNT  --记录数
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_InvestorRiskMgrt.up_QueryAmlInvestor';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '投资者身份信息识别查询';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '客户风险等级管理', '投资者身份信息识别查询');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_InvestorRiskMgrt.up_QueryAmlInvestor(' ||
                           i_tyQueryAmlInvestor.uf_toString()
                      || ',' ||
                           i_tyPage.uf_toString()
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_curAmlInvestor'
                      || ',' ||
                        'o_nCount'
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_InvestorRiskMgrt.up_QueryAmlInvestor(
                               i_tyQueryAmlInvestor
                              ,i_tyPage
                              ,i_chLanguage
                              ,o_curAmlInvestor
                              ,o_nCount
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_QueryAmlInvestor;

  /*************************************************************************
  $spDesc 投资者身份识别变更参数
  *************************************************************************/
  PROCEDURE up_QryAmlInvstChChkParam
  (
     i_tyAmlInvstChangeChkParam IN TY_AMLINVSTCHANGECHKPARAM  --投资者身份识别变更参数
    ,i_tyPage IN  TY_PAGE  --分页信息
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_curAmlChkParam OUT NOCOPY PKGS_DATATYPE.TYPEREFCURSOR  --查询结果游标
    ,o_nCount OUT PKGS_DATATYPE.STY_COUNT  --记录数
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_InvestorRiskMgrt.up_QryAmlInvstChChkParam';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '投资者身份识别变更参数';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '客户风险等级管理', '投资者身份识别变更参数');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_InvestorRiskMgrt.up_QryAmlInvstChChkParam(' ||
                           i_tyAmlInvstChangeChkParam.uf_toString()
                      || ',' ||
                           i_tyPage.uf_toString()
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_curAmlChkParam'
                      || ',' ||
                        'o_nCount'
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_InvestorRiskMgrt.up_QryAmlInvstChChkParam(
                               i_tyAmlInvstChangeChkParam
                              ,i_tyPage
                              ,i_chLanguage
                              ,o_curAmlChkParam
                              ,o_nCount
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_QryAmlInvstChChkParam;

  /*************************************************************************
  $spDesc 投资者身份信息变更人工识别新增
  *************************************************************************/
  PROCEDURE up_InsAmlinvestorchange
  (
     i_tyAmlinvestorchange IN TY_AMLINVESTORCHANGE  --投资者身份信息变更
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_InvestorRiskMgrt.up_InsAmlinvestorchange';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '投资者身份信息变更人工识别新增';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '客户风险等级管理', '投资者身份信息变更人工识别新增');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_InvestorRiskMgrt.up_InsAmlinvestorchange(' ||
                           i_tyAmlinvestorchange.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_InvestorRiskMgrt.up_InsAmlinvestorchange(
                               i_tyAmlinvestorchange
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_InsAmlinvestorchange;

  /*************************************************************************
  $spDesc 投资者身份信息变更人工识别删除
  *************************************************************************/
  PROCEDURE up_DelAmlinvestorchange
  (
     i_tyAmlinvestorchange IN TY_AMLINVESTORCHANGE  --投资者身份信息变更
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_InvestorRiskMgrt.up_DelAmlinvestorchange';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '投资者身份信息变更人工识别删除';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '客户风险等级管理', '投资者身份信息变更人工识别删除');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_InvestorRiskMgrt.up_DelAmlinvestorchange(' ||
                           i_tyAmlinvestorchange.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_InvestorRiskMgrt.up_DelAmlinvestorchange(
                               i_tyAmlinvestorchange
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_DelAmlinvestorchange;

  /*************************************************************************
  $spDesc 投资者身份信息变更人工识别更新
  *************************************************************************/
  PROCEDURE up_UpdAmlinvestorchange
  (
     i_tyAmlinvestorchange IN TY_AMLINVESTORCHANGE  --投资者身份信息变更
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_InvestorRiskMgrt.up_UpdAmlinvestorchange';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '投资者身份信息变更人工识别更新';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '客户风险等级管理', '投资者身份信息变更人工识别更新');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_InvestorRiskMgrt.up_UpdAmlinvestorchange(' ||
                           i_tyAmlinvestorchange.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_InvestorRiskMgrt.up_UpdAmlinvestorchange(
                               i_tyAmlinvestorchange
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_UpdAmlinvestorchange;

  /*************************************************************************
  $spDesc 投资者身份信息变更人工识别查询
  *************************************************************************/
  PROCEDURE up_QryAmlinvestorchangeByHand
  (
     i_tyQueryAmlinvestorchange IN TY_QUERYAMLINVESTORCHANGE  --投资者身份信息变更人工识别查询条件
    ,i_tyPage IN  TY_PAGE  --分页信息
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_curInvestorchange OUT NOCOPY PKGS_DATATYPE.TYPEREFCURSOR  --查询结果游标
    ,o_nCount OUT PKGS_DATATYPE.STY_COUNT  --记录数
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_InvestorRiskMgrt.up_QryAmlinvestorchangeByHand';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '投资者身份信息变更人工识别查询';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '客户风险等级管理', '投资者身份信息变更人工识别查询');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_InvestorRiskMgrt.up_QryAmlinvestorchangeByHand(' ||
                           i_tyQueryAmlinvestorchange.uf_toString()
                      || ',' ||
                           i_tyPage.uf_toString()
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_curInvestorchange'
                      || ',' ||
                        'o_nCount'
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_InvestorRiskMgrt.up_QryAmlinvestorchangeByHand(
                               i_tyQueryAmlinvestorchange
                              ,i_tyPage
                              ,i_chLanguage
                              ,o_curInvestorchange
                              ,o_nCount
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_QryAmlinvestorchangeByHand;

  /*************************************************************************
  $spDesc 投资者身份信息变更自动识别查询
  *************************************************************************/
  PROCEDURE up_QryAmlinvestorchangeAuto
  (
     i_tyQueryAmlinvestorchange IN TY_QUERYAMLINVESTORCHANGE  --投资者身份信息变更自动识别查询条件
    ,i_tyPage IN  TY_PAGE  --分页信息
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_curInvestorchange OUT NOCOPY PKGS_DATATYPE.TYPEREFCURSOR  --查询结果游标
    ,o_nCount OUT PKGS_DATATYPE.STY_COUNT  --记录数
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_InvestorRiskMgrt.up_QryAmlinvestorchangeAuto';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '投资者身份信息变更自动识别查询';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '客户风险等级管理', '投资者身份信息变更自动识别查询');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_InvestorRiskMgrt.up_QryAmlinvestorchangeAuto(' ||
                           i_tyQueryAmlinvestorchange.uf_toString()
                      || ',' ||
                           i_tyPage.uf_toString()
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_curInvestorchange'
                      || ',' ||
                        'o_nCount'
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_InvestorRiskMgrt.up_QryAmlinvestorchangeAuto(
                               i_tyQueryAmlinvestorchange
                              ,i_tyPage
                              ,i_chLanguage
                              ,o_curInvestorchange
                              ,o_nCount
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_QryAmlinvestorchangeAuto;

  /*************************************************************************
  $spDesc 投资者身份信息变更自动识别
  *************************************************************************/
  PROCEDURE up_CheckAmlinvestorchangeAuto
  (
     i_tyQueryAmlinvestorchange IN TY_QUERYAMLINVESTORCHANGE  --投资者身份信息变更
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_InvestorRiskMgrt.up_CheckAmlinvestorchangeAuto';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '投资者身份信息变更自动识别';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '客户风险等级管理', '投资者身份信息变更自动识别');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_InvestorRiskMgrt.up_CheckAmlinvestorchangeAuto(' ||
                           i_tyQueryAmlinvestorchange.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_InvestorRiskMgrt.up_CheckAmlinvestorchangeAuto(
                               i_tyQueryAmlinvestorchange
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_CheckAmlinvestorchangeAuto;

  /*************************************************************************
  $spDesc 证件到期日提醒查询
  *************************************************************************/
  PROCEDURE up_QryAmlCardExpireAlarm
  (
     i_tyQueryCardExpireAlarm IN TY_QUERYCARDEXPIREALARM  --证件到期日提醒查询条件
    ,i_tyPage IN  TY_PAGE  --分页信息
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_curCardExpireAlarm OUT NOCOPY PKGS_DATATYPE.TYPEREFCURSOR  --查询结果游标
    ,o_nCount OUT PKGS_DATATYPE.STY_COUNT  --记录数
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_InvestorRiskMgrt.up_QryAmlCardExpireAlarm';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '证件到期日提醒查询';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '客户风险等级管理', '证件到期日提醒查询');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_InvestorRiskMgrt.up_QryAmlCardExpireAlarm(' ||
                           i_tyQueryCardExpireAlarm.uf_toString()
                      || ',' ||
                           i_tyPage.uf_toString()
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_curCardExpireAlarm'
                      || ',' ||
                        'o_nCount'
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_InvestorRiskMgrt.up_QryAmlCardExpireAlarm(
                               i_tyQueryCardExpireAlarm
                              ,i_tyPage
                              ,i_chLanguage
                              ,o_curCardExpireAlarm
                              ,o_nCount
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_QryAmlCardExpireAlarm;

  /*************************************************************************
  $spDesc 获取所有匹配投资者批量评级总数
  *************************************************************************/
  PROCEDURE up_getCRAInvestorNumber
  (
     i_tyQueryCRAInvestorRisk IN TY_QUERYCRAINVESTORRISK  --投资者匹配条件
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_cnt OUT PKGS_DATATYPE.STY_COUNT  --记录数
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_InvestorRiskMgrt.up_getCRAInvestorNumber';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '获取所有匹配投资者批量评级总数';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '客户风险等级管理', '获取所有匹配投资者批量评级总数');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_InvestorRiskMgrt.up_getCRAInvestorNumber(' ||
                           i_tyQueryCRAInvestorRisk.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_cnt'
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_InvestorRiskMgrt.up_getCRAInvestorNumber(
                               i_tyQueryCRAInvestorRisk
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_cnt
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_getCRAInvestorNumber;

  /*************************************************************************
  $spDesc 投资者批量评级对所有匹配投资者批量评级
  *************************************************************************/
  PROCEDURE up_UpdCRAInvestorRisksByPage
  (
     i_tyQueryCRAInvestorRisk IN TY_QUERYCRAINVESTORRISK  --投资者匹配条件
    ,i_startIndex IN INT  --开始
    ,i_endIndex IN INT  --结束
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_InvestorRiskMgrt.up_UpdCRAInvestorRisksByPage';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '投资者批量评级对所有匹配投资者批量评级';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '客户风险等级管理', '投资者批量评级对所有匹配投资者批量评级');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_InvestorRiskMgrt.up_UpdCRAInvestorRisksByPage(' ||
                           i_tyQueryCRAInvestorRisk.uf_toString()
                      || ',' ||
                           '''' || trim(i_startIndex) || ''''
                      || ',' ||
                           '''' || trim(i_endIndex) || ''''
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_InvestorRiskMgrt.up_UpdCRAInvestorRisksByPage(
                               i_tyQueryCRAInvestorRisk
                              ,i_startIndex
                              ,i_endIndex
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_UpdCRAInvestorRisksByPage;

END PKGI_InvestorRiskMgrt;
/

