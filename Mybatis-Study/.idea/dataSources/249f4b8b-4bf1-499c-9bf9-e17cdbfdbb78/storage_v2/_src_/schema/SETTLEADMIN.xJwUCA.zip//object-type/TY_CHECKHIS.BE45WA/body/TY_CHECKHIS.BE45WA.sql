create TYPE BODY Ty_CheckHis IS

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_CheckHis RETURN SELF AS RESULT IS
  BEGIN
    RETURN;
  END;

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2 IS
    l_string VARCHAR2(4000);
  BEGIN
    l_string:='ty_CheckHis('
      || 'TradingDay=>' || '''' || trim(TradingDay) || '''' --交易日
      || ',BrokerID=>' || '''' || trim(BrokerID) || '''' --经纪公司代码
      || ',ApplyDate=>' || '''' || trim(ApplyDate) || '''' --申请日期
      || ',ApplyNo=>' || NVL(to_char(ApplyNo),'NULL')--申请流水号
      || ',ApplyOperate=>' || '''' || trim(ApplyOperate) || '''' --触发流程操作
      || ',CheckNo=>' || NVL(to_char(CheckNo),'NULL')--操作次数
      || ',FlowID=>' || '''' || trim(FlowID) || '''' --流程ID
      || ',CheckStatus=>' || '''' || trim(CheckStatus) || '''' --复核状态
      || ',CheckMemo=>' || '''' || trim(CheckMemo) || '''' --复核情况说明
      || ',CurrCheckLevel=>' || '''' || trim(CurrCheckLevel) || '''' --当前复核级别
      || ',MaxCheckLevel=>' || '''' || trim(MaxCheckLevel) || '''' --最高复核级别
      || ',UsedStatus=>' || '''' || trim(UsedStatus) || '''' --生效状态
      || ',Applier=>' || '''' || trim(Applier) || '''' --申请人
      || ',ApplyTime=>' || '''' || trim(ApplyTime) || '''' --申请时间
      || ',InvestorRange=>' || '''' || trim(InvestorRange) || '''' --投资者类型
      || ',InvestorID=>' || '''' || trim(InvestorID) || '''' --投资者代码
      || ',InvestUnitID=>' || '''' || trim(InvestUnitID) || '''' --投资单元代码
      || ',IsLatest=>' || '''' || trim(IsLatest) || '''' --是否最新
      || ',OperatorID=>' || '''' || trim(OperatorID) || '''' --复核员代码
      || ',OperateDate=>' || '''' || trim(OperateDate) || '''' --复核日期
      || ',OperateTime=>' || '''' || trim(OperateTime) || '''' --复核时间
      || ',CheckContent=>' || '''' || trim(CheckContent) || '''' --复核内容
      || ',VersionNo=>' || NVL(to_char(VersionNo),'NULL')--版本号
      || ')';


    RETURN l_string;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN NULL;
  END;



END;
/

