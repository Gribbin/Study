create PACKAGE BODY PKGS_Tyt2STRINGEX IS
-- 此处添加定制的代码 -------------------
-- *** BEGIN PUMP GENERATED PACKAGE BODY *** --
-- *** DO NOT MODIFY FOLLOWING CONTENT MANUALLY *** --
---- 将tyt_AccountOwnerWithCurrency转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_AccountOwnerWithCurrency) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_AccountOwnerWithCurrency(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QueryPositionInstrument转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QueryPositionInstrument) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QueryPositionInstrument(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QryChkSettleFund转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QryChkSettleFund) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QryChkSettleFund(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CheckSettleInvestor转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CheckSettleInvestor) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CheckSettleInvestor(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QryChkPositionInstrument转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QryChkPositionInstrument) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QryChkPositionInstrument(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultSHFESettlementFund转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultSHFESettlementFund) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultSHFESettlementFund(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultCFFEXSettlementFund转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultCFFEXSettlementFund) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultCFFEXSettlementFund(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultDCESettlementFund转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultDCESettlementFund) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultDCESettlementFund(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultCZCESettlementFund转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultCZCESettlementFund) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultCZCESettlementFund(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultINESettlementFund转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultINESettlementFund) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultINESettlementFund(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultSHFESetBrokerPos转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultSHFESetBrokerPos) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultSHFESetBrokerPos(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultCFFEXSetBrokerPos转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultCFFEXSetBrokerPos) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultCFFEXSetBrokerPos(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultDCESetBrokerPos转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultDCESetBrokerPos) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultDCESetBrokerPos(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultCZCESetBrokerPos转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultCZCESetBrokerPos) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultCZCESetBrokerPos(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultINESetBrokerPos转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultINESetBrokerPos) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultINESetBrokerPos(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultInvstModelMarginRate转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultInvstModelMarginRate) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultInvstModelMarginRate(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultSHFESetInvestorPos转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultSHFESetInvestorPos) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultSHFESetInvestorPos(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultINESetInvestorPos转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultINESetInvestorPos) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultINESetInvestorPos(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultCFFEXSetInvestorPos转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultCFFEXSetInvestorPos) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultCFFEXSetInvestorPos(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultDCESetInvestorPos转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultDCESetInvestorPos) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultDCESetInvestorPos(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultCZCESetInvestorPos转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultCZCESetInvestorPos) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultCZCESetInvestorPos(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultCZCESetInvstComPos转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultCZCESetInvstComPos) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultCZCESetInvstComPos(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultDCESetInvstComPos转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultDCESetInvstComPos) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultDCESetInvstComPos(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResSHFESpeParSettleFund转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResSHFESpeParSettleFund) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResSHFESpeParSettleFund(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResCFFEXSpeParSettleFund转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResCFFEXSpeParSettleFund) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResCFFEXSpeParSettleFund(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResDCESpeParSettleFund转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResDCESpeParSettleFund) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResDCESpeParSettleFund(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResCZCESpeParSettleFund转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResCZCESpeParSettleFund) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResCZCESpeParSettleFund(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResINESpeParSettleFund转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResINESpeParSettleFund) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResINESpeParSettleFund(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CheckCSRCFundDepAlg转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CheckCSRCFundDepAlg) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CheckCSRCFundDepAlg(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CheckCSRCFundSettleDeposit转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CheckCSRCFundSettleDeposit) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CheckCSRCFundSettleDeposit(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CheckCSRCFundAvailable转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CheckCSRCFundAvailable) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CheckCSRCFundAvailable(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CheckCSRCFundLastDeposit转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CheckCSRCFundLastDeposit) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CheckCSRCFundLastDeposit(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CheckCSRCFundDeposit转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CheckCSRCFundDeposit) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CheckCSRCFundDeposit(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CheckCSRCActual转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CheckCSRCActual) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CheckCSRCActual(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultEWarrantOffset转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultEWarrantOffset) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultEWarrantOffset(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QryEWarrantOffset转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QryEWarrantOffset) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QryEWarrantOffset(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultSHFEInstrumentCheck转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultSHFEInstrumentCheck) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultSHFEInstrumentCheck(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultSHFEInstrumentInfo转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultSHFEInstrumentInfo) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultSHFEInstrumentInfo(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultInsInDiffDate转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultInsInDiffDate) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultInsInDiffDate(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CopyInvstCommRate转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CopyInvstCommRate) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CopyInvstCommRate(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CopyInvstCommRateExch转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CopyInvstCommRateExch) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CopyInvstCommRateExch(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QueryRelatedAccountInfo转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QueryRelatedAccountInfo) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QueryRelatedAccountInfo(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CopyInvstCommRateTpl转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CopyInvstCommRateTpl) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CopyInvstCommRateTpl(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CopyTplCommRate转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CopyTplCommRate) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CopyTplCommRate(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultInvstOptCommrate转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultInvstOptCommrate) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultInvstOptCommrate(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultInvstFutCommRate转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultInvstFutCommRate) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultInvstFutCommRate(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QueryCSRCOtherInfo转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QueryCSRCOtherInfo) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QueryCSRCOtherInfo(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_FBTTransfer转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_FBTTransfer) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_FBTTransfer(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QuerySettlementPrice转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QuerySettlementPrice) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QuerySettlementPrice(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultChkASPSettleDeposit转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultChkASPSettleDeposit) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultChkASPSettleDeposit(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_Accountowner转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_Accountowner) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_Accountowner(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultInvestMarginRatePhas转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultInvestMarginRatePhas) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultInvestMarginRatePhas(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QueryAmlinvestorchange转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QueryAmlinvestorchange) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QueryAmlinvestorchange(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultAmlinvestorchange转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultAmlinvestorchange) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultAmlinvestorchange(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultCardExpireAlarm转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultCardExpireAlarm) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultCardExpireAlarm(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QueryAmlInvestor转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QueryAmlInvestor) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QueryAmlInvestor(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultAmlInvestor转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultAmlInvestor) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultAmlInvestor(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QueryCardExpireAlarm转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QueryCardExpireAlarm) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QueryCardExpireAlarm(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_Instrument转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_Instrument) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_Instrument(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QueryTrade转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QueryTrade) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QueryTrade(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_BatchUpdateTrade转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_BatchUpdateTrade) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_BatchUpdateTrade(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QueryDepartmentProperty转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QueryDepartmentProperty) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QueryDepartmentProperty(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultDepartmentProperty转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultDepartmentProperty) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultDepartmentProperty(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QueryDepartmentPartyMap转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QueryDepartmentPartyMap) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QueryDepartmentPartyMap(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultDepartmentPartyMap转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultDepartmentPartyMap) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultDepartmentPartyMap(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QueryInstDiffDepartParty转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QueryInstDiffDepartParty) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QueryInstDiffDepartParty(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultInstDiffDepartParty转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultInstDiffDepartParty) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultInstDiffDepartParty(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QueryUserRole转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QueryUserRole) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QueryUserRole(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QueryRoleFunction转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QueryRoleFunction) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QueryRoleFunction(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QueryInvestorLinkMan转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QueryInvestorLinkMan) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QueryInvestorLinkMan(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultInvestorLinkMan转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultInvestorLinkMan) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultInvestorLinkMan(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultUserRole转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultUserRole) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultUserRole(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultRoleFunction转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultRoleFunction) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultRoleFunction(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QueryBrokerVolume转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QueryBrokerVolume) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QueryBrokerVolume(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultBrokerVolume转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultBrokerVolume) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultBrokerVolume(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QueryDepartmentUser转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QueryDepartmentUser) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QueryDepartmentUser(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultDepartmentUser转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultDepartmentUser) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultDepartmentUser(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QryDepartmentUserBlacklist转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QryDepartmentUserBlacklist) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QryDepartmentUserBlacklist(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_RstDepartmentUserBlacklist转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_RstDepartmentUserBlacklist) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_RstDepartmentUserBlacklist(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QueryCSRCData转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QueryCSRCData) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QueryCSRCData(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QueryEWarrantOffset转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QueryEWarrantOffset) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QueryEWarrantOffset(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultEWarrantOffsett转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultEWarrantOffsett) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultEWarrantOffsett(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QueryInvestor转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QueryInvestor) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QueryInvestor(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultInvestor转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultInvestor) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultInvestor(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_InvestorSpecial转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_InvestorSpecial) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_InvestorSpecial(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QueryInveExchApply转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QueryInveExchApply) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QueryInveExchApply(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultInveExchApply转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultInveExchApply) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultInveExchApply(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QueryInvestorUnifyFreeze转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QueryInvestorUnifyFreeze) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QueryInvestorUnifyFreeze(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultInvestorUnifyFreeze转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultInvestorUnifyFreeze) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultInvestorUnifyFreeze(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QueryInvestorRight转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QueryInvestorRight) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QueryInvestorRight(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultInvestorRight转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultInvestorRight) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultInvestorRight(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QueryOptInstrTrdRight转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QueryOptInstrTrdRight) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QueryOptInstrTrdRight(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultOptInstrTrdRight转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultOptInstrTrdRight) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultOptInstrTrdRight(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QueryGeneralInstrTrdRight转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QueryGeneralInstrTrdRight) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QueryGeneralInstrTrdRight(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultGeneralInstrTrdRight转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultGeneralInstrTrdRight) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultGeneralInstrTrdRight(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QueryO_OpenInvestor转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QueryO_OpenInvestor) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QueryO_OpenInvestor(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultO_OpenInvestor转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultO_OpenInvestor) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultO_OpenInvestor(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QueryInvestorBankAccount转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QueryInvestorBankAccount) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QueryInvestorBankAccount(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultInvestorBankAccount转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultInvestorBankAccount) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultInvestorBankAccount(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QueryFBTAccountRegister转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QueryFBTAccountRegister) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QueryFBTAccountRegister(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultFBTAccountRegister转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultFBTAccountRegister) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultFBTAccountRegister(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_UpdateLoginPassword转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_UpdateLoginPassword) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_UpdateLoginPassword(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_UpdateAccountPassword转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_UpdateAccountPassword) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_UpdateAccountPassword(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QueryExchMarginRateDay转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QueryExchMarginRateDay) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QueryExchMarginRateDay(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultExchMarginRateDay转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultExchMarginRateDay) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultExchMarginRateDay(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QueryInvestMarginRateDay转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QueryInvestMarginRateDay) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QueryInvestMarginRateDay(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultInvestMarginRateDay转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultInvestMarginRateDay) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultInvestMarginRateDay(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QueryInvestMarginRatePhase转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QueryInvestMarginRatePhase) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QueryInvestMarginRatePhase(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QueryInvestMarginRateTpl转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QueryInvestMarginRateTpl) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QueryInvestMarginRateTpl(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CopyInvstMarginRateTpl转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CopyInvstMarginRateTpl) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CopyInvstMarginRateTpl(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QueryInvestMgnRateAdjTpl转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QueryInvestMgnRateAdjTpl) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QueryInvestMgnRateAdjTpl(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QueryInvstOptMargRateUlTpl转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QueryInvstOptMargRateUlTpl) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QueryInvstOptMargRateUlTpl(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultInstrumentExprDate转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultInstrumentExprDate) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultInstrumentExprDate(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QryExchFutMarginRateChk转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QryExchFutMarginRateChk) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QryExchFutMarginRateChk(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ExchFutMarginRateChk转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ExchFutMarginRateChk) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ExchFutMarginRateChk(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QryInvstFutMarginRateUpd转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QryInvstFutMarginRateUpd) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QryInvstFutMarginRateUpd(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QryInvstFutMarginRateDay转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QryInvstFutMarginRateDay) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QryInvstFutMarginRateDay(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_InvstFutMarginRateExDay转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_InvstFutMarginRateExDay) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_InvstFutMarginRateExDay(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CopyInvstFutMarginRate转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CopyInvstFutMarginRate) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CopyInvstFutMarginRate(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CopyInstrFutMarginRate转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CopyInstrFutMarginRate) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CopyInstrFutMarginRate(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QueryChkSettleBrokerPos转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QueryChkSettleBrokerPos) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QueryChkSettleBrokerPos(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QueryChkSettleInvestorPos转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QueryChkSettleInvestorPos) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QueryChkSettleInvestorPos(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QueryChkProductLifeRule转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QueryChkProductLifeRule) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QueryChkProductLifeRule(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QueryInvestorFund转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QueryInvestorFund) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QueryInvestorFund(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultInvestorFund转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultInvestorFund) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultInvestorFund(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QueryBrokerUserEvent转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QueryBrokerUserEvent) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QueryBrokerUserEvent(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultBrokerUserEvent转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultBrokerUserEvent) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultBrokerUserEvent(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QrySettleInfoConfirm转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QrySettleInfoConfirm) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QrySettleInfoConfirm(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_RstSettleInfoConfirm转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_RstSettleInfoConfirm) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_RstSettleInfoConfirm(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QueryRiskNotify转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QueryRiskNotify) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QueryRiskNotify(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultRiskNotify转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultRiskNotify) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultRiskNotify(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QueryBizNotice转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QueryBizNotice) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QueryBizNotice(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultBizNotice转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultBizNotice) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultBizNotice(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QueryRiskUserEvent转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QueryRiskUserEvent) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QueryRiskUserEvent(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultRiskUserEvent转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultRiskUserEvent) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultRiskUserEvent(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultExportFileLog转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultExportFileLog) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultExportFileLog(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QueryInvestorStatus转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QueryInvestorStatus) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QueryInvestorStatus(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultInvestorStatus转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultInvestorStatus) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultInvestorStatus(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QueryInvestorOpenStat转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QueryInvestorOpenStat) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QueryInvestorOpenStat(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultInvestorOpenStat转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultInvestorOpenStat) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultInvestorOpenStat(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QryTradingCodeOpenStat转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QryTradingCodeOpenStat) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QryTradingCodeOpenStat(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_RstTradingCodeOpenStat转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_RstTradingCodeOpenStat) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_RstTradingCodeOpenStat(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QueryRTInvestorOrder转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QueryRTInvestorOrder) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QueryRTInvestorOrder(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultRTInvestorOrder转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultRTInvestorOrder) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultRTInvestorOrder(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QueryRTTrade转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QueryRTTrade) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QueryRTTrade(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultRTTrade转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultRTTrade) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultRTTrade(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QueryRTBrokerUserEvent转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QueryRTBrokerUserEvent) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QueryRTBrokerUserEvent(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_RstRTBrokerUserEvent转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_RstRTBrokerUserEvent) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_RstRTBrokerUserEvent(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_RstRTTmdbOptionSelfClose转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_RstRTTmdbOptionSelfClose) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_RstRTTmdbOptionSelfClose(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_RstCombAction转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_RstCombAction) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_RstCombAction(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QueryTBCommand转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QueryTBCommand) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QueryTBCommand(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultTBCommand转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultTBCommand) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultTBCommand(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QrySecAgentSettlement转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QrySecAgentSettlement) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QrySecAgentSettlement(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_RstSecAgentSettlement转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_RstSecAgentSettlement) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_RstSecAgentSettlement(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QuerySecAgentPosition转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QuerySecAgentPosition) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QuerySecAgentPosition(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultSecAgentPosition转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultSecAgentPosition) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultSecAgentPosition(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QueryMarketData转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QueryMarketData) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QueryMarketData(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ProductAndProductAttr转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ProductAndProductAttr) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ProductAndProductAttr(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_FutInsAndInsTraAttr转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_FutInsAndInsTraAttr) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_FutInsAndInsTraAttr(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_OptInsAndInsTraAttr转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_OptInsAndInsTraAttr) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_OptInsAndInsTraAttr(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultProAndIns转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultProAndIns) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultProAndIns(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultCFFEXSetInvestorMag转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultCFFEXSetInvestorMag) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultCFFEXSetInvestorMag(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultCFFEXSetInvComPos转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultCFFEXSetInvComPos) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultCFFEXSetInvComPos(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QueryTradingCode转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QueryTradingCode) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QueryTradingCode(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultTradingCode转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultTradingCode) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultTradingCode(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QueryExchFutComm转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QueryExchFutComm) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QueryExchFutComm(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ExchFutCommEx转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ExchFutCommEx) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ExchFutCommEx(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QueryInvstFutComm转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QueryInvstFutComm) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QueryInvstFutComm(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_InvstFutCommEx转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_InvstFutCommEx) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_InvstFutCommEx(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ExchFutMarginRateEx转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ExchFutMarginRateEx) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ExchFutMarginRateEx(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QueryInvstOptComm转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QueryInvstOptComm) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QueryInvstOptComm(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QryFloatInvstComm转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QryFloatInvstComm) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QryFloatInvstComm(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_InvstOptCommEx转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_InvstOptCommEx) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_InvstOptCommEx(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ExchOptCommEx转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ExchOptCommEx) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ExchOptCommEx(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CurrExchFutMarginRateEx转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CurrExchFutMarginRateEx) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CurrExchFutMarginRateEx(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QryCExchFutMarginRateChk转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QryCExchFutMarginRateChk) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QryCExchFutMarginRateChk(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_RsCExchFutMarginRateChk转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_RsCExchFutMarginRateChk) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_RsCExchFutMarginRateChk(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_InvstFutMarginRateEx转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_InvstFutMarginRateEx) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_InvstFutMarginRateEx(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CurrInvstFutMarginRateEx转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CurrInvstFutMarginRateEx) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CurrInvstFutMarginRateEx(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CurrExchFutMarginRateAdjEx转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CurrExchFutMarginRateAdjEx) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CurrExchFutMarginRateAdjEx(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultInvstFutMgnRateMA转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultInvstFutMgnRateMA) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultInvstFutMgnRateMA(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QueryInvstFutMarginRate转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QueryInvstFutMarginRate) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QueryInvstFutMarginRate(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QueryInvstFutMgnRateAdj转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QueryInvstFutMgnRateAdj) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QueryInvstFutMgnRateAdj(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultInvstFutMgnRateAdj转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultInvstFutMgnRateAdj) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultInvstFutMgnRateAdj(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QueryModelMarginRate转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QueryModelMarginRate) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QueryModelMarginRate(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultModelMarginRate转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultModelMarginRate) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultModelMarginRate(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QueryMarginRateModelInvst转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QueryMarginRateModelInvst) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QueryMarginRateModelInvst(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultMarginRateModelInvst转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultMarginRateModelInvst) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultMarginRateModelInvst(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QueryInvstCommRateTpl转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QueryInvstCommRateTpl) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QueryInvstCommRateTpl(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QueryAMLNiSHCus转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QueryAMLNiSHCus) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QueryAMLNiSHCus(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QueryAMLNiSHTrade转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QueryAMLNiSHTrade) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QueryAMLNiSHTrade(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QueryAMLNiSSCus转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QueryAMLNiSSCus) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QueryAMLNiSSCus(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QueryAMLNiSSTrade转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QueryAMLNiSSTrade) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QueryAMLNiSSTrade(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QueryCheckReportHis转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QueryCheckReportHis) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QueryCheckReportHis(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QueryNiSSReport转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QueryNiSSReport) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QueryNiSSReport(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QueryNiSHReport转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QueryNiSHReport) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QueryNiSHReport(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QueryAMLDailyDrawStatus转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QueryAMLDailyDrawStatus) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QueryAMLDailyDrawStatus(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QueryAMLSHReport转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QueryAMLSHReport) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QueryAMLSHReport(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QueryAMLSHTrade转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QueryAMLSHTrade) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QueryAMLSHTrade(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QueryAMLSSReport转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QueryAMLSSReport) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QueryAMLSSReport(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QueryAMLSSTrade转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QueryAMLSSTrade) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QueryAMLSSTrade(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QueryAmlCheckHis转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QueryAmlCheckHis) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QueryAmlCheckHis(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultAmlCheckHis转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultAmlCheckHis) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultAmlCheckHis(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QueryAmlCheckHisStas转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QueryAmlCheckHisStas) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QueryAmlCheckHisStas(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultAMLCheckHisStas转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultAMLCheckHisStas) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultAMLCheckHisStas(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_AmlReportHis转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_AmlReportHis) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_AmlReportHis(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QueryAmlReport转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QueryAmlReport) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QueryAmlReport(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultAmlReport转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultAmlReport) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultAmlReport(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QueryAmlGenFileLog转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QueryAmlGenFileLog) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QueryAmlGenFileLog(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultAmlGenFileLog转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultAmlGenFileLog) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultAmlGenFileLog(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QueryAmlGenFileContent转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QueryAmlGenFileContent) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QueryAmlGenFileContent(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultAmlGenFileContent转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultAmlGenFileContent) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultAmlGenFileContent(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_InvestorTradeSummary转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_InvestorTradeSummary) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_InvestorTradeSummary(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_InvestorRisk转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_InvestorRisk) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_InvestorRisk(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_InvestorFeeSort转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_InvestorFeeSort) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_InvestorFeeSort(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_InvestorMarginCall转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_InvestorMarginCall) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_InvestorMarginCall(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_VoInstrTradingRightTpl转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_VoInstrTradingRightTpl) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_VoInstrTradingRightTpl(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultInvestorTradeSumF转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultInvestorTradeSumF) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultInvestorTradeSumF(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultInvestorRiskSettleF转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultInvestorRiskSettleF) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultInvestorRiskSettleF(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultInvestorMarginCall转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultInvestorMarginCall) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultInvestorMarginCall(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultInvestorFeeSort转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultInvestorFeeSort) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultInvestorFeeSort(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultInvestorFundCollect转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultInvestorFundCollect) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultInvestorFundCollect(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_SettlementBill转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_SettlementBill) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_SettlementBill(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultSettlementBillFund转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultSettlementBillFund) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultSettlementBillFund(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultSettlementBillDeliv转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultSettlementBillDeliv) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultSettlementBillDeliv(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultSettlementBillMort转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultSettlementBillMort) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultSettlementBillMort(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultSettlementBillFundM转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultSettlementBillFundM) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultSettlementBillFundM(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultSettlementBillPosDtl转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultSettlementBillPosDtl) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultSettlementBillPosDtl(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultSettlementBillMIO转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultSettlementBillMIO) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultSettlementBillMIO(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultSettlementBillCloDtl转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultSettlementBillCloDtl) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultSettlementBillCloDtl(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultSettlementBillPos转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultSettlementBillPos) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultSettlementBillPos(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultSettlementBillStrike转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultSettlementBillStrike) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultSettlementBillStrike(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultSettlementBillTrade转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultSettlementBillTrade) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultSettlementBillTrade(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QryInvstrFundInfo转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QryInvstrFundInfo) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QryInvstrFundInfo(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_HisSettleFile转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_HisSettleFile) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_HisSettleFile(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QueryEventLog转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QueryEventLog) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QueryEventLog(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QueryAccount转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QueryAccount) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QueryAccount(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultAccount转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultAccount) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultAccount(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QuerySysOperateLog转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QuerySysOperateLog) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QuerySysOperateLog(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultSysOperateLog转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultSysOperateLog) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultSysOperateLog(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QryPositionInstrument转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QryPositionInstrument) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QryPositionInstrument(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QueryCurrencySwapApplyDora转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QueryCurrencySwapApplyDora) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QueryCurrencySwapApplyDora(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultAspSettlePosition转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultAspSettlePosition) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultAspSettlePosition(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultSettlementPrice转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultSettlementPrice) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultSettlementPrice(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultAspSettleCZCEComPos转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultAspSettleCZCEComPos) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultAspSettleCZCEComPos(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultAspSettleDCEComPos转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultAspSettleDCEComPos) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultAspSettleDCEComPos(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultInstrCurrExchMargin转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultInstrCurrExchMargin) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultInstrCurrExchMargin(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultOptCffexEMargin转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultOptCffexEMargin) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultOptCffexEMargin(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QueryCZCEClose转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QueryCZCEClose) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QueryCZCEClose(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultChkSHFESetBrokerTra转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultChkSHFESetBrokerTra) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultChkSHFESetBrokerTra(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultChkINESetBrokerTra转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultChkINESetBrokerTra) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultChkINESetBrokerTra(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultChkCFFEXSetBrokerTra转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultChkCFFEXSetBrokerTra) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultChkCFFEXSetBrokerTra(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultChkDCESetBrokerTra转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultChkDCESetBrokerTra) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultChkDCESetBrokerTra(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultChkCZCESetBrokerTra转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultChkCZCESetBrokerTra) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultChkCZCESetBrokerTra(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QueryFundEventLog转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QueryFundEventLog) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QueryFundEventLog(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultCZCEClose转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultCZCEClose) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultCZCEClose(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QueryInvestorFundStatement转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QueryInvestorFundStatement) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QueryInvestorFundStatement(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QueryInvestorPosition转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QueryInvestorPosition) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QueryInvestorPosition(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QueryInvestorClose转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QueryInvestorClose) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QueryInvestorClose(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QueryInvestorFundChange转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QueryInvestorFundChange) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QueryInvestorFundChange(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QryInvFundIODetail转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QryInvFundIODetail) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QryInvFundIODetail(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultInvFundIODetail转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultInvFundIODetail) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultInvFundIODetail(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QueryInvestorComplete转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QueryInvestorComplete) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QueryInvestorComplete(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QueryInvestorPosSUMmary转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QueryInvestorPosSUMmary) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QueryInvestorPosSUMmary(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QueryInvestorTrade转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QueryInvestorTrade) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QueryInvestorTrade(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QueryInvestorFundIODetail转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QueryInvestorFundIODetail) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QueryInvestorFundIODetail(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QueryInvestorFundDetail转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QueryInvestorFundDetail) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QueryInvestorFundDetail(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QueryInvestorFundSummary转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QueryInvestorFundSummary) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QueryInvestorFundSummary(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QueryInvestorMortgage转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QueryInvestorMortgage) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QueryInvestorMortgage(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QueryFBTTransfer转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QueryFBTTransfer) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QueryFBTTransfer(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QuerySubEntryFund转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QuerySubEntryFund) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QuerySubEntryFund(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QueryDelivery转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QueryDelivery) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QueryDelivery(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QueryForceClose转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QueryForceClose) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QueryForceClose(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultFCDtlAccount转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultFCDtlAccount) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultFCDtlAccount(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultForceCloseMd转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultForceCloseMd) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultForceCloseMd(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultFCDtlPosStatus转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultFCDtlPosStatus) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultFCDtlPosStatus(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultFCDtlOrdStatus转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultFCDtlOrdStatus) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultFCDtlOrdStatus(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QueryInvestorVolume转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QueryInvestorVolume) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QueryInvestorVolume(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QueryInvPositionComDtl转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QueryInvPositionComDtl) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QueryInvPositionComDtl(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QueryInvestorHedge转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QueryInvestorHedge) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QueryInvestorHedge(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QueryHedgeLimit转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QueryHedgeLimit) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QueryHedgeLimit(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QueryInvestorFundMortgage转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QueryInvestorFundMortgage) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QueryInvestorFundMortgage(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QueryInvestorS2H转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QueryInvestorS2H) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QueryInvestorS2H(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QueryExchangeFund转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QueryExchangeFund) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QueryExchangeFund(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QueryExchangeSettlement转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QueryExchangeSettlement) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QueryExchangeSettlement(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QueryExchangeClose转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QueryExchangeClose) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QueryExchangeClose(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QueryExchangePosition转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QueryExchangePosition) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QueryExchangePosition(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QueryExchSettlementDetail转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QueryExchSettlementDetail) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QueryExchSettlementDetail(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QueryExchFundIODetail转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QueryExchFundIODetail) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QueryExchFundIODetail(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QueryInvestorHISOrder转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QueryInvestorHISOrder) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QueryInvestorHISOrder(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QueryInvestorHISTrade转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QueryInvestorHISTrade) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QueryInvestorHISTrade(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QueryHisSettlementPrice转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QueryHisSettlementPrice) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QueryHisSettlementPrice(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QueryHisInvstFundChange转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QueryHisInvstFundChange) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QueryHisInvstFundChange(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QueryHisExchFundChange转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QueryHisExchFundChange) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QueryHisExchFundChange(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QryTmdbOptionSelfClose转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QryTmdbOptionSelfClose) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QryTmdbOptionSelfClose(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QryTmdbQuote转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QryTmdbQuote) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QryTmdbQuote(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QryHisTmdbQuote转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QryHisTmdbQuote) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QryHisTmdbQuote(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultTmdbQuote转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultTmdbQuote) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultTmdbQuote(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QryHisTmdbOptionSelfClose转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QryHisTmdbOptionSelfClose) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QryHisTmdbOptionSelfClose(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QryTmdbCombAction转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QryTmdbCombAction) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QryTmdbCombAction(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QryHisTmdbCombAction转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QryHisTmdbCombAction) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QryHisTmdbCombAction(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultInvstFundStatement转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultInvstFundStatement) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultInvstFundStatement(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultInvestorPosition转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultInvestorPosition) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultInvestorPosition(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultInvestorClose转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultInvestorClose) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultInvestorClose(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultInvestorFundChange转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultInvestorFundChange) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultInvestorFundChange(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultInvestorComplete转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultInvestorComplete) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultInvestorComplete(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultInvestorPosSummary转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultInvestorPosSummary) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultInvestorPosSummary(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultInvestorTrade转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultInvestorTrade) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultInvestorTrade(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultInvestorFundIODetail转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultInvestorFundIODetail) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultInvestorFundIODetail(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultInvestorFundDetail转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultInvestorFundDetail) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultInvestorFundDetail(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultInvestorFundSummary转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultInvestorFundSummary) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultInvestorFundSummary(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultInvestorMortgage转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultInvestorMortgage) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultInvestorMortgage(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultSubEntryFund转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultSubEntryFund) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultSubEntryFund(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultDelivery转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultDelivery) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultDelivery(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultForceClose转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultForceClose) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultForceClose(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultInvestorVolume转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultInvestorVolume) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultInvestorVolume(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultInvPositionComDtl转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultInvPositionComDtl) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultInvPositionComDtl(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultInvestorHedge转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultInvestorHedge) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultInvestorHedge(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultHedgeLimit转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultHedgeLimit) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultHedgeLimit(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultInvestorFundMortgage转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultInvestorFundMortgage) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultInvestorFundMortgage(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultCurrencySwapApply转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultCurrencySwapApply) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultCurrencySwapApply(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultInvestorS2H转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultInvestorS2H) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultInvestorS2H(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultExchangeFund转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultExchangeFund) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultExchangeFund(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultExchangeSettlement转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultExchangeSettlement) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultExchangeSettlement(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultExchangeClose转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultExchangeClose) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultExchangeClose(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultExchangePosition转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultExchangePosition) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultExchangePosition(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultExchSettlementDetail转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultExchSettlementDetail) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultExchSettlementDetail(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultExchFundIODetail转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultExchFundIODetail) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultExchFundIODetail(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultInvestorHisOrder转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultInvestorHisOrder) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultInvestorHisOrder(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultInvestorHisTrade转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultInvestorHisTrade) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultInvestorHisTrade(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultHisSettlementPrice转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultHisSettlementPrice) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultHisSettlementPrice(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_OptCffexEMarginCom转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_OptCffexEMarginCom) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_OptCffexEMarginCom(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_OptCffexIMarginCom转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_OptCffexIMarginCom) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_OptCffexIMarginCom(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultExchInstrumentInfo转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultExchInstrumentInfo) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultExchInstrumentInfo(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QueryCloudExApply转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QueryCloudExApply) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QueryCloudExApply(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultAccountInfoEx转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultAccountInfoEx) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultAccountInfoEx(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultHisInvstFundChange转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultHisInvstFundChange) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultHisInvstFundChange(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultHisExchFundChange转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultHisExchFundChange) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultHisExchFundChange(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultExchFutMarginRateEx转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultExchFutMarginRateEx) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultExchFutMarginRateEx(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultInvstFutMarginRateEx转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultInvstFutMarginRateEx) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultInvstFutMarginRateEx(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultChkProductLifeRule转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultChkProductLifeRule) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultChkProductLifeRule(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QuerySettlementFile转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QuerySettlementFile) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QuerySettlementFile(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultPositionInstrument转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultPositionInstrument) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultPositionInstrument(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QueryCffexExchangeRate转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QueryCffexExchangeRate) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QueryCffexExchangeRate(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QryInvstMarginModelTpl转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QryInvstMarginModelTpl) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QryInvstMarginModelTpl(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultInvstMarginModelTpl转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultInvstMarginModelTpl) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultInvstMarginModelTpl(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_InvestorSequence转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_InvestorSequence) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_InvestorSequence(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QueryInvestorStrike转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QueryInvestorStrike) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QueryInvestorStrike(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultInvestorStrike转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultInvestorStrike) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultInvestorStrike(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QueryComparedSPrice转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QueryComparedSPrice) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QueryComparedSPrice(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultComparedSPrice转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultComparedSPrice) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultComparedSPrice(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_RstChkCffexExchangeRate转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_RstChkCffexExchangeRate) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_RstChkCffexExchangeRate(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QueryCloudBranchMap转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QueryCloudBranchMap) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QueryCloudBranchMap(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QueryCheckHisLatest转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QueryCheckHisLatest) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QueryCheckHisLatest(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_InvstFutMarginRateDay转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_InvstFutMarginRateDay) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_InvstFutMarginRateDay(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QueryCRAPBLPerson转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QueryCRAPBLPerson) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QueryCRAPBLPerson(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultCRAPBLPerson转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultCRAPBLPerson) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultCRAPBLPerson(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QueryCRAABLPerson转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QueryCRAABLPerson) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QueryCRAABLPerson(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultCRAABLPerson转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultCRAABLPerson) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultCRAABLPerson(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_RecogCRABLPerson转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_RecogCRABLPerson) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_RecogCRABLPerson(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_UpdateCRAPBLPerson转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_UpdateCRAPBLPerson) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_UpdateCRAPBLPerson(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_UpdateCRAABLPerson转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_UpdateCRAABLPerson) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_UpdateCRAABLPerson(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultCRARiskWeight转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultCRARiskWeight) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultCRARiskWeight(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QueryCRARiskWeight转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QueryCRARiskWeight) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QueryCRARiskWeight(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultCRARiskDetail转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultCRARiskDetail) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultCRARiskDetail(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QueryCRARiskDetail转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QueryCRARiskDetail) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QueryCRARiskDetail(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultCRARiskIndexOption转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultCRARiskIndexOption) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultCRARiskIndexOption(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QueryCRARiskIndexOption转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QueryCRARiskIndexOption) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QueryCRARiskIndexOption(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultCRAInvestorRisk转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultCRAInvestorRisk) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultCRAInvestorRisk(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QueryCRAInvestorRisk转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QueryCRAInvestorRisk) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QueryCRAInvestorRisk(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultCRAManualRating转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultCRAManualRating) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultCRAManualRating(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QueryCRAManualRating转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QueryCRAManualRating) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QueryCRAManualRating(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QueryCRACheckHis转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QueryCRACheckHis) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QueryCRACheckHis(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QueryRiskTBCommand转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QueryRiskTBCommand) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QueryRiskTBCommand(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultRiskTBCommand转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultRiskTBCommand) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultRiskTBCommand(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_InvstOptMarginRateULEx转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_InvstOptMarginRateULEx) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_InvstOptMarginRateULEx(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QueryCRADistribute转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QueryCRADistribute) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QueryCRADistribute(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QueryCRADistributeEx转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QueryCRADistributeEx) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QueryCRADistributeEx(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CRAScoreDistribute转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CRAScoreDistribute) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CRAScoreDistribute(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CRALevelDistribute转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CRALevelDistribute) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CRALevelDistribute(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CRAIndexDistribute转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CRAIndexDistribute) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CRAIndexDistribute(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QueryHisInvestorExecOrder转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QueryHisInvestorExecOrder) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QueryHisInvestorExecOrder(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultHisInvestorExecOrder转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultHisInvestorExecOrder) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultHisInvestorExecOrder(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QueryCurrencySwapFund转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QueryCurrencySwapFund) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QueryCurrencySwapFund(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultCurrencySwapFund转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultCurrencySwapFund) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultCurrencySwapFund(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QuerySettleFileInvestor转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QuerySettleFileInvestor) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QuerySettleFileInvestor(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QueryInvestorProperty转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QueryInvestorProperty) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QueryInvestorProperty(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QuerySpecPartFund转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QuerySpecPartFund) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QuerySpecPartFund(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QryInvstOptMarginRateUL转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QryInvstOptMarginRateUL) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QryInvstOptMarginRateUL(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultInvestMarginRateUL转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultInvestMarginRateUL) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultInvestMarginRateUL(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultAnswerMaxScore转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultAnswerMaxScore) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultAnswerMaxScore(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QueryInvestorInterest转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QueryInvestorInterest) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QueryInvestorInterest(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultInvestorInterestdtl转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultInvestorInterestdtl) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultInvestorInterestdtl(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultInvestorInterest转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultInvestorInterest) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultInvestorInterest(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultChkCurrShfeOpExchMar转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultChkCurrShfeOpExchMar) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultChkCurrShfeOpExchMar(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultChkCffexExchangeRate转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultChkCffexExchangeRate) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultChkCffexExchangeRate(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultNonMaxMarginInstrume转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultNonMaxMarginInstrume) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultNonMaxMarginInstrume(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QryNonMaxMarginInstrument转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QryNonMaxMarginInstrument) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QryNonMaxMarginInstrument(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QUERYCFFEXINVPOSCOMDTL转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QUERYCFFEXINVPOSCOMDTL) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QUERYCFFEXINVPOSCOMDTL(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultCFFEXINVPOSCOMDTL转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultCFFEXINVPOSCOMDTL) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultCFFEXINVPOSCOMDTL(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QueryInvsProprietyInfo转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QueryInvsProprietyInfo) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QueryInvsProprietyInfo(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultRiskEvaluationLog转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultRiskEvaluationLog) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultRiskEvaluationLog(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QryInvMultiTradingRight转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QryInvMultiTradingRight) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QryInvMultiTradingRight(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultInvMultiTradRight转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultInvMultiTradRight) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultInvMultiTradRight(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_DetailInvMultiTradingRight转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_DetailInvMultiTradingRight) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_DetailInvMultiTradingRight(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QueryO_MutiTradingRight转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QueryO_MutiTradingRight) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QueryO_MutiTradingRight(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultTradingRight转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultTradingRight) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultTradingRight(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_TradingRightPreview转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_TradingRightPreview) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_TradingRightPreview(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_GeneralTradingRight转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_GeneralTradingRight) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_GeneralTradingRight(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_SpecTradingRight转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_SpecTradingRight) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_SpecTradingRight(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultCFFEXOTCPartBrokerRe转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultCFFEXOTCPartBrokerRe) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultCFFEXOTCPartBrokerRe(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QuerySpecTRApply转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QuerySpecTRApply) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QuerySpecTRApply(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_TradingRightCopyByProduct转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_TradingRightCopyByProduct) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_TradingRightCopyByProduct(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QryBankAccount转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QryBankAccount) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QryBankAccount(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultBankAccount转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultBankAccount) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultBankAccount(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QrySmsCode转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QrySmsCode) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QrySmsCode(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QryInvProprietyInfoNew转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QryInvProprietyInfoNew) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QryInvProprietyInfoNew(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResInvProprietyInfoNew转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResInvProprietyInfoNew) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResInvProprietyInfoNew(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResInvProprietyInfoHis转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResInvProprietyInfoHis) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResInvProprietyInfoHis(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultDBVersion转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultDBVersion) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultDBVersion(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultSettleLog转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultSettleLog) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultSettleLog(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QryValidateCust转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QryValidateCust) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QryValidateCust(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CheckInvestor转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CheckInvestor) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CheckInvestor(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResOpFavor转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResOpFavor) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResOpFavor(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QryBillFormat转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QryBillFormat) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QryBillFormat(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QueryInvstInfoChg转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QueryInvstInfoChg) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QueryInvstInfoChg(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultInvstInfoChg转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultInvstInfoChg) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultInvstInfoChg(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QryClientName转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QryClientName) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QryClientName(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultClientName转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultClientName) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultClientName(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QryPreCalStrikeFee转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QryPreCalStrikeFee) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QryPreCalStrikeFee(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultPreCalStrikeFee转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultPreCalStrikeFee) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultPreCalStrikeFee(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ErrorInfo转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ErrorInfo) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ErrorInfo(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QryFloatCommRate转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QryFloatCommRate) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QryFloatCommRate(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultFloatCommRate转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultFloatCommRate) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultFloatCommRate(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_RstInvestorFundChange转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_RstInvestorFundChange) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_RstInvestorFundChange(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_RstTradingRightSnapshot转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_RstTradingRightSnapshot) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_RstTradingRightSnapshot(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultO_InvMortgage转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultO_InvMortgage) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultO_InvMortgage(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultInvMortgage转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultInvMortgage) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultInvMortgage(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ResultInvstWillDelivFee转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ResultInvstWillDelivFee) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ResultInvstWillDelivFee(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CurrInvstBaseMargin转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CurrInvstBaseMargin) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CurrInvstBaseMargin(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QueryBackSettleData转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QueryBackSettleData) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QueryBackSettleData(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_RstFloatInvstFutComChk转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_RstFloatInvstFutComChk) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_RstFloatInvstFutComChk(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_RstFloatInvstOptComChk转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_RstFloatInvstOptComChk) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_RstFloatInvstOptComChk(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_SettleProductGroupResult转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_SettleProductGroupResult) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_SettleProductGroupResult(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_SettleProductGroupMode转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_SettleProductGroupMode) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_SettleProductGroupMode(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QryRiskProductFrozenRatio转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QryRiskProductFrozenRatio) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QryRiskProductFrozenRatio(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_RstProductGroupRelation转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_RstProductGroupRelation) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_RstProductGroupRelation(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ProductSettleInfo转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ProductSettleInfo) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ProductSettleInfo(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QryCAPInfo转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QryCAPInfo) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QryCAPInfo(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CAPInvstBasicInfo转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CAPInvstBasicInfo) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CAPInvstBasicInfo(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CAPAccount转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CAPAccount) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CAPAccount(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CAPInvstLoginAccount转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CAPInvstLoginAccount) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CAPInvstLoginAccount(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CAPInvstBankAccount转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CAPInvstBankAccount) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CAPInvstBankAccount(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CAPInvstLinkman转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CAPInvstLinkman) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CAPInvstLinkman(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CAPInvstAmAccount转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CAPInvstAmAccount) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CAPInvstAmAccount(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CAPInvstAmCustodyAcc转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CAPInvstAmCustodyAcc) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CAPInvstAmCustodyAcc(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CAPAmTrusteeAccount转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CAPAmTrusteeAccount) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CAPAmTrusteeAccount(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CAPAmTransferAccount转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CAPAmTransferAccount) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CAPAmTransferAccount(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CAPTradingCode转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CAPTradingCode) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CAPTradingCode(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CAPInvestUnit转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CAPInvestUnit) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CAPInvestUnit(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CAPDepartment转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CAPDepartment) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CAPDepartment(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CAPInvstDepartment转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CAPInvstDepartment) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CAPInvstDepartment(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CAPProperty转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CAPProperty) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CAPProperty(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CAPInvstPropertyMap转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CAPInvstPropertyMap) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CAPInvstPropertyMap(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CAPIdentifiedCard转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CAPIdentifiedCard) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CAPIdentifiedCard(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CAPInvstActiveStatus转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CAPInvstActiveStatus) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CAPInvstActiveStatus(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CAPInvstStandardStatus转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CAPInvstStandardStatus) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CAPInvstStandardStatus(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CAPInvstFreezeStatus转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CAPInvstFreezeStatus) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CAPInvstFreezeStatus(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CAPBatchFreezeCondition转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CAPBatchFreezeCondition) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CAPBatchFreezeCondition(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CAPAccCancelCondition转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CAPAccCancelCondition) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CAPAccCancelCondition(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CAPInvstCancelChkCondition转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CAPInvstCancelChkCondition) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CAPInvstCancelChkCondition(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CAPInvstFreezeChkCondition转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CAPInvstFreezeChkCondition) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CAPInvstFreezeChkCondition(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CAPInvstCancelChkResult转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CAPInvstCancelChkResult) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CAPInvstCancelChkResult(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CAPAccCancelChkCondition转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CAPAccCancelChkCondition) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CAPAccCancelChkCondition(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CAPAppTradCodeCondition转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CAPAppTradCodeCondition) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CAPAppTradCodeCondition(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CAPBankRelationCondition转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CAPBankRelationCondition) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CAPBankRelationCondition(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CAPTraCancelChkCondition转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CAPTraCancelChkCondition) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CAPTraCancelChkCondition(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CAPAccCancelChkResult转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CAPAccCancelChkResult) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CAPAccCancelChkResult(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CAPInvstFreezeChkResult转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CAPInvstFreezeChkResult) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CAPInvstFreezeChkResult(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CAPBankRelationResult转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CAPBankRelationResult) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CAPBankRelationResult(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CAPInvstToFreezeResult转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CAPInvstToFreezeResult) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CAPInvstToFreezeResult(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CAPAppTradingCodeResult转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CAPAppTradingCodeResult) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CAPAppTradingCodeResult(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CAPTraCancelChkResult转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CAPTraCancelChkResult) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CAPTraCancelChkResult(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;


-- *** END PUMP GENERATED PACKAGE BODY *** --

END PKGS_Tyt2STRINGEX;
/

