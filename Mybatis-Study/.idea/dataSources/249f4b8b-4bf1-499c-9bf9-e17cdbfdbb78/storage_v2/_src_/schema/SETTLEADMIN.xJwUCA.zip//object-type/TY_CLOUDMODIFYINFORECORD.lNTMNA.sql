create TYPE Ty_CloudModifyInfoRecord AS OBJECT
(
    SequenceNo NUMBER(12),  --序号
    BrokerID CHAR(10),  --经纪公司代码
    ProcessID CHAR(32),  --业务流水号
    ProcessType CHAR(2),  --流程功能类型
    InvestorID CHAR(12),  --投资者代码
    InvestorName VARCHAR2(80),  --投资者名称
    IdentifiedCardNo CHAR(50),  --证件号码
    IdentifiedCardType CHAR(1),  --证件类型
    CompanyID CHAR(10),  --期货公司统一编码
    OperatorID CHAR(64),  --操作员代码
    OperateDate CHAR(8),  --操作日期
    OperateTime CHAR(8),  --操作时间

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_CloudModifyInfoRecord RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

