create TYPE BODY Ty_CFFEXDelivery IS

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_CFFEXDelivery RETURN SELF AS RESULT IS
  BEGIN
    RETURN;
  END;

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2 IS
    l_string VARCHAR2(4000);
  BEGIN
    l_string:='ty_CFFEXDelivery('
      || 'TradingDay=>' || '''' || trim(TradingDay) || '''' --交易日
      || ',ExchangeID=>' || '''' || trim(ExchangeID) || '''' --交易所代码
      || ',ParticipantID=>' || '''' || trim(ParticipantID) || '''' --会员代码
      || ',ExchangeInstID=>' || '''' || trim(ExchangeInstID) || '''' --合约代码
      || ',SettlePartID=>' || '''' || trim(SettlePartID) || '''' --结算会员号
      || ',AccountID=>' || '''' || trim(AccountID) || '''' --资金账号
      || ',CurrencyID=>' || '''' || trim(CurrencyID) || '''' --资金账号币种
      || ',SettlePartAbbr=>' || '''' || trim(SettlePartAbbr) || '''' --结算会员简称
      || ',Property=>' || '''' || trim(Property) || '''' --属性
      || ',SettlementPrice=>' || NVL(to_char(SettlementPrice),'NULL')--交割结算价
      || ',BuyAmt=>' || NVL(to_char(BuyAmt),'NULL')--买入量
      || ',SellAmt=>' || NVL(to_char(SellAmt),'NULL')--卖出量
      || ',TransFee=>' || NVL(to_char(TransFee),'NULL')--交割手续费
      || ')';


    RETURN l_string;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN NULL;
  END;



END;
/

