create TYPE Ty_CSRC_OtherFund AS OBJECT
(
    TradingDay CHAR(10),  --交易日
    ParticipantID CHAR(10),  --会员代码
    InvestorID CHAR(12),  --客户内部资金账户
    ExchangeFlag CHAR(1),  --交易所统一标识
    FundProjectID CHAR(4),  --资金项目编号
    Deposit NUMBER(15,3),  --资金金额
    Memo CHAR(100),  --备注
    ClientID CHAR(10),  --客户编码
    IsSettlement CHAR(1),  --是否为非结算会员
    CurrencyID CHAR(3),  --币种

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_CSRC_OtherFund RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

