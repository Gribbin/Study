create TYPE BODY Ty_ChkInvestorPosOUT IS

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_ChkInvestorPosOUT RETURN SELF AS RESULT IS
  BEGIN
    RETURN;
  END;

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2 IS
    l_string VARCHAR2(4000);
  BEGIN
    l_string:='ty_ChkInvestorPosOUT('
      || 'BrokerID=>' || '''' || trim(BrokerID) || '''' --经纪公司代码
      || ',ExchangeID=>' || '''' || trim(ExchangeID) || '''' --交易所代码
      || ',InvestorID=>' || '''' || trim(InvestorID) || '''' --投资者代码
      || ',InstrumentID=>' || '''' || trim(InstrumentID) || '''' --合约代码
      || ',Actual=>' || NVL(to_char(Actual),'NULL')--当日盈亏
      || ',ExchTransFee=>' || NVL(to_char(ExchTransFee),'NULL')--交易所交易手续费
      || ',ExchSettlementFee=>' || NVL(to_char(ExchSettlementFee),'NULL')--交易所结算手续费
      || ',ExchDelivFee=>' || NVL(to_char(ExchDelivFee),'NULL')--交易所交割手续费
      || ',ExchTransferPosFee=>' || NVL(to_char(ExchTransferPosFee),'NULL')--交易所移仓手续费
      || ')';


    RETURN l_string;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN NULL;
  END;



END;
/

