create TYPE Ty_CSRC_DelivContractData AS OBJECT
(
    TradingDay CHAR(10),  --交易日
    ParticipantID CHAR(10),  --会员代码
    InvestorID CHAR(12),  --客户内部资金账户
    ExchangeInstID CHAR(30),  --品种合约
    TradeID CHAR(20),  --成交流水号
    Direction CHAR(1),  --买卖标志
    Volume NUMBER(20),  --待交割持仓量
    DelivMargin NUMBER(15,3),  --交割保证金
    Price NUMBER(15,3),  --开仓价
    DeliveryPrice NUMBER(15,3),  --交割结算价
    ClientID CHAR(10),  --交易编码
    ExchangeFlag CHAR(1),  --交易所统一标识
    IsSettlement CHAR(1),  --是否为非结算会员
    CurrencyID CHAR(3),  --币种

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_CSRC_DelivContractData RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

