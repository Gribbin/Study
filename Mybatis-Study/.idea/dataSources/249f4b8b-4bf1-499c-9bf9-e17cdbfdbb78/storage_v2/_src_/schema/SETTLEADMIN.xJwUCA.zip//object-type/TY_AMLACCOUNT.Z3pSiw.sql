create TYPE Ty_AmlAccount AS OBJECT
(
    BrokerID CHAR(10),  --经纪公司代码
    InvestorID CHAR(12),  --投资者代码
    AccountID CHAR(14),  --资金账号代码
    CurrencyID CHAR(3),  --币种
    Password CHAR(40),  --密码
    IsActive NUMBER(1),  --是否活跃

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_AmlAccount RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

