create TYPE Ty_Company AS OBJECT
(
    BrokerID CHAR(10),  --经纪公司代码
    InvestorID CHAR(12),  --投资者代码
    TaxNo VARCHAR2(30),  --税务登记号
    TaxNoStart CHAR(8),  --税务登记号有效期（起）
    TaxNoEnd CHAR(8),  --税务登记号有效期（止）
    Corporation VARCHAR2(100),  --法人代表
    Linkman VARCHAR2(100),  --联系人
    LinkmanIdType CHAR(1),  --法人代表证件类型
    LinkmanIdNo CHAR(50),  --法人代表证件号码
    LinkmanNoStart CHAR(8),  --营业执照有效期（起）
    LinkmanNoEnd CHAR(8),  --证营业执照有效期（止）
    LicenseNo CHAR(32),  --统一社会信用代码
    LicenseNoStart CHAR(8),  --营业执照有效期（起）
    LicenseNoEnd CHAR(8),  --证营业执照有效期（止）
    CompanyType CHAR(15),  --企业性质
    Capital NUMBER(21,6),  --注册资本
    CapitalCurrency CHAR(3),  --注册资本货币
    WebSite VARCHAR2(100),  --网址
    HasBoard CHAR(1),  --是否有董事会
    BusinessPeriod VARCHAR2(20),  --经营期限
    InvestorNameEng VARCHAR2(100),  --投资者英文名称
    CorporateIdentifiedCardType CHAR(1),  --法人代表证件类型
    CorporateIdentifiedCardNo CHAR(50),  --法人代表证件号码
    CorporateNoStart CHAR(8),  --法人代表证件有效期（起）
    CorporateNoEnd CHAR(8),  --法人代表证件有效期（止）
    CorporatePhoneCountryCode CHAR(10),  --法人代表国家代码
    CorporatePhoneAreaCode CHAR(10),  --法人代表区号
    CorporateTelephone CHAR(40),  --法人代表联系电话
    CorporateCountry CHAR(15),  --法人代表身份归属国家或地区
    CorporateProvince CHAR(50),  --法人代表所在省
    CorporateCity CHAR(50),  --法人代表所在市
    CorporateAddress CHAR(100),  --法人代表所在地
    CorporateBirthDay CHAR(8),  --法人代表出生日期
    CorporateZipCode CHAR(10),  --法人代表邮政编码
    CorporateNational CHAR(30),  --法人代表身份归属国家/地区
    CorporateNationalProvince CHAR(50),  --法人代表所在省
    CorporateNationalCity CHAR(50),  --法人代表所在市
    CorporateSex CHAR(1),  --法人代表性别
    InstitutionExtraCode CHAR(50),  --附加码
    RegistryCountry CHAR(15),  --注册国家
    RegistryProvince CHAR(50),  --注册省州
    RegistryCity CHAR(50),  --注册城市
    RegistryAddress CHAR(100),  --注册地址

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_Company RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

