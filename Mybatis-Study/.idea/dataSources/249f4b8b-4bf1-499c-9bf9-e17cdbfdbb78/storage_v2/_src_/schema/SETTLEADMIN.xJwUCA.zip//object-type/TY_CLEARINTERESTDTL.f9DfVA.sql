create TYPE Ty_ClearInterestDtl AS OBJECT
(
    BrokerID CHAR(10),  --经纪公司代码
    ClearIntNo NUMBER(14),  --结息操作编号
    AccountID CHAR(14),  --资金账号
    CurrencyID CHAR(3),  --资金账号币种
    InvestorID CHAR(12),  --投资者代码
    BeginDate CHAR(8),  --开始日期
    EndDate CHAR(8),  --结束日期
    InterestRate NUMBER(19,8),  --利率
    DepositSum NUMBER(22,6),  --计息积数
    InterestSum NUMBER(22,6),  --利息金额
    AdjustInterest NUMBER(22,6),  --利息调整

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_ClearInterestDtl RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

