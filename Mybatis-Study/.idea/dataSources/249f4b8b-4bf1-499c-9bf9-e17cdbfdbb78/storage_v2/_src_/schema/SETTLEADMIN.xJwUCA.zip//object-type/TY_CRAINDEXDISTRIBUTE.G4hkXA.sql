create TYPE Ty_CRAIndexDistribute AS OBJECT
(
    RiskIndexID NUMBER(8),  --风险指标ID
    RiskIndexOptionID NUMBER(8),  --风险指标选项ID
    RiskIndexOptionName VARCHAR2(50),  --名称
    IndexDisNumber NUMBER(20),  --风险等级客户人数

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_CRAIndexDistribute RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

