create TYPE BODY Ty_CFFEXCltPosTransfer IS

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_CFFEXCltPosTransfer RETURN SELF AS RESULT IS
  BEGIN
    RETURN;
  END;

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2 IS
    l_string VARCHAR2(4000);
  BEGIN
    l_string:='ty_CFFEXCltPosTransfer('
      || 'TradingDay=>' || '''' || trim(TradingDay) || '''' --交易日
      || ',ExchangeID=>' || '''' || trim(ExchangeID) || '''' --交易所代码
      || ',ParticipantID=>' || '''' || trim(ParticipantID) || '''' --会员代码
      || ',ClientID=>' || '''' || trim(ClientID) || '''' --投资者号
      || ',ExchangeInstID=>' || '''' || trim(ExchangeInstID) || '''' --合约代码
      || ',BTransferPosAmt=>' || NVL(to_char(BTransferPosAmt),'NULL')--多头移仓量
      || ',STransferPosAmt=>' || NVL(to_char(STransferPosAmt),'NULL')--空头移仓量
      || ',MarginChange=>' || NVL(to_char(MarginChange),'NULL')--保证金变化
      || ',TransferOutPartID=>' || '''' || trim(TransferOutPartID) || '''' --移出期货公司
      || ',TransferOutSettlePartID=>' || '''' || trim(TransferOutSettlePartID) || '''' --移出期货公司所属结算会员
      || ',TransferInPartID=>' || '''' || trim(TransferInPartID) || '''' --移入期货公司
      || ',TransferInSettlePartID=>' || '''' || trim(TransferInSettlePartID) || '''' --移入期货公司所属结算会员
      || ')';


    RETURN l_string;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN NULL;
  END;



END;
/

