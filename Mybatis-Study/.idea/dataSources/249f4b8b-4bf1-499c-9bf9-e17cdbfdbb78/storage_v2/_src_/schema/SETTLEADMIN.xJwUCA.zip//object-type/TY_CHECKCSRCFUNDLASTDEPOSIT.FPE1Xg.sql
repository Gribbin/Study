create TYPE Ty_CheckCSRCFundLastDeposit AS OBJECT
(
    IsSame NUMBER(1),  --是否相同
    TradingDay CHAR(8),  --交易日
    InvestorID CHAR(12),  --投资者编码
    InvestorName VARCHAR2(80),  --投资者名称
    CurrencyID CHAR(3),  --币种
    lastdepositbydate1 NUMBER(22,6),  --本日日初权益（逐日盯市）
    lastdepositbyvolume1 NUMBER(22,6),  --本日日初权益（逐笔对冲）
    lastdepositbydate2 NUMBER(22,6),  --上日日终权益（逐日盯市）
    lastdepositbyvolume2 NUMBER(22,6),  --上日日终权益（逐笔对冲）

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_CheckCSRCFundLastDeposit RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

