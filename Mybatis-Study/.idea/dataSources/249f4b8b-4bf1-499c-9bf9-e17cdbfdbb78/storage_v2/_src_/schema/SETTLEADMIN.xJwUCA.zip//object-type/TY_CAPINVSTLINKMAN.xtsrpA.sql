create TYPE Ty_CAPInvstLinkman AS OBJECT
(
    BrokerID CHAR(10),  --经纪公司代码
    InvestorID CHAR(12),  --投资者代码
    InvestUnitID CHAR(16),  --投资单元代码
    PersonType CHAR(1),  --联系人类型
    PersonCardType CHAR(1),  --证件类型
    PersonCardNo CHAR(50),  --证件号码
    PersonName VARCHAR2(100),  --名称
    PersonTelephone CHAR(40),  --联系电话
    PersonAddress CHAR(100),  --通讯地址
    PersonZipCode CHAR(10),  --邮政编码
    PersonSex CHAR(1),  --性别
    PersonNational CHAR(30),  --身份归属国家/地区
    PhoneCountryCode CHAR(10),  --国家代码
    PhoneAreaCode CHAR(10),  --区号
    Country CHAR(15),  --联系地址国家或地区
    Province CHAR(50),  --联系地址省
    City CHAR(50),  --联系地址市
    IsMain NUMBER(1),  --是否报送联系人

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_CAPInvstLinkman RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

