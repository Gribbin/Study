create TYPE BODY Ty_AmlInvestor IS

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_AmlInvestor RETURN SELF AS RESULT IS
  BEGIN
    RETURN;
  END;

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2 IS
    l_string VARCHAR2(4000);
  BEGIN
    l_string:='ty_AmlInvestor('
      || 'BrokerID=>' || '''' || trim(BrokerID) || '''' --经纪公司代码
      || ',InvestorID=>' || '''' || trim(InvestorID) || '''' --投资者代码
      || ',InvestorName=>' || '''' || trim(InvestorName) || '''' --投资者名称
      || ',InvestorType=>' || '''' || trim(InvestorType) || '''' --投资者类型
      || ',DepartmentID=>' || '''' || trim(DepartmentID) || '''' --组织架构代码
      || ',InvestorFlag=>' || '''' || trim(InvestorFlag) || '''' --投资者状态
      || ',OpenDate=>' || '''' || trim(OpenDate) || '''' --开户日期
      || ',CancelDate=>' || '''' || trim(CancelDate) || '''' --销户日期
      || ',ClientRegion=>' || '''' || trim(ClientRegion) || '''' --开户客户地域
      || ',ClientMode=>' || '''' || trim(ClientMode) || '''' --开户模式
      || ',AssetmgrClientType=>' || '''' || trim(AssetmgrClientType) || '''' --资产户客户类型
      || ',RiskLevel=>' || NVL(to_char(RiskLevel),'NULL')--风险等级
      || ',ContractCode=>' || '''' || trim(ContractCode) || '''' --合同编号
      || ',IsActive=>' || '''' || trim(IsActive) || '''' --是否活跃
      || ',InvestorFullName=>' || '''' || trim(InvestorFullName) || '''' --投资者全称
      || ',Telephone=>' || '''' || trim(Telephone) || '''' --联系电话
      || ',PhoneCountryCode=>' || '''' || trim(PhoneCountryCode) || '''' --国家代码
      || ',PhoneAreaCode=>' || '''' || trim(PhoneAreaCode) || '''' --区号
      || ',FaxCountryCode=>' || '''' || trim(FaxCountryCode) || '''' --传真国家代码
      || ',FaxAreaCode=>' || '''' || trim(FaxAreaCode) || '''' --传真区号
      || ',Fax=>' || '''' || trim(Fax) || '''' --传真
      || ',Mobile=>' || '''' || trim(Mobile) || '''' --移动电话
      || ',ZipCode=>' || '''' || trim(ZipCode) || '''' --邮政编码
      || ',EMail=>' || '''' || trim(EMail) || '''' --电子邮件
      || ',IdentifiedCardType=>' || '''' || trim(IdentifiedCardType) || '''' --证件类型
      || ',IdentifiedCardNo=>' || '''' || trim(IdentifiedCardNo) || '''' --证件号码
      || ',IdCardValidityStart=>' || '''' || trim(IdCardValidityStart) || '''' --证件有效期（起）
      || ',IdCardValidityEnd=>' || '''' || trim(IdCardValidityEnd) || '''' --证件有效期（止）
      || ',Classify=>' || '''' || trim(Classify) || '''' --客户分类码
      || ',Nationality=>' || '''' || trim(Nationality) || '''' --国籍国家
      || ',NationalityProvince=>' || '''' || trim(NationalityProvince) || '''' --国籍省州
      || ',NationalityCity=>' || '''' || trim(NationalityCity) || '''' --国籍城市
      || ',Country=>' || '''' || trim(Country) || '''' --联系地址中的国家
      || ',Province=>' || '''' || trim(Province) || '''' --联系地址中的省州
      || ',City=>' || '''' || trim(City) || '''' --联系地址中的城市
      || ',Region=>' || '''' || trim(Region) || '''' --区
      || ',Address=>' || '''' || trim(Address) || '''' --联系地址
      || ',AppropriaType=>' || '''' || trim(AppropriaType) || '''' --客户适当性分类
      || ',Corporation=>' || '''' || trim(Corporation) || '''' --法人代表
      || ',Capital=>' || NVL(to_char(Capital),'NULL')--注册资本
      || ',CapitalCurrency=>' || '''' || trim(CapitalCurrency) || '''' --注册资本货币
      || ',RegistryCountry=>' || '''' || trim(RegistryCountry) || '''' --注册国家
      || ',RegistryProvince=>' || '''' || trim(RegistryProvince) || '''' --注册省州
      || ',RegistryCity=>' || '''' || trim(RegistryCity) || '''' --注册城市
      || ',FreezeStatus=>' || '''' || trim(FreezeStatus) || '''' --休眠状态
      || ',Memo=>' || '''' || trim(Memo) || '''' --备注
      || ')';


    RETURN l_string;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN NULL;
  END;



END;
/

