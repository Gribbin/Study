create TYPE BODY Ty_AmlCheckNiSsReport IS

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_AmlCheckNiSsReport RETURN SELF AS RESULT IS
  BEGIN
    RETURN;
  END;

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2 IS
    l_string VARCHAR2(4000);
  BEGIN
    l_string:='ty_AmlCheckNiSsReport('
      || 'TradingDay=>' || '''' || trim(TradingDay) || '''' --交易日期
      || ',ApplyNo=>' || NVL(to_char(ApplyNo),'NULL')--流水号
      || ',FlowID=>' || '''' || trim(FlowID) || '''' --流程ID
      || ',ApplyOperate=>' || '''' || trim(ApplyOperate) || '''' --触发流程操作
      || ',AMLCheckStatus=>' || '''' || trim(AMLCheckStatus) || '''' --审核状态
      || ',BrokerID=>' || '''' || trim(BrokerID) || '''' --经纪公司代码
      || ',ReportSeqNo=>' || '''' || trim(ReportSeqNo) || '''' --报告序号
      || ',Action=>' || '''' || trim(Action) || '''' --报告类别-新增或修改
      || ',ReportName=>' || '''' || trim(ReportName) || '''' --报文名称
      || ',FilePath=>' || '''' || trim(FilePath) || '''' --报告文件存放路径
      || ',GenDate=>' || '''' || trim(GenDate) || '''' --生成日期
      || ',RICD=>' || '''' || trim(RICD) || '''' --报告机构编码
      || ',RPNC=>' || '''' || trim(RPNC) || '''' --上报网点代码
      || ',DETR=>' || '''' || trim(DETR) || '''' --可疑交易报告紧急程度
      || ',TORP=>' || '''' || trim(TORP) || '''' --报送次数标志
      || ',ORXN=>' || '''' || trim(ORXN) || '''' --初次报送的可疑交易报告报文名称
      || ',DORP=>' || '''' || trim(DORP) || '''' --报送方向
      || ',ODRP=>' || '''' || trim(ODRP) || '''' --其他报送方向
      || ',TPTR=>' || '''' || trim(TPTR) || '''' --可疑交易报告触发点
      || ',OTPR=>' || '''' || trim(OTPR) || '''' --其他可疑交易报告触发点
      || ',STCB=>' || '''' || trim(STCB) || '''' --资金交易及客户行为情况
      || ',AOSP=>' || '''' || trim(AOSP) || '''' --疑点分析
      || ',TOSC=>' || '''' || trim(TOSC) || '''' --涉罪类型
      || ',STCR=>' || '''' || trim(STCR) || '''' --可疑交易特征代码
      || ',SETN=>' || '''' || trim(SETN) || '''' --可疑主体总数
      || ',STNM=>' || '''' || trim(STNM) || '''' --可疑交易总数
      || ',RPNM=>' || '''' || trim(RPNM) || '''' --可疑交易报告的填报人员
      || ',MIRS=>' || '''' || trim(MIRS) || '''' --人工补正标志
      || ',AttachFileOne=>' || '''' || trim(AttachFileOne) || '''' --附件
      || ',AttachFileTwo=>' || '''' || trim(AttachFileTwo) || '''' --附件
      || ',AttachFileThree=>' || '''' || trim(AttachFileThree) || '''' --附件
      || ',AttachFileFour=>' || '''' || trim(AttachFileFour) || '''' --附件
      || ',AttachFileFive=>' || '''' || trim(AttachFileFive) || '''' --附件
      || ',AttachFileSix=>' || '''' || trim(AttachFileSix) || '''' --附件
      || ',AttachFileSeven=>' || '''' || trim(AttachFileSeven) || '''' --附件
      || ',AttachFileEight=>' || '''' || trim(AttachFileEight) || '''' --附件
      || ')';


    RETURN l_string;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN NULL;
  END;



END;
/

