create TYPE Ty_AMLXMLReport AS OBJECT
(
    BrokerID CHAR(10),  --经纪公司代码
    AMLGenSeqID NUMBER(8),  --文件生成事件序列号
    XMLNumber NUMBER(4),  --XML编号
    InvestorID CHAR(12),  --投资者代码

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_AMLXMLReport RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

