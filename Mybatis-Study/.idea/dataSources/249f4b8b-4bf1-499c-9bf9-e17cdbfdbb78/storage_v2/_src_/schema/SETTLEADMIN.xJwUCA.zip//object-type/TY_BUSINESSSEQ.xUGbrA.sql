create TYPE Ty_BusinessSeq AS OBJECT
(
    BrokerID CHAR(10),  --经纪公司代码
    BusinessType CHAR(60),  --业务类型
    BusinessTypeName CHAR(80),  --业务类型名称
    CurrentSeqNo NUMBER(20),  --当前序列号
    MinSeqNo NUMBER(20),  --最小序列号
    MaxSeqNo NUMBER(20),  --最大序列号
    IsRefreshByDate NUMBER(1),  --是否根据日期刷新
    CurrentDate CHAR(8),  --当前日期

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_BusinessSeq RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

