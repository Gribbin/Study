create TYPE Ty_BrokerUser AS OBJECT
(
    BrokerID CHAR(10),  --经纪公司代码
    UserID CHAR(15),  --用户代码
    UserName VARCHAR2(80),  --用户名称
    IsActive NUMBER(1),  --是否活跃
    Password CHAR(40),  --密码
    IsAdmin NUMBER(1),  --是否为管理员
    DepartmentID CHAR(12),  --组织架构

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_BrokerUser RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

