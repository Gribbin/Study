create TYPE Ty_Bank AS OBJECT
(
    BankID CHAR(3),  --结算银行代码
    BankName CHAR(100),  --结算银行名称

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_Bank RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

