create TYPE BODY Ty_BrokerFundMortgage IS

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_BrokerFundMortgage RETURN SELF AS RESULT IS
  BEGIN
    RETURN;
  END;

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2 IS
    l_string VARCHAR2(4000);
  BEGIN
    l_string:='ty_BrokerFundMortgage('
      || 'TradingDay=>' || '''' || trim(TradingDay) || '''' --交易日
      || ',BrokerID=>' || '''' || trim(BrokerID) || '''' --经纪公司代码
      || ',ExchangeID=>' || '''' || trim(ExchangeID) || '''' --交易所代码
      || ',SourceCurrencyID=>' || '''' || trim(SourceCurrencyID) || '''' --货币质押来源币种
      || ',TargetCurrencyID=>' || '''' || trim(TargetCurrencyID) || '''' --货币质押目标币种
      || ',SourceDeposit=>' || NVL(to_char(SourceDeposit),'NULL')--货币质押来源金额
      || ',TargetDeposit=>' || NVL(to_char(TargetDeposit),'NULL')--货币质押来源金额
      || ',ExchangeRate=>' || NVL(to_char(ExchangeRate),'NULL')--汇率
      || ',OperatorID=>' || '''' || trim(OperatorID) || '''' --操作员代码
      || ',OpDate=>' || '''' || trim(OpDate) || '''' --操作日期
      || ',OpTime=>' || '''' || trim(OpTime) || '''' --操作时间
      || ')';


    RETURN l_string;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN NULL;
  END;



END;
/

