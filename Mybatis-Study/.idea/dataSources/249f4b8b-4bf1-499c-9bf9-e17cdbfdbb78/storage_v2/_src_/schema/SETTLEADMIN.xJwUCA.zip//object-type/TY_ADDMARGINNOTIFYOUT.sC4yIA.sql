create TYPE Ty_AddMarginNotifyOUT AS OBJECT
(
    SettleTaskID CHAR(16),  --结算任务ID
    BrokerID CHAR(10),  --经纪公司代码
    AccountID CHAR(14),  --资金账户
    CurrencyID CHAR(3),  --资金账户币种
    CallMargin NUMBER(22,6),  --追加保证金

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_AddMarginNotifyOUT RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

