create TYPE BODY Ty_AmlNiEnumMap IS

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_AmlNiEnumMap RETURN SELF AS RESULT IS
  BEGIN
    RETURN;
  END;

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2 IS
    l_string VARCHAR2(4000);
  BEGIN
    l_string:='ty_AmlNiEnumMap('
      || 'ReportType=>' || '''' || trim(ReportType) || '''' --大额或可疑
      || ',EnumGroup=>' || '''' || trim(EnumGroup) || '''' --字典集名称
      || ',CtpValue=>' || '''' || trim(CtpValue) || '''' --CTP值
      || ',CtpValueMemo=>' || '''' || trim(CtpValueMemo) || '''' --CTP值备注
      || ',AmlNiValue=>' || '''' || trim(AmlNiValue) || '''' --反洗钱新接口值
      || ',AmlNiValueMemo=>' || '''' || trim(AmlNiValueMemo) || '''' --反洗钱新接口值备注
      || ')';


    RETURN l_string;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN NULL;
  END;



END;
/

