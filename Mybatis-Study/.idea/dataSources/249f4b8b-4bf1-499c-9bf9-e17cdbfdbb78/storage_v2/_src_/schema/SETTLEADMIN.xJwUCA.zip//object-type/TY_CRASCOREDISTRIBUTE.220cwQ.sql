create TYPE Ty_CRAScoreDistribute AS OBJECT
(
    uppScore NUMBER(8),  --得分区间上限
    lowScore NUMBER(8),  --得分区间下限
    ScoreDisNumber NUMBER(20),  --风险等级客户人数

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_CRAScoreDistribute RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

