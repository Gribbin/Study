create PACKAGE BODY PKGS_Tyt2STRING IS
-- 此处添加定制的代码 -------------------
-- *** BEGIN PUMP GENERATED PACKAGE BODY *** --
-- *** DO NOT MODIFY FOLLOWING CONTENT MANUALLY *** --
---- 将tyt_CAPInfo转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_Exchange) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_Exchange(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_Exchange转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_Bank) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_Bank(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_Bank转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_Broker) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_Broker(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_Broker转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_BrokerEx) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_BrokerEx(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_BrokerEx转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_Commodity) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_Commodity(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_Commodity转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_Product) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_Product(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_Product转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ProductStatus) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ProductStatus(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ProductStatus转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ComProduct) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ComProduct(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ComProduct转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ProductAttr) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ProductAttr(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ProductAttr转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_FutInstrument) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_FutInstrument(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_FutInstrument转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_OptInstrument) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_OptInstrument(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_OptInstrument转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_InstrumentTradeAttr) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_InstrumentTradeAttr(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_InstrumentTradeAttr转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_Calendar) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_Calendar(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_Calendar转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_SystemParam) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_SystemParam(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_SystemParam转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_BrokerWithdrawAlm) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_BrokerWithdrawAlm(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_BrokerWithdrawAlm转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_BrokerMarginAlm) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_BrokerMarginAlm(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_BrokerMarginAlm转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_RiskParameter) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_RiskParameter(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_RiskParameter转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_TradeParam) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_TradeParam(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_TradeParam转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_FBEExchangeTime) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_FBEExchangeTime(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_FBEExchangeTime转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_FBTTransferTime) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_FBTTransferTime(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_FBTTransferTime转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_MDInstrument) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_MDInstrument(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_MDInstrument转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_SettleDate) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_SettleDate(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_SettleDate转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_Trader) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_Trader(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_Trader转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CFFEXOTCPartBrokerRec) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CFFEXOTCPartBrokerRec(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CFFEXOTCPartBrokerRec转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_SettleLog) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_SettleLog(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_SettleLog转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_SettleItemCheck) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_SettleItemCheck(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_SettleItemCheck转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_Investor) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_Investor(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_Investor转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_InvestorEx) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_InvestorEx(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_InvestorEx转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_InvestUnit) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_InvestUnit(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_InvestUnit转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_Person) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_Person(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_Person转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_Company) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_Company(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_Company转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_AMInvestorSpecInfo) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_AMInvestorSpecInfo(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_AMInvestorSpecInfo转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_InvestorIdentifiedcard) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_InvestorIdentifiedcard(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_InvestorIdentifiedcard转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_InvestorLinkMan) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_InvestorLinkMan(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_InvestorLinkMan转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_AccountLinkMan) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_AccountLinkMan(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_AccountLinkMan转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_SeconderyAgent) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_SeconderyAgent(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_SeconderyAgent转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_SecAgentAccProperty) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_SecAgentAccProperty(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_SecAgentAccProperty转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_InvestorExSpecOption) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_InvestorExSpecOption(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_InvestorExSpecOption转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ExSpecific) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ExSpecific(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ExSpecific转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ExSpecOption) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ExSpecOption(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ExSpecOption转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_InvestorBusinessRange) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_InvestorBusinessRange(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_InvestorBusinessRange转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_LedRefBankAcc) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_LedRefBankAcc(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_LedRefBankAcc转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ReferenceDoc) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ReferenceDoc(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ReferenceDoc转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_LegalReferenceDoc) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_LegalReferenceDoc(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_LegalReferenceDoc转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_AmTrusteeAccount) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_AmTrusteeAccount(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_AmTrusteeAccount转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_AmTransferAccount) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_AmTransferAccount(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_AmTransferAccount转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_InvestorAmAccount) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_InvestorAmAccount(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_InvestorAmAccount转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_InveAmCustodyAcc) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_InveAmCustodyAcc(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_InveAmCustodyAcc转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_InvestorUnifyProperty) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_InvestorUnifyProperty(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_InvestorUnifyProperty转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_InvestorIDRule) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_InvestorIDRule(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_InvestorIDRule转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_OperatorInvestorIDRule) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_OperatorInvestorIDRule(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_OperatorInvestorIDRule转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_InvestorExchangeApply) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_InvestorExchangeApply(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_InvestorExchangeApply转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_Send_ShareHolders) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_Send_ShareHolders(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_Send_ShareHolders转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_Seq_ShareHolders) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_Seq_ShareHolders(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_Seq_ShareHolders转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_Send_Process) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_Send_Process(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_Send_Process转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_Send_InvestorExUnify) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_Send_InvestorExUnify(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_Send_InvestorExUnify转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_Send_BusinessRange) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_Send_BusinessRange(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_Send_BusinessRange转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_Send_ExSpecOption) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_Send_ExSpecOption(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_Send_ExSpecOption转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_Send_BankAccount) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_Send_BankAccount(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_Send_BankAccount转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_Send_LedRefBankAcc) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_Send_LedRefBankAcc(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_Send_LedRefBankAcc转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_Send_AmTrusteeAccount) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_Send_AmTrusteeAccount(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_Send_AmTrusteeAccount转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_Send_AmTransferAccount) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_Send_AmTransferAccount(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_Send_AmTransferAccount转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_Send_ReferenceDoc) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_Send_ReferenceDoc(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_Send_ReferenceDoc转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_Send_LegalReferenceDoc) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_Send_LegalReferenceDoc(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_Send_LegalReferenceDoc转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_Seq_Process) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_Seq_Process(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_Seq_Process转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_Seq_InvestorExUnify) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_Seq_InvestorExUnify(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_Seq_InvestorExUnify转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_Seq_BusinessRange) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_Seq_BusinessRange(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_Seq_BusinessRange转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_Seq_ExSpecOption) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_Seq_ExSpecOption(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_Seq_ExSpecOption转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_Seq_BankAccount) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_Seq_BankAccount(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_Seq_BankAccount转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_Seq_LedRefBankAcc) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_Seq_LedRefBankAcc(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_Seq_LedRefBankAcc转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_Seq_AmTrusteeAccount) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_Seq_AmTrusteeAccount(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_Seq_AmTrusteeAccount转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_Seq_AmTransferAccount) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_Seq_AmTransferAccount(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_Seq_AmTransferAccount转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_Seq_ReferenceDoc) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_Seq_ReferenceDoc(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_Seq_ReferenceDoc转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_Seq_LegalReferenceDoc) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_Seq_LegalReferenceDoc(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_Seq_LegalReferenceDoc转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CMMCFileLog) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CMMCFileLog(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CMMCFileLog转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_InvestorLoginAccount) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_InvestorLoginAccount(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_InvestorLoginAccount转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_InstrumentTradingRight) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_InstrumentTradingRight(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_InstrumentTradingRight转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_OptInstrTradingRight) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_OptInstrTradingRight(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_OptInstrTradingRight转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_InvestorGroup) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_InvestorGroup(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_InvestorGroup转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_Account) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_Account(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_Account转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_AccountOwnerShip) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_AccountOwnerShip(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_AccountOwnerShip转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_AccountGroup) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_AccountGroup(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_AccountGroup转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_AccountGroupMap) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_AccountGroupMap(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_AccountGroupMap转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_TradingCode) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_TradingCode(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_TradingCode转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_TradingCodeMap) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_TradingCodeMap(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_TradingCodeMap转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_TradingCodeRight) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_TradingCodeRight(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_TradingCodeRight转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_InvstrAccByProduct) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_InvstrAccByProduct(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_InvstrAccByProduct转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_InvstrAccByInstrument) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_InvstrAccByInstrument(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_InvstrAccByInstrument转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_InvstrAccByTradeID) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_InvstrAccByTradeID(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_InvstrAccByTradeID转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_InvestorBankAccount) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_InvestorBankAccount(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_InvestorBankAccount转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_BrokerAccount) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_BrokerAccount(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_BrokerAccount转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_SpecPartAccount) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_SpecPartAccount(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_SpecPartAccount转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_Department) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_Department(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_Department转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_DepartmentUser) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_DepartmentUser(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_DepartmentUser转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_DepartmentUserBlacklist) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_DepartmentUserBlacklist(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_DepartmentUserBlacklist转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_DepartmentLoginAccMap) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_DepartmentLoginAccMap(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_DepartmentLoginAccMap转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_Party) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_Party(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_Party转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_InvestorPartyMap) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_InvestorPartyMap(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_InvestorPartyMap转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_InvestorGroupPartyMap) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_InvestorGroupPartyMap(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_InvestorGroupPartyMap转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_DepartmentPartyMap) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_DepartmentPartyMap(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_DepartmentPartyMap转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_RightTemplateManager) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_RightTemplateManager(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_RightTemplateManager转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_RightTemplate) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_RightTemplate(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_RightTemplate转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_InstrTradingRightTpl) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_InstrTradingRightTpl(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_InstrTradingRightTpl转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_OptInstrTradingRightTpl) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_OptInstrTradingRightTpl(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_OptInstrTradingRightTpl转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_UserRightTpl) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_UserRightTpl(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_UserRightTpl转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_RestrictionTpl) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_RestrictionTpl(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_RestrictionTpl转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_SettlementPrice) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_SettlementPrice(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_SettlementPrice转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_SecuritiesVariety) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_SecuritiesVariety(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_SecuritiesVariety转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_BusinessSeq) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_BusinessSeq(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_BusinessSeq转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_Order) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_Order(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_Order转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_Trade) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_Trade(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_Trade转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_PartBroker) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_PartBroker(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_PartBroker转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_PartInvestor) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_PartInvestor(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_PartInvestor转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_RegulatorDic) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_RegulatorDic(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_RegulatorDic转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ExchangeRate) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ExchangeRate(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ExchangeRate转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_BankExchangeRate) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_BankExchangeRate(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_BankExchangeRate转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_MarketData) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_MarketData(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_MarketData转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_SHFEInstrumentCheck) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_SHFEInstrumentCheck(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_SHFEInstrumentCheck转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_SysSettleParam) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_SysSettleParam(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_SysSettleParam转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_SpecDealProduct) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_SpecDealProduct(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_SpecDealProduct转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_BakFile) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_BakFile(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_BakFile转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_BrokerUserQueryRight) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_BrokerUserQueryRight(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_BrokerUserQueryRight转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_SeconderyAgentACIDMap) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_SeconderyAgentACIDMap(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_SeconderyAgentACIDMap转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_BrokerAgent) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_BrokerAgent(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_BrokerAgent转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CSRCPartBroker) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CSRCPartBroker(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CSRCPartBroker转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CSRCOtherInfo) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CSRCOtherInfo(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CSRCOtherInfo转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CSRCAssets) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CSRCAssets(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CSRCAssets转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CSRCDataSend) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CSRCDataSend(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CSRCDataSend转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_InvestorDelivProfit) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_InvestorDelivProfit(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_InvestorDelivProfit转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ProductExchRate) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ProductExchRate(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ProductExchRate转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ProductGroup) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ProductGroup(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ProductGroup转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ForQuoteParam) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ForQuoteParam(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ForQuoteParam转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_FutureLimitPosiParam) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_FutureLimitPosiParam(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_FutureLimitPosiParam转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_FutureOrderFreqParam) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_FutureOrderFreqParam(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_FutureOrderFreqParam转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ReserveOpenAccount) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ReserveOpenAccount(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ReserveOpenAccount转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_HostingSetBrokerUser) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_HostingSetBrokerUser(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_HostingSetBrokerUser转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_SettlementInfoConfirm) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_SettlementInfoConfirm(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_SettlementInfoConfirm转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CheckFlow) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CheckFlow(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CheckFlow转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CheckHis) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CheckHis(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CheckHis转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ExecForbiddenTime) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ExecForbiddenTime(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ExecForbiddenTime转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_BankFlagMaping) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_BankFlagMaping(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_BankFlagMaping转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_UserRight) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_UserRight(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_UserRight转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_SpecCompany) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_SpecCompany(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_SpecCompany转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_FutInsAutoAdd) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_FutInsAutoAdd(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_FutInsAutoAdd转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ForQuoteFreqLimit) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ForQuoteFreqLimit(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ForQuoteFreqLimit转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_RelieveOpenLimit) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_RelieveOpenLimit(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_RelieveOpenLimit转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_SettleProductGroup) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_SettleProductGroup(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_SettleProductGroup转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_SettleProductGroupRelation) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_SettleProductGroupRelation(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_SettleProductGroupRelation转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_RiskProductFrozenRatio) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_RiskProductFrozenRatio(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_RiskProductFrozenRatio转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_s_RiskProductFrozenRatio) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_s_RiskProductFrozenRatio(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_s_RiskProductFrozenRatio转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_SettleScope) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_SettleScope(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_SettleScope转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_UploadFile) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_UploadFile(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_UploadFile转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_UploadFileList) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_UploadFileList(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_UploadFileList转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_UploadMode) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_UploadMode(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_UploadMode转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_InvestorBillContent) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_InvestorBillContent(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_InvestorBillContent转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_BillFormat) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_BillFormat(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_BillFormat转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_BizNotice) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_BizNotice(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_BizNotice转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_InstSettleInfo) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_InstSettleInfo(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_InstSettleInfo转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_SettleItemCfg) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_SettleItemCfg(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_SettleItemCfg转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_BrokerPosition) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_BrokerPosition(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_BrokerPosition转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_SettleTaskRecord) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_SettleTaskRecord(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_SettleTaskRecord转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_SettleReturnRecord) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_SettleReturnRecord(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_SettleReturnRecord转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CheckSettleBrokerTra) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CheckSettleBrokerTra(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CheckSettleBrokerTra转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_Queryinvestorgroupmap) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_Queryinvestorgroupmap(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_Queryinvestorgroupmap转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_QueryInvestorGroup) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_QueryInvestorGroup(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_QueryInvestorGroup转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ExchFutCommRate) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ExchFutCommRate(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ExchFutCommRate转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ExchFutTransferCommRate) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ExchFutTransferCommRate(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ExchFutTransferCommRate转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_InvstFutCommRate) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_InvstFutCommRate(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_InvstFutCommRate转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_FloatInvstFutCommRate) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_FloatInvstFutCommRate(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_FloatInvstFutCommRate转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_FloatInvstFutCommRateUpd) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_FloatInvstFutCommRateUpd(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_FloatInvstFutCommRateUpd转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_O_FloatInvstFutCommRate) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_O_FloatInvstFutCommRate(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_O_FloatInvstFutCommRate转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_O_FloatInvstFutComResult) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_O_FloatInvstFutComResult(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_O_FloatInvstFutComResult转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_InvstFutTransferCommRate) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_InvstFutTransferCommRate(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_InvstFutTransferCommRate转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_InvstFutSettleCommRate) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_InvstFutSettleCommRate(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_InvstFutSettleCommRate转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_InvstFutGUARFundCommRate) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_InvstFutGUARFundCommRate(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_InvstFutGUARFundCommRate转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_InvstFutCommRateUpd) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_InvstFutCommRateUpd(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_InvstFutCommRateUpd转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_InvstOptCommRateUpd) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_InvstOptCommRateUpd(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_InvstOptCommRateUpd转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ExchFutMarginRate) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ExchFutMarginRate(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ExchFutMarginRate转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CurrExchFutMarginRate) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CurrExchFutMarginRate(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CurrExchFutMarginRate转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CurrExchFutMarginRateAdj) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CurrExchFutMarginRateAdj(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CurrExchFutMarginRateAdj转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ExchFutMarginRateUpd) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ExchFutMarginRateUpd(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ExchFutMarginRateUpd转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_InvstFutMarginRate) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_InvstFutMarginRate(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_InvstFutMarginRate转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CurrInvstFutMarginRate) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CurrInvstFutMarginRate(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CurrInvstFutMarginRate转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_InvstFutMarginRateUpd) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_InvstFutMarginRateUpd(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_InvstFutMarginRateUpd转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CurrInvstFutMarginRateAdj) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CurrInvstFutMarginRateAdj(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CurrInvstFutMarginRateAdj转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_InvstFutMarginRateMA) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_InvstFutMarginRateMA(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_InvstFutMarginRateMA转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_InvstMarginModel) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_InvstMarginModel(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_InvstMarginModel转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_BrokerUserMarginModel) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_BrokerUserMarginModel(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_BrokerUserMarginModel转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_InvstCommModel) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_InvstCommModel(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_InvstCommModel转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_BrokerUserCommModel) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_BrokerUserCommModel(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_BrokerUserCommModel转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CommRateTemplate) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CommRateTemplate(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CommRateTemplate转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_InvstCommRateTpl) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_InvstCommRateTpl(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_InvstCommRateTpl转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_InstrumentOrderCommRate) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_InstrumentOrderCommRate(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_InstrumentOrderCommRate转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ProductLifeRule) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ProductLifeRule(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ProductLifeRule转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_InstrumentExprDate) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_InstrumentExprDate(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_InstrumentExprDate转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_InvstMarginRateTpl) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_InvstMarginRateTpl(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_InvstMarginRateTpl转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_InvstMarginRateTplUpd) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_InvstMarginRateTplUpd(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_InvstMarginRateTplUpd转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_InvstMarginRateAdjTpl) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_InvstMarginRateAdjTpl(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_InvstMarginRateAdjTpl转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_MarginRateTemplate) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_MarginRateTemplate(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_MarginRateTemplate转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_InvstOptMarginRateUL) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_InvstOptMarginRateUL(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_InvstOptMarginRateUL转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_InvstOptMarginRateULTpl) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_InvstOptMarginRateULTpl(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_InvstOptMarginRateULTpl转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_InvestorSettleParam) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_InvestorSettleParam(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_InvestorSettleParam转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ExchangeSettleParam) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ExchangeSettleParam(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ExchangeSettleParam转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ExchangeOpenParam) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ExchangeOpenParam(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ExchangeOpenParam转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_BrokerFund) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_BrokerFund(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_BrokerFund转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_SpecPartFund) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_SpecPartFund(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_SpecPartFund转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_InvestorOptStrike) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_InvestorOptStrike(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_InvestorOptStrike转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_InvestorFundDtl) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_InvestorFundDtl(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_InvestorFundDtl转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_InvestorPosition) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_InvestorPosition(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_InvestorPosition转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_InvstPositionDtl) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_InvstPositionDtl(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_InvstPositionDtl转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_InvstPositionComDtl) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_InvstPositionComDtl(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_InvstPositionComDtl转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_TmdbExecOrder) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_TmdbExecOrder(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_TmdbExecOrder转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_BatchExecOrder) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_BatchExecOrder(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_BatchExecOrder转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ExchOptCommRate) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ExchOptCommRate(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ExchOptCommRate转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ExchOptTransferCommRate) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ExchOptTransferCommRate(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ExchOptTransferCommRate转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_InvstOptCommRate) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_InvstOptCommRate(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_InvstOptCommRate转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_FloatInvstOptCommRate) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_FloatInvstOptCommRate(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_FloatInvstOptCommRate转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_FloatInvstOptCommRateUpd) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_FloatInvstOptCommRateUpd(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_FloatInvstOptCommRateUpd转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_O_FloatInvstOptCommRate) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_O_FloatInvstOptCommRate(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_O_FloatInvstOptCommRate转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_O_FloatInvstOptComResult) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_O_FloatInvstOptComResult(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_O_FloatInvstOptComResult转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_InvstOptTransferCommRate) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_InvstOptTransferCommRate(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_InvstOptTransferCommRate转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_InvstOptSettleCommRate) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_InvstOptSettleCommRate(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_InvstOptSettleCommRate转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_OptCffexEMargin) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_OptCffexEMargin(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_OptCffexEMargin转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_OptCffexIMargin) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_OptCffexIMargin(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_OptCffexIMargin转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_OptShfeExchMargin) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_OptShfeExchMargin(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_OptShfeExchMargin转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_OptShfeInvstMargin) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_OptShfeInvstMargin(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_OptShfeInvstMargin转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_OptShfeInvstDelta) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_OptShfeInvstDelta(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_OptShfeInvstDelta转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_InvstOptStrikeOffset) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_InvstOptStrikeOffset(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_InvstOptStrikeOffset转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_MainBrokerSyncStatus) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_MainBrokerSyncStatus(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_MainBrokerSyncStatus转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CombinationLeg) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CombinationLeg(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CombinationLeg转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ComInstrument) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ComInstrument(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ComInstrument转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_Discount) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_Discount(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_Discount转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ProfitAlgorithm) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ProfitAlgorithm(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ProfitAlgorithm转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CFMMCPartBroker) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CFMMCPartBroker(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CFMMCPartBroker转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_InvstInstrSettleInfo) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_InvstInstrSettleInfo(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_InvstInstrSettleInfo转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_InvestorCloseDtl) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_InvestorCloseDtl(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_InvestorCloseDtl转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_InvestorDelivery) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_InvestorDelivery(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_InvestorDelivery转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_InvestorTradeDtl) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_InvestorTradeDtl(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_InvestorTradeDtl转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_NonMaxMarginInstrument) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_NonMaxMarginInstrument(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_NonMaxMarginInstrument转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_SettleFileInvestor) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_SettleFileInvestor(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_SettleFileInvestor转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_SettleFileLog) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_SettleFileLog(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_SettleFileLog转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_BillInvestor) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_BillInvestor(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_BillInvestor转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CombInstrumentMap) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CombInstrumentMap(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CombInstrumentMap转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CombInstrumentGuard) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CombInstrumentGuard(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CombInstrumentGuard转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CffexPositionComDtl) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CffexPositionComDtl(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CffexPositionComDtl转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CffexCombRule) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CffexCombRule(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CffexCombRule转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CffexCombPosition) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CffexCombPosition(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CffexCombPosition转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CffexExchangeRate) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CffexExchangeRate(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CffexExchangeRate转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CffexSpTransRatio) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CffexSpTransRatio(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CffexSpTransRatio转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_InvestorMarginModelTpl) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_InvestorMarginModelTpl(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_InvestorMarginModelTpl转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_OpInstrTradingRightTpl) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_OpInstrTradingRightTpl(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_OpInstrTradingRightTpl转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_InvestorInterestRate) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_InvestorInterestRate(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_InvestorInterestRate转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_InvestorInterest) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_InvestorInterest(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_InvestorInterest转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_s_InvestorInterestRate) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_s_InvestorInterestRate(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_s_InvestorInterestRate转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_s_InvestorInterest) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_s_InvestorInterest(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_s_InvestorInterest转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_TradingMemberPositionIn) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_TradingMemberPositionIn(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_TradingMemberPositionIn转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_TradingMemberPositionOut) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_TradingMemberPositionOut(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_TradingMemberPositionOut转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_s_TradingMemberPositionIn) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_s_TradingMemberPositionIn(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_s_TradingMemberPositionIn转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_s_TradingMemberPositionOut) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_s_TradingMemberPositionOut(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_s_TradingMemberPositionOut转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_SHFENontradeposchangedtl) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_SHFENontradeposchangedtl(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_SHFENontradeposchangedtl转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_s_SHFENontradeposchangedtl) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_s_SHFENontradeposchangedtl(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_s_SHFENontradeposchangedtl转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_OpShfeNontradeResult) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_OpShfeNontradeResult(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_OpShfeNontradeResult转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_s_OpShfeNontradeResult) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_s_OpShfeNontradeResult(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_s_OpShfeNontradeResult转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_OpSHFEStrikeResult) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_OpSHFEStrikeResult(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_OpSHFEStrikeResult转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_MarketMakerInvestor) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_MarketMakerInvestor(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_MarketMakerInvestor转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_INENonTradePosChangeDtl) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_INENonTradePosChangeDtl(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_INENonTradePosChangeDtl转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_OpINEStrikeResult) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_OpINEStrikeResult(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_OpINEStrikeResult转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_InvestorEWarrantOffset) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_InvestorEWarrantOffset(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_InvestorEWarrantOffset转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_InvstDelivVolSerial) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_InvstDelivVolSerial(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_InvstDelivVolSerial转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_InvstWillDelivVol) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_InvstWillDelivVol(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_InvstWillDelivVol转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_InvstDelivFeeSerial) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_InvstDelivFeeSerial(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_InvstDelivFeeSerial转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_InvstWillDelivFee) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_InvstWillDelivFee(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_InvstWillDelivFee转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_InvstDelivSubmitSerial) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_InvstDelivSubmitSerial(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_InvstDelivSubmitSerial转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_InvstWillDelivSubmit) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_InvstWillDelivSubmit(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_InvstWillDelivSubmit转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_NonExpireDelivery) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_NonExpireDelivery(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_NonExpireDelivery转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_InvestorFund) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_InvestorFund(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_InvestorFund转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_InvestorFundChange) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_InvestorFundChange(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_InvestorFundChange转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ExchangeFundChange) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ExchangeFundChange(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ExchangeFundChange转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_SpecPartFundChange) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_SpecPartFundChange(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_SpecPartFundChange转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_Mortgage) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_Mortgage(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_Mortgage转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_InvestorMortgage) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_InvestorMortgage(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_InvestorMortgage转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_Frozen) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_Frozen(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_Frozen转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_FundMortgage) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_FundMortgage(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_FundMortgage转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_InvstFundMortDiscount) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_InvstFundMortDiscount(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_InvstFundMortDiscount转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_BrokerFundMortgage) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_BrokerFundMortgage(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_BrokerFundMortgage转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_InvestorFundMortgage) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_InvestorFundMortgage(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_InvestorFundMortgage转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_InterestRate) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_InterestRate(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_InterestRate转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_DepositSumAdjust) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_DepositSumAdjust(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_DepositSumAdjust转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ClearInterest) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ClearInterest(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ClearInterest转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ClearInterestDtl) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ClearInterestDtl(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ClearInterestDtl转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_Role) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_Role(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_Role转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_Function) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_Function(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_Function转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_FunctionUrl) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_FunctionUrl(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_FunctionUrl转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_RoleFunction) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_RoleFunction(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_RoleFunction转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_UserRole) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_UserRole(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_UserRole转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_DefaultFunction) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_DefaultFunction(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_DefaultFunction转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_BrokerUser) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_BrokerUser(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_BrokerUser转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_BrokerUserFunction) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_BrokerUserFunction(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_BrokerUserFunction转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_SuperUser) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_SuperUser(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_SuperUser转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_SuperUserFunction) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_SuperUserFunction(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_SuperUserFunction转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_EnumMetadata) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_EnumMetadata(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_EnumMetadata转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_OpFavor) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_OpFavor(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_OpFavor转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_BackDataSpecialTable) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_BackDataSpecialTable(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_BackDataSpecialTable转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CSRC_Customer) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CSRC_Customer(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CSRC_Customer转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CSRC_CusCode) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CSRC_CusCode(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CSRC_CusCode转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CSRC_CusAccount) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CSRC_CusAccount(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CSRC_CusAccount转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CSRC_CusFund) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CSRC_CusFund(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CSRC_CusFund转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CSRC_FundChg) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CSRC_FundChg(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CSRC_FundChg转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CSRC_TrdData) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CSRC_TrdData(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CSRC_TrdData转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CSRC_HoldData) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CSRC_HoldData(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CSRC_HoldData转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CSRC_OtherFund) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CSRC_OtherFund(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CSRC_OtherFund转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CSRC_OtherInfo) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CSRC_OtherInfo(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CSRC_OtherInfo转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CSRC_LiquidDetails) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CSRC_LiquidDetails(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CSRC_LiquidDetails转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CSRC_HoldDetails) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CSRC_HoldDetails(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CSRC_HoldDetails转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CSRC_MortgageDetails) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CSRC_MortgageDetails(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CSRC_MortgageDetails转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CSRC_DelivDetails) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CSRC_DelivDetails(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CSRC_DelivDetails转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CSRC_DelivContractData) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CSRC_DelivContractData(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CSRC_DelivContractData转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CSRC_ExchangeDetails) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CSRC_ExchangeDetails(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CSRC_ExchangeDetails转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CSRC_CurrencyMortgage) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CSRC_CurrencyMortgage(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CSRC_CurrencyMortgage转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CSRC_AmAccounts) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CSRC_AmAccounts(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CSRC_AmAccounts转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CSRC_AmCustodyAccounts) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CSRC_AmCustodyAccounts(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CSRC_AmCustodyAccounts转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CSRC_AmAssets) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CSRC_AmAssets(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CSRC_AmAssets转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CSRC_AmAssetsDtl) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CSRC_AmAssetsDtl(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CSRC_AmAssetsDtl转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CSRC_OptTrdData) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CSRC_OptTrdData(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CSRC_OptTrdData转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CSRC_OptHoldData) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CSRC_OptHoldData(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CSRC_OptHoldData转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CSRC_OptLiquidDetails) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CSRC_OptLiquidDetails(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CSRC_OptLiquidDetails转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CSRC_OptExerData) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CSRC_OptExerData(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CSRC_OptExerData转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CSRC_OptHoldDetails) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CSRC_OptHoldDetails(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CSRC_OptHoldDetails转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CSRCOtherFund) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CSRCOtherFund(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CSRCOtherFund转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CSRCDataSendLog) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CSRCDataSendLog(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CSRCDataSendLog转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CSRC_ClientInfo) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CSRC_ClientInfo(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CSRC_ClientInfo转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_OperationLog) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_OperationLog(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_OperationLog转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_EventLog) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_EventLog(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_EventLog转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_FundEventLog) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_FundEventLog(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_FundEventLog转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_DBVersionManager) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_DBVersionManager(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_DBVersionManager转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_Page) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_Page(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_Page转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ExchangeRateIN) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ExchangeRateIN(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ExchangeRateIN转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ExchFutCommRateIN) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ExchFutCommRateIN(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ExchFutCommRateIN转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ExchOptCommRateIN) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ExchOptCommRateIN(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ExchOptCommRateIN转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_InvestorFutCommRateIN) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_InvestorFutCommRateIN(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_InvestorFutCommRateIN转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_InvestorOptCommRateIN) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_InvestorOptCommRateIN(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_InvestorOptCommRateIN转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ExchMarginRateIN) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ExchMarginRateIN(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ExchMarginRateIN转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_InvestorMarginRateIN) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_InvestorMarginRateIN(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_InvestorMarginRateIN转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_InvestorMortgageValueIN) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_InvestorMortgageValueIN(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_InvestorMortgageValueIN转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_InvestorEWarrantOffsetIN) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_InvestorEWarrantOffsetIN(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_InvestorEWarrantOffsetIN转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_InvestorSettleParamIN) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_InvestorSettleParamIN(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_InvestorSettleParamIN转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ExchangeSettleParamIN) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ExchangeSettleParamIN(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ExchangeSettleParamIN转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_SysSettleParamIN) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_SysSettleParamIN(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_SysSettleParamIN转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_SpecDealProductIN) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_SpecDealProductIN(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_SpecDealProductIN转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_NonMaxMarginInstrumentIN) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_NonMaxMarginInstrumentIN(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_NonMaxMarginInstrumentIN转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_OptShfeExchMinMarginIN) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_OptShfeExchMinMarginIN(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_OptShfeExchMinMarginIN转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_OptShfeInvstMinMarginIN) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_OptShfeInvstMinMarginIN(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_OptShfeInvstMinMarginIN转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_OptShfeInvestorDeltaIN) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_OptShfeInvestorDeltaIN(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_OptShfeInvestorDeltaIN转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_OptCffexExchMarginAdjIN) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_OptCffexExchMarginAdjIN(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_OptCffexExchMarginAdjIN转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_OptCffexInvstMarginAdjIN) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_OptCffexInvstMarginAdjIN(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_OptCffexInvstMarginAdjIN转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_OptCffexIndexPriceIN) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_OptCffexIndexPriceIN(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_OptCffexIndexPriceIN转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_LastSettleDateIN) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_LastSettleDateIN(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_LastSettleDateIN转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_LastFundIN) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_LastFundIN(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_LastFundIN转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_LastBrokerFundIN) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_LastBrokerFundIN(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_LastBrokerFundIN转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_LastInvestorSettleInfoIN) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_LastInvestorSettleInfoIN(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_LastInvestorSettleInfoIN转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_LastInvestorPosDtlIN) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_LastInvestorPosDtlIN(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_LastInvestorPosDtlIN转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_LastInvestorCombPosDtlIN) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_LastInvestorCombPosDtlIN(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_LastInvestorCombPosDtlIN转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_InvestorFundChgIN) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_InvestorFundChgIN(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_InvestorFundChgIN转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_BrokerFundChgIN) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_BrokerFundChgIN(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_BrokerFundChgIN转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_InvestorCalSpdArbAppIN) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_InvestorCalSpdArbAppIN(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_InvestorCalSpdArbAppIN转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_InvestorHedgeAppIN) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_InvestorHedgeAppIN(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_InvestorHedgeAppIN转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_InvestorS2HIN) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_InvestorS2HIN(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_InvestorS2HIN转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_InvestorHedgeLimitIN) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_InvestorHedgeLimitIN(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_InvestorHedgeLimitIN转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_InvestorDelivVolSerialIN) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_InvestorDelivVolSerialIN(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_InvestorDelivVolSerialIN转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_InvstWillDelivVolIN) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_InvstWillDelivVolIN(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_InvstWillDelivVolIN转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_InvstDelivFeeSerialIN) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_InvstDelivFeeSerialIN(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_InvstDelivFeeSerialIN转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_InvstWillDelivFeeIN) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_InvstWillDelivFeeIN(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_InvstWillDelivFeeIN转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_InvstDelivSubmitSerialIN) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_InvstDelivSubmitSerialIN(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_InvstDelivSubmitSerialIN转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_InvstWillDelivSubmitIN) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_InvstWillDelivSubmitIN(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_InvstWillDelivSubmitIN转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_InvstIntBaseAdjSerialIN) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_InvstIntBaseAdjSerialIN(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_InvstIntBaseAdjSerialIN转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_NonExpireDeliveryIN) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_NonExpireDeliveryIN(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_NonExpireDeliveryIN转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_InvestorMortgageIN) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_InvestorMortgageIN(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_InvestorMortgageIN转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CZCEComFlagIN) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CZCEComFlagIN(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CZCEComFlagIN转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CZCECloseIN) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CZCECloseIN(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CZCECloseIN转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CZCENoCloseIN) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CZCENoCloseIN(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CZCENoCloseIN转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_FundMortgageIN) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_FundMortgageIN(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_FundMortgageIN转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_InvstFundMortDiscountIN) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_InvstFundMortDiscountIN(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_InvstFundMortDiscountIN转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_BrokerFundMortgageIN) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_BrokerFundMortgageIN(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_BrokerFundMortgageIN转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_InvestorFundMortgageIN) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_InvestorFundMortgageIN(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_InvestorFundMortgageIN转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_BrokerFundOUT) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_BrokerFundOUT(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_BrokerFundOUT转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_InvestorFundOUT) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_InvestorFundOUT(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_InvestorFundOUT转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_InvestorFundDtlOUT) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_InvestorFundDtlOUT(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_InvestorFundDtlOUT转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_InvestorTradeFeeDtlOUT) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_InvestorTradeFeeDtlOUT(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_InvestorTradeFeeDtlOUT转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_InvestorCloseDtlOUT) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_InvestorCloseDtlOUT(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_InvestorCloseDtlOUT转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_InvstInstrSettleInfoOUT) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_InvstInstrSettleInfoOUT(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_InvstInstrSettleInfoOUT转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_BrokerPositionOUT) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_BrokerPositionOUT(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_BrokerPositionOUT转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_InvstPositionOUT) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_InvstPositionOUT(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_InvstPositionOUT转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_InvstPositionDtlOUT) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_InvstPositionDtlOUT(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_InvstPositionDtlOUT转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_InvstPositionComDtlOUT) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_InvstPositionComDtlOUT(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_InvstPositionComDtlOUT转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_InvstDelivVolumeOUT) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_InvstDelivVolumeOUT(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_InvstDelivVolumeOUT转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_InvestorDelivFeeOUT) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_InvestorDelivFeeOUT(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_InvestorDelivFeeOUT转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_AddMarginNotifyOUT) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_AddMarginNotifyOUT(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_AddMarginNotifyOUT转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_OptionStrikeResultOUT) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_OptionStrikeResultOUT(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_OptionStrikeResultOUT转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_NonExpireDeliveryUpdOUT) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_NonExpireDeliveryUpdOUT(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_NonExpireDeliveryUpdOUT转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_InvestorDelivSubmitOUT) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_InvestorDelivSubmitOUT(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_InvestorDelivSubmitOUT转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_DelivStatusOUT) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_DelivStatusOUT(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_DelivStatusOUT转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ChkInvestorPosOUT) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ChkInvestorPosOUT(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ChkInvestorPosOUT转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ChkBrokerPosOUT) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ChkBrokerPosOUT(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ChkBrokerPosOUT转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_InvestorDelivProfitOUT) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_InvestorDelivProfitOUT(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_InvestorDelivProfitOUT转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CFFEXCapital) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CFFEXCapital(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CFFEXCapital转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_SHFECapital) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_SHFECapital(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_SHFECapital转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_INECapital) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_INECapital(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_INECapital转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CZCECapital) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CZCECapital(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CZCECapital转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_DCECapital) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_DCECapital(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_DCECapital转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_NoHandledTrade) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_NoHandledTrade(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_NoHandledTrade转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CFFEXTrade) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CFFEXTrade(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CFFEXTrade转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_SHFETrade) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_SHFETrade(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_SHFETrade转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_INETrade) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_INETrade(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_INETrade转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CZCETrade) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CZCETrade(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CZCETrade转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_DCETrade) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_DCETrade(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_DCETrade转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CZCEClose) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CZCEClose(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CZCEClose转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CZCENoClose) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CZCENoClose(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CZCENoClose转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CFFEXSettleDetail) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CFFEXSettleDetail(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CFFEXSettleDetail转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_SHFESettleDetail) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_SHFESettleDetail(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_SHFESettleDetail转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_INESettleDetail) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_INESettleDetail(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_INESettleDetail转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CZCELegPosition) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CZCELegPosition(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CZCELegPosition转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_DCEPosition) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_DCEPosition(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_DCEPosition转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CZCECombinePosition) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CZCECombinePosition(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CZCECombinePosition转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CZCEComFlag) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CZCEComFlag(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CZCEComFlag转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_DCEComFlag) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_DCEComFlag(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_DCEComFlag转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_DCEExchMarginFavParam) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_DCEExchMarginFavParam(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_DCEExchMarginFavParam转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_Customer) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_Customer(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_Customer转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CusCode) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CusCode(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CusCode转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CusAccount) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CusAccount(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CusAccount转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CusFund) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CusFund(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CusFund转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_FundChg) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_FundChg(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_FundChg转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_TrdData) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_TrdData(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_TrdData转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_HoldData) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_HoldData(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_HoldData转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_OtherFund) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_OtherFund(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_OtherFund转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_OtherInfo) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_OtherInfo(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_OtherInfo转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_LiquidDetails) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_LiquidDetails(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_LiquidDetails转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_HoldDetails) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_HoldDetails(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_HoldDetails转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_MortgageDetails) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_MortgageDetails(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_MortgageDetails转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_DelivDetails) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_DelivDetails(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_DelivDetails转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_DelivContractData) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_DelivContractData(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_DelivContractData转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ExchangeDetails) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ExchangeDetails(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ExchangeDetails转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CurrencyMortgage) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CurrencyMortgage(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CurrencyMortgage转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_AMCustomer) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_AMCustomer(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_AMCustomer转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_AmAccounts) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_AmAccounts(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_AmAccounts转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_AmCustodyAccounts) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_AmCustodyAccounts(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_AmCustodyAccounts转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_AmAssets) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_AmAssets(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_AmAssets转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_AmAssetsDtl) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_AmAssetsDtl(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_AmAssetsDtl转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ClientInfo) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ClientInfo(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ClientInfo转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_DCEPositionDtl) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_DCEPositionDtl(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_DCEPositionDtl转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CffexOptionStrike) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CffexOptionStrike(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CffexOptionStrike转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_DceOptionStrike) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_DceOptionStrike(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_DceOptionStrike转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CzceMarginParam) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CzceMarginParam(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CzceMarginParam转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_SHFEExchMarginParam) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_SHFEExchMarginParam(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_SHFEExchMarginParam转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_INEExchMarginParam) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_INEExchMarginParam(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_INEExchMarginParam转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_DCEExchMarginParam) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_DCEExchMarginParam(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_DCEExchMarginParam转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_SubEntryFundIMP) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_SubEntryFundIMP(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_SubEntryFundIMP转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ExchangeRateIMP) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ExchangeRateIMP(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ExchangeRateIMP转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_SubEntryFund) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_SubEntryFund(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_SubEntryFund转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_Opcffexstrikeresult) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_Opcffexstrikeresult(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_Opcffexstrikeresult转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_OpDcestrikeresult) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_OpDcestrikeresult(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_OpDcestrikeresult转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CFFEXOrder) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CFFEXOrder(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CFFEXOrder转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_MarginCall) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_MarginCall(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_MarginCall转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_SHFEClientOverLimitStat) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_SHFEClientOverLimitStat(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_SHFEClientOverLimitStat转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CZCEMortgageFund) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CZCEMortgageFund(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CZCEMortgageFund转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_DCEDelivery) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_DCEDelivery(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_DCEDelivery转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_HandDelivery) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_HandDelivery(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_HandDelivery转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_BrokerUserEvent) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_BrokerUserEvent(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_BrokerUserEvent转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_OptTrdData) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_OptTrdData(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_OptTrdData转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_OptHoldDetails) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_OptHoldDetails(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_OptHoldDetails转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_InvestorDeliveryEx) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_InvestorDeliveryEx(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_InvestorDeliveryEx转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_InvestorHedge) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_InvestorHedge(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_InvestorHedge转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CFFEXCltPosTransfer) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CFFEXCltPosTransfer(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CFFEXCltPosTransfer转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CFFEXAddMarginNotify) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CFFEXAddMarginNotify(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CFFEXAddMarginNotify转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CFFEXCltOverLimitStat) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CFFEXCltOverLimitStat(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CFFEXCltOverLimitStat转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CFFEXPartLackDepositStat) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CFFEXPartLackDepositStat(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CFFEXPartLackDepositStat转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CFFEXPartOverLimitStat) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CFFEXPartOverLimitStat(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CFFEXPartOverLimitStat转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CFFEXPartPosTransfer) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CFFEXPartPosTransfer(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CFFEXPartPosTransfer转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CFFEXCapitalChangeDetail) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CFFEXCapitalChangeDetail(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CFFEXCapitalChangeDetail转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CFFEXSettle) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CFFEXSettle(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CFFEXSettle转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_SHFEExecuteBulletin) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_SHFEExecuteBulletin(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_SHFEExecuteBulletin转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_INEOrder) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_INEOrder(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_INEOrder转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_SysOperateLog) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_SysOperateLog(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_SysOperateLog转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_InvestorTradeFeeDtl) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_InvestorTradeFeeDtl(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_InvestorTradeFeeDtl转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_SHFECapitalChangeDetail) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_SHFECapitalChangeDetail(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_SHFECapitalChangeDetail转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_SHFEPartOverLimitStat) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_SHFEPartOverLimitStat(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_SHFEPartOverLimitStat转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_INEClientNoIntegerStat) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_INEClientNoIntegerStat(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_INEClientNoIntegerStat转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_INEPartOverLimitStat) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_INEPartOverLimitStat(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_INEPartOverLimitStat转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_OptExerData) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_OptExerData(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_OptExerData转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_HedgeLimit) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_HedgeLimit(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_HedgeLimit转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_SHFEOrder) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_SHFEOrder(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_SHFEOrder转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_DCECaptialOthers) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_DCECaptialOthers(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_DCECaptialOthers转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_DCEMortgageOut) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_DCEMortgageOut(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_DCEMortgageOut转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_DCEEFPTrade) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_DCEEFPTrade(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_DCEEFPTrade转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_OptHoldData) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_OptHoldData(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_OptHoldData转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_OptLiquidDetails) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_OptLiquidDetails(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_OptLiquidDetails转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_InvestorComFlag) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_InvestorComFlag(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_InvestorComFlag转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_Credit) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_Credit(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_Credit转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_SHFEMortgageDetail) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_SHFEMortgageDetail(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_SHFEMortgageDetail转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_INECapitalChangeDetail) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_INECapitalChangeDetail(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_INECapitalChangeDetail转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_OptionCffexIndexPrice) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_OptionCffexIndexPrice(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_OptionCffexIndexPrice转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CFFEXClientOverLimitStat) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CFFEXClientOverLimitStat(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CFFEXClientOverLimitStat转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CFFEXDelivery) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CFFEXDelivery(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CFFEXDelivery转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_SHFEPartLackDepositStat) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_SHFEPartLackDepositStat(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_SHFEPartLackDepositStat转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_INEExecuteBulletin) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_INEExecuteBulletin(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_INEExecuteBulletin转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_INEPartLackDepositStat) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_INEPartLackDepositStat(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_INEPartLackDepositStat转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_SettleFile) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_SettleFile(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_SettleFile转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_SubSettleFile) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_SubSettleFile(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_SubSettleFile转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_INESubCapital) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_INESubCapital(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_INESubCapital转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_SHFEClientNoIntegerStat) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_SHFEClientNoIntegerStat(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_SHFEClientNoIntegerStat转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_SHFESettle) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_SHFESettle(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_SHFESettle转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_INEMortgageDetail) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_INEMortgageDetail(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_INEMortgageDetail转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_INEClientOverLimitStat) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_INEClientOverLimitStat(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_INEClientOverLimitStat转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_INESettle) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_INESettle(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_INESettle转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CZCEMortgage) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CZCEMortgage(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CZCEMortgage转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_DCEMortgageIn) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_DCEMortgageIn(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_DCEMortgageIn转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_DCEMortgageAdjust) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_DCEMortgageAdjust(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_DCEMortgageAdjust转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_InvestorS2H) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_InvestorS2H(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_InvestorS2H转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CFFEXMarketmakerFeeDerate) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CFFEXMarketmakerFeeDerate(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CFFEXMarketmakerFeeDerate转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_O_Commodity) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_O_Commodity(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_O_Commodity转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_O_Product) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_O_Product(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_O_Product转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_O_FutInstrument) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_O_FutInstrument(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_O_FutInstrument转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_O_OptInstrument) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_O_OptInstrument(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_O_OptInstrument转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_O_InstrumentTradeAttr) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_O_InstrumentTradeAttr(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_O_InstrumentTradeAttr转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_O_OpenInvestor) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_O_OpenInvestor(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_O_OpenInvestor转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_O_Investor) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_O_Investor(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_O_Investor转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_O_InvestorEx) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_O_InvestorEx(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_O_InvestorEx转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_O_Person) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_O_Person(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_O_Person转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_O_Company) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_O_Company(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_O_Company转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_O_SpecCompany) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_O_SpecCompany(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_O_SpecCompany转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_O_AMInvestorSpecInfo) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_O_AMInvestorSpecInfo(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_O_AMInvestorSpecInfo转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_O_InvestorLinkMan) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_O_InvestorLinkMan(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_O_InvestorLinkMan转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_O_InvestorBusinessRange) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_O_InvestorBusinessRange(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_O_InvestorBusinessRange转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_O_LedRefBankAcc) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_O_LedRefBankAcc(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_O_LedRefBankAcc转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_O_ReferenceDoc) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_O_ReferenceDoc(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_O_ReferenceDoc转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_O_LegalReferenceDoc) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_O_LegalReferenceDoc(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_O_LegalReferenceDoc转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_O_AmTrusteeAccount) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_O_AmTrusteeAccount(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_O_AmTrusteeAccount转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_O_AmTransferAccount) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_O_AmTransferAccount(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_O_AmTransferAccount转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_O_InvestorAmAccount) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_O_InvestorAmAccount(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_O_InvestorAmAccount转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_O_InveAmCustodyAcc) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_O_InveAmCustodyAcc(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_O_InveAmCustodyAcc转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_O_InvestorExSpecOption) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_O_InvestorExSpecOption(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_O_InvestorExSpecOption转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_O_InvestorPartyMap) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_O_InvestorPartyMap(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_O_InvestorPartyMap转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_O_InvestorLoginAccount) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_O_InvestorLoginAccount(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_O_InvestorLoginAccount转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_O_InvestorGroup) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_O_InvestorGroup(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_O_InvestorGroup转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ShareHolders) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ShareHolders(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ShareHolders转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_O_ShareHolders) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_O_ShareHolders(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_O_ShareHolders转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_O_InvestorInfoChange) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_O_InvestorInfoChange(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_O_InvestorInfoChange转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_O_Account) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_O_Account(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_O_Account转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_O_TradingCode) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_O_TradingCode(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_O_TradingCode转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_O_TradingCodeMap) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_O_TradingCodeMap(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_O_TradingCodeMap转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_O_TradingCodeRight) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_O_TradingCodeRight(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_O_TradingCodeRight转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_O_InvstrAccByProduct) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_O_InvstrAccByProduct(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_O_InvstrAccByProduct转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_O_InvstrAccByInstrument) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_O_InvstrAccByInstrument(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_O_InvstrAccByInstrument转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_O_InvstrAccByTradeID) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_O_InvstrAccByTradeID(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_O_InvstrAccByTradeID转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_O_InvestorBankAccount) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_O_InvestorBankAccount(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_O_InvestorBankAccount转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_O_BrokerAccount) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_O_BrokerAccount(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_O_BrokerAccount转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_O_Department) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_O_Department(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_O_Department转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_O_DepartmentLoginAccMap) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_O_DepartmentLoginAccMap(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_O_DepartmentLoginAccMap转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_O_SettlementPrice) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_O_SettlementPrice(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_O_SettlementPrice转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_O_SecuritiesVariety) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_O_SecuritiesVariety(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_O_SecuritiesVariety转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_O_ExchangeRate) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_O_ExchangeRate(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_O_ExchangeRate转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_O_InvstFutCommRate) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_O_InvstFutCommRate(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_O_InvstFutCommRate转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_O_InvstFutCommRateCopy) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_O_InvstFutCommRateCopy(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_O_InvstFutCommRateCopy转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_O_InvstCommModel) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_O_InvstCommModel(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_O_InvstCommModel转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_O_InvestorFundChange) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_O_InvestorFundChange(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_O_InvestorFundChange转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_O_ExchangeFundChange) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_O_ExchangeFundChange(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_O_ExchangeFundChange转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_O_SpecPartFundChange) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_O_SpecPartFundChange(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_O_SpecPartFundChange转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_O_Mortgage) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_O_Mortgage(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_O_Mortgage转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_O_InvestorMortgage) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_O_InvestorMortgage(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_O_InvestorMortgage转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_O_Frozen) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_O_Frozen(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_O_Frozen转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_O_BrokerUser) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_O_BrokerUser(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_O_BrokerUser转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_O_SuperUser) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_O_SuperUser(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_O_SuperUser转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_O_SuperUserFunction) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_O_SuperUserFunction(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_O_SuperUserFunction转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_O_InvestorFundMortgage) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_O_InvestorFundMortgage(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_O_InvestorFundMortgage转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_O_InvstOptCommRate) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_O_InvstOptCommRate(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_O_InvstOptCommRate转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_O_InvstFutSettleCommrate) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_O_InvstFutSettleCommrate(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_O_InvstFutSettleCommrate转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_O_InvstFutTransferCommrate) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_O_InvstFutTransferCommrate(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_O_InvstFutTransferCommrate转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_O_InvstFutGUARFundCommRate) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_O_InvstFutGUARFundCommRate(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_O_InvstFutGUARFundCommRate转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_O_InvstOptSettleCommrate) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_O_InvstOptSettleCommrate(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_O_InvstOptSettleCommrate转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_O_InvstOptTransferCommrate) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_O_InvstOptTransferCommrate(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_O_InvstOptTransferCommrate转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_AMLCharacter) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_AMLCharacter(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_AMLCharacter转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_AMLOperationParam) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_AMLOperationParam(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_AMLOperationParam转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_AMLNotReport) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_AMLNotReport(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_AMLNotReport转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_AMLInstitutionParam) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_AMLInstitutionParam(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_AMLInstitutionParam转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_AMLEnumMetaData) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_AMLEnumMetaData(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_AMLEnumMetaData转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_AMLGenFileLog) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_AMLGenFileLog(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_AMLGenFileLog转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_AMLZipFile) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_AMLZipFile(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_AMLZipFile转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_AMLXMLReport) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_AMLXMLReport(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_AMLXMLReport转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_AMLXMLTrade) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_AMLXMLTrade(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_AMLXMLTrade转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_AMLDrawLog) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_AMLDrawLog(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_AMLDrawLog转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_AMLSHReport) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_AMLSHReport(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_AMLSHReport转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_AMLSHTrade) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_AMLSHTrade(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_AMLSHTrade转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_AMLSSReport) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_AMLSSReport(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_AMLSSReport转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_AMLSSTrade) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_AMLSSTrade(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_AMLSSTrade转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_AMLDrawStatus) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_AMLDrawStatus(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_AMLDrawStatus转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_AMLCheckFlow) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_AMLCheckFlow(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_AMLCheckFlow转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_AMLUserCheckRight) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_AMLUserCheckRight(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_AMLUserCheckRight转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_AMLCheckHis) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_AMLCheckHis(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_AMLCheckHis转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_AMLCheckSHReport) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_AMLCheckSHReport(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_AMLCheckSHReport转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_AMLCheckSSReport) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_AMLCheckSSReport(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_AMLCheckSSReport转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_AMLCheckSHTrade) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_AMLCheckSHTrade(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_AMLCheckSHTrade转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_AMLCheckSSTrade) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_AMLCheckSSTrade(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_AMLCheckSSTrade转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_AmlInvestor) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_AmlInvestor(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_AmlInvestor转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_AmlInvestorBusinessRange) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_AmlInvestorBusinessRange(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_AmlInvestorBusinessRange转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_AmlInvstChangeChkParam) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_AmlInvstChangeChkParam(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_AmlInvstChangeChkParam转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_AmlInvestorchange) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_AmlInvestorchange(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_AmlInvestorchange转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_AmlInvestorLoginAccount) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_AmlInvestorLoginAccount(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_AmlInvestorLoginAccount转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_AmlAccount) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_AmlAccount(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_AmlAccount转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_AMLSHReportHis) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_AMLSHReportHis(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_AMLSHReportHis转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_AMLSHTradeHis) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_AMLSHTradeHis(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_AMLSHTradeHis转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_AMLSSReportHis) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_AMLSSReportHis(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_AMLSSReportHis转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_AMLSSTradeHis) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_AMLSSTradeHis(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_AMLSSTradeHis转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CRAPersonBlackList) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CRAPersonBlackList(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CRAPersonBlackList转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CRAAreaBlackList) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CRAAreaBlackList(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CRAAreaBlackList转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CRAPersonBlackListPerson) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CRAPersonBlackListPerson(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CRAPersonBlackListPerson转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CRAAreaBlackListPerson) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CRAAreaBlackListPerson(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CRAAreaBlackListPerson转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CRARiskFactor) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CRARiskFactor(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CRARiskFactor转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CRARiskIndex) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CRARiskIndex(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CRARiskIndex转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CRARiskIndexOption) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CRARiskIndexOption(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CRARiskIndexOption转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CRARiskLevel) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CRARiskLevel(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CRARiskLevel转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CRAInvestorRisk) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CRAInvestorRisk(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CRAInvestorRisk转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CRAInvestorRiskDetail) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CRAInvestorRiskDetail(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CRAInvestorRiskDetail转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_O_CRAInvestorRisk) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_O_CRAInvestorRisk(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_O_CRAInvestorRisk转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_O_CRAInvestorRiskDetail) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_O_CRAInvestorRiskDetail(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_O_CRAInvestorRiskDetail转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CRACheckHis) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CRACheckHis(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CRACheckHis转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_InvestorBeneficiary) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_InvestorBeneficiary(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_InvestorBeneficiary转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_AmlNiShReport) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_AmlNiShReport(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_AmlNiShReport转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_AmlNiShCus) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_AmlNiShCus(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_AmlNiShCus转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_AmlNiShTrade) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_AmlNiShTrade(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_AmlNiShTrade转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_AmlNiSsReport) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_AmlNiSsReport(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_AmlNiSsReport转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_AmlNiSsCus) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_AmlNiSsCus(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_AmlNiSsCus转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_AmlNiSsTrade) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_AmlNiSsTrade(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_AmlNiSsTrade转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_AmlNiReportMap) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_AmlNiReportMap(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_AmlNiReportMap转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_AmlCheckNiShReport) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_AmlCheckNiShReport(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_AmlCheckNiShReport转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_AmlCheckNiShCus) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_AmlCheckNiShCus(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_AmlCheckNiShCus转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_AmlCheckNiShTrade) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_AmlCheckNiShTrade(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_AmlCheckNiShTrade转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_AmlCheckNiSsReport) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_AmlCheckNiSsReport(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_AmlCheckNiSsReport转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_AmlCheckNiSsCus) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_AmlCheckNiSsCus(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_AmlCheckNiSsCus转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_AmlCheckNiSsTrade) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_AmlCheckNiSsTrade(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_AmlCheckNiSsTrade转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_AmlCheckReportHis) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_AmlCheckReportHis(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_AmlCheckReportHis转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_AmlNiEnumMap) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_AmlNiEnumMap(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_AmlNiEnumMap转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_AmlDailyDrawStatus) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_AmlDailyDrawStatus(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_AmlDailyDrawStatus转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_AmlDrawSchedulerLog) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_AmlDrawSchedulerLog(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_AmlDrawSchedulerLog转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_DataGridConfig) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_DataGridConfig(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_DataGridConfig转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_DataGridConfigMember) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_DataGridConfigMember(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_DataGridConfigMember转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_Question) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_Question(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_Question转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_Answer) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_Answer(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_Answer转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_Paper) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_Paper(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_Paper转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_PaperQuestionMap) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_PaperQuestionMap(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_PaperQuestionMap转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_InvestorProprietyInfo) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_InvestorProprietyInfo(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_InvestorProprietyInfo转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_InvsProprietyInfoHis) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_InvsProprietyInfoHis(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_InvsProprietyInfoHis转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_RiskEvaluationLog) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_RiskEvaluationLog(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_RiskEvaluationLog转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_RiskEvaluationLogHis) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_RiskEvaluationLogHis(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_RiskEvaluationLogHis转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_InvestorClone) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_InvestorClone(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_InvestorClone转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ProprietyScoreRange) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ProprietyScoreRange(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ProprietyScoreRange转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CTPProductRiskLevel) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CTPProductRiskLevel(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CTPProductRiskLevel转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_Proctor) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_Proctor(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_Proctor转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_WeakPasswordLib) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_WeakPasswordLib(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_WeakPasswordLib转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_UserPasswordProfile) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_UserPasswordProfile(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_UserPasswordProfile转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_IPList) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_IPList(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_IPList转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_InvestorLowestRiskLevel) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_InvestorLowestRiskLevel(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_InvestorLowestRiskLevel转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_SpecTRStrategy) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_SpecTRStrategy(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_SpecTRStrategy转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_SpecTRStrategyApply) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_SpecTRStrategyApply(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_SpecTRStrategyApply转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_FutGeneralTradingRight) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_FutGeneralTradingRight(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_FutGeneralTradingRight转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_OptGeneralTradingRight) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_OptGeneralTradingRight(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_OptGeneralTradingRight转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_FutSpecTradingRight) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_FutSpecTradingRight(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_FutSpecTradingRight转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_OptSpecTradingRight) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_OptSpecTradingRight(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_OptSpecTradingRight转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_O_MutiTradingRight) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_O_MutiTradingRight(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_O_MutiTradingRight转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_O_TradingRightSnapshot) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_O_TradingRightSnapshot(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_O_TradingRightSnapshot转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_O_SpecTRStrategy) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_O_SpecTRStrategy(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_O_SpecTRStrategy转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_O_SpecTRStrategyApply) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_O_SpecTRStrategyApply(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_O_SpecTRStrategyApply转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_O_FutTradingRight) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_O_FutTradingRight(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_O_FutTradingRight转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_O_OptTradingRight) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_O_OptTradingRight(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_O_OptTradingRight转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CloudOpenLog) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CloudOpenLog(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CloudOpenLog转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_SmsCode) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_SmsCode(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_SmsCode转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_InvestorProprietyInfoNew) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_InvestorProprietyInfoNew(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_InvestorProprietyInfoNew转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_InvestorProprietyLog) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_InvestorProprietyLog(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_InvestorProprietyLog转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_TmpParam) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_TmpParam(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_TmpParam转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_ProprietyScoreRangeNew) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_ProprietyScoreRangeNew(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_ProprietyScoreRangeNew转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CloudAccountIDRule) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CloudAccountIDRule(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CloudAccountIDRule转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CloudBranchMap) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CloudBranchMap(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CloudBranchMap转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CloudExApply) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CloudExApply(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CloudExApply转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_InvestorProprietyExInfo) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_InvestorProprietyExInfo(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_InvestorProprietyExInfo转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CloudPartBroker) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CloudPartBroker(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CloudPartBroker转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_AssetInvestor) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_AssetInvestor(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_AssetInvestor转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CloudModifyInfoRecord) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CloudModifyInfoRecord(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CloudModifyInfoRecord转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CAPLog) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CAPLog(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;

---- 将tyt_CAPLog转换成VARCHAR2
  FUNCTION uf_Tyt2String(i_type IN tyt_CAPInfo) RETURN VARCHAR2
  IS
    l_string VARCHAR2(3500);
  BEGIN
    IF i_type IS NULL THEN
  	  RETURN 'NULL';
  	END IF;

  	l_string := 'tyt_CAPInfo(';
  	FOR i IN 1 .. i_type.COUNT
  	LOOP
  	  IF i = 1 THEN
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || 'NULL';
        ELSE
  	      l_string := l_string || CHR(10) || i_type(i).uf_toString();
        END IF;
  	  ELSE
        IF i_type(i) IS NULL THEN
          l_string := l_string || CHR(10) || ',' || 'NULL';
  	    ELSE
  	      l_string := l_string || CHR(10) || ',' || i_type(i).uf_toString();
  	    END IF;
  	  END IF;
  	END LOOP;
  	l_string := l_string || ')';
    RETURN l_string;

  EXCEPTION
      WHEN OTHERS THEN
        RETURN l_string;
  END;


-- *** END PUMP GENERATED PACKAGE BODY *** --

END PKGS_Tyt2STRING;
/

