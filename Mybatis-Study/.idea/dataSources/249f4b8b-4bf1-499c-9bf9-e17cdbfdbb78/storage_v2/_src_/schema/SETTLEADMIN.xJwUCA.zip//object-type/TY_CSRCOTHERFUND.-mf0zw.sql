create TYPE Ty_CSRCOtherFund AS OBJECT
(
    BrokerID CHAR(10),  --经纪公司代码
    TradingDay CHAR(8),  --交易日
    InvestorID CHAR(12),  --投资者代码
    ExchangeID CHAR(8),  --交易所代码
    FundProjectID CHAR(4),  --资金项目编号
    ClientID CHAR(10),  --客户编码
    OrgDeposit NUMBER(22,6),  --原资金金额
    Deposit NUMBER(22,6),  --录入资金金额
    Memo CHAR(160),  --备注
    OperatorID CHAR(64),  --录入员代码
    OperateDate CHAR(8),  --录入日期
    OperateTime CHAR(8),  --录入时间
    CheckerID CHAR(64),  --复核员代码
    CheckDate CHAR(8),  --复核日期
    CheckTime CHAR(8),  --复核时间

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_CSRCOtherFund RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

