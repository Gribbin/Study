create TYPE BODY Ty_BrokerFund IS

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_BrokerFund RETURN SELF AS RESULT IS
  BEGIN
    RETURN;
  END;

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2 IS
    l_string VARCHAR2(4000);
  BEGIN
    l_string:='ty_BrokerFund('
      || 'TradingDay=>' || '''' || trim(TradingDay) || '''' --交易日
      || ',BrokerID=>' || '''' || trim(BrokerID) || '''' --经纪公司代码
      || ',ExchangeID=>' || '''' || trim(ExchangeID) || '''' --交易所代码
      || ',AccountID=>' || '''' || trim(AccountID) || '''' --资金账号
      || ',CurrencyID=>' || '''' || trim(CurrencyID) || '''' --资金账号币种
      || ',Deposit=>' || NVL(to_char(Deposit),'NULL')--存款额
      || ',LastDeposit=>' || NVL(to_char(LastDeposit),'NULL')--昨日存款额
      || ',Remain=>' || NVL(to_char(Remain),'NULL')--结算准备金余额
      || ',Prepa=>' || NVL(to_char(Prepa),'NULL')--开仓准备金
      || ',WithdrawQuota=>' || NVL(to_char(WithdrawQuota),'NULL')--提款限额
      || ',FundOut=>' || NVL(to_char(FundOut),'NULL')--出金金额
      || ',FundIn=>' || NVL(to_char(FundIn),'NULL')--入金金额
      || ',Mortgage=>' || NVL(to_char(Mortgage),'NULL')--质押金额
      || ',Margin=>' || NVL(to_char(Margin),'NULL')--保证金总额
      || ',SMargin=>' || NVL(to_char(SMargin),'NULL')--投机保证金
      || ',HMargin=>' || NVL(to_char(HMargin),'NULL')--保值保证金
      || ',DelivMargin=>' || NVL(to_char(DelivMargin),'NULL')--交割保证金
      || ',ExchMargin=>' || NVL(to_char(ExchMargin),'NULL')--交易所保证金总额
      || ',ExchSMargin=>' || NVL(to_char(ExchSMargin),'NULL')--交易所投机保证金
      || ',ExchHMargin=>' || NVL(to_char(ExchHMargin),'NULL')--交易所保值保证金
      || ',ExchDelivMargin=>' || NVL(to_char(ExchDelivMargin),'NULL')--交易所交割保证金
      || ',CloseProfit=>' || NVL(to_char(CloseProfit),'NULL')--平仓盈亏
      || ',PositionProfit=>' || NVL(to_char(PositionProfit),'NULL')--持仓盈亏
      || ',Actual=>' || NVL(to_char(Actual),'NULL')--当日盈亏
      || ',FloatProfit=>' || NVL(to_char(FloatProfit),'NULL')--浮动盈亏
      || ',TransFee=>' || NVL(to_char(TransFee),'NULL')--交易手续费
      || ',DelivFee=>' || NVL(to_char(DelivFee),'NULL')--交割手续费
      || ',SettlementFee=>' || NVL(to_char(SettlementFee),'NULL')--结算手续费
      || ',TransferPosFee=>' || NVL(to_char(TransferPosFee),'NULL')--移仓手续费
      || ',StrikeFee=>' || NVL(to_char(StrikeFee),'NULL')--执行手续费
      || ',PerformFee=>' || NVL(to_char(PerformFee),'NULL')--履约手续费
      || ',ExchTransFee=>' || NVL(to_char(ExchTransFee),'NULL')--交易所交易手续费
      || ',ExchDelivFee=>' || NVL(to_char(ExchDelivFee),'NULL')--交易所交割手续费
      || ',ExchSettlementFee=>' || NVL(to_char(ExchSettlementFee),'NULL')--交易所结算手续费
      || ',ExchTransferPosFee=>' || NVL(to_char(ExchTransferPosFee),'NULL')--交易所移仓手续费
      || ',ExchStrikeFee=>' || NVL(to_char(ExchStrikeFee),'NULL')--交易所执行手续费
      || ',ExchPerformFee=>' || NVL(to_char(ExchPerformFee),'NULL')--交易所履约手续费
      || ',OptPremiumIncome=>' || NVL(to_char(OptPremiumIncome),'NULL')--期权权利金收入
      || ',OptPremiumPay=>' || NVL(to_char(OptPremiumPay),'NULL')--期权权利金支出
      || ',OptStrikeProfit=>' || NVL(to_char(OptStrikeProfit),'NULL')--期权执行盈亏
      || ')';


    RETURN l_string;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN NULL;
  END;



END;
/

