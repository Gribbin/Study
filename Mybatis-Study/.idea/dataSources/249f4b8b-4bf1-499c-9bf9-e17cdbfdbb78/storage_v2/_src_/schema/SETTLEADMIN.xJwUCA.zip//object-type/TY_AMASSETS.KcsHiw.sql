create TYPE Ty_AmAssets AS OBJECT
(
    TradingDay CHAR(10),  --交易日
    ParticipantID CHAR(10),  --会员代码
    InvestorID CHAR(12),  --客户内部资金账户
    Actual NUMBER(15,3),  --当日盈亏
    Deposit NUMBER(15,3),  --净值总额
    CurrencyID CHAR(3),  --币种
    Memo CHAR(40),  --说明

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_AmAssets RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

