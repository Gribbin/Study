create TYPE BODY Ty_AMLNotReport IS

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_AMLNotReport RETURN SELF AS RESULT IS
  BEGIN
    RETURN;
  END;

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2 IS
    l_string VARCHAR2(4000);
  BEGIN
    l_string:='ty_AMLNotReport('
      || 'BrokerID=>' || '''' || trim(BrokerID) || '''' --经纪公司代码
      || ',InvestorRange=>' || '''' || trim(InvestorRange) || '''' --投资者范围
      || ',InvestorID=>' || '''' || trim(InvestorID) || '''' --投资者代码
      || ',ReportTypeID=>' || '''' || trim(ReportTypeID) || '''' --报告类型
      || ',CharacterID=>' || '''' || trim(CharacterID) || '''' --特征代码
      || ',OperatorID=>' || '''' || trim(OperatorID) || '''' --录入员代码
      || ',OperateDate=>' || '''' || trim(OperateDate) || '''' --录入日期
      || ',OperateTime=>' || '''' || trim(OperateTime) || '''' --录入时间
      || ')';


    RETURN l_string;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN NULL;
  END;



END;
/

