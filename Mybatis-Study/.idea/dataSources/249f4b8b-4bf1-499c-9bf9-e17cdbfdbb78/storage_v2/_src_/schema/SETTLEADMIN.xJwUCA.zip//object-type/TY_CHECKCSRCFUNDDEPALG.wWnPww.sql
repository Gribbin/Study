create TYPE Ty_CheckCSRCFundDepAlg AS OBJECT
(
    IsSame NUMBER(1),  --是否相同
    TradingDay CHAR(8),  --交易日
    InvestorID CHAR(12),  --投资者编码
    InvestorName VARCHAR2(80),  --投资者名称
    CurrencyID CHAR(3),  --币种
    diffvalue NUMBER(22,6),  --差值
    deposit NUMBER(22,6),  --本日结存
    lastdepositbydate NUMBER(22,6),  --上日结存(逐日盯市)
    fundio NUMBER(22,6),  --出入金
    profit NUMBER(22,6),  --当日盈亏
    fee NUMBER(22,6),  --手续费
    mortgage NUMBER(22,6),  --质押金
    fundmortgage NUMBER(22,6),  --货币质押金额
    delivery NUMBER(22,6),  --交割货款
    other NUMBER(22,6),  --其他分项资金
    optpremiummoney NUMBER(22,6),  --权利金

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_CheckCSRCFundDepAlg RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

