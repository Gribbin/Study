create TYPE Ty_CRAPersonBlackList AS OBJECT
(
    BrokerID CHAR(10),  --经纪商代码
    PersonName VARCHAR2(50),  --姓名
    PersonBlackListType CHAR(1),  --人员类型
    IdentifiedCardType CHAR(1),  --证件类型
    IdentifiedCardNo CHAR(50),  --证件号码
    Area CHAR(100),  --地址

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_CRAPersonBlackList RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

