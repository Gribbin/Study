create TYPE BODY Ty_CRARiskFactor IS

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_CRARiskFactor RETURN SELF AS RESULT IS
  BEGIN
    RETURN;
  END;

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2 IS
    l_string VARCHAR2(4000);
  BEGIN
    l_string:='ty_CRARiskFactor('
      || 'BrokerID=>' || '''' || trim(BrokerID) || '''' --经纪商代码
      || ',RiskFactorID=>' || NVL(to_char(RiskFactorID),'NULL')--风险因素ID
      || ',RiskFactorName=>' || '''' || trim(RiskFactorName) || '''' --名称
      || ',RiskFactorWeight=>' || NVL(to_char(RiskFactorWeight),'NULL')--权重
      || ',IsAddItem=>' || '''' || trim(IsAddItem) || '''' --是否附加项
      || ')';


    RETURN l_string;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN NULL;
  END;



END;
/

