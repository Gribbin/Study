create TYPE BODY Ty_AmlInvstChangeChkParam IS

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_AmlInvstChangeChkParam RETURN SELF AS RESULT IS
  BEGIN
    RETURN;
  END;

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2 IS
    l_string VARCHAR2(4000);
  BEGIN
    l_string:='ty_AmlInvstChangeChkParam('
      || 'BrokerID=>' || '''' || trim(BrokerID) || '''' --经纪公司代码
      || ',AmlinvstchangeChkParamID=>' || '''' || trim(AmlinvstchangeChkParamID) || '''' --识别身份变更参数代码
      || ',AmlInvstchangeChkParamName=>' || '''' || trim(AmlInvstchangeChkParamName) || '''' --识别身份变更参数名称
      || ',isActive=>' || '''' || trim(isActive) || '''' --是否启用
      || ')';


    RETURN l_string;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN NULL;
  END;



END;
/

