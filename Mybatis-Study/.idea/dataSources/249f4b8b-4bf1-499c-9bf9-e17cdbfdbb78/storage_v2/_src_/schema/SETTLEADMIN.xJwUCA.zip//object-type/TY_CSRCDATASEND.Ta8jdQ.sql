create TYPE Ty_CSRCDataSend AS OBJECT
(
    TradingDay CHAR(8),  --交易日
    ParticipantID CHAR(10),  --会员代码
    IsConfirm NUMBER(1),  --是否保证发送成功
    IsSend NUMBER(1),  --是否已经发送

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_CSRCDataSend RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

