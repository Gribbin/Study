create TYPE Ty_CRAAreaBlackListPerson AS OBJECT
(
    BrokerID CHAR(10),  --经纪商代码
    InvestorID CHAR(12),  --投资者代码
    AreaBlackListType CHAR(1),  --地域黑名单类型
    Area CHAR(15),  --地域
    DataSource CHAR(1),  --数据来源

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_CRAAreaBlackListPerson RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

