create TYPE Ty_CFFEXSettle AS OBJECT
(
    TradingDay CHAR(8),  --交易日
    ExchangeID CHAR(8),  --交易所代码
    ParticipantID CHAR(10),  --会员代码
    AccountID CHAR(14),  --资金账号
    CurrencyID CHAR(3),  --资金账号币种
    ExchangeInstID CHAR(30),  --合约代码
    SettlementPrice NUMBER(19,10),  --结算价
    AccountProperty CHAR(160),  --账号属性
    BuyAmt NUMBER(20),  --买成交量合计
    SellAmt NUMBER(20),  --卖成交量合计
    BuyOpenAmt NUMBER(20),  --买开成交量
    SellOpenAmt NUMBER(20),  --卖开成交量
    BuyCloseAmt NUMBER(20),  --买平成交量
    SellCloseAmt NUMBER(20),  --卖平成交量
    BTotalAmt NUMBER(20),  --买持仓量合计
    STotalAmt NUMBER(20),  --卖持仓量合计
    BuySum NUMBER(22,6),  --买入成交额
    SellSum NUMBER(22,6),  --卖出成交额
    Margin NUMBER(22,6),  --交易保证金
    Transfee NUMBER(22,6),  --费用合计
    Actual NUMBER(22,6),  --当日盈亏
    OptPremiumMoney NUMBER(22,6),  --权利金

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_CFFEXSettle RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

