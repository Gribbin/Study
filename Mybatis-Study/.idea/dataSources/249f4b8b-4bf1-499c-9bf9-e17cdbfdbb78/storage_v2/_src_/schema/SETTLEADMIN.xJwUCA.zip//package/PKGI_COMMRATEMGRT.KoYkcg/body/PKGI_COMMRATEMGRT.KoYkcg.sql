create PACKAGE BODY PKGI_CommRateMgrt  IS
  /*************************************************************************
  $spDesc 新增手续费盘中同步参数
  *************************************************************************/
  PROCEDURE up_InsCommSyncPara
  (
     i_tySysSettleParam IN TY_SYSSETTLEPARAM  --系统结算参数
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_CommRateMgrt.up_InsCommSyncPara';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '新增手续费盘中同步参数';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '手续费管理', '新增手续费盘中同步参数');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_CommRateMgrt.up_InsCommSyncPara(' ||
                           i_tySysSettleParam.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_CommRateMgrt.up_InsCommSyncPara(
                               i_tySysSettleParam
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_InsCommSyncPara;

  /*************************************************************************
  $spDesc 修改手续费盘中同步参数
  *************************************************************************/
  PROCEDURE up_UpdCommSyncPara
  (
     i_tySysSettleParam IN TY_SYSSETTLEPARAM  --系统结算参数
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_CommRateMgrt.up_UpdCommSyncPara';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '修改手续费盘中同步参数';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '手续费管理', '修改手续费盘中同步参数');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_CommRateMgrt.up_UpdCommSyncPara(' ||
                           i_tySysSettleParam.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_CommRateMgrt.up_UpdCommSyncPara(
                               i_tySysSettleParam
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_UpdCommSyncPara;

  /*************************************************************************
  $spDesc 新增投资者期货手续费
  *************************************************************************/
  PROCEDURE up_InsInvstFutComm
  (
     i_tytInvstFutComm IN TYT_INVSTFUTCOMMEX  --投资者期货手续费信息
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_CommRateMgrt.up_InsInvstFutComm';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '新增投资者期货手续费';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '手续费管理', '新增投资者期货手续费');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_CommRateMgrt.up_InsInvstFutComm(' ||
                           PKGS_Tyt2STRINGEx.uf_Tyt2String(i_tytInvstFutComm)
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_CommRateMgrt.up_InsInvstFutComm(
                               i_tytInvstFutComm
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_InsInvstFutComm;

  /*************************************************************************
  $spDesc 新增投资者期货手续费
  *************************************************************************/
  PROCEDURE up_IncreaseInvstFutComm
  (
     i_tytInvstFutComm IN TYT_INVSTFUTCOMMEX  --投资者期货手续费信息
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_CommRateMgrt.up_IncreaseInvstFutComm';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '新增投资者期货手续费';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '手续费管理', '新增投资者期货手续费');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_CommRateMgrt.up_IncreaseInvstFutComm(' ||
                           PKGS_Tyt2STRINGEx.uf_Tyt2String(i_tytInvstFutComm)
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_CommRateMgrt.up_IncreaseInvstFutComm(
                               i_tytInvstFutComm
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_IncreaseInvstFutComm;

  /*************************************************************************
  $spDesc 修改投资者期货手续费
  *************************************************************************/
  PROCEDURE up_UpdInvstFutComm
  (
     i_tytInvstFutComm IN TYT_INVSTFUTCOMMEX  --投资者期货手续费信息
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_CommRateMgrt.up_UpdInvstFutComm';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '修改投资者期货手续费';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '手续费管理', '修改投资者期货手续费');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_CommRateMgrt.up_UpdInvstFutComm(' ||
                           PKGS_Tyt2STRINGEx.uf_Tyt2String(i_tytInvstFutComm)
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_CommRateMgrt.up_UpdInvstFutComm(
                               i_tytInvstFutComm
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_UpdInvstFutComm;

  /*************************************************************************
  $spDesc 修改投资者期货手续费
  *************************************************************************/
  PROCEDURE up_UpdateInvstFutComm
  (
     i_tytInvstFutComm IN TYT_INVSTFUTCOMMEX  --投资者期货手续费信息
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_CommRateMgrt.up_UpdateInvstFutComm';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '修改投资者期货手续费';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '手续费管理', '修改投资者期货手续费');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_CommRateMgrt.up_UpdateInvstFutComm(' ||
                           PKGS_Tyt2STRINGEx.uf_Tyt2String(i_tytInvstFutComm)
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_CommRateMgrt.up_UpdateInvstFutComm(
                               i_tytInvstFutComm
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_UpdateInvstFutComm;

  /*************************************************************************
  $spDesc 删除投资者期货手续费
  *************************************************************************/
  PROCEDURE up_DelInvstFutComm
  (
     i_tytInvstFutComm IN TYT_INVSTFUTCOMMEX  --投资者期货手续费信息
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_CommRateMgrt.up_DelInvstFutComm';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '删除投资者期货手续费';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '手续费管理', '删除投资者期货手续费');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_CommRateMgrt.up_DelInvstFutComm(' ||
                           PKGS_Tyt2STRINGEx.uf_Tyt2String(i_tytInvstFutComm)
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_CommRateMgrt.up_DelInvstFutComm(
                               i_tytInvstFutComm
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_DelInvstFutComm;

  /*************************************************************************
  $spDesc 删除投资者期货手续费
  *************************************************************************/
  PROCEDURE up_DeleteInvstFutComm
  (
     i_tytInvstFutComm IN TYT_INVSTFUTCOMMEX  --投资者期货手续费信息
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_CommRateMgrt.up_DeleteInvstFutComm';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '删除投资者期货手续费';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '手续费管理', '删除投资者期货手续费');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_CommRateMgrt.up_DeleteInvstFutComm(' ||
                           PKGS_Tyt2STRINGEx.uf_Tyt2String(i_tytInvstFutComm)
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_CommRateMgrt.up_DeleteInvstFutComm(
                               i_tytInvstFutComm
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_DeleteInvstFutComm;

  /*************************************************************************
  $spDesc 新增投资者所期货结算手续费
  *************************************************************************/
  PROCEDURE up_InsInvstFutSettleComm
  (
     i_tytInvstFutSettleComm IN TYT_INVSTFUTSETTLECOMMRATE  --投资者期货结算手续费信息
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_CommRateMgrt.up_InsInvstFutSettleComm';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '新增投资者所期货结算手续费';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '手续费管理', '新增投资者所期货结算手续费');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_CommRateMgrt.up_InsInvstFutSettleComm(' ||
                           PKGS_Tyt2STRING.uf_Tyt2String(i_tytInvstFutSettleComm)
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_CommRateMgrt.up_InsInvstFutSettleComm(
                               i_tytInvstFutSettleComm
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_InsInvstFutSettleComm;

  /*************************************************************************
  $spDesc 新增投资者所期货结算手续费
  *************************************************************************/
  PROCEDURE up_InsInvstFutSettComm
  (
     i_tytInvstFutSettleComm IN TYT_INVSTFUTSETTLECOMMRATE  --投资者期货结算手续费信息
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_CommRateMgrt.up_InsInvstFutSettComm';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '新增投资者所期货结算手续费';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '手续费管理', '新增投资者所期货结算手续费');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_CommRateMgrt.up_InsInvstFutSettComm(' ||
                           PKGS_Tyt2STRING.uf_Tyt2String(i_tytInvstFutSettleComm)
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_CommRateMgrt.up_InsInvstFutSettComm(
                               i_tytInvstFutSettleComm
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_InsInvstFutSettComm;

  /*************************************************************************
  $spDesc 修改投资者所期货结算手续费
  *************************************************************************/
  PROCEDURE up_UpdInvstFutSettleComm
  (
     i_tytInvstFutSettleComm IN TYT_INVSTFUTSETTLECOMMRATE  --投资者期货结算手续费信息
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_CommRateMgrt.up_UpdInvstFutSettleComm';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '修改投资者所期货结算手续费';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '手续费管理', '修改投资者所期货结算手续费');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_CommRateMgrt.up_UpdInvstFutSettleComm(' ||
                           PKGS_Tyt2STRING.uf_Tyt2String(i_tytInvstFutSettleComm)
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_CommRateMgrt.up_UpdInvstFutSettleComm(
                               i_tytInvstFutSettleComm
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_UpdInvstFutSettleComm;

  /*************************************************************************
  $spDesc 修改投资者所期货结算手续费
  *************************************************************************/
  PROCEDURE up_UpdInvstFutSettComm
  (
     i_tytInvstFutSettleComm IN TYT_INVSTFUTSETTLECOMMRATE  --投资者期货结算手续费信息
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_CommRateMgrt.up_UpdInvstFutSettComm';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '修改投资者所期货结算手续费';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '手续费管理', '修改投资者所期货结算手续费');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_CommRateMgrt.up_UpdInvstFutSettComm(' ||
                           PKGS_Tyt2STRING.uf_Tyt2String(i_tytInvstFutSettleComm)
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_CommRateMgrt.up_UpdInvstFutSettComm(
                               i_tytInvstFutSettleComm
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_UpdInvstFutSettComm;

  /*************************************************************************
  $spDesc 删除投资者所期货结算手续费
  *************************************************************************/
  PROCEDURE up_DelInvstFutSettleComm
  (
     i_tytInvstFutSettleComm IN TYT_INVSTFUTSETTLECOMMRATE  --投资者期货结算手续费信息
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_CommRateMgrt.up_DelInvstFutSettleComm';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '删除投资者所期货结算手续费';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '手续费管理', '删除投资者所期货结算手续费');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_CommRateMgrt.up_DelInvstFutSettleComm(' ||
                           PKGS_Tyt2STRING.uf_Tyt2String(i_tytInvstFutSettleComm)
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_CommRateMgrt.up_DelInvstFutSettleComm(
                               i_tytInvstFutSettleComm
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_DelInvstFutSettleComm;

  /*************************************************************************
  $spDesc 删除投资者所期货结算手续费
  *************************************************************************/
  PROCEDURE up_DelInvstFutSettComm
  (
     i_tytInvstFutSettleComm IN TYT_INVSTFUTSETTLECOMMRATE  --投资者期货结算手续费信息
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_CommRateMgrt.up_DelInvstFutSettComm';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '删除投资者所期货结算手续费';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '手续费管理', '删除投资者所期货结算手续费');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_CommRateMgrt.up_DelInvstFutSettComm(' ||
                           PKGS_Tyt2STRING.uf_Tyt2String(i_tytInvstFutSettleComm)
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_CommRateMgrt.up_DelInvstFutSettComm(
                               i_tytInvstFutSettleComm
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_DelInvstFutSettComm;

  /*************************************************************************
  $spDesc 查询投资者所期货结算手续费
  *************************************************************************/
  PROCEDURE up_QryInvstFutSettleComm
  (
     i_tytInvstFutSettleComm IN TYT_INVSTFUTSETTLECOMMRATE  --投资者期货结算手续费信息
    ,i_tyPage IN  TY_PAGE  --分页信息
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_curInvstFutSettleComm OUT NOCOPY PKGS_DATATYPE.TYPEREFCURSOR  --查询结果游标
    ,o_nCount OUT PKGS_DATATYPE.STY_COUNT  --记录数
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_CommRateMgrt.up_QryInvstFutSettleComm';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '查询投资者所期货结算手续费';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '手续费管理', '查询投资者所期货结算手续费');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_CommRateMgrt.up_QryInvstFutSettleComm(' ||
                           PKGS_Tyt2STRING.uf_Tyt2String(i_tytInvstFutSettleComm)
                      || ',' ||
                           i_tyPage.uf_toString()
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_curInvstFutSettleComm'
                      || ',' ||
                        'o_nCount'
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_CommRateMgrt.up_QryInvstFutSettleComm(
                               i_tytInvstFutSettleComm
                              ,i_tyPage
                              ,i_chLanguage
                              ,o_curInvstFutSettleComm
                              ,o_nCount
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_QryInvstFutSettleComm;

  /*************************************************************************
  $spDesc 新增交易所期货移仓手续费
  *************************************************************************/
  PROCEDURE up_InsExchFutTransComm
  (
     i_ExchFutTransferCommRate IN TYT_EXCHFUTTRANSFERCOMMRATE  --交易所期货移仓手续费信息
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_CommRateMgrt.up_InsExchFutTransComm';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '新增交易所期货移仓手续费';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '手续费管理', '新增交易所期货移仓手续费');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_CommRateMgrt.up_InsExchFutTransComm(' ||
                           PKGS_Tyt2STRING.uf_Tyt2String(i_ExchFutTransferCommRate)
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_CommRateMgrt.up_InsExchFutTransComm(
                               i_ExchFutTransferCommRate
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_InsExchFutTransComm;

  /*************************************************************************
  $spDesc 修改交易所期货移仓手续费
  *************************************************************************/
  PROCEDURE up_UpdExchFutTransComm
  (
     i_ExchFutTransferCommRate IN TYT_EXCHFUTTRANSFERCOMMRATE  --交易所期货移仓手续费信息
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_CommRateMgrt.up_UpdExchFutTransComm';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '修改交易所期货移仓手续费';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '手续费管理', '修改交易所期货移仓手续费');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_CommRateMgrt.up_UpdExchFutTransComm(' ||
                           PKGS_Tyt2STRING.uf_Tyt2String(i_ExchFutTransferCommRate)
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_CommRateMgrt.up_UpdExchFutTransComm(
                               i_ExchFutTransferCommRate
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_UpdExchFutTransComm;

  /*************************************************************************
  $spDesc 删除交易所期货移仓手续费
  *************************************************************************/
  PROCEDURE up_DelExchFutTransComm
  (
     i_ExchFutTransferCommRate IN TYT_EXCHFUTTRANSFERCOMMRATE  --交易所期货移仓手续费信息
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_CommRateMgrt.up_DelExchFutTransComm';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '删除交易所期货移仓手续费';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '手续费管理', '删除交易所期货移仓手续费');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_CommRateMgrt.up_DelExchFutTransComm(' ||
                           PKGS_Tyt2STRING.uf_Tyt2String(i_ExchFutTransferCommRate)
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_CommRateMgrt.up_DelExchFutTransComm(
                               i_ExchFutTransferCommRate
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_DelExchFutTransComm;

  /*************************************************************************
  $spDesc 查询交易所期货移仓手续费
  *************************************************************************/
  PROCEDURE up_QryExchFutTransComm
  (
     i_ExchFutTransferCommRate IN TYT_EXCHFUTTRANSFERCOMMRATE  --交易所期货移仓手续费信息
    ,i_tyPage IN  TY_PAGE  --分页信息
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_curExchFutTransferCommRate OUT NOCOPY PKGS_DATATYPE.TYPEREFCURSOR  --查询结果游标
    ,o_nCount OUT PKGS_DATATYPE.STY_COUNT  --记录数
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_CommRateMgrt.up_QryExchFutTransComm';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '查询交易所期货移仓手续费';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '手续费管理', '查询交易所期货移仓手续费');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_CommRateMgrt.up_QryExchFutTransComm(' ||
                           PKGS_Tyt2STRING.uf_Tyt2String(i_ExchFutTransferCommRate)
                      || ',' ||
                           i_tyPage.uf_toString()
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_curExchFutTransferCommRate'
                      || ',' ||
                        'o_nCount'
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_CommRateMgrt.up_QryExchFutTransComm(
                               i_ExchFutTransferCommRate
                              ,i_tyPage
                              ,i_chLanguage
                              ,o_curExchFutTransferCommRate
                              ,o_nCount
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_QryExchFutTransComm;

  /*************************************************************************
  $spDesc 新增投资者期货移仓手续费
  *************************************************************************/
  PROCEDURE up_InsInvstFutTransferComm
  (
     i_InvstFutTransferCommRate IN TYT_INVSTFUTCOMMEX  --投资者期货移仓手续费信息
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_CommRateMgrt.up_InsInvstFutTransferComm';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '新增投资者期货移仓手续费';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '手续费管理', '新增投资者期货移仓手续费');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_CommRateMgrt.up_InsInvstFutTransferComm(' ||
                           PKGS_Tyt2STRINGEx.uf_Tyt2String(i_InvstFutTransferCommRate)
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_CommRateMgrt.up_InsInvstFutTransferComm(
                               i_InvstFutTransferCommRate
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_InsInvstFutTransferComm;

  /*************************************************************************
  $spDesc 新增投资者期货移仓手续费
  *************************************************************************/
  PROCEDURE up_InsInvstFutTransComm
  (
     i_InvstFutTransferCommRate IN TYT_INVSTFUTCOMMEX  --投资者期货移仓手续费信息
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_CommRateMgrt.up_InsInvstFutTransComm';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '新增投资者期货移仓手续费';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '手续费管理', '新增投资者期货移仓手续费');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_CommRateMgrt.up_InsInvstFutTransComm(' ||
                           PKGS_Tyt2STRINGEx.uf_Tyt2String(i_InvstFutTransferCommRate)
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_CommRateMgrt.up_InsInvstFutTransComm(
                               i_InvstFutTransferCommRate
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_InsInvstFutTransComm;

  /*************************************************************************
  $spDesc 删除投资者期货移仓手续费
  *************************************************************************/
  PROCEDURE up_DelInvstFutTransferComm
  (
     i_InvstFutTransferCommRate IN TYT_INVSTFUTCOMMEX  --投资者期货移仓手续费信息
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_CommRateMgrt.up_DelInvstFutTransferComm';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '删除投资者期货移仓手续费';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '手续费管理', '删除投资者期货移仓手续费');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_CommRateMgrt.up_DelInvstFutTransferComm(' ||
                           PKGS_Tyt2STRINGEx.uf_Tyt2String(i_InvstFutTransferCommRate)
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_CommRateMgrt.up_DelInvstFutTransferComm(
                               i_InvstFutTransferCommRate
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_DelInvstFutTransferComm;

  /*************************************************************************
  $spDesc 删除投资者期货移仓手续费
  *************************************************************************/
  PROCEDURE up_DelInvstFutTransComm
  (
     i_InvstFutTransferCommRate IN TYT_INVSTFUTCOMMEX  --投资者期货移仓手续费信息
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_CommRateMgrt.up_DelInvstFutTransComm';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '删除投资者期货移仓手续费';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '手续费管理', '删除投资者期货移仓手续费');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_CommRateMgrt.up_DelInvstFutTransComm(' ||
                           PKGS_Tyt2STRINGEx.uf_Tyt2String(i_InvstFutTransferCommRate)
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_CommRateMgrt.up_DelInvstFutTransComm(
                               i_InvstFutTransferCommRate
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_DelInvstFutTransComm;

  /*************************************************************************
  $spDesc 新增投资者期货移仓手续费
  *************************************************************************/
  PROCEDURE up_UpdInvstFutTransferComm
  (
     i_InvstFutTransferCommRate IN TYT_INVSTFUTCOMMEX  --修改者期货移仓手续费信息
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_CommRateMgrt.up_UpdInvstFutTransferComm';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '新增投资者期货移仓手续费';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '手续费管理', '新增投资者期货移仓手续费');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_CommRateMgrt.up_UpdInvstFutTransferComm(' ||
                           PKGS_Tyt2STRINGEx.uf_Tyt2String(i_InvstFutTransferCommRate)
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_CommRateMgrt.up_UpdInvstFutTransferComm(
                               i_InvstFutTransferCommRate
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_UpdInvstFutTransferComm;

  /*************************************************************************
  $spDesc 新增投资者期货移仓手续费
  *************************************************************************/
  PROCEDURE up_UpdInvstFutTransComm
  (
     i_InvstFutTransferCommRate IN TYT_INVSTFUTCOMMEX  --修改者期货移仓手续费信息
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_CommRateMgrt.up_UpdInvstFutTransComm';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '新增投资者期货移仓手续费';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '手续费管理', '新增投资者期货移仓手续费');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_CommRateMgrt.up_UpdInvstFutTransComm(' ||
                           PKGS_Tyt2STRINGEx.uf_Tyt2String(i_InvstFutTransferCommRate)
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_CommRateMgrt.up_UpdInvstFutTransComm(
                               i_InvstFutTransferCommRate
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_UpdInvstFutTransComm;

  /*************************************************************************
  $spDesc 查询投资者期货移仓手续费
  *************************************************************************/
  PROCEDURE up_QryInvstFutTransferComm
  (
     i_InvstFutTransferCommRate IN TYT_INVSTFUTTRANSFERCOMMRATE  --交易所期货移仓手续费信息
    ,i_tyPage IN  TY_PAGE  --分页信息
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_curInvstFutTransferCommRate OUT NOCOPY PKGS_DATATYPE.TYPEREFCURSOR  --查询结果游标
    ,o_nCount OUT PKGS_DATATYPE.STY_COUNT  --记录数
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_CommRateMgrt.up_QryInvstFutTransferComm';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '查询投资者期货移仓手续费';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '手续费管理', '查询投资者期货移仓手续费');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_CommRateMgrt.up_QryInvstFutTransferComm(' ||
                           PKGS_Tyt2STRING.uf_Tyt2String(i_InvstFutTransferCommRate)
                      || ',' ||
                           i_tyPage.uf_toString()
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_curInvstFutTransferCommRate'
                      || ',' ||
                        'o_nCount'
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_CommRateMgrt.up_QryInvstFutTransferComm(
                               i_InvstFutTransferCommRate
                              ,i_tyPage
                              ,i_chLanguage
                              ,o_curInvstFutTransferCommRate
                              ,o_nCount
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_QryInvstFutTransferComm;

  /*************************************************************************
  $spDesc 新增投资者期货保障基金手续费
  *************************************************************************/
  PROCEDURE up_InsInvstFutGUARFundComm
  (
     i_InvstFutGUARFundCommRate IN TYT_INVSTFUTGUARFUNDCOMMRATE  --投资者期货保障基金手续费信息
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_CommRateMgrt.up_InsInvstFutGUARFundComm';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '新增投资者期货保障基金手续费';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '手续费管理', '新增投资者期货保障基金手续费');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_CommRateMgrt.up_InsInvstFutGUARFundComm(' ||
                           PKGS_Tyt2STRING.uf_Tyt2String(i_InvstFutGUARFundCommRate)
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_CommRateMgrt.up_InsInvstFutGUARFundComm(
                               i_InvstFutGUARFundCommRate
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_InsInvstFutGUARFundComm;

  /*************************************************************************
  $spDesc 新增投资者期货保障基金手续费
  *************************************************************************/
  PROCEDURE up_InsInvstFutGUARFComm
  (
     i_InvstFutGUARFundCommRate IN TYT_INVSTFUTGUARFUNDCOMMRATE  --投资者期货保障基金手续费信息
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_CommRateMgrt.up_InsInvstFutGUARFComm';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '新增投资者期货保障基金手续费';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '手续费管理', '新增投资者期货保障基金手续费');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_CommRateMgrt.up_InsInvstFutGUARFComm(' ||
                           PKGS_Tyt2STRING.uf_Tyt2String(i_InvstFutGUARFundCommRate)
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_CommRateMgrt.up_InsInvstFutGUARFComm(
                               i_InvstFutGUARFundCommRate
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_InsInvstFutGUARFComm;

  /*************************************************************************
  $spDesc 删除投资者期货保障基金手续费
  *************************************************************************/
  PROCEDURE up_DelInvstFutGUARFundComm
  (
     i_InvstFutGUARFundCommRate IN TYT_INVSTFUTGUARFUNDCOMMRATE  --投资者期货保障基金手续费信息
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_CommRateMgrt.up_DelInvstFutGUARFundComm';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '删除投资者期货保障基金手续费';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '手续费管理', '删除投资者期货保障基金手续费');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_CommRateMgrt.up_DelInvstFutGUARFundComm(' ||
                           PKGS_Tyt2STRING.uf_Tyt2String(i_InvstFutGUARFundCommRate)
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_CommRateMgrt.up_DelInvstFutGUARFundComm(
                               i_InvstFutGUARFundCommRate
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_DelInvstFutGUARFundComm;

  /*************************************************************************
  $spDesc 删除投资者期货保障基金手续费
  *************************************************************************/
  PROCEDURE up_DelInvstFutGUARFComm
  (
     i_InvstFutGUARFundCommRate IN TYT_INVSTFUTGUARFUNDCOMMRATE  --投资者期货保障基金手续费信息
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_CommRateMgrt.up_DelInvstFutGUARFComm';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '删除投资者期货保障基金手续费';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '手续费管理', '删除投资者期货保障基金手续费');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_CommRateMgrt.up_DelInvstFutGUARFComm(' ||
                           PKGS_Tyt2STRING.uf_Tyt2String(i_InvstFutGUARFundCommRate)
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_CommRateMgrt.up_DelInvstFutGUARFComm(
                               i_InvstFutGUARFundCommRate
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_DelInvstFutGUARFComm;

  /*************************************************************************
  $spDesc 修改投资者期货保障基金手续费
  *************************************************************************/
  PROCEDURE up_UpdInvstFutGUARFundComm
  (
     i_InvstFutGUARFundCommRate IN TYT_INVSTFUTGUARFUNDCOMMRATE  --投资者期货保障基金手续费信息
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_CommRateMgrt.up_UpdInvstFutGUARFundComm';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '修改投资者期货保障基金手续费';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '手续费管理', '修改投资者期货保障基金手续费');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_CommRateMgrt.up_UpdInvstFutGUARFundComm(' ||
                           PKGS_Tyt2STRING.uf_Tyt2String(i_InvstFutGUARFundCommRate)
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_CommRateMgrt.up_UpdInvstFutGUARFundComm(
                               i_InvstFutGUARFundCommRate
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_UpdInvstFutGUARFundComm;

  /*************************************************************************
  $spDesc 修改投资者期货保障基金手续费
  *************************************************************************/
  PROCEDURE up_UpdInvstFutGUARFComm
  (
     i_InvstFutGUARFundCommRate IN TYT_INVSTFUTGUARFUNDCOMMRATE  --投资者期货保障基金手续费信息
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_CommRateMgrt.up_UpdInvstFutGUARFComm';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '修改投资者期货保障基金手续费';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '手续费管理', '修改投资者期货保障基金手续费');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_CommRateMgrt.up_UpdInvstFutGUARFComm(' ||
                           PKGS_Tyt2STRING.uf_Tyt2String(i_InvstFutGUARFundCommRate)
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_CommRateMgrt.up_UpdInvstFutGUARFComm(
                               i_InvstFutGUARFundCommRate
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_UpdInvstFutGUARFComm;

  /*************************************************************************
  $spDesc 查询投资者期货保障基金手续费
  *************************************************************************/
  PROCEDURE up_QryInvstFutGUARFundComm
  (
     i_InvstFutGUARFundCommRate IN TYT_INVSTFUTGUARFUNDCOMMRATE  --交易所期货移仓手续费信息
    ,i_tyPage IN  TY_PAGE  --分页信息
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_curInvstFutGUARFundCommRate OUT NOCOPY PKGS_DATATYPE.TYPEREFCURSOR  --查询结果游标
    ,o_nCount OUT PKGS_DATATYPE.STY_COUNT  --记录数
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_CommRateMgrt.up_QryInvstFutGUARFundComm';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '查询投资者期货保障基金手续费';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '手续费管理', '查询投资者期货保障基金手续费');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_CommRateMgrt.up_QryInvstFutGUARFundComm(' ||
                           PKGS_Tyt2STRING.uf_Tyt2String(i_InvstFutGUARFundCommRate)
                      || ',' ||
                           i_tyPage.uf_toString()
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_curInvstFutGUARFundCommRate'
                      || ',' ||
                        'o_nCount'
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_CommRateMgrt.up_QryInvstFutGUARFundComm(
                               i_InvstFutGUARFundCommRate
                              ,i_tyPage
                              ,i_chLanguage
                              ,o_curInvstFutGUARFundCommRate
                              ,o_nCount
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_QryInvstFutGUARFundComm;

  /*************************************************************************
  $spDesc 新增交易所期货手续费
  *************************************************************************/
  PROCEDURE up_InsExchFutComm
  (
     i_tytExchFutComm IN TYT_EXCHFUTCOMMEX  --交易所期货手续费信息
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_CommRateMgrt.up_InsExchFutComm';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '新增交易所期货手续费';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '手续费管理', '新增交易所期货手续费');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_CommRateMgrt.up_InsExchFutComm(' ||
                           PKGS_Tyt2STRINGEx.uf_Tyt2String(i_tytExchFutComm)
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_CommRateMgrt.up_InsExchFutComm(
                               i_tytExchFutComm
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_InsExchFutComm;

  /*************************************************************************
  $spDesc 修改交易所期货手续费
  *************************************************************************/
  PROCEDURE up_UpdExchFutComm
  (
     i_tytExchFutComm IN TYT_EXCHFUTCOMMEX  --交易所期货手续费信息
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_CommRateMgrt.up_UpdExchFutComm';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '修改交易所期货手续费';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '手续费管理', '修改交易所期货手续费');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_CommRateMgrt.up_UpdExchFutComm(' ||
                           PKGS_Tyt2STRINGEx.uf_Tyt2String(i_tytExchFutComm)
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_CommRateMgrt.up_UpdExchFutComm(
                               i_tytExchFutComm
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_UpdExchFutComm;

  /*************************************************************************
  $spDesc 删除交易所期货手续费
  *************************************************************************/
  PROCEDURE up_DelExchFutComm
  (
     i_tytExchFutComm IN TYT_EXCHFUTCOMMEX  --交易所期货手续费信息
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_CommRateMgrt.up_DelExchFutComm';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '删除交易所期货手续费';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '手续费管理', '删除交易所期货手续费');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_CommRateMgrt.up_DelExchFutComm(' ||
                           PKGS_Tyt2STRINGEx.uf_Tyt2String(i_tytExchFutComm)
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_CommRateMgrt.up_DelExchFutComm(
                               i_tytExchFutComm
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_DelExchFutComm;

  /*************************************************************************
  $spDesc 新增投资者期货手续费模板
  *************************************************************************/
  PROCEDURE up_InsInvstCommModel
  (
     i_tyInvstCommModel IN TY_INVSTCOMMMODEL  --投资者手续费模板信息
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_CommRateMgrt.up_InsInvstCommModel';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '新增投资者期货手续费模板';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '手续费管理', '新增投资者期货手续费模板');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_CommRateMgrt.up_InsInvstCommModel(' ||
                           i_tyInvstCommModel.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_CommRateMgrt.up_InsInvstCommModel(
                               i_tyInvstCommModel
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_InsInvstCommModel;

  /*************************************************************************
  $spDesc 修改投资者期货手续费模板
  *************************************************************************/
  PROCEDURE up_UpdInvstCommModel
  (
     i_tyInvstCommModel IN TY_INVSTCOMMMODEL  --投资者手续费模板信息
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_CommRateMgrt.up_UpdInvstCommModel';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '修改投资者期货手续费模板';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '手续费管理', '修改投资者期货手续费模板');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_CommRateMgrt.up_UpdInvstCommModel(' ||
                           i_tyInvstCommModel.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_CommRateMgrt.up_UpdInvstCommModel(
                               i_tyInvstCommModel
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_UpdInvstCommModel;

  /*************************************************************************
  $spDesc 删除投资者期货手续费模板
  *************************************************************************/
  PROCEDURE up_DelInvstCommModel
  (
     i_tytInvstCommModel IN TYT_INVSTCOMMMODEL  --投资者手续费模板信息
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_CommRateMgrt.up_DelInvstCommModel';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '删除投资者期货手续费模板';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '手续费管理', '删除投资者期货手续费模板');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_CommRateMgrt.up_DelInvstCommModel(' ||
                           PKGS_Tyt2STRING.uf_Tyt2String(i_tytInvstCommModel)
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_CommRateMgrt.up_DelInvstCommModel(
                               i_tytInvstCommModel
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_DelInvstCommModel;

  /*************************************************************************
  $spDesc 修改投资者手续费率模板关系
  *************************************************************************/
  PROCEDURE up_UpdInvestorCommRateModel
  (
     i_tytInvestorCommRateModel IN TYT_QUERYMARGINRATEMODELINVST  --投资者手续费模板信息
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_CommRateMgrt.up_UpdInvestorCommRateModel';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '修改投资者手续费率模板关系';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '手续费管理', '修改投资者手续费率模板关系');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_CommRateMgrt.up_UpdInvestorCommRateModel(' ||
                           PKGS_Tyt2STRINGEx.uf_Tyt2String(i_tytInvestorCommRateModel)
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_CommRateMgrt.up_UpdInvestorCommRateModel(
                               i_tytInvestorCommRateModel
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_UpdInvestorCommRateModel;

  /*************************************************************************
  $spDesc 修改投资者手续费率模板关系
  *************************************************************************/
  PROCEDURE up_UpdateInvestorCommRateModel
  (
     i_tytInvestorCommRateModel IN TYT_QUERYMARGINRATEMODELINVST  --投资者手续费模板信息
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_CommRateMgrt.up_UpdateInvestorCommRateModel';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '修改投资者手续费率模板关系';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '手续费管理', '修改投资者手续费率模板关系');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_CommRateMgrt.up_UpdateInvestorCommRateModel(' ||
                           PKGS_Tyt2STRINGEx.uf_Tyt2String(i_tytInvestorCommRateModel)
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_CommRateMgrt.up_UpdateInvestorCommRateModel(
                               i_tytInvestorCommRateModel
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_UpdateInvestorCommRateModel;

  /*************************************************************************
  $spDesc 新增手续费率模型
  *************************************************************************/
  PROCEDURE up_InsCommRateTemplate
  (
     i_tyCommRateTemplate IN TY_COMMRATETEMPLATE  --手续费率模型信息
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_CommRateMgrt.up_InsCommRateTemplate';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '新增手续费率模型';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '手续费管理', '新增手续费率模型');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_CommRateMgrt.up_InsCommRateTemplate(' ||
                           i_tyCommRateTemplate.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_CommRateMgrt.up_InsCommRateTemplate(
                               i_tyCommRateTemplate
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_InsCommRateTemplate;

  /*************************************************************************
  $spDesc 修改手续费率模型
  *************************************************************************/
  PROCEDURE up_UpdCommRateTemplate
  (
     i_tyCommRateTemplate IN TY_COMMRATETEMPLATE  --手续费率模型信息
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_CommRateMgrt.up_UpdCommRateTemplate';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '修改手续费率模型';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '手续费管理', '修改手续费率模型');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_CommRateMgrt.up_UpdCommRateTemplate(' ||
                           i_tyCommRateTemplate.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_CommRateMgrt.up_UpdCommRateTemplate(
                               i_tyCommRateTemplate
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_UpdCommRateTemplate;

  /*************************************************************************
  $spDesc 删除手续费率模型
  *************************************************************************/
  PROCEDURE up_DelCommRateTemplate
  (
     i_tyCommRateTemplate IN TY_COMMRATETEMPLATE  --手续费率模型信息
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_CommRateMgrt.up_DelCommRateTemplate';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '删除手续费率模型';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '手续费管理', '删除手续费率模型');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_CommRateMgrt.up_DelCommRateTemplate(' ||
                           i_tyCommRateTemplate.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_CommRateMgrt.up_DelCommRateTemplate(
                               i_tyCommRateTemplate
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_DelCommRateTemplate;

  /*************************************************************************
  $spDesc 激活手续费率模型
  *************************************************************************/
  PROCEDURE up_ActiveCommRateTemplate
  (
     i_tyCommRateTemplate IN TY_COMMRATETEMPLATE  --手续费率模型信息
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_CommRateMgrt.up_ActiveCommRateTemplate';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '激活手续费率模型';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '手续费管理', '激活手续费率模型');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_CommRateMgrt.up_ActiveCommRateTemplate(' ||
                           i_tyCommRateTemplate.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_CommRateMgrt.up_ActiveCommRateTemplate(
                               i_tyCommRateTemplate
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_ActiveCommRateTemplate;

  /*************************************************************************
  $spDesc 新增投资者手续费率模型信息
  *************************************************************************/
  PROCEDURE up_InsInvstCommRateTpl
  (
     i_tytInvstCommRateTpl IN TYT_INVSTCOMMRATETPL  --投资者手续费率模型信息
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_CommRateMgrt.up_InsInvstCommRateTpl';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '新增投资者手续费率模型信息';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '手续费管理', '新增投资者手续费率模型信息');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_CommRateMgrt.up_InsInvstCommRateTpl(' ||
                           PKGS_Tyt2STRING.uf_Tyt2String(i_tytInvstCommRateTpl)
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_CommRateMgrt.up_InsInvstCommRateTpl(
                               i_tytInvstCommRateTpl
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_InsInvstCommRateTpl;

  /*************************************************************************
  $spDesc 修改投资者手续费率模型信息
  *************************************************************************/
  PROCEDURE up_UpdInvstCommRateTpl
  (
     i_tytInvstCommRateTpl IN TYT_INVSTCOMMRATETPL  --投资者手续费率模型信息
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_CommRateMgrt.up_UpdInvstCommRateTpl';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '修改投资者手续费率模型信息';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '手续费管理', '修改投资者手续费率模型信息');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_CommRateMgrt.up_UpdInvstCommRateTpl(' ||
                           PKGS_Tyt2STRING.uf_Tyt2String(i_tytInvstCommRateTpl)
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_CommRateMgrt.up_UpdInvstCommRateTpl(
                               i_tytInvstCommRateTpl
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_UpdInvstCommRateTpl;

  /*************************************************************************
  $spDesc 删除投资者手续费率模型信息
  *************************************************************************/
  PROCEDURE up_DelInvstCommRateTpl
  (
     i_tytInvstCommRateTpl IN TYT_INVSTCOMMRATETPL  --投资者手续费率模型信息
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_CommRateMgrt.up_DelInvstCommRateTpl';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '删除投资者手续费率模型信息';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '手续费管理', '删除投资者手续费率模型信息');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_CommRateMgrt.up_DelInvstCommRateTpl(' ||
                           PKGS_Tyt2STRING.uf_Tyt2String(i_tytInvstCommRateTpl)
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_CommRateMgrt.up_DelInvstCommRateTpl(
                               i_tytInvstCommRateTpl
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_DelInvstCommRateTpl;

  /*************************************************************************
  $spDesc 上传投资者期货手续费率
  *************************************************************************/
  PROCEDURE up_InvstFutCommRateUpd
  (
     i_tytInvstFutCommRateUpd IN TYT_INVSTFUTCOMMRATEUPD  --投资者期货手续费率上传
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_CommRateMgrt.up_InvstFutCommRateUpd';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '上传投资者期货手续费率';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '手续费管理', '上传投资者期货手续费率');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_CommRateMgrt.up_InvstFutCommRateUpd(' ||
                           PKGS_Tyt2STRING.uf_Tyt2String(i_tytInvstFutCommRateUpd)
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_CommRateMgrt.up_InvstFutCommRateUpd(
                               i_tytInvstFutCommRateUpd
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_InvstFutCommRateUpd;

  /*************************************************************************
  $spDesc 投资者期货手续费率应用
  *************************************************************************/
  PROCEDURE up_InvstFutCommRateApp
  (
     i_tytInvstFutCommRateApp IN TYT_INVSTFUTCOMMRATEUPD  --投资者期货手续费率应用
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_CommRateMgrt.up_InvstFutCommRateApp';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '投资者期货手续费率应用';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '手续费管理', '投资者期货手续费率应用');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_CommRateMgrt.up_InvstFutCommRateApp(' ||
                           PKGS_Tyt2STRING.uf_Tyt2String(i_tytInvstFutCommRateApp)
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_CommRateMgrt.up_InvstFutCommRateApp(
                               i_tytInvstFutCommRateApp
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_InvstFutCommRateApp;

  /*************************************************************************
  $spDesc 修改上传投资者期货手续费率
  *************************************************************************/
  PROCEDURE up_UpdInvstFutCommRateUpd
  (
     i_tytInvstFutCommRateUpd IN TYT_INVSTFUTCOMMRATEUPD  --投资者期货手续费率上传
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_CommRateMgrt.up_UpdInvstFutCommRateUpd';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '修改上传投资者期货手续费率';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '手续费管理', '修改上传投资者期货手续费率');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_CommRateMgrt.up_UpdInvstFutCommRateUpd(' ||
                           PKGS_Tyt2STRING.uf_Tyt2String(i_tytInvstFutCommRateUpd)
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_CommRateMgrt.up_UpdInvstFutCommRateUpd(
                               i_tytInvstFutCommRateUpd
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_UpdInvstFutCommRateUpd;

  /*************************************************************************
  $spDesc 删除上传投资者期货手续费率
  *************************************************************************/
  PROCEDURE up_DelInvstFutCommRateUpd
  (
     i_tytInvstFutCommRateUpd IN TYT_INVSTFUTCOMMRATEUPD  --投资者期货手续费率上传
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_CommRateMgrt.up_DelInvstFutCommRateUpd';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '删除上传投资者期货手续费率';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '手续费管理', '删除上传投资者期货手续费率');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_CommRateMgrt.up_DelInvstFutCommRateUpd(' ||
                           PKGS_Tyt2STRING.uf_Tyt2String(i_tytInvstFutCommRateUpd)
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_CommRateMgrt.up_DelInvstFutCommRateUpd(
                               i_tytInvstFutCommRateUpd
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_DelInvstFutCommRateUpd;

  /*************************************************************************
  $spDesc 新增操作员对应手续费率模板权限
  *************************************************************************/
  PROCEDURE up_InsBrokerUserCommModel
  (
     i_BrokerUserCommModel IN TY_BROKERUSERCOMMMODEL  --新增操作员对应手续费率模板权限
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_CommRateMgrt.up_InsBrokerUserCommModel';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '新增操作员对应手续费率模板权限';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '手续费管理', '新增操作员对应手续费率模板权限');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_CommRateMgrt.up_InsBrokerUserCommModel(' ||
                           i_BrokerUserCommModel.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_CommRateMgrt.up_InsBrokerUserCommModel(
                               i_BrokerUserCommModel
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_InsBrokerUserCommModel;

  /*************************************************************************
  $spDesc 修改操作员对应手续费率模板权限
  *************************************************************************/
  PROCEDURE up_UpdBrokerUserCommModel
  (
     i_BrokerUserCommModel IN TY_BROKERUSERCOMMMODEL  --修改操作员对应手续费率模板权限
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_CommRateMgrt.up_UpdBrokerUserCommModel';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '修改操作员对应手续费率模板权限';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '手续费管理', '修改操作员对应手续费率模板权限');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_CommRateMgrt.up_UpdBrokerUserCommModel(' ||
                           i_BrokerUserCommModel.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_CommRateMgrt.up_UpdBrokerUserCommModel(
                               i_BrokerUserCommModel
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_UpdBrokerUserCommModel;

  /*************************************************************************
  $spDesc 删除操作员对应手续费率模板权限
  *************************************************************************/
  PROCEDURE up_DelBrokerUserCommModel
  (
     i_BrokerUserCommModel IN TY_BROKERUSERCOMMMODEL  --删除操作员对应手续费率模板权限
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_CommRateMgrt.up_DelBrokerUserCommModel';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '删除操作员对应手续费率模板权限';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '手续费管理', '删除操作员对应手续费率模板权限');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_CommRateMgrt.up_DelBrokerUserCommModel(' ||
                           i_BrokerUserCommModel.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_CommRateMgrt.up_DelBrokerUserCommModel(
                               i_BrokerUserCommModel
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_DelBrokerUserCommModel;

  /*************************************************************************
  $spDesc 不同投资者费率信息拷贝
  *************************************************************************/
  PROCEDURE up_CopyDiffInvstCommRate
  (
     i_tyCopyInvstCommRate IN TY_COPYINVSTCOMMRATE  --不同投资者费率信息拷贝
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_CommRateMgrt.up_CopyDiffInvstCommRate';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '不同投资者费率信息拷贝';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '手续费管理', '不同投资者费率信息拷贝');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_CommRateMgrt.up_CopyDiffInvstCommRate(' ||
                           i_tyCopyInvstCommRate.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_CommRateMgrt.up_CopyDiffInvstCommRate(
                               i_tyCopyInvstCommRate
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_CopyDiffInvstCommRate;

  /*************************************************************************
  $spDesc 同一投资者不同合约费率信息拷贝
  *************************************************************************/
  PROCEDURE up_CopyDiffInstrumentCommRate
  (
     i_tyCopyInvstCommRateExch IN TY_COPYINVSTCOMMRATEEXCH  --同一投资者不同合约费率信息拷贝
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_CommRateMgrt.up_CopyDiffInstrumentCommRate';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '同一投资者不同合约费率信息拷贝';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '手续费管理', '同一投资者不同合约费率信息拷贝');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_CommRateMgrt.up_CopyDiffInstrumentCommRate(' ||
                           i_tyCopyInvstCommRateExch.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_CommRateMgrt.up_CopyDiffInstrumentCommRate(
                               i_tyCopyInvstCommRateExch
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_CopyDiffInstrumentCommRate;

  /*************************************************************************
  $spDesc 不同投资者模型费率信息拷贝
  *************************************************************************/
  PROCEDURE up_CopyDiffInvstCommRateTpl
  (
     i_tyCopyInvstCommRateTpl IN TY_COPYINVSTCOMMRATETPL  --不同投资者模型费率信息拷贝
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_CommRateMgrt.up_CopyDiffInvstCommRateTpl';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '不同投资者模型费率信息拷贝';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '手续费管理', '不同投资者模型费率信息拷贝');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_CommRateMgrt.up_CopyDiffInvstCommRateTpl(' ||
                           i_tyCopyInvstCommRateTpl.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_CommRateMgrt.up_CopyDiffInvstCommRateTpl(
                               i_tyCopyInvstCommRateTpl
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_CopyDiffInvstCommRateTpl;

  /*************************************************************************
  $spDesc 拷贝投资者保证金率模型信息
  *************************************************************************/
  PROCEDURE up_CopyInvstCommRateTpl
  (
     i_tyCopyTplCommRate IN TY_COPYTPLCOMMRATE  --拷贝投资者保证金率模型信息
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_CommRateMgrt.up_CopyInvstCommRateTpl';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '拷贝投资者保证金率模型信息';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '手续费管理', '拷贝投资者保证金率模型信息');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_CommRateMgrt.up_CopyInvstCommRateTpl(' ||
                           i_tyCopyTplCommRate.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_CommRateMgrt.up_CopyInvstCommRateTpl(
                               i_tyCopyTplCommRate
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_CopyInvstCommRateTpl;

  /*************************************************************************
  $spDesc 查询手续费盘中同步参数
  *************************************************************************/
  PROCEDURE up_QryCommSyncPara
  (
     i_tySysSettleParam IN TY_SYSSETTLEPARAM  --系统结算参数
    ,i_tyPage IN  TY_PAGE  --分页信息
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_curSysSettleParam OUT NOCOPY PKGS_DATATYPE.TYPEREFCURSOR  --查询结果游标
    ,o_nCount OUT PKGS_DATATYPE.STY_COUNT  --记录数
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_CommRateMgrt.up_QryCommSyncPara';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '查询手续费盘中同步参数';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '手续费管理', '查询手续费盘中同步参数');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_CommRateMgrt.up_QryCommSyncPara(' ||
                           i_tySysSettleParam.uf_toString()
                      || ',' ||
                           i_tyPage.uf_toString()
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_curSysSettleParam'
                      || ',' ||
                        'o_nCount'
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_CommRateMgrt.up_QryCommSyncPara(
                               i_tySysSettleParam
                              ,i_tyPage
                              ,i_chLanguage
                              ,o_curSysSettleParam
                              ,o_nCount
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_QryCommSyncPara;

  /*************************************************************************
  $spDesc 查询投资者期货手续费
  *************************************************************************/
  PROCEDURE up_QueryInvstFutComm
  (
     i_tytQueryInvstFutComm IN TYT_QUERYINVSTFUTCOMM  --查询投资者期货手续费信息
    ,i_tyPage IN  TY_PAGE  --分页信息
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_curInvstFutComm OUT NOCOPY PKGS_DATATYPE.TYPEREFCURSOR  --查询结果游标
    ,o_nCount OUT PKGS_DATATYPE.STY_COUNT  --记录数
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_CommRateMgrt.up_QueryInvstFutComm';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '查询投资者期货手续费';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '手续费管理', '查询投资者期货手续费');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_CommRateMgrt.up_QueryInvstFutComm(' ||
                           PKGS_Tyt2STRINGEx.uf_Tyt2String(i_tytQueryInvstFutComm)
                      || ',' ||
                           i_tyPage.uf_toString()
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_curInvstFutComm'
                      || ',' ||
                        'o_nCount'
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_CommRateMgrt.up_QueryInvstFutComm(
                               i_tytQueryInvstFutComm
                              ,i_tyPage
                              ,i_chLanguage
                              ,o_curInvstFutComm
                              ,o_nCount
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_QueryInvstFutComm;

  /*************************************************************************
  $spDesc 查询交易所期货手续费
  *************************************************************************/
  PROCEDURE up_QueryExchFutComm
  (
     i_tytQueryExchFutComm IN TYT_QUERYEXCHFUTCOMM  --查询交易所期货手续费信息
    ,i_tyPage IN  TY_PAGE  --分页信息
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_curExchFutComm OUT NOCOPY PKGS_DATATYPE.TYPEREFCURSOR  --查询结果游标
    ,o_nCount OUT PKGS_DATATYPE.STY_COUNT  --记录数
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_CommRateMgrt.up_QueryExchFutComm';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '查询交易所期货手续费';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '手续费管理', '查询交易所期货手续费');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_CommRateMgrt.up_QueryExchFutComm(' ||
                           PKGS_Tyt2STRINGEx.uf_Tyt2String(i_tytQueryExchFutComm)
                      || ',' ||
                           i_tyPage.uf_toString()
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_curExchFutComm'
                      || ',' ||
                        'o_nCount'
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_CommRateMgrt.up_QueryExchFutComm(
                               i_tytQueryExchFutComm
                              ,i_tyPage
                              ,i_chLanguage
                              ,o_curExchFutComm
                              ,o_nCount
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_QueryExchFutComm;

  /*************************************************************************
  $spDesc 查询投资者手续费模板
  *************************************************************************/
  PROCEDURE up_QryInvstCommModel
  (
     i_tyInvstCommModel IN TY_INVSTCOMMMODEL  --投资者手续费模板信息
    ,i_tyPage IN  TY_PAGE  --分页信息
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_curInvstCommModel OUT NOCOPY PKGS_DATATYPE.TYPEREFCURSOR  --查询结果游标
    ,o_nCount OUT PKGS_DATATYPE.STY_COUNT  --记录数
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_CommRateMgrt.up_QryInvstCommModel';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '查询投资者手续费模板';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '手续费管理', '查询投资者手续费模板');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_CommRateMgrt.up_QryInvstCommModel(' ||
                           i_tyInvstCommModel.uf_toString()
                      || ',' ||
                           i_tyPage.uf_toString()
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_curInvstCommModel'
                      || ',' ||
                        'o_nCount'
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_CommRateMgrt.up_QryInvstCommModel(
                               i_tyInvstCommModel
                              ,i_tyPage
                              ,i_chLanguage
                              ,o_curInvstCommModel
                              ,o_nCount
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_QryInvstCommModel;

  /*************************************************************************
  $spDesc 查询投资者手续费模板(不带校验)
  *************************************************************************/
  PROCEDURE up_QryInvstCommModelEx
  (
     i_tyInvstCommModel IN TY_INVSTCOMMMODEL  --投资者手续费模板信息
    ,i_tyPage IN  TY_PAGE  --分页信息
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_curInvstCommModel OUT NOCOPY PKGS_DATATYPE.TYPEREFCURSOR  --查询结果游标
    ,o_nCount OUT PKGS_DATATYPE.STY_COUNT  --记录数
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_CommRateMgrt.up_QryInvstCommModelEx';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '查询投资者手续费模板(不带校验)';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '手续费管理', '查询投资者手续费模板(不带校验)');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_CommRateMgrt.up_QryInvstCommModelEx(' ||
                           i_tyInvstCommModel.uf_toString()
                      || ',' ||
                           i_tyPage.uf_toString()
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_curInvstCommModel'
                      || ',' ||
                        'o_nCount'
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_CommRateMgrt.up_QryInvstCommModelEx(
                               i_tyInvstCommModel
                              ,i_tyPage
                              ,i_chLanguage
                              ,o_curInvstCommModel
                              ,o_nCount
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_QryInvstCommModelEx;

  /*************************************************************************
  $spDesc 查询模板手续费率
  *************************************************************************/
  PROCEDURE up_QueryModelCommRate
  (
     i_tytQueryModelCommRate IN TYT_QUERYMODELMARGINRATE  --手续费模板设置
    ,i_tyPage IN  TY_PAGE  --分页信息
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_curModelCommRate OUT NOCOPY PKGS_DATATYPE.TYPEREFCURSOR  --查询结果游标
    ,o_nCount OUT PKGS_DATATYPE.STY_COUNT  --记录数
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_CommRateMgrt.up_QueryModelCommRate';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '查询模板手续费率';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '手续费管理', '查询模板手续费率');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_CommRateMgrt.up_QueryModelCommRate(' ||
                           PKGS_Tyt2STRINGEx.uf_Tyt2String(i_tytQueryModelCommRate)
                      || ',' ||
                           i_tyPage.uf_toString()
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_curModelCommRate'
                      || ',' ||
                        'o_nCount'
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_CommRateMgrt.up_QueryModelCommRate(
                               i_tytQueryModelCommRate
                              ,i_tyPage
                              ,i_chLanguage
                              ,o_curModelCommRate
                              ,o_nCount
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_QueryModelCommRate;

  /*************************************************************************
  $spDesc 查询手续费模板对应投资者
  *************************************************************************/
  PROCEDURE up_QueryCommRateModelInvst
  (
     i_tyQueryCommRateModelInvst IN TY_QUERYMARGINRATEMODELINVST  --手续费模板设置
    ,i_tyPage IN  TY_PAGE  --分页信息
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_curCommRateModelInvst OUT NOCOPY PKGS_DATATYPE.TYPEREFCURSOR  --查询结果游标
    ,o_nCount OUT PKGS_DATATYPE.STY_COUNT  --记录数
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_CommRateMgrt.up_QueryCommRateModelInvst';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '查询手续费模板对应投资者';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '手续费管理', '查询手续费模板对应投资者');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_CommRateMgrt.up_QueryCommRateModelInvst(' ||
                           i_tyQueryCommRateModelInvst.uf_toString()
                      || ',' ||
                           i_tyPage.uf_toString()
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_curCommRateModelInvst'
                      || ',' ||
                        'o_nCount'
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_CommRateMgrt.up_QueryCommRateModelInvst(
                               i_tyQueryCommRateModelInvst
                              ,i_tyPage
                              ,i_chLanguage
                              ,o_curCommRateModelInvst
                              ,o_nCount
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_QueryCommRateModelInvst;

  /*************************************************************************
  $spDesc 查询手续费率模型
  *************************************************************************/
  PROCEDURE up_QryCommRateTemplate
  (
     i_tyCommRateTemplate IN TY_COMMRATETEMPLATE  --手续费率模型信息
    ,i_tyPage IN  TY_PAGE  --分页信息
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_curCommRateTemplate OUT NOCOPY PKGS_DATATYPE.TYPEREFCURSOR  --查询结果游标
    ,o_nCount OUT PKGS_DATATYPE.STY_COUNT  --记录数
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_CommRateMgrt.up_QryCommRateTemplate';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '查询手续费率模型';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '手续费管理', '查询手续费率模型');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_CommRateMgrt.up_QryCommRateTemplate(' ||
                           i_tyCommRateTemplate.uf_toString()
                      || ',' ||
                           i_tyPage.uf_toString()
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_curCommRateTemplate'
                      || ',' ||
                        'o_nCount'
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_CommRateMgrt.up_QryCommRateTemplate(
                               i_tyCommRateTemplate
                              ,i_tyPage
                              ,i_chLanguage
                              ,o_curCommRateTemplate
                              ,o_nCount
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_QryCommRateTemplate;

  /*************************************************************************
  $spDesc 查询投资者手续费率模型
  *************************************************************************/
  PROCEDURE up_QryInvstCommRateTpl
  (
     i_tytQueryInvstCommRateTpl IN TYT_QUERYINVSTCOMMRATETPL  --投资者手续费率模型
    ,i_tyPage IN  TY_PAGE  --分页信息
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_curQueryInvstCommRateTpl OUT NOCOPY PKGS_DATATYPE.TYPEREFCURSOR  --查询结果游标
    ,o_nCount OUT PKGS_DATATYPE.STY_COUNT  --记录数
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_CommRateMgrt.up_QryInvstCommRateTpl';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '查询投资者手续费率模型';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '手续费管理', '查询投资者手续费率模型');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_CommRateMgrt.up_QryInvstCommRateTpl(' ||
                           PKGS_Tyt2STRINGEx.uf_Tyt2String(i_tytQueryInvstCommRateTpl)
                      || ',' ||
                           i_tyPage.uf_toString()
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_curQueryInvstCommRateTpl'
                      || ',' ||
                        'o_nCount'
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_CommRateMgrt.up_QryInvstCommRateTpl(
                               i_tytQueryInvstCommRateTpl
                              ,i_tyPage
                              ,i_chLanguage
                              ,o_curQueryInvstCommRateTpl
                              ,o_nCount
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_QryInvstCommRateTpl;

  /*************************************************************************
  $spDesc 查询投资者手续费率（供模型批量修改试算）
  *************************************************************************/
  PROCEDURE up_QryInvstCommRateForTrial
  (
     i_tytQueryInvstCommRateTpl IN TYT_QUERYINVSTCOMMRATETPL  --投资者手续费率模型
    ,i_tyPage IN  TY_PAGE  --分页信息
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_curQueryInvstCommRateTpl OUT NOCOPY PKGS_DATATYPE.TYPEREFCURSOR  --查询结果游标
    ,o_nCount OUT PKGS_DATATYPE.STY_COUNT  --记录数
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_CommRateMgrt.up_QryInvstCommRateForTrial';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '查询投资者手续费率（供模型批量修改试算）';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '手续费管理', '查询投资者手续费率（供模型批量修改试算）');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_CommRateMgrt.up_QryInvstCommRateForTrial(' ||
                           PKGS_Tyt2STRINGEx.uf_Tyt2String(i_tytQueryInvstCommRateTpl)
                      || ',' ||
                           i_tyPage.uf_toString()
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_curQueryInvstCommRateTpl'
                      || ',' ||
                        'o_nCount'
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_CommRateMgrt.up_QryInvstCommRateForTrial(
                               i_tytQueryInvstCommRateTpl
                              ,i_tyPage
                              ,i_chLanguage
                              ,o_curQueryInvstCommRateTpl
                              ,o_nCount
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_QryInvstCommRateForTrial;

  /*************************************************************************
  $spDesc 查询投资者手续费率模型
  *************************************************************************/
  PROCEDURE up_QueryInvstCommRateTpl
  (
     i_tytQueryInvstCommRateTpl IN TYT_QUERYINVSTCOMMRATETPL  --投资者手续费率模型
    ,i_tyPage IN  TY_PAGE  --分页信息
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_curQueryInvstCommRateTpl OUT NOCOPY PKGS_DATATYPE.TYPEREFCURSOR  --查询结果游标
    ,o_nCount OUT PKGS_DATATYPE.STY_COUNT  --记录数
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_CommRateMgrt.up_QueryInvstCommRateTpl';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '查询投资者手续费率模型';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '手续费管理', '查询投资者手续费率模型');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_CommRateMgrt.up_QueryInvstCommRateTpl(' ||
                           PKGS_Tyt2STRINGEx.uf_Tyt2String(i_tytQueryInvstCommRateTpl)
                      || ',' ||
                           i_tyPage.uf_toString()
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_curQueryInvstCommRateTpl'
                      || ',' ||
                        'o_nCount'
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_CommRateMgrt.up_QueryInvstCommRateTpl(
                               i_tytQueryInvstCommRateTpl
                              ,i_tyPage
                              ,i_chLanguage
                              ,o_curQueryInvstCommRateTpl
                              ,o_nCount
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_QueryInvstCommRateTpl;

  /*************************************************************************
  $spDesc 查询指定日交易所期货手续费
  *************************************************************************/
  PROCEDURE up_QryExchFutCommRateDay
  (
     i_tytQryExchFutCommRateDay IN TYT_QUERYEXCHFUTCOMM  --查询交易所期货手续费
    ,i_tyPage IN  TY_PAGE  --分页信息
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_curQryExchFutCommRateDay OUT NOCOPY PKGS_DATATYPE.TYPEREFCURSOR  --查询结果游标
    ,o_nCount OUT PKGS_DATATYPE.STY_COUNT  --记录数
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_CommRateMgrt.up_QryExchFutCommRateDay';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '查询指定日交易所期货手续费';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '手续费管理', '查询指定日交易所期货手续费');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_CommRateMgrt.up_QryExchFutCommRateDay(' ||
                           PKGS_Tyt2STRINGEx.uf_Tyt2String(i_tytQryExchFutCommRateDay)
                      || ',' ||
                           i_tyPage.uf_toString()
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_curQryExchFutCommRateDay'
                      || ',' ||
                        'o_nCount'
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_CommRateMgrt.up_QryExchFutCommRateDay(
                               i_tytQryExchFutCommRateDay
                              ,i_tyPage
                              ,i_chLanguage
                              ,o_curQryExchFutCommRateDay
                              ,o_nCount
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_QryExchFutCommRateDay;

  /*************************************************************************
  $spDesc 查询指定日投资者期货手续费
  *************************************************************************/
  PROCEDURE up_QryInvstFutCommRateDay
  (
     i_tytQryInvstFutCommRateDay IN TYT_QUERYINVSTFUTCOMM  --查询投资者期货手续费
    ,i_tyPage IN  TY_PAGE  --分页信息
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_curQryInvstFutCommRateDay OUT NOCOPY PKGS_DATATYPE.TYPEREFCURSOR  --查询结果游标
    ,o_nCount OUT PKGS_DATATYPE.STY_COUNT  --记录数
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_CommRateMgrt.up_QryInvstFutCommRateDay';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '查询指定日投资者期货手续费';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '手续费管理', '查询指定日投资者期货手续费');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_CommRateMgrt.up_QryInvstFutCommRateDay(' ||
                           PKGS_Tyt2STRINGEx.uf_Tyt2String(i_tytQryInvstFutCommRateDay)
                      || ',' ||
                           i_tyPage.uf_toString()
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_curQryInvstFutCommRateDay'
                      || ',' ||
                        'o_nCount'
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_CommRateMgrt.up_QryInvstFutCommRateDay(
                               i_tytQryInvstFutCommRateDay
                              ,i_tyPage
                              ,i_chLanguage
                              ,o_curQryInvstFutCommRateDay
                              ,o_nCount
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_QryInvstFutCommRateDay;

  /*************************************************************************
  $spDesc 当前投资者期货手续费率上传查询
  *************************************************************************/
  PROCEDURE up_QryInvstFutCommRateUpd
  (
     i_tytQryInvstFutCommRateUpd IN TYT_QUERYINVSTFUTCOMM  --当前投资者期货手续费率上传查询
    ,i_tyPage IN  TY_PAGE  --分页信息
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_curInvstFutCommEx OUT NOCOPY PKGS_DATATYPE.TYPEREFCURSOR  --查询结果游标
    ,o_nCount OUT PKGS_DATATYPE.STY_COUNT  --记录数
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_CommRateMgrt.up_QryInvstFutCommRateUpd';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '当前投资者期货手续费率上传查询';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '手续费管理', '当前投资者期货手续费率上传查询');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_CommRateMgrt.up_QryInvstFutCommRateUpd(' ||
                           PKGS_Tyt2STRINGEx.uf_Tyt2String(i_tytQryInvstFutCommRateUpd)
                      || ',' ||
                           i_tyPage.uf_toString()
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_curInvstFutCommEx'
                      || ',' ||
                        'o_nCount'
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_CommRateMgrt.up_QryInvstFutCommRateUpd(
                               i_tytQryInvstFutCommRateUpd
                              ,i_tyPage
                              ,i_chLanguage
                              ,o_curInvstFutCommEx
                              ,o_nCount
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_QryInvstFutCommRateUpd;

  /*************************************************************************
  $spDesc 查询操作员对应保证金率模板权限
  *************************************************************************/
  PROCEDURE up_QryBrokerUserCommModel
  (
     i_QryBrokerUserCommModel IN TY_BROKERUSERCOMMMODEL  --操作员对应保证金率模板权限
    ,i_tyPage IN  TY_PAGE  --分页信息
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_curBrokerUserCommModel OUT NOCOPY PKGS_DATATYPE.TYPEREFCURSOR  --查询结果游标
    ,o_nCount OUT PKGS_DATATYPE.STY_COUNT  --记录数
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_CommRateMgrt.up_QryBrokerUserCommModel';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '查询操作员对应保证金率模板权限';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '手续费管理', '查询操作员对应保证金率模板权限');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_CommRateMgrt.up_QryBrokerUserCommModel(' ||
                           i_QryBrokerUserCommModel.uf_toString()
                      || ',' ||
                           i_tyPage.uf_toString()
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_curBrokerUserCommModel'
                      || ',' ||
                        'o_nCount'
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_CommRateMgrt.up_QryBrokerUserCommModel(
                               i_QryBrokerUserCommModel
                              ,i_tyPage
                              ,i_chLanguage
                              ,o_curBrokerUserCommModel
                              ,o_nCount
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_QryBrokerUserCommModel;

  /*************************************************************************
  $spDesc 查询业务操作日志信息
  *************************************************************************/
  PROCEDURE up_QryCommRateEventLogs
  (
     i_QueryEventLog IN TY_QUERYEVENTLOG  --查询业务操作日志信息
    ,i_tyPage IN  TY_PAGE  --分页信息
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_curCommRateEventLogs OUT NOCOPY PKGS_DATATYPE.TYPEREFCURSOR  --查询结果游标
    ,o_nCount OUT PKGS_DATATYPE.STY_COUNT  --记录数
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_CommRateMgrt.up_QryCommRateEventLogs';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '查询业务操作日志信息';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '手续费管理', '查询业务操作日志信息');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_CommRateMgrt.up_QryCommRateEventLogs(' ||
                           i_QueryEventLog.uf_toString()
                      || ',' ||
                           i_tyPage.uf_toString()
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_curCommRateEventLogs'
                      || ',' ||
                        'o_nCount'
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_CommRateMgrt.up_QryCommRateEventLogs(
                               i_QueryEventLog
                              ,i_tyPage
                              ,i_chLanguage
                              ,o_curCommRateEventLogs
                              ,o_nCount
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_QryCommRateEventLogs;

  /*************************************************************************
  $spDesc 查询中金所申报手续费率
  *************************************************************************/
  PROCEDURE up_QryInstrumentOrderCommRate
  (
     i_tyInstrumentOrderCommRate IN TYT_INSTRUMENTORDERCOMMRATE  --中金所申报手续费率
    ,i_tyPage IN  TY_PAGE  --分页信息
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_curInstrumentOrderCommRate OUT NOCOPY PKGS_DATATYPE.TYPEREFCURSOR  --查询结果游标
    ,o_nCount OUT PKGS_DATATYPE.STY_COUNT  --记录数
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_CommRateMgrt.up_QryInstrumentOrderCommRate';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '查询中金所申报手续费率';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '手续费管理', '查询中金所申报手续费率');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_CommRateMgrt.up_QryInstrumentOrderCommRate(' ||
                           PKGS_Tyt2STRING.uf_Tyt2String(i_tyInstrumentOrderCommRate)
                      || ',' ||
                           i_tyPage.uf_toString()
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_curInstrumentOrderCommRate'
                      || ',' ||
                        'o_nCount'
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_CommRateMgrt.up_QryInstrumentOrderCommRate(
                               i_tyInstrumentOrderCommRate
                              ,i_tyPage
                              ,i_chLanguage
                              ,o_curInstrumentOrderCommRate
                              ,o_nCount
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_QryInstrumentOrderCommRate;

  /*************************************************************************
  $spDesc 新增中金所申报手续费率
  *************************************************************************/
  PROCEDURE up_InsInstrumentOrderCommRate
  (
     io_tyInstrumentOrderCommRate IN  TYT_INSTRUMENTORDERCOMMRATE  --中金所申报手续费率
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_CommRateMgrt.up_InsInstrumentOrderCommRate';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '新增中金所申报手续费率';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '手续费管理', '新增中金所申报手续费率');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_CommRateMgrt.up_InsInstrumentOrderCommRate(' ||
                           PKGS_Tyt2STRING.uf_Tyt2String(io_tyInstrumentOrderCommRate)
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_CommRateMgrt.up_InsInstrumentOrderCommRate(
                               io_tyInstrumentOrderCommRate
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_InsInstrumentOrderCommRate;

  /*************************************************************************
  $spDesc 修改中金所申报手续费率
  *************************************************************************/
  PROCEDURE up_UpdInstrumentOrderCommRate
  (
     io_tyInstrumentOrderCommRate IN  TYT_INSTRUMENTORDERCOMMRATE  --中金所申报手续费率
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_CommRateMgrt.up_UpdInstrumentOrderCommRate';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '修改中金所申报手续费率';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '手续费管理', '修改中金所申报手续费率');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_CommRateMgrt.up_UpdInstrumentOrderCommRate(' ||
                           PKGS_Tyt2STRING.uf_Tyt2String(io_tyInstrumentOrderCommRate)
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_CommRateMgrt.up_UpdInstrumentOrderCommRate(
                               io_tyInstrumentOrderCommRate
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_UpdInstrumentOrderCommRate;

  /*************************************************************************
  $spDesc 删除中金所申报手续费率
  *************************************************************************/
  PROCEDURE up_DelInstrumentOrderCommRate
  (
     io_tyInstrumentOrderCommRate IN  TYT_INSTRUMENTORDERCOMMRATE  --中金所申报手续费率
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_CommRateMgrt.up_DelInstrumentOrderCommRate';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '删除中金所申报手续费率';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '手续费管理', '删除中金所申报手续费率');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_CommRateMgrt.up_DelInstrumentOrderCommRate(' ||
                           PKGS_Tyt2STRING.uf_Tyt2String(io_tyInstrumentOrderCommRate)
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_CommRateMgrt.up_DelInstrumentOrderCommRate(
                               io_tyInstrumentOrderCommRate
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_DelInstrumentOrderCommRate;

  /*************************************************************************
  $spDesc 区别操作员有权限和无权限的投资者
  *************************************************************************/
  PROCEDURE up_DistDepartmentInvestor
  (
     i_tytInvestor IN  TYT_INVESTOR  --投资者列表
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,i_BrokerID IN PKGS_DATATYPE.STY_BROKERID  --经纪公司代码
    ,o_nCountAuthInvst OUT PKGS_DATATYPE.STY_COUNT  --有权限的投资者记录数
    ,o_nCountUnAuthInvst OUT PKGS_DATATYPE.STY_COUNT  --无权限的投资者记录数
    ,o_authInvstCursor OUT NOCOPY PKGS_DATATYPE.TYPEREFCURSOR  --有权限的投资者游标
    ,o_unAuthInvstCursor OUT NOCOPY PKGS_DATATYPE.TYPEREFCURSOR  --无权限的投资者游标
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_CommRateMgrt.up_DistDepartmentInvestor';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '区别操作员有权限和无权限的投资者';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '手续费管理', '区别操作员有权限和无权限的投资者');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_CommRateMgrt.up_DistDepartmentInvestor(' ||
                           PKGS_Tyt2STRING.uf_Tyt2String(i_tytInvestor)
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                           '''' || trim(i_BrokerID) || ''''
                      || ',' ||
                        'o_nCountAuthInvst'
                      || ',' ||
                        'o_nCountUnAuthInvst'
                      || ',' ||
                        'o_authInvstCursor'
                      || ',' ||
                        'o_unAuthInvstCursor'
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_CommRateMgrt.up_DistDepartmentInvestor(
                               i_tytInvestor
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,i_BrokerID
                              ,o_nCountAuthInvst
                              ,o_nCountUnAuthInvst
                              ,o_authInvstCursor
                              ,o_unAuthInvstCursor
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_DistDepartmentInvestor;

  /*************************************************************************
  $spDesc 查询投资者手续费率模板序列
  *************************************************************************/
  PROCEDURE up_QryInvstCommModelSequence
  (
     io_tyInvestorsequence IN OUT TY_INVESTORSEQUENCE  --手续费率模板序列
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_CommRateMgrt.up_QryInvstCommModelSequence';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '查询投资者手续费率模板序列';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '手续费管理', '查询投资者手续费率模板序列');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_CommRateMgrt.up_QryInvstCommModelSequence(' ||
                           io_tyInvestorsequence.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_CommRateMgrt.up_QryInvstCommModelSequence(
                               io_tyInvestorsequence
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_QryInvstCommModelSequence;

END PKGI_CommRateMgrt;
/

