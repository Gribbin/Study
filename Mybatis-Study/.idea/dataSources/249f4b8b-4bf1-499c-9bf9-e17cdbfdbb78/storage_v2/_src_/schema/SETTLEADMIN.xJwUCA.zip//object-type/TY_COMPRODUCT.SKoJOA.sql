create TYPE Ty_ComProduct AS OBJECT
(
    ExchangeID CHAR(8),  --交易所代码
    ComProductID CHAR(30),  --组合产品代码
    ComProductName CHAR(60),  --组合产品名称
    ComProductClass CHAR(1),  --组合产品类型
    ComType CHAR(1),  --组合类型
    ProductLifePhase CHAR(1),  --产品生命周期状态
    Memo CHAR(160),  --备注

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_ComProduct RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

