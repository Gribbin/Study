create TYPE Ty_BrokerFundChgIN AS OBJECT
(
    SettleTaskID CHAR(16),  --结算任务ID
    BrokerID CHAR(10),  --经纪公司代码
    ExchangeID CHAR(8),  --交易所代码
    AccountID CHAR(14),  --经纪公司资金账号
    CurrencyID CHAR(3),  --经纪公司资金账号币种
    FundDirection CHAR(1),  --出入金方向
    Deposite NUMBER(22,6),  --出入金金额
    DepositSeqNo CHAR(14),  --出入金流水号

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_BrokerFundChgIN RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

