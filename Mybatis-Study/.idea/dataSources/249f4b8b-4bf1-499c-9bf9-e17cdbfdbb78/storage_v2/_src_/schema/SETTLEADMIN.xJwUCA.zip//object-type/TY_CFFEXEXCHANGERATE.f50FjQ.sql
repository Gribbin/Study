create TYPE Ty_CffexExchangeRate AS OBJECT
(
    TradingDay CHAR(8),  --交易日
    ProductID CHAR(20),  --合约代码
    ExchgRate NUMBER(16,8),  --汇率
    ExchgUnit CHAR(10),  --汇率单位

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_CffexExchangeRate RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

