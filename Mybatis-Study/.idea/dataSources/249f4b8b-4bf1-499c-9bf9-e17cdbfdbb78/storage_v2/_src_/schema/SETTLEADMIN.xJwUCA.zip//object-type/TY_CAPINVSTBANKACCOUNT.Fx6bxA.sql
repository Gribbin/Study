create TYPE Ty_CAPInvstBankAccount AS OBJECT
(
    BrokerID CHAR(10),  --经纪公司代码
    InvestorID CHAR(12),  --投资者代码
    AccountID CHAR(14),  --资金账号
    BankFlag CHAR(3),  --银行代码
    BankAccount CHAR(40),  --银行账号
    OpenName VARCHAR2(100),  --银行账户的开户人名称
    OpenBank CHAR(100),  --银行账户的开户行
    IsActive NUMBER(1),  --是否活跃
    AccountSourceType CHAR(1),  --账户来源
    OpenDate CHAR(8),  --开户日期
    CancelDate CHAR(8),  --注销日期
    CurrencyID CHAR(3),  --币种

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_CAPInvstBankAccount RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

