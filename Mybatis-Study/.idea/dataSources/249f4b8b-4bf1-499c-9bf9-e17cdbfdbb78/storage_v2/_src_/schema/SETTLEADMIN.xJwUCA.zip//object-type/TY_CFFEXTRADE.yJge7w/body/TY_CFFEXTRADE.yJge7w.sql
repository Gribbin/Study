create TYPE BODY Ty_CFFEXTrade IS

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_CFFEXTrade RETURN SELF AS RESULT IS
  BEGIN
    RETURN;
  END;

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2 IS
    l_string VARCHAR2(4000);
  BEGIN
    l_string:='ty_CFFEXTrade('
      || 'ParticipantID=>' || '''' || trim(ParticipantID) || '''' --会员代码
      || ',TradePartID=>' || '''' || trim(TradePartID) || '''' --交易会员
      || ',ClientID=>' || '''' || trim(ClientID) || '''' --客户编码
      || ',ExchangeInstID=>' || '''' || trim(ExchangeInstID) || '''' --合约代码
      || ',TradeID=>' || '''' || trim(TradeID) || '''' --合约编号
      || ',Direction=>' || '''' || trim(Direction) || '''' --买卖
      || ',Volume=>' || NVL(to_char(Volume),'NULL')--成交量
      || ',Price=>' || NVL(to_char(Price),'NULL')--成交价
      || ',TurnOver=>' || NVL(to_char(TurnOver),'NULL')--成交金额
      || ',TradeTime=>' || '''' || trim(TradeTime) || '''' --成交时间
      || ',OffsetFlag=>' || '''' || trim(OffsetFlag) || '''' --开平标志
      || ',OrderSysID=>' || '''' || trim(OrderSysID) || '''' --报单号
      || ',TraderID=>' || '''' || trim(TraderID) || '''' --交易所交易员代码
      || ',TradingDay=>' || '''' || trim(TradingDay) || '''' --交易日
      || ',ExchangeID=>' || '''' || trim(ExchangeID) || '''' --交易所代码
      || ')';


    RETURN l_string;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN NULL;
  END;



END;
/

