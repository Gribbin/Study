create TYPE Ty_BrokerEx AS OBJECT
(
    BrokerID CHAR(10),  --经纪公司代码
    Corporation VARCHAR2(100),  --法人代表
    LinkMan VARCHAR2(100),  --联系人
    Fax CHAR(40),  --传真
    Telephone CHAR(40),  --联系电话
    Email CHAR(40),  --电子邮件
    Address CHAR(100),  --联系地址
    ZipCode CHAR(10),  --邮政编码
    Website VARCHAR2(50),  --网站地址
    CompanyCode CHAR(50),  --企业代码
    TaxNo VARCHAR2(30),  --税务登记号
    LicenseNo CHAR(50),  --营业执照号
    OpenDate CHAR(8),  --开户日期
    CancleDate CHAR(8),  --销户日期
    BrokerFlag NUMBER(1),  --状态
    BrokerDNS CHAR(255),  --访问域名
    BrokerDNS2 CHAR(255),  --备份访问域名
    SMTP VARCHAR2(50),  --电邮服务器地址
    EmailUser VARCHAR2(80),  --电邮用户名
    EmailPassword CHAR(40),  --电邮密码
    IsSMTPLogin NUMBER(1),  --SMTP是否需要身份验证

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_BrokerEx RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

