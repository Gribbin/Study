create TYPE Ty_CAPDepartment AS OBJECT
(
    BrokerID CHAR(10),  --经纪公司代码
    DepartmentID CHAR(12),  --组织架构代码
    DepartmentName VARCHAR2(80),  --组织架构名称
    ParentID CHAR(12),  --上级组织架构代码
    LevelNo CHAR(1),  --层次
    Memo CHAR(160),  --备注

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_CAPDepartment RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

