create TYPE BODY Ty_AmTrusteeAccount IS

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_AmTrusteeAccount RETURN SELF AS RESULT IS
  BEGIN
    RETURN;
  END;

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2 IS
    l_string VARCHAR2(4000);
  BEGIN
    l_string:='ty_AmTrusteeAccount('
      || 'BrokerID=>' || '''' || trim(BrokerID) || '''' --经纪公司代码
      || ',AccountID=>' || '''' || trim(AccountID) || '''' --投资者账号
      || ',BankFlag=>' || '''' || trim(BankFlag) || '''' --银行统一标识类型
      || ',BankAccount=>' || '''' || trim(BankAccount) || '''' --银行账户
      || ',OpenName=>' || '''' || trim(OpenName) || '''' --银行账户的开户人名称
      || ',OpenBank=>' || '''' || trim(OpenBank) || '''' --银行账户的开户行
      || ',IsActive=>' || '''' || trim(IsActive) || '''' --是否活跃
      || ',CurrencyID=>' || '''' || trim(CurrencyID) || '''' --币种
      || ')';


    RETURN l_string;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN NULL;
  END;



END;
/

