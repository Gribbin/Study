create TYPE BODY Ty_AccountLinkMan IS

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_AccountLinkMan RETURN SELF AS RESULT IS
  BEGIN
    RETURN;
  END;

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2 IS
    l_string VARCHAR2(4000);
  BEGIN
    l_string:='ty_AccountLinkMan('
      || 'BrokerID=>' || '''' || trim(BrokerID) || '''' --经纪公司代码
      || ',AccountID=>' || '''' || trim(AccountID) || '''' --投资者账号
      || ',CurrencyID=>' || '''' || trim(CurrencyID) || '''' --投资者账号币种
      || ',PersonType=>' || '''' || trim(PersonType) || '''' --联系人类型
      || ',PersonCardType=>' || '''' || trim(PersonCardType) || '''' --证件类型
      || ',PersonCardNo=>' || '''' || trim(PersonCardNo) || '''' --证件号码
      || ',PersonName=>' || '''' || trim(PersonName) || '''' --名称
      || ',PersonTelephone=>' || '''' || trim(PersonTelephone) || '''' --联系电话
      || ',PersonAddress=>' || '''' || trim(PersonAddress) || '''' --通讯地址
      || ',PersonZipCode=>' || '''' || trim(PersonZipCode) || '''' --邮政编码
      || ',PersonSex=>' || '''' || trim(PersonSex) || '''' --性别
      || ',PersonNational=>' || '''' || trim(PersonNational) || '''' --身份归属国家/地区
      || ',NationalProvince=>' || '''' || trim(NationalProvince) || '''' --所在省
      || ',NationalCity=>' || '''' || trim(NationalCity) || '''' --所在市
      || ',Priority=>' || NVL(to_char(Priority),'NULL')--优先级
      || ',PhoneCountryCode=>' || '''' || trim(PhoneCountryCode) || '''' --国家代码
      || ',PhoneAreaCode=>' || '''' || trim(PhoneAreaCode) || '''' --区号
      || ',Country=>' || '''' || trim(Country) || '''' --联系地址国家或地区
      || ',Province=>' || '''' || trim(Province) || '''' --联系地址省
      || ',City=>' || '''' || trim(City) || '''' --联系地址市
      || ',IdCardValidityStart=>' || '''' || trim(IdCardValidityStart) || '''' --证件有效期（起）
      || ',IdCardValidityEnd=>' || '''' || trim(IdCardValidityEnd) || '''' --证件有效期（止）
      || ',Mobile=>' || '''' || trim(Mobile) || '''' --手机
      || ',EMail=>' || '''' || trim(EMail) || '''' --电子邮件
      || ',Memo=>' || '''' || trim(Memo) || '''' --备注
      || ')';


    RETURN l_string;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN NULL;
  END;



END;
/

