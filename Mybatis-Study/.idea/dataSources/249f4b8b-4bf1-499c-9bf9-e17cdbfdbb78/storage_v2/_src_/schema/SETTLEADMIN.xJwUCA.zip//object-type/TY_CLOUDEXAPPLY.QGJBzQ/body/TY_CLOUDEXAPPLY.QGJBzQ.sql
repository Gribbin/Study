create TYPE BODY Ty_CloudExApply IS

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_CloudExApply RETURN SELF AS RESULT IS
  BEGIN
    RETURN;
  END;

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2 IS
    l_string VARCHAR2(4000);
  BEGIN
    l_string:='ty_CloudExApply('
      || 'TradingDay=>' || '''' || trim(TradingDay) || '''' --交易日
      || ',BrokerID=>' || '''' || trim(BrokerID) || '''' --经纪公司代码
      || ',ProcessID=>' || '''' || trim(ProcessID) || '''' --业务流水号
      || ',ProcessType=>' || '''' || trim(ProcessType) || '''' --流程功能类型
      || ',InvestorID=>' || '''' || trim(InvestorID) || '''' --投资者代码
      || ',InvestorName=>' || '''' || trim(InvestorName) || '''' --投资者名称
      || ',IdentifiedCardNo=>' || '''' || trim(IdentifiedCardNo) || '''' --证件号码
      || ',IdentifiedCardType=>' || '''' || trim(IdentifiedCardType) || '''' --证件类型
      || ',CompanyID=>' || '''' || trim(CompanyID) || '''' --期货公司统一编码
      || ',ExchangeID=>' || '''' || trim(ExchangeID) || '''' --交易所代码
      || ',ClientIDType=>' || '''' || trim(ClientIDType) || '''' --交易编码类型
      || ',ExClientID=>' || '''' || trim(ExClientID) || '''' --交易编码
      || ',CfmmcReturnCode=>' || '''' || trim(CfmmcReturnCode) || '''' --监控中心返回码
      || ',CfmmcReturnMsg=>' || '''' || trim(CfmmcReturnMsg) || '''' --监控中心返回提示信息
      || ',IsReturned=>' || '''' || trim(IsReturned) || '''' --是否返回云平台
      || ',DevelopSource=>' || '''' || trim(DevelopSource) || '''' --客户来源
      || ',TerminalType=>' || '''' || trim(TerminalType) || '''' --开户终端类型
      || ',AcceptNo=>' || '''' || trim(AcceptNo) || '''' --受理单号
      || ')';


    RETURN l_string;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN NULL;
  END;



END;
/

