create TYPE Ty_Commodity AS OBJECT
(
    ExchangeID CHAR(8),  --交易所代码
    CommodityID CHAR(30),  --基础品种代码
    CommodityName VARCHAR2(80),  --基础品种名称
    Uom VARCHAR2(10),  --计量单位
    VersionNo NUMBER(10),  --版本号

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_Commodity RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

