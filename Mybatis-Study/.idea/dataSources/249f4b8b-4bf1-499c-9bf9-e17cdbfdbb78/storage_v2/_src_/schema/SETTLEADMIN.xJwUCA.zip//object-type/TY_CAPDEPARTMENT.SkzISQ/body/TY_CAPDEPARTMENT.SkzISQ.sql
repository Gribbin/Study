create TYPE BODY Ty_CAPDepartment IS

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_CAPDepartment RETURN SELF AS RESULT IS
  BEGIN
    RETURN;
  END;

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2 IS
    l_string VARCHAR2(4000);
  BEGIN
    l_string:='ty_CAPDepartment('
      || 'BrokerID=>' || '''' || trim(BrokerID) || '''' --经纪公司代码
      || ',DepartmentID=>' || '''' || trim(DepartmentID) || '''' --组织架构代码
      || ',DepartmentName=>' || '''' || trim(DepartmentName) || '''' --组织架构名称
      || ',ParentID=>' || '''' || trim(ParentID) || '''' --上级组织架构代码
      || ',LevelNo=>' || '''' || trim(LevelNo) || '''' --层次
      || ',Memo=>' || '''' || trim(Memo) || '''' --备注
      || ')';


    RETURN l_string;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN NULL;
  END;



END;
/

