create TYPE Ty_AMLDrawLog AS OBJECT
(
    SequenceNo NUMBER(8),  --序号
    BrokerID CHAR(10),  --经纪公司代码
    DrawDay CHAR(8),  --检查日期
    UserID CHAR(15),  --用户代码
    ReportTypeID CHAR(2),  --报告类型
    CharacterID CHAR(4),  --交易特征代码
    BeginDay CHAR(8),  --开始检查日期
    EndDay CHAR(8),  --结束检查日期
    Description VARCHAR2(400),  --抽取结果
    OperatorID CHAR(64),  --录入员代码
    OperateDate CHAR(8),  --录入日期
    OperateTime CHAR(8),  --录入时间

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_AMLDrawLog RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

