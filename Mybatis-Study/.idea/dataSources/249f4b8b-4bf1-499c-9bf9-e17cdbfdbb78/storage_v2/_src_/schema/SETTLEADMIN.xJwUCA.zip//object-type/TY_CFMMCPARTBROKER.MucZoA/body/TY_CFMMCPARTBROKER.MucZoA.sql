create TYPE BODY Ty_CFMMCPartBroker IS

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_CFMMCPartBroker RETURN SELF AS RESULT IS
  BEGIN
    RETURN;
  END;

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2 IS
    l_string VARCHAR2(4000);
  BEGIN
    l_string:='ty_CFMMCPartBroker('
      || 'BrokerID=>' || '''' || trim(BrokerID) || '''' --经纪公司代码
      || ',ParticipantID=>' || '''' || trim(ParticipantID) || '''' --经纪公司统一编码
      || ',Password=>' || '''' || trim(Password) || '''' --密码
      || ',IsActive=>' || '''' || trim(IsActive) || '''' --是否活跃
      || ',UserID=>' || '''' || trim(UserID) || '''' --用户代码,登录监控中心使用
      || ',DRIdentityID=>' || NVL(to_char(DRIdentityID),'NULL')--交易中心代码
      || ')';


    RETURN l_string;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN NULL;
  END;



END;
/

