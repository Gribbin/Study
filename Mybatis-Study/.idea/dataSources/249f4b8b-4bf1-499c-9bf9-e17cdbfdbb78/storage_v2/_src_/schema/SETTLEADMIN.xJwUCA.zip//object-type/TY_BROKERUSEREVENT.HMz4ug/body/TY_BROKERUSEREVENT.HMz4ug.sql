create TYPE BODY Ty_BrokerUserEvent IS

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_BrokerUserEvent RETURN SELF AS RESULT IS
  BEGIN
    RETURN;
  END;

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2 IS
    l_string VARCHAR2(4000);
  BEGIN
    l_string:='ty_BrokerUserEvent('
      || 'BrokerID=>' || '''' || trim(BrokerID) || '''' --经纪公司代码
      || ',UserID=>' || '''' || trim(UserID) || '''' --用户代码
      || ',UserEventType=>' || '''' || trim(UserEventType) || '''' --用户事件类型
      || ',EventSequenceNo=>' || NVL(to_char(EventSequenceNo),'NULL')--用户事件序号
      || ',EventDate=>' || '''' || trim(EventDate) || '''' --事件发生日期
      || ',EventTime=>' || '''' || trim(EventTime) || '''' --事件发生时间
      || ',UserEventInfo=>' || '''' || trim(UserEventInfo) || '''' --用户事件信息
      || ',InvestorID=>' || '''' || trim(InvestorID) || '''' --投资者代码
      || ',InstrumentID=>' || '''' || trim(InstrumentID) || '''' --合约代码
      || ',DRIdentityID=>' || NVL(to_char(DRIdentityID),'NULL')--交易中心代码
      || ',ExchangeID=>' || '''' || trim(ExchangeID) || '''' --交易所代码
      || ',InvestUnitID=>' || '''' || trim(InvestUnitID) || '''' --投资单元代码
      || ')';


    RETURN l_string;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN NULL;
  END;



END;
/

