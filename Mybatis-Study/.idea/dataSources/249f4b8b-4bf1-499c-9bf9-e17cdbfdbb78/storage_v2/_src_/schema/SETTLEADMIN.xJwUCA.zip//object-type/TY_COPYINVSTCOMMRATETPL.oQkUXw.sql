create TYPE Ty_CopyInvstCommRateTpl AS OBJECT
(
    BrokerID CHAR(10),  --经纪公司代码
    RateTemplateID CHAR(8),  --模型代码
    SourceInvestorRange CHAR(1),  --源投资者范围
    SourceInvestorID CHAR(12),  --源投资者代码
    SourceInvestUnitID CHAR(16),  --源投资单元代码
    TargetInvestorRange CHAR(1),  --目标投资者范围
    TargetInvestorID CHAR(12),  --目标投资者代码
    TargetInvestUnitID CHAR(16),  --目标投资单元代码
    ExchangeID CHAR(8),  --交易所
    InstrumentID CHAR(30),  --合约

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_CopyInvstCommRateTpl RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

