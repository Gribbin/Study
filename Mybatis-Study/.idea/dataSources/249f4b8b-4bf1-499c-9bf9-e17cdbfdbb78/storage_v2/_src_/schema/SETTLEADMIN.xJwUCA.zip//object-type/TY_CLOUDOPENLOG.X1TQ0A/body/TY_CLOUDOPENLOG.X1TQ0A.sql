create TYPE BODY Ty_CloudOpenLog IS

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_CloudOpenLog RETURN SELF AS RESULT IS
  BEGIN
    RETURN;
  END;

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2 IS
    l_string VARCHAR2(4000);
  BEGIN
    l_string:='ty_CloudOpenLog('
      || 'TradingDay=>' || '''' || trim(TradingDay) || '''' --交易日
      || ',SequenceNo=>' || NVL(to_char(SequenceNo),'NULL')--序号
      || ',BrokerID=>' || '''' || trim(BrokerID) || '''' --经纪公司代码
      || ',LogLevel=>' || '''' || trim(LogLevel) || '''' --日志级别
      || ',requestURL=>' || '''' || trim(requestURL) || '''' --请求地址
      || ',requestBody=>' || '''' || trim(requestBody) || '''' --请求参数
      || ',operationMemo=>' || '''' || trim(operationMemo) || '''' --日志信息
      || ',OperationDate=>' || '''' || trim(OperationDate) || '''' --日期
      || ',OperationTime=>' || '''' || trim(OperationTime) || '''' --时间
      || ')';


    RETURN l_string;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN NULL;
  END;



END;
/

