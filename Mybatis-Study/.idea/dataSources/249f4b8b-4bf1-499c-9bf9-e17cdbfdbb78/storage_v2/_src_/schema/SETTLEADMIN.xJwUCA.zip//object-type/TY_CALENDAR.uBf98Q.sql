create TYPE Ty_Calendar AS OBJECT
(
    ExchangeID CHAR(8),  --交易所代码
    Day CHAR(8),  --（自然）日期
    Dat NUMBER(1),  --公历日
    Wrk NUMBER(1),  --工作日
    Tra NUMBER(1),  --交易日
    Sun NUMBER(1),  --周日
    Mon NUMBER(1),  --周一
    Tue NUMBER(1),  --周二
    Wed NUMBER(1),  --周三
    Thu NUMBER(1),  --周四
    Fri NUMBER(1),  --周五
    Sat NUMBER(1),  --周六
    Str NUMBER(1),  --月初
    Tal NUMBER(1),  --月末
    Spr NUMBER(1),  --春节

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_Calendar RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

