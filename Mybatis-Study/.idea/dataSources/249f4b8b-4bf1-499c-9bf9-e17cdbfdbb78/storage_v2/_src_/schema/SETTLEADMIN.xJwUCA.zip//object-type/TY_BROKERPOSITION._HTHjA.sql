create TYPE Ty_BrokerPosition AS OBJECT
(
    TradingDay CHAR(8),  --交易日
    BrokerID CHAR(10),  --经纪公司代码
    ExchangeID CHAR(8),  --交易所代码
    InstrumentID CHAR(30),  --合约代码
    HedgeFlag CHAR(1),  --投机套保标志
    BuyAmt NUMBER(20),  --买入成交量
    BuySum NUMBER(22,6),  --买入成交额
    BOpenAmt NUMBER(20),  --买入开仓量
    BOpenSum NUMBER(22,6),  --买入开仓额
    BCloseAmt NUMBER(20),  --买入平仓量
    BCloseSum NUMBER(22,6),  --买入平仓额
    BCloseTodayAmt NUMBER(20),  --买入平今仓量
    BCloseTodaySum NUMBER(22,6),  --买入平今仓额
    SellAmt NUMBER(20),  --卖出成交量
    SellSum NUMBER(22,6),  --卖出成交额
    SOpenAmt NUMBER(20),  --卖出开仓量
    SOpenSum NUMBER(22,6),  --卖出开仓额
    SCloseAmt NUMBER(20),  --卖出平仓量
    SCloseSum NUMBER(22,6),  --卖出平仓额
    SCloseTodayAmt NUMBER(20),  --卖出平今仓量
    SCloseTodaySum NUMBER(22,6),  --卖出平今仓额
    BTotalAmt NUMBER(20),  --多头持仓量
    BTotalSum NUMBER(22,6),  --多头持仓额
    STotalAmt NUMBER(20),  --空头持仓量
    STotalSum NUMBER(22,6),  --空头持仓额
    BCloseProfitByDate NUMBER(22,6),  --多头平仓盈亏
    SCloseProfitByDate NUMBER(22,6),  --空头平仓盈亏
    BCloseProfitByTrade NUMBER(22,6),  --多头平仓盈亏
    SCloseProfitByTrade NUMBER(22,6),  --空头平仓盈亏
    BPositionProfitByDate NUMBER(22,6),  --多头持仓盈亏
    SPositionProfitByDate NUMBER(22,6),  --空头持仓盈亏
    BPositionProfitByTrade NUMBER(22,6),  --多头持仓盈亏
    SPositionProfitByTrade NUMBER(22,6),  --空头持仓盈亏
    BActual NUMBER(22,6),  --多头当日盈亏
    SActual NUMBER(22,6),  --空头当日盈亏
    TransFee NUMBER(22,6),  --投资者交易手续费
    SettlementFee NUMBER(22,6),  --投资者结算手续费
    DelivFee NUMBER(22,6),  --投资者交割手续费
    TransferPosFee NUMBER(22,6),  --投资者移仓手续费
    StrikeFee NUMBER(22,6),  --投资者执行手续费
    PerformFee NUMBER(22,6),  --投资者履约手续费
    ExchTransFee NUMBER(22,6),  --交易所交易手续费
    ExchSettlementFee NUMBER(22,6),  --交易所结算手续费
    ExchDelivFee NUMBER(22,6),  --交易所交割手续费
    ExchTransferPosFee NUMBER(22,6),  --交易所移仓手续费
    ExchStrikeFee NUMBER(22,6),  --交易所执行手续费
    ExchPerformFee NUMBER(22,6),  --交易所履约手续费
    BMargin NUMBER(22,6),  --投资者多头保证金
    SMargin NUMBER(22,6),  --投资者空头保证金
    ExchBMargin NUMBER(22,6),  --交易所多头保证金
    ExchSMargin NUMBER(22,6),  --交易所空头保证金
    SettlementPrice NUMBER(19,10),  --本次结算价
    BAvgCost NUMBER(22,6),  --买入成本
    SAvgCost NUMBER(22,6),  --卖出成本
    LastBTotalAmt NUMBER(20),  --昨多头持仓量
    LastSTotalAmt NUMBER(20),  --昨空头持仓量
    VolumeMultiple NUMBER(12),  --合约数量乘数

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_BrokerPosition RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

