create TYPE BODY Ty_CAPLog IS

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_CAPLog RETURN SELF AS RESULT IS
  BEGIN
    RETURN;
  END;

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2 IS
    l_string VARCHAR2(4000);
  BEGIN
    l_string:='ty_CAPLog('
      || 'SequenceNo=>' || NVL(to_char(SequenceNo),'NULL')--序号
      || ',ErrorNo=>' || '''' || trim(ErrorNo) || '''' --处理状态
      || ',ErrorInfo=>' || '''' || trim(ErrorInfo) || '''' --处理结果
      || ',MQTopic=>' || '''' || trim(MQTopic) || '''' --MQ业务对象
      || ',MQTag=>' || '''' || trim(MQTag) || '''' --MQ业务类型
      || ',MQKey=>' || '''' || trim(MQKey) || '''' --MQ索引
      || ',MQMsgID=>' || '''' || trim(MQMsgID) || '''' --MQ消息ID
      || ',MQTotal=>' || '''' || trim(MQTotal) || '''' --每个原子操作的消息总数
      || ',MQIndex=>' || '''' || trim(MQIndex) || '''' --单条消息编号
      || ',MQProcessID=>' || '''' || trim(MQProcessID) || '''' --每个原子操作的操作序号
      || ',Sender=>' || '''' || trim(Sender) || '''' --MQ发送方
      || ',BrokerID=>' || '''' || trim(BrokerID) || '''' --经纪公司代码
      || ',OperatorID=>' || '''' || trim(OperatorID) || '''' --操作人代码
      || ',OperateDate=>' || '''' || trim(OperateDate) || '''' --操作日期
      || ',OperateTime=>' || '''' || trim(OperateTime) || '''' --操作时间
      || ')';


    RETURN l_string;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN NULL;
  END;



END;
/

