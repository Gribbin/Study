create TYPE Ty_BrokerFundMortgageIN AS OBJECT
(
    SettleTaskID CHAR(16),  --结算任务ID
    BrokerID CHAR(10),  --经纪公司代码
    ExchangeID CHAR(8),  --交易所代码
    SourceCurrencyID CHAR(3),  --货币质押来源币种
    TargetCurrencyID CHAR(3),  --货币质押目标币种
    SourceDeposit NUMBER(22,6),  --货币质押来源金额
    TargetDeposit NUMBER(22,6),  --货币质押来源金额
    ExchangeRate NUMBER(16,8),  --汇率

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_BrokerFundMortgageIN RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

