create TYPE Ty_AMLEnumMetaData AS OBJECT
(
    EnumValueID CHAR(64),  --枚举值代码
    TagID CHAR(64),  --标签名称代码
    TagValue CHAR(32),  --标签字段内容
    EnumValueResult CHAR(32),  --枚举值结果
    EnumValueDesc VARCHAR2(400),  --枚举值说明

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_AMLEnumMetaData RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

