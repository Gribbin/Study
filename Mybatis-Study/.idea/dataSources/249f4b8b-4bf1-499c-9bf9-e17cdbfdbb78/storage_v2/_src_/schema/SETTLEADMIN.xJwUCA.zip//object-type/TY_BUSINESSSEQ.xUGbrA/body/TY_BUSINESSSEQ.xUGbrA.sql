create TYPE BODY Ty_BusinessSeq IS

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_BusinessSeq RETURN SELF AS RESULT IS
  BEGIN
    RETURN;
  END;

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2 IS
    l_string VARCHAR2(4000);
  BEGIN
    l_string:='ty_BusinessSeq('
      || 'BrokerID=>' || '''' || trim(BrokerID) || '''' --经纪公司代码
      || ',BusinessType=>' || '''' || trim(BusinessType) || '''' --业务类型
      || ',BusinessTypeName=>' || '''' || trim(BusinessTypeName) || '''' --业务类型名称
      || ',CurrentSeqNo=>' || NVL(to_char(CurrentSeqNo),'NULL')--当前序列号
      || ',MinSeqNo=>' || NVL(to_char(MinSeqNo),'NULL')--最小序列号
      || ',MaxSeqNo=>' || NVL(to_char(MaxSeqNo),'NULL')--最大序列号
      || ',IsRefreshByDate=>' || '''' || trim(IsRefreshByDate) || '''' --是否根据日期刷新
      || ',CurrentDate=>' || '''' || trim(CurrentDate) || '''' --当前日期
      || ')';


    RETURN l_string;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN NULL;
  END;



END;
/

