create TYPE Ty_CffexSpTransRatio AS OBJECT
(
    TradingDay CHAR(8),  --交易日
    ExchangeID CHAR(8),  --交易所代码
    ParticipantID CHAR(10),  --会员代码
    ClientID CHAR(10),  --客户编码
    ProductID CHAR(30),  --产品代码
    SpcFeeRate NUMBER(19,8),  --交易手续费率
    SpcFeeDJ NUMBER(22,6),  --交易手续费单价

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_CffexSpTransRatio RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

