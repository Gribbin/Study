create TYPE Ty_AmlCheckReportHis AS OBJECT
(
    TradingDay CHAR(8),  --交易日
    BrokerID CHAR(10),  --经纪公司代码
    ApplyNo NUMBER(8),  --流水号
    CheckNo NUMBER(5),  --操作次数
    FlowID CHAR(1),  --流程ID
    REPORTSEQNO CHAR(20),  --报告序号
    ReportType CHAR(2),  --报告类别
    ACTION CHAR(1),  --报告类别：新增，修改，删除
    FILEPATH VARCHAR2(200),  --报告文件存放路径
    AMLCheckStatus CHAR(1),  --审核状态
    CheckMemo CHAR(400),  --审核情况说明
    CurrCheckLevel CHAR(1),  --当前审核级别
    MaxCheckLevel CHAR(1),  --最高审核级别
    UsedStatus CHAR(1),  --生效状态
    Applier CHAR(64),  --申请人
    ApplyTime CHAR(8),  --申请时间
    IsLatest NUMBER(1),  --是否最新
    OperatorID CHAR(64),  --审核员代码
    OperateDate CHAR(8),  --审核日期
    OperateTime CHAR(8),  --审核时间
    CheckContent VARCHAR2(4000),  --审核内容
    AttatchMent CHAR(160),  --附件

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_AmlCheckReportHis RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

