create TYPE BODY Ty_BrokerFundChgIN IS

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_BrokerFundChgIN RETURN SELF AS RESULT IS
  BEGIN
    RETURN;
  END;

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2 IS
    l_string VARCHAR2(4000);
  BEGIN
    l_string:='ty_BrokerFundChgIN('
      || 'SettleTaskID=>' || '''' || trim(SettleTaskID) || '''' --结算任务ID
      || ',BrokerID=>' || '''' || trim(BrokerID) || '''' --经纪公司代码
      || ',ExchangeID=>' || '''' || trim(ExchangeID) || '''' --交易所代码
      || ',AccountID=>' || '''' || trim(AccountID) || '''' --经纪公司资金账号
      || ',CurrencyID=>' || '''' || trim(CurrencyID) || '''' --经纪公司资金账号币种
      || ',FundDirection=>' || '''' || trim(FundDirection) || '''' --出入金方向
      || ',Deposite=>' || NVL(to_char(Deposite),'NULL')--出入金金额
      || ',DepositSeqNo=>' || '''' || trim(DepositSeqNo) || '''' --出入金流水号
      || ')';


    RETURN l_string;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN NULL;
  END;



END;
/

