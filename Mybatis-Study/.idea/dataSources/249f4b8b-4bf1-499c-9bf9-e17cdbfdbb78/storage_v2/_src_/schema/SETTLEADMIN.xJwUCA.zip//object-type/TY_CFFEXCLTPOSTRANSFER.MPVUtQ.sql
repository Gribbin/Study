create TYPE Ty_CFFEXCltPosTransfer AS OBJECT
(
    TradingDay CHAR(8),  --交易日
    ExchangeID CHAR(8),  --交易所代码
    ParticipantID CHAR(10),  --会员代码
    ClientID CHAR(10),  --投资者号
    ExchangeInstID CHAR(30),  --合约代码
    BTransferPosAmt NUMBER(20),  --多头移仓量
    STransferPosAmt NUMBER(20),  --空头移仓量
    MarginChange NUMBER(22,6),  --保证金变化
    TransferOutPartID CHAR(10),  --移出期货公司
    TransferOutSettlePartID CHAR(10),  --移出期货公司所属结算会员
    TransferInPartID CHAR(10),  --移入期货公司
    TransferInSettlePartID CHAR(10),  --移入期货公司所属结算会员

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_CFFEXCltPosTransfer RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

