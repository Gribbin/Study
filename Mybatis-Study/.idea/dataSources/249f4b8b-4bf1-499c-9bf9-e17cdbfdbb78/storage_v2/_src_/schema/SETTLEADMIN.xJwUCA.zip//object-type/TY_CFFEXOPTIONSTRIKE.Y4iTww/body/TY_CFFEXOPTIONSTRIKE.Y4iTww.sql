create TYPE BODY Ty_CffexOptionStrike IS

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_CffexOptionStrike RETURN SELF AS RESULT IS
  BEGIN
    RETURN;
  END;

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2 IS
    l_string VARCHAR2(4000);
  BEGIN
    l_string:='ty_CffexOptionStrike('
      || 'TradingDay=>' || '''' || trim(TradingDay) || '''' --交易日
      || ',ExchangeID=>' || '''' || trim(ExchangeID) || '''' --交易所代码
      || ',ParticipantID=>' || '''' || trim(ParticipantID) || '''' --会员代码
      || ',ClientID=>' || '''' || trim(ClientID) || '''' --客户编码
      || ',ExchangeInstID=>' || '''' || trim(ExchangeInstID) || '''' --合约代码
      || ',DeliveryPrice=>' || NVL(to_char(DeliveryPrice),'NULL')--交割结算价
      || ',BuyNotCloseNum=>' || NVL(to_char(BuyNotCloseNum),'NULL')--买未平仓量
      || ',BuyCanStrikeNum=>' || NVL(to_char(BuyCanStrikeNum),'NULL')--买可执行量
      || ',GiveUpStrikeNum=>' || NVL(to_char(GiveUpStrikeNum),'NULL')--申请放弃执行量
      || ',BuyStrikeNum=>' || NVL(to_char(BuyStrikeNum),'NULL')--买执行量
      || ',SellNotCloseNum=>' || NVL(to_char(SellNotCloseNum),'NULL')--卖未平仓量
      || ',SellStrikeNum=>' || NVL(to_char(SellStrikeNum),'NULL')--卖执行量
      || ',OptStrikeProfit=>' || NVL(to_char(OptStrikeProfit),'NULL')--期权执行盈亏
      || ',OptStrikeFee=>' || NVL(to_char(OptStrikeFee),'NULL')--期权执行手续费
      || ')';


    RETURN l_string;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN NULL;
  END;



END;
/

