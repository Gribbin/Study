create TYPE BODY Ty_CRARiskIndexOption IS

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_CRARiskIndexOption RETURN SELF AS RESULT IS
  BEGIN
    RETURN;
  END;

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2 IS
    l_string VARCHAR2(4000);
  BEGIN
    l_string:='ty_CRARiskIndexOption('
      || 'BrokerID=>' || '''' || trim(BrokerID) || '''' --经纪商代码
      || ',RiskFactorID=>' || NVL(to_char(RiskFactorID),'NULL')--风险因素ID
      || ',RiskIndexID=>' || NVL(to_char(RiskIndexID),'NULL')--风险指标ID
      || ',RiskIndexOptionID=>' || NVL(to_char(RiskIndexOptionID),'NULL')--风险指标项ID
      || ',RiskIndexOptionName=>' || '''' || trim(RiskIndexOptionName) || '''' --名称
      || ',RiskIndexOptionDesc=>' || '''' || trim(RiskIndexOptionDesc) || '''' --说明
      || ',RiskIndexOptionScore=>' || NVL(to_char(RiskIndexOptionScore),'NULL')--分类评分
      || ',IsAddItem=>' || '''' || trim(IsAddItem) || '''' --是否附加项
      || ')';


    RETURN l_string;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN NULL;
  END;



END;
/

