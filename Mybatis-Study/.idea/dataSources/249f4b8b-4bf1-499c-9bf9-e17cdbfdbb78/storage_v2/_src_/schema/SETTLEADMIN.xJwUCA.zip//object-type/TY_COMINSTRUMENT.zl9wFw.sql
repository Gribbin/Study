create TYPE Ty_ComInstrument AS OBJECT
(
    InstrumentID CHAR(80),  --合约代码
    ExchangeID CHAR(8),  --交易所代码
    InstrumentName CHAR(20),  --合约名称
    ExchangeInstID CHAR(80),  --合约在交易所的代码
    ProductID CHAR(30),  --产品代码
    ProductClass CHAR(1),  --产品类型
    DeliveryYear NUMBER(4),  --交割年份
    DeliveryMonth NUMBER(2),  --交割月
    MaxMarketOrderVolume NUMBER(20),  --市价单最大下单量
    MinMarketOrderVolume NUMBER(20),  --市价单最小下单量
    MaxLimitOrderVolume NUMBER(20),  --限价单最大下单量
    MinLimitOrderVolume NUMBER(20),  --限价单最小下单量
    VolumeMultiple NUMBER(12),  --合约数量乘数
    PriceTick NUMBER(19,10),  --最小变动价位
    CreateDate CHAR(8),  --创建日
    OpenDate CHAR(8),  --上市日
    ExpireDate CHAR(8),  --到期日
    StartDelivDate CHAR(8),  --开始交割日
    EndDelivDate CHAR(8),  --结束交割日
    InstLifePhase CHAR(1),  --合约生命周期状态
    IsTrading NUMBER(1),  --当前是否交易
    PositionType CHAR(1),  --持仓类型
    PositionDateType CHAR(1),  --持仓日期类型
    LongMarginRatio NUMBER(19,8),  --多头保证金率
    ShortMarginRatio NUMBER(19,8),  --空头保证金率
    MaxMarginSideAlgorithm CHAR(1),  --是否使用大额单边保证金算法
    UnderlyingInstrID CHAR(30),  --基础商品代码
    StrikePrice NUMBER(19,10),  --执行价
    OptionsType CHAR(1),  --期权类型
    UnderlyingMultiple NUMBER(19,8),  --合约基础商品乘数
    CombinationType CHAR(1),  --组合类型

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_ComInstrument RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

