create TYPE BODY Ty_ClearAccountSync IS

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_ClearAccountSync RETURN SELF AS RESULT IS
  BEGIN
    RETURN;
  END;

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2 IS
    l_string VARCHAR2(4000);
  BEGIN
    l_string:='ty_ClearAccountSync('
      || 'BrokerID=>' || '''' || trim(BrokerID) || '''' --经纪公司代码
      || ',BankID=>' || '''' || trim(BankID) || '''' --银行代码
      || ',ClearAccount=>' || '''' || trim(ClearAccount) || '''' --结算账户
      || ',OpenName=>' || '''' || trim(OpenName) || '''' --结算账户名称
      || ',CurrencyCode=>' || '''' || trim(CurrencyCode) || '''' --结算币别
      || ',IsMainClearAccount=>' || '''' || trim(IsMainClearAccount) || '''' --是否主账户
      || ',Memo=>' || '''' || trim(Memo) || '''' --备注
      || ')';


    RETURN l_string;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN NULL;
  END;



END;
/

