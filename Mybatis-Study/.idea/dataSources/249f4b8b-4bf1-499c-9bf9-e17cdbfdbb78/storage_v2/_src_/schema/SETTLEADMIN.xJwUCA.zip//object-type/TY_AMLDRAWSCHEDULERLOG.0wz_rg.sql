create TYPE Ty_AmlDrawSchedulerLog AS OBJECT
(
    Id NUMBER(15),  --序号
    BrokerID CHAR(10),  --经纪公司代码
    DrawDay CHAR(8),  --检查日期
    Description VARCHAR2(4000),  --描述
    OperatorId CHAR(64),  --操作员代码
    OperateDate CHAR(8),  --日期
    OperateTime CHAR(8),  --时间

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_AmlDrawSchedulerLog RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

