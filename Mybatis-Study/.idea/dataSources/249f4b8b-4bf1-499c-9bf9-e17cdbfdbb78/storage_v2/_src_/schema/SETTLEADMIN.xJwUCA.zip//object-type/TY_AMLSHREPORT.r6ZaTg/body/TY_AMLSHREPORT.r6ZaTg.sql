create TYPE BODY Ty_AMLSHReport IS

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_AMLSHReport RETURN SELF AS RESULT IS
  BEGIN
    RETURN;
  END;

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2 IS
    l_string VARCHAR2(4000);
  BEGIN
    l_string:='ty_AMLSHReport('
      || 'BrokerID=>' || '''' || trim(BrokerID) || '''' --经纪公司代码
      || ',InvestorID=>' || '''' || trim(InvestorID) || '''' --投资者代码
      || ',TouchDay=>' || '''' || trim(TouchDay) || '''' --大额交易发生日期
      || ',CharacterID=>' || '''' || trim(CharacterID) || '''' --大额交易特征代码
      || ',DrawDay=>' || '''' || trim(DrawDay) || '''' --检查日期
      || ',AMLGenStatus=>' || '''' || trim(AMLGenStatus) || '''' --数据来源
      || ',InvestorType=>' || '''' || trim(InvestorType) || '''' --投资者类型
      || ',InvestorName=>' || '''' || trim(InvestorName) || '''' --投资者名称
      || ',IdentifiedCardType=>' || '''' || trim(IdentifiedCardType) || '''' --证件类型
      || ',IdentifiedCardNo=>' || '''' || trim(IdentifiedCardNo) || '''' --证件号码
      || ',National=>' || '''' || trim(National) || '''' --身份归属国家/地区
      || ',IsReport=>' || '''' || trim(IsReport) || '''' --是否报送
      || ')';


    RETURN l_string;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN NULL;
  END;



END;
/

