create TYPE Ty_AmlNiShTrade AS OBJECT
(
    BrokerID CHAR(10),  --经纪公司代码
    CharacterID CHAR(4),  --大额交易特征码
    TouchDay CHAR(8),  --大额交易发生日期
    DrawDay CHAR(8),  --检查日期
    InvestorID CHAR(12),  --投资者代码
    DataSource VARCHAR2(5),  --数据来源
    CTNM VARCHAR2(30),  --客户姓名
    CITP VARCHAR2(10),  --客户身份证件/证明文件类型
    CTID VARCHAR2(50),  --客户身份证件/证明文件号码
    FINC VARCHAR2(20),  --金融机构网点代码
    RLFC VARCHAR2(20),  --金融机构与客户的关系
    CATP VARCHAR2(10),  --客户账户类型
    CTAC VARCHAR2(50),  --客户账号
    OATM VARCHAR2(30),  --客户账户开立时间
    CBCT VARCHAR2(10),  --客户银行卡类型
    CBCN VARCHAR2(50),  --客户银行卡号码
    TBNM VARCHAR2(30),  --交易代办人姓名
    TBIT VARCHAR2(10),  --交易代办人身份证件/证明文件类型
    TBID VARCHAR2(50),  --交易代办人身份证件/证明文件号码
    TBNT VARCHAR2(5),  --交易代办人国籍
    TSTM VARCHAR2(30),  --交易时间
    TRCD VARCHAR2(10),  --交易发生地
    TICD VARCHAR2(50),  --业务标识号
    RPMT VARCHAR2(10),  --收付款方匹配号类型
    RPMN VARCHAR2(50),  --收付款方匹配号
    TSTP VARCHAR2(10),  --交易方式
    OCTT VARCHAR2(10),  --非柜台交易方式
    OOCT VARCHAR2(10),  --其他非柜台交易方式
    OCEC VARCHAR2(50),  --非柜台交易方式的设备代码
    BPTC VARCHAR2(50),  --银行与支付机构之间的业务交易编码
    TSCT VARCHAR2(10),  --涉外收支交易分类与代码
    TSDR VARCHAR2(10),  --资金收付标志
    CRPP VARCHAR2(30),  --资金用途
    CRTP VARCHAR2(3),  --交易币种
    CRAT VARCHAR2(100),  --交易金额
    CRMB VARCHAR2(100),  --交易金额（折人民币）
    CUSD VARCHAR2(100),  --交易金额（折美元）
    CFIN VARCHAR2(50),  --对方金融机构网点名称
    CFCT VARCHAR2(10),  --对方金融机构网点代码类型
    CFIC VARCHAR2(30),  --对方金融机构网点代码
    CFRC VARCHAR2(10),  --对方金融机构网点行政区划代码
    TCNM VARCHAR2(30),  --交易对手姓名/名称
    TCIT VARCHAR2(10),  --交易对手身份证件/证明文件类型
    OITP VARCHAR2(10),  --其他身份证件/证明文件类型
    TCID VARCHAR2(50),  --交易对手身份证件/证明文件号码
    TCAT VARCHAR2(10),  --交易对手账户类型
    TCAC VARCHAR2(50),  --交易对手账号
    ROTF VARCHAR2(300),  --交易信息备注

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_AmlNiShTrade RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

