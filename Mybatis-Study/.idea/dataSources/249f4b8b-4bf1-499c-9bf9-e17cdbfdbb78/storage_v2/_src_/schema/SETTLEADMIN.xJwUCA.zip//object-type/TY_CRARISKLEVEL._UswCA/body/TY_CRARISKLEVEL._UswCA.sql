create TYPE BODY Ty_CRARiskLevel IS

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_CRARiskLevel RETURN SELF AS RESULT IS
  BEGIN
    RETURN;
  END;

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2 IS
    l_string VARCHAR2(4000);
  BEGIN
    l_string:='ty_CRARiskLevel('
      || 'BrokerID=>' || '''' || trim(BrokerID) || '''' --经纪商代码
      || ',RiskLevel=>' || NVL(to_char(RiskLevel),'NULL')--等级编号
      || ',ScoreLower=>' || NVL(to_char(ScoreLower),'NULL')--分值下限
      || ',ScoreUpper=>' || NVL(to_char(ScoreUpper),'NULL')--分值上限
      || ',LevelDesc=>' || '''' || trim(LevelDesc) || '''' --等级名称
      || ',Validity=>' || '''' || trim(Validity) || '''' --复评有效期
      || ')';


    RETURN l_string;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN NULL;
  END;



END;
/

