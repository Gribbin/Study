create PACKAGE BODY PKGI_ASTSettleTools  IS
  /*************************************************************************
  $spDesc 检查系统状态是否符合增备条件
  *************************************************************************/
  PROCEDURE up_CheckBackSettleDataStatus
  (
     o_BackSettleDataDay OUT NOCOPY PKGS_DATATYPE.STY_DATE  --符合备份条件的系统日期
    ,o_BackSettleDataLastDay OUT NOCOPY PKGS_DATATYPE.STY_DATE  --昨结算日
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_ASTSettleTools.up_CheckBackSettleDataStatus';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '检查系统状态是否符合增备条件';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, 'AST统一工具平台调用包', '检查系统状态是否符合增备条件');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_ASTSettleTools.up_CheckBackSettleDataStatus(' ||
                        'o_BackSettleDataDay'
                      || ',' ||
                        'o_BackSettleDataLastDay'
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_ASTSettleTools.up_CheckBackSettleDataStatus(
                               o_BackSettleDataDay
                              ,o_BackSettleDataLastDay
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_CheckBackSettleDataStatus;

  /*************************************************************************
  $spDesc 获取增备流水号
  *************************************************************************/
  PROCEDURE up_GetBackSettleDataSeq
  (
     o_SettleDataSeq OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --增备流水号
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_ASTSettleTools.up_GetBackSettleDataSeq';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '获取增备流水号';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, 'AST统一工具平台调用包', '获取增备流水号');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_ASTSettleTools.up_GetBackSettleDataSeq(' ||
                        'o_SettleDataSeq'
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_ASTSettleTools.up_GetBackSettleDataSeq(
                               o_SettleDataSeq
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_GetBackSettleDataSeq;

  /*************************************************************************
  $spDesc 更新增备流水号
  *************************************************************************/
  PROCEDURE up_UpdBackSettleDataSeq
  (
     o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_ASTSettleTools.up_UpdBackSettleDataSeq';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '更新增备流水号';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, 'AST统一工具平台调用包', '更新增备流水号');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_ASTSettleTools.up_UpdBackSettleDataSeq(' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_ASTSettleTools.up_UpdBackSettleDataSeq(
                               o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_UpdBackSettleDataSeq;

  /*************************************************************************
  $spDesc 查询需要进行备份的表中的详细数据
  *************************************************************************/
  PROCEDURE up_QueryBackSettleTableData
  (
     i_TradingDay IN PKGS_DATATYPE.STY_DATE  --交易日
    ,i_lastTradingDay IN PKGS_DATATYPE.STY_DATE  --昨交易日
    ,i_Schema IN PKGS_DATATYPE.STY_LOGIC  --Schema
    ,i_TableName IN PKGS_DATATYPE.STY_TABLENAME  --TableName
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_BackSettleTableData OUT NOCOPY PKGS_DATATYPE.TYPEREFCURSOR  --查询结果游标
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_ASTSettleTools.up_QueryBackSettleTableData';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '查询需要进行备份的表中的详细数据';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, 'AST统一工具平台调用包', '查询需要进行备份的表中的详细数据');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_ASTSettleTools.up_QueryBackSettleTableData(' ||
                           '''' || trim(i_TradingDay) || ''''
                      || ',' ||
                           '''' || trim(i_lastTradingDay) || ''''
                      || ',' ||
                           '''' || trim(i_Schema) || ''''
                      || ',' ||
                           '''' || trim(i_TableName) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_BackSettleTableData'
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_ASTSettleTools.up_QueryBackSettleTableData(
                               i_TradingDay
                              ,i_lastTradingDay
                              ,i_Schema
                              ,i_TableName
                              ,o_BackSettleTableData
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_QueryBackSettleTableData;

  /*************************************************************************
  $spDesc 查询需要进行备份的表导入时需要使用的delete/truncate语句
  *************************************************************************/
  PROCEDURE up_QueryBackSettleDelSQL
  (
     i_TradingDay IN PKGS_DATATYPE.STY_DATE  --交易日
    ,i_lastTradingDay IN PKGS_DATATYPE.STY_DATE  --昨交易日
    ,i_Schema IN PKGS_DATATYPE.STY_LOGIC  --Schema
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_truncateSql OUT NOCOPY CLOB  --返回的truncate语句
    ,o_deleteSql OUT NOCOPY CLOB  --返回的delete语句
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_ASTSettleTools.up_QueryBackSettleDelSQL';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '查询需要进行备份的表导入时需要使用的delete/truncate语句';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, 'AST统一工具平台调用包', '查询需要进行备份的表导入时需要使用的delete/truncate语句');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_ASTSettleTools.up_QueryBackSettleDelSQL(' ||
                           '''' || trim(i_TradingDay) || ''''
                      || ',' ||
                           '''' || trim(i_lastTradingDay) || ''''
                      || ',' ||
                           '''' || trim(i_Schema) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_truncateSql'
                      || ',' ||
                        'o_deleteSql'
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_ASTSettleTools.up_QueryBackSettleDelSQL(
                               i_TradingDay
                              ,i_lastTradingDay
                              ,i_Schema
                              ,o_truncateSql
                              ,o_deleteSql
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_QueryBackSettleDelSQL;

  /*************************************************************************
  $spDesc 查询需要进行备份的表导入时使用的ctl语句
  *************************************************************************/
  PROCEDURE up_QueryBackSettleCtlMsg
  (
     i_Schema IN PKGS_DATATYPE.STY_LOGIC  --Schema
    ,i_TableName IN PKGS_DATATYPE.STY_TABLENAME  --TableName
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_BackSettleCtlMsg OUT NOCOPY CLOB  --单个表导入使用ctl语句
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_ASTSettleTools.up_QueryBackSettleCtlMsg';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '查询需要进行备份的表导入时使用的ctl语句';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, 'AST统一工具平台调用包', '查询需要进行备份的表导入时使用的ctl语句');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_ASTSettleTools.up_QueryBackSettleCtlMsg(' ||
                           '''' || trim(i_Schema) || ''''
                      || ',' ||
                           '''' || trim(i_TableName) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_BackSettleCtlMsg'
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_ASTSettleTools.up_QueryBackSettleCtlMsg(
                               i_Schema
                              ,i_TableName
                              ,o_BackSettleCtlMsg
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_QueryBackSettleCtlMsg;

  /*************************************************************************
  $spDesc 查询需要进行备份的数据数量
  *************************************************************************/
  PROCEDURE up_QueryBackDataCount
  (
     i_TradingDay IN PKGS_DATATYPE.STY_DATE  --交易日
    ,i_lastTradingDay IN PKGS_DATATYPE.STY_DATE  --昨交易日
    ,i_Schema IN PKGS_DATATYPE.STY_LOGIC  --Schema
    ,i_TableName IN PKGS_DATATYPE.STY_TABLENAME  --TableName
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_BackDataCount OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --表中数据条数
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_ASTSettleTools.up_QueryBackDataCount';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '查询需要进行备份的数据数量';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, 'AST统一工具平台调用包', '查询需要进行备份的数据数量');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_ASTSettleTools.up_QueryBackDataCount(' ||
                           '''' || trim(i_TradingDay) || ''''
                      || ',' ||
                           '''' || trim(i_lastTradingDay) || ''''
                      || ',' ||
                           '''' || trim(i_Schema) || ''''
                      || ',' ||
                           '''' || trim(i_TableName) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_BackDataCount'
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_ASTSettleTools.up_QueryBackDataCount(
                               i_TradingDay
                              ,i_lastTradingDay
                              ,i_Schema
                              ,i_TableName
                              ,o_BackDataCount
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_QueryBackDataCount;

END PKGI_ASTSettleTools;
/

