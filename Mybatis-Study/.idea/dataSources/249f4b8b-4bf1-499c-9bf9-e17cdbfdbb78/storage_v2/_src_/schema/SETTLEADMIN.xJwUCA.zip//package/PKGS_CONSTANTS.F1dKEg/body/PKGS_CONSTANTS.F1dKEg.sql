create PACKAGE BODY PKGS_Constants IS
  ----返回值----->>
  FUNCTION C_RET_SUCCESS RETURN pkgs_datatype.STY_RETCODE DETERMINISTIC IS
    l_number pkgs_datatype.STY_RETCODE;
  BEGIN
    l_number := 0;
    RETURN l_number;
  END C_RET_SUCCESS;

  FUNCTION C_RET_FAIL RETURN pkgs_datatype.STY_RETCODE DETERMINISTIC IS
    l_number pkgs_datatype.STY_RETCODE;
  BEGIN
    l_number := -1;
    RETURN l_number;
  END C_RET_FAIL;
  ----返回值-----<<

  ----返回信息----->>
  FUNCTION C_RETMSG_SUCCESS RETURN pkgs_datatype.STY_RETMSG DETERMINISTIC IS
    l_char pkgs_datatype.STY_RETMSG;
  BEGIN
    l_char := '操作成功';
    RETURN l_char;
  END C_RETMSG_SUCCESS;

  FUNCTION C_RETMSG_FAIL RETURN pkgs_datatype.STY_RETMSG DETERMINISTIC IS
    l_char pkgs_datatype.STY_RETMSG;
  BEGIN
    l_char := '操作失败';
    RETURN l_char;
  END C_RETMSG_FAIL;
  ----返回信息-----<<

  -- SP执行后返回的三类异常编码-->>
  --  Oracle抛出的运行异常
  FUNCTION E_RUNTIME_ERROR RETURN pkgs_datatype.STY_RETCODE DETERMINISTIC IS
    l_number pkgs_datatype.STY_RETCODE;
  BEGIN
    l_number := 1;
    RETURN l_number;
  END E_RUNTIME_ERROR;

  --  用户已经转义的异常
  FUNCTION E_USER_ERROR RETURN pkgs_datatype.STY_RETCODE DETERMINISTIC IS
    l_number pkgs_datatype.STY_RETCODE;
  BEGIN
    l_number := 2;
    RETURN l_number;
  END E_USER_ERROR;

  --  要求 应用程序 重新连接数据库的异常
  FUNCTION E_RECONNECT_ERROR RETURN pkgs_datatype.STY_RETCODE DETERMINISTIC IS
    l_number pkgs_datatype.STY_RETCODE;
  BEGIN
    l_number := 3;
    RETURN l_number;
  END E_RECONNECT_ERROR;
  -- SP执行后返回的三类异常编码--<<

  -- 新增记录的初始版本号
  FUNCTION C_Initial_VersionNo RETURN pkgs_datatype.STY_VERSIONNO DETERMINISTIC IS
    l_versionno pkgs_datatype.STY_VERSIONNO;
  BEGIN
    l_versionno := 1;
    RETURN l_versionno;
  END C_Initial_VersionNo;

  -- 新增用户的初始密码
  FUNCTION C_Initial_Password RETURN pkgs_datatype.STY_RETMSG DETERMINISTIC IS
    l_password pkgs_datatype.STY_RETMSG;
  BEGIN
    l_password := '888888';
    RETURN l_password;
  END C_Initial_Password;

  --数据已被他人更新,请获取最新数据
  FUNCTION E_VERSIONNO_TOO_OLD RETURN pkgs_datatype.STY_RETCODE DETERMINISTIC IS
    l_retcode pkgs_datatype.STY_RETCODE;
  BEGIN
    l_retcode := 4;
    RETURN l_retcode;
  END E_VERSIONNO_TOO_OLD;

  --'数据已被他人更新,请获取最新数据';
  FUNCTION EMSG_VERSIONNO_TOO_OLD RETURN pkgs_datatype.STY_RETMSG DETERMINISTIC IS
    l_msg pkgs_datatype.STY_RETMSG;
  BEGIN
    l_msg := '数据已被他人更新,请获取最新数据';
    RETURN l_msg;
  END EMSG_VERSIONNO_TOO_OLD;

  -------------系统支持的LOG级别设置--------------------
  FUNCTION C_LOG_DEBUG RETURN t_operationlog.loglevel%TYPE DETERMINISTIC IS
    l_loglevel t_operationlog.loglevel%TYPE;
  BEGIN
    l_loglevel := 'Debug';
    RETURN l_loglevel;
  END C_LOG_DEBUG;

  FUNCTION C_LOG_INFO RETURN t_operationlog.loglevel%TYPE DETERMINISTIC IS
    l_loglevel t_operationlog.loglevel%TYPE;
  BEGIN
    l_loglevel := 'Info';
    RETURN l_loglevel;
  END C_LOG_INFO;

  FUNCTION C_LOG_WARN RETURN t_operationlog.loglevel%TYPE DETERMINISTIC IS
    l_loglevel t_operationlog.loglevel%TYPE;
  BEGIN
    l_loglevel := 'Warn';
    RETURN l_loglevel;
  END C_LOG_WARN;

  FUNCTION C_LOG_ERROR RETURN t_operationlog.loglevel%TYPE DETERMINISTIC IS
    l_loglevel t_operationlog.loglevel%TYPE;
  BEGIN
    l_loglevel := 'Error';
    RETURN l_loglevel;
  END C_LOG_ERROR;

  FUNCTION C_UNIT_TEST RETURN t_operationlog.loglevel%TYPE DETERMINISTIC IS
    l_loglevel t_operationlog.loglevel%TYPE;
  BEGIN
    l_loglevel := 'Unit';
    RETURN l_loglevel;
  END C_UNIT_TEST;

  ----------------------------功能代码---------------------------
  FUNCTION C_FunctionCode_NONE RETURN CHAR DETERMINISTIC IS
    l_functioncode CHAR(24);
  BEGIN
    l_functioncode := '0000';
    RETURN l_functioncode;
  END C_FunctionCode_NONE;

  ----------------------------默认语种-中文简体---------------------------
  FUNCTION C_LANG_CHS RETURN CHAR DETERMINISTIC IS
    l_chLanguage CHAR(5);
  BEGIN
    l_chLanguage := 'cn_ZH';
    RETURN l_chLanguage;
  END C_LANG_CHS;

  FUNCTION C_LANG_ENG RETURN CHAR DETERMINISTIC IS
    l_chLanguage CHAR(5);
  BEGIN
    l_chLanguage := 'en_US';
    RETURN l_chLanguage;
  END C_LANG_ENG;
 -----------------------------文件状态------------------------------------
  FUNCTION C_FUS_SUCCEED_UPLOAD RETURN CHAR DETERMINISTIC IS
    l_SucceedUpload CHAR(1);
  BEGIN
    l_SucceedUpload := '1';---- 上传成功
    RETURN l_SucceedUpload;
  END C_FUS_SUCCEED_UPLOAD;

  FUNCTION C_FUS_FAILED_UPLOAD RETURN CHAR DETERMINISTIC IS
    l_FailedUpload CHAR(1);
  BEGIN
    l_FailedUpload := '2';---- 上传失败
    RETURN l_FailedUpload;
  END C_FUS_FAILED_UPLOAD;

  FUNCTION C_FUS_SUCCEED_LOAD RETURN CHAR DETERMINISTIC IS
    l_SucceedLoad CHAR(1);
  BEGIN
    l_SucceedLoad := '3';---- 导入成功
    RETURN l_SucceedLoad;
  END C_FUS_SUCCEED_LOAD;

  FUNCTION C_FUS_PART_SUCCEED_LOAD RETURN CHAR DETERMINISTIC IS
    l_PartSucceedLoad CHAR(1);
  BEGIN
    l_PartSucceedLoad := '4';---- 导入部分成功
    RETURN l_PartSucceedLoad;
  END C_FUS_PART_SUCCEED_LOAD;

  FUNCTION C_FUS_FAILED_LOAD RETURN CHAR DETERMINISTIC IS
    l_FailedLoad CHAR(1);
  BEGIN
    l_FailedLoad := '5';---- 导入失败
    RETURN l_FailedLoad;
  END C_FUS_FAILED_LOAD;
 -----------------------------文件标识------------------------------------

  FUNCTION C_FI_SETTLE_FUND RETURN CHAR DETERMINISTIC IS ---- 资金数据
    l_SettleFund  CHAR(1);
  BEGIN
    l_SettleFund  := 'F';
    RETURN l_SettleFund ;
  END C_FI_SETTLE_FUND;

  FUNCTION C_FI_Trade RETURN CHAR DETERMINISTIC IS ---- 成交数据
    l_Trade  CHAR(1);
  BEGIN
    l_Trade  := 'T';
    RETURN l_Trade ;
  END C_FI_Trade;

  FUNCTION C_FI_IVST_POSITION  RETURN CHAR DETERMINISTIC IS ---- 投资者持仓数据
    l_InvestorPosition   CHAR(1);
  BEGIN
    l_InvestorPosition   := 'P';
    RETURN l_InvestorPosition  ;
  END C_FI_IVST_POSITION;

  FUNCTION C_FI_SUBENTRYFUND RETURN CHAR DETERMINISTIC IS ---- 投资者分项资金数据
    l_SubEntryFund  CHAR(1);
  BEGIN
    l_SubEntryFund  := 'O';
    RETURN l_SubEntryFund ;
  END C_FI_SUBENTRYFUND;

  FUNCTION C_FI_CZCECOMBINATIONPOS RETURN CHAR DETERMINISTIC IS ---- 组合持仓数据
    l_CZCECombinationPos  CHAR(1);
  BEGIN
    l_CZCECombinationPos  := 'C';
    RETURN l_CZCECombinationPos ;
  END C_FI_CZCECOMBINATIONPOS;

  FUNCTION C_FI_CSRCDATA RETURN CHAR DETERMINISTIC IS ---- 上报保证金监控中心数据
    l_CSRCData  CHAR(1);
  BEGIN
    l_CSRCData  := 'R';
    RETURN l_CSRCData ;
  END C_FI_CSRCDATA;

  FUNCTION C_FI_CZCECLOSE RETURN CHAR DETERMINISTIC IS ---- 郑商所平仓数据
    l_CZCEClose  CHAR(1);
  BEGIN
    l_CZCEClose  := 'L';
    RETURN l_CZCEClose ;
  END C_FI_CZCECLOSE;

  FUNCTION C_FI_CZCENOCLOSE  RETURN CHAR DETERMINISTIC IS ---- 郑商所非平仓了结数据
    l_CZCENoClose   CHAR(1);
  BEGIN
    l_CZCENoClose   := 'N';
    RETURN l_CZCENoClose  ;
  END C_FI_CZCENOCLOSE ;

  FUNCTION C_FI_PositionDtl RETURN CHAR DETERMINISTIC IS ---- 持仓明细数据
    l_PositionDtl  CHAR(1);
  BEGIN
    l_PositionDtl  := 'D';
    RETURN l_PositionDtl ;
  END C_FI_PositionDtl;

  FUNCTION C_FUT_SETTLEMENT RETURN CHAR DETERMINISTIC IS ---- 结算
    l_Settlement  CHAR(1);
  BEGIN
    l_Settlement  := '0';
    RETURN l_Settlement ;
  END C_FUT_SETTLEMENT;

  FUNCTION C_FUT_CHECK RETURN CHAR DETERMINISTIC IS ---- 核对
    l_Check  CHAR(1);
  BEGIN
    l_Check  := '1';
    RETURN l_Check ;
  END C_FUT_CHECK;

  FUNCTION C_FI_CFFEXCombPosition  RETURN CHAR DETERMINISTIC IS ---- 中金所组合持仓数据
    l_CFFEXCombPosition   CHAR(1);
  BEGIN
    l_CFFEXCombPosition   := 'X';
    RETURN l_CFFEXCombPosition  ;
  END C_FI_CFFEXCombPosition ;

  FUNCTION C_FI_CffexCombRule  RETURN CHAR DETERMINISTIC IS ---- 中金所组合策略规则
    l_CffexCombRule   CHAR(1);
  BEGIN
    l_CffexCombRule   := 'U';
    RETURN l_CffexCombRule  ;
  END C_FI_CffexCombRule ;

  FUNCTION C_FI_CffexExchangeRate  RETURN CHAR DETERMINISTIC IS ---- 中金所交叉汇率
    l_CffexExchangeRate   CHAR(1);
  BEGIN
    l_CffexExchangeRate   := 'E';
    RETURN l_CffexExchangeRate  ;
  END C_FI_CffexExchangeRate ;

  FUNCTION C_FI_CffexSpcTransRatio  RETURN CHAR DETERMINISTIC IS ---- 中金所差异化手续费率表
    l_CffexSpcTransRatio   CHAR(1);
  BEGIN
    l_CffexSpcTransRatio   := 'Y';
    RETURN l_CffexSpcTransRatio  ;
  END C_FI_CffexSpcTransRatio ;

  FUNCTION C_FI_CffexPosTransfer  RETURN CHAR DETERMINISTIC IS ---- 中金所移仓文件
    l_CffexPosTransfer   CHAR(1);
  BEGIN
    l_CffexPosTransfer   := 'A';
    RETURN l_CffexPosTransfer  ;
  END C_FI_CffexPosTransfer ;


  -----------------------------布尔常量定义------------------------------------

  FUNCTION C_BOOL_TRUE RETURN PKGS_DataType.STY_Bool DETERMINISTIC IS  ---- True
	l_nBool  PKGS_DataType.STY_Bool;
  BEGIN
    l_nBool  := 1;
	  RETURN l_nBool;
  END C_BOOL_TRUE;

  FUNCTION C_BOOL_FALSE RETURN PKGS_DataType.STY_Bool DETERMINISTIC IS ---- False
    l_nBool		PKGS_DataType.STY_Bool;
  BEGIN
    l_nBool  := 0;
	  RETURN l_nBool;
  END C_BOOL_FALSE;
   -------------------------------币种代码--------------------------------------
  FUNCTION C_CURRENCY_CNY        RETURN   t_account.currencyid%Type   DETERMINISTIC IS
    ---- 人民币
 	l_currency  t_account.currencyid%Type;
  BEGIN
    l_currency  := 'CNY';
	  RETURN l_currency;
  END C_CURRENCY_CNY;

  FUNCTION C_CURRENCY_USD        RETURN   t_account.currencyid%Type   DETERMINISTIC IS
    ---- 美元
 	l_currency  t_account.currencyid%Type;
  BEGIN
    l_currency  := 'USD';
	  RETURN l_currency;
  END C_CURRENCY_USD;

  FUNCTION C_CURRENCY_HKD        RETURN   t_account.currencyid%Type   DETERMINISTIC IS
    ---- 港币
 	l_currency  t_account.currencyid%Type;
  BEGIN
    l_currency  := 'HKD';
	  RETURN l_currency;
  END C_CURRENCY_HKD;

  FUNCTION C_DEFAULT_CURRENCY    RETURN   t_account.currencyid%Type   DETERMINISTIC IS
    ---- 默认人民币
 	l_currency  t_account.currencyid%Type;
  BEGIN
    l_currency  := 'CNY';
	  RETURN l_currency;
  END C_DEFAULT_CURRENCY;
  --------------------------------文件标识相关-----------------------------------
  FUNCTION C_FI_OptionStrike   RETURN CHAR DETERMINISTIC IS ---- 期权执行文件
   --CONSTANT TypeEnumChar := 'S';
    l_CHAR  CHAR(1);
  BEGIN
    l_CHAR  := 'S';
    RETURN l_CHAR ;
  END C_FI_OptionStrike;

  FUNCTION C_FI_MarginParam   RETURN CHAR DETERMINISTIC IS---- 保证金参数文件
   --CONSTANT TypeEnumChar := 'M';
    l_CHAR  CHAR(1);
  BEGIN
    l_CHAR  := 'M';
    RETURN l_CHAR ;
  END C_FI_MarginParam;

  FUNCTION C_FI_NonTradePosChange  RETURN CHAR DETERMINISTIC IS ---- 上期所非持仓变动明细
    l_CHAR  CHAR(1);
  BEGIN
    l_CHAR  := 'B';
    RETURN l_CHAR ;
  END C_FI_NonTradePosChange;

  FUNCTION C_FI_ExchangeRate   RETURN CHAR DETERMINISTIC IS---- 汇率文件
   --CONSTANT TypeEnumChar := 'I';
    l_CHAR  CHAR(1);
  BEGIN
    l_CHAR  := 'I';
    RETURN l_CHAR ;
  END C_FI_ExchangeRate;

  -- --------------------------------期权类型----------------------------------------------
  FUNCTION CP_CallOptions  RETURN CHAR DETERMINISTIC IS
    --CONSTANT TypeEnumChar := '1' ;        ---- 看涨
     l_CHAR  CHAR(1);
  BEGIN
    l_CHAR  := '1';
    RETURN l_CHAR ;
  END CP_CallOptions;

  FUNCTION CP_PutOptions   RETURN CHAR DETERMINISTIC IS
  --CONSTANT TypeEnumChar := '2' ;        ---- 看跌
  l_CHAR  CHAR(1);
  BEGIN
    l_CHAR  := '2';
    RETURN l_CHAR ;
  END CP_PutOptions;
  -- --------------------------------合约比较类型----------------------------------------------

  FUNCTION CIT_HasExch  RETURN CHAR DETERMINISTIC IS
    -- CONSTANT TypeEnumChar := '0';       ---合约交易所不存在
     l_CHAR  CHAR(1);
  BEGIN
    l_CHAR  := '0';
    RETURN l_CHAR ;
  END CIT_HasExch;

  FUNCTION CIT_HasATP   RETURN CHAR DETERMINISTIC IS
  --CONSTANT TypeEnumChar := '1';             ----合约本系统不存在
  l_CHAR  CHAR(1);
  BEGIN
    l_CHAR  := '1';
    RETURN l_CHAR ;
  END CIT_HasATP;

  FUNCTION CIT_HasDiff           RETURN CHAR DETERMINISTIC IS
  --CONSTANT TypeEnumChar := '2';                    ----合约比较不一致
  l_CHAR  CHAR(1);
  BEGIN
    l_CHAR  := '2';
    RETURN l_CHAR ;
  END CIT_HasDiff;
   ---------------------- 交易所结算参数-----------------------------------------
  FUNCTION ESPI_ExcSetParamID     RETURN CHAR DETERMINISTIC IS
  	l_CHAR t_EnummetaData.EnumvalueType%TYPE ;
  BEGIN
	  l_CHAR :='ExchangeSettlementParamID';
	  RETURN l_CHAR;
  END ESPI_ExcSetParamID;

 /* FUNCTION ESPI_MortgageRatio           RETURN CHAR DETERMINISTIC IS
  --CONSTANT TypeEnumChar := '1';      ---- 质押比例
  l_CHAR  CHAR(1);
  BEGIN
    l_CHAR  := '1';
  RETURN l_CHAR ;
  END ESPI_MortgageRatio;

  FUNCTION ESPI_CFFEXMinPrepa           RETURN CHAR DETERMINISTIC IS
  -- CONSTANT TypeEnumChar := '6';      ---- 中金所开户最低可用金额
  l_CHAR  CHAR(1);
  BEGIN
    l_CHAR  := '6';
  RETURN l_CHAR ;
  END ESPI_CFFEXMinPrepa ;

  FUNCTION ESPI_OptOutDisCountRate           RETURN CHAR DETERMINISTIC IS
  -- CONSTANT TypeEnumChar := 'a';        ---- 虚值期权保证金优惠比率
  l_CHAR  CHAR(1);
  BEGIN
    l_CHAR  := 'a';
  RETURN l_CHAR ;
  END ESPI_OptOutDisCountRate ;

   FUNCTION ESPI_OptMiniGuarantee           RETURN CHAR DETERMINISTIC IS
  -- CONSTANT TypeEnumChar := 'b';         --- 最低保障系数 .
  l_CHAR  CHAR(1);
  BEGIN
    l_CHAR  := 'b';
  RETURN l_CHAR ;
  END ESPI_OptMiniGuarantee ;

  FUNCTION ESPI_OtherFundItem           RETURN CHAR DETERMINISTIC IS                    ---- 分项资金导入项
  l_CHAR  CHAR(1);
  BEGIN
    l_CHAR  := '2';
  RETURN l_CHAR ;
  END ESPI_OtherFundItem ;

  FUNCTION ESPI_OtherFundImport           RETURN CHAR DETERMINISTIC IS            ---- 分项资金导入项
  l_CHAR  CHAR(1);
  BEGIN
    l_CHAR  := '3';
  RETURN l_CHAR ;
  END ESPI_OtherFundImport ;

  FUNCTION ESPI_SHFEDelivFee           RETURN CHAR DETERMINISTIC IS                 ---- 上期所交割手续费收取方式
  l_CHAR  CHAR(1);
  BEGIN
    l_CHAR  := '4';
  RETURN l_CHAR ;
  END ESPI_SHFEDelivFee;

  FUNCTION ESPI_DCEDelivFee           RETURN CHAR DETERMINISTIC IS                  ---- 大商所交割手续费收取方式
  l_CHAR  CHAR(1);
  BEGIN
    l_CHAR  := '5';
  RETURN l_CHAR ;
  END ESPI_DCEDelivFee;

  FUNCTION ESPI_CZCESettlementType           RETURN CHAR DETERMINISTIC IS             ---- 郑商所结算方式
  l_CHAR  CHAR(1);
  BEGIN
    l_CHAR  := '7';
  RETURN l_CHAR ;
  END ESPI_CZCESettlementType;
  FUNCTION ESPI_ExchDelivFeeMode           RETURN CHAR DETERMINISTIC IS              ---- 交易所交割手续费收取方式
  l_CHAR  CHAR(1);
  BEGIN
    l_CHAR  := '9';
  RETURN l_CHAR ;
  END ESPI_ExchDelivFeeMode ;

  FUNCTION ESPI_DelivFeeMode           RETURN CHAR DETERMINISTIC IS                    ---- 分项资金导入项
  l_CHAR  CHAR(1);
  BEGIN
    l_CHAR  := '0';
  RETURN l_CHAR ;
  END ESPI_DelivFeeMode ;

  FUNCTION ESPI_CZCEComMarginType           RETURN CHAR DETERMINISTIC IS            ---- 郑商所组合持仓保证金收取方式
  l_CHAR  CHAR(1);
  BEGIN
    l_CHAR  := 'A';
  RETURN l_CHAR ;
  END ESPI_CZCEComMarginType ;

  FUNCTION ESPI_DceComMarginType           RETURN CHAR DETERMINISTIC IS                 ---- 大商所套利保证金是否优惠
  l_CHAR  CHAR(1);
  BEGIN
    l_CHAR  := 'B';
  RETURN l_CHAR ;
  END ESPI_DceComMarginType;

  FUNCTION ESPI_CZCEOptExerFeeType           RETURN CHAR DETERMINISTIC IS                  ---- 郑商所行权手续费收取方式
  l_CHAR  CHAR(1);
  BEGIN
    l_CHAR  := 'c';
  RETURN l_CHAR ;
  END ESPI_CZCEOptExerFeeType;*/

  --------------------------------定义投机套保标志--------------------------------
  FUNCTION C_HF_Speculation                RETURN CHAR DETERMINISTIC IS          ---- 投机
    l_CHAR  CHAR(1);
  BEGIN
    l_CHAR  := '1';
    RETURN l_CHAR ;
  END C_HF_Speculation;

  FUNCTION C_HF_Arbitrage                  RETURN CHAR DETERMINISTIC IS            ---- 套利
      l_CHAR  CHAR(1);
  BEGIN
    l_CHAR  := '2';
    RETURN l_CHAR ;
  END C_HF_Arbitrage;

  FUNCTION C_HF_Hedge                      RETURN CHAR DETERMINISTIC IS        ---- 套保
      l_CHAR  CHAR(1);
  BEGIN
    l_CHAR  := '3';
    RETURN l_CHAR ;
  END C_HF_Hedge;

  --------------------------------定义持仓多空方向-------------------------------
  FUNCTION C_PD_Net                        RETURN CHAR DETERMINISTIC IS             ---- 净
      l_CHAR  CHAR(1);
  BEGIN
    l_CHAR  := '1';
    RETURN l_CHAR ;
  END C_PD_Net;

  FUNCTION C_PD_Long                       RETURN CHAR DETERMINISTIC IS              ---- 多头
      l_CHAR  CHAR(1);
  BEGIN
    l_CHAR  := '2';
    RETURN l_CHAR ;
  END C_PD_Long;

  FUNCTION C_PD_Short                      RETURN CHAR DETERMINISTIC IS              ---- 空头
      l_CHAR  CHAR(1);
  BEGIN
    l_CHAR  := '3';
    RETURN l_CHAR ;
  END C_PD_Short;

  --------------------------------定义数据同步状态--------------------------------
  FUNCTION C_DS_Asynchronous                         RETURN CHAR DETERMINISTIC IS           ---- 未同步
      l_CHAR  CHAR(1);
  BEGIN
    l_CHAR  := '1';
    RETURN l_CHAR ;
  END C_DS_Asynchronous;

  FUNCTION C_DS_Synchronizing                        RETURN CHAR DETERMINISTIC IS       ---- 同步中
      l_CHAR  CHAR(1);
  BEGIN
    l_CHAR  := '2';
    RETURN l_CHAR ;
  END C_DS_Synchronizing;

  FUNCTION C_DS_Synchronized                         RETURN CHAR DETERMINISTIC IS          ---- 已同步
      l_CHAR  CHAR(1);
  BEGIN
    l_CHAR  := '3';
    RETURN l_CHAR ;
  END C_DS_Synchronized;


  --------------------------------定义特殊的创建规则--------------------------------
  FUNCTION C_SC_NoSpecialRule                         RETURN CHAR DETERMINISTIC  IS         ---- 没有特殊创建规则
      l_CHAR  CHAR(1);
  BEGIN
    l_CHAR  := '0';
    RETURN l_CHAR ;
  END C_SC_NoSpecialRule;
  FUNCTION C_SC_NoSpringFestival                      RETURN CHAR DETERMINISTIC  IS         ---- 不包含春节
      l_CHAR  CHAR(1);
  BEGIN
    l_CHAR  := '1';
    RETURN l_CHAR ;
  END C_SC_NoSpringFestival;
  --------------------------------定义成交类型--------------------------------
  FUNCTION C_TRDT_Common                              RETURN CHAR DETERMINISTIC  IS          ---- 普通成交
      l_CHAR  CHAR(1);
  BEGIN
    l_CHAR  := '0';
    RETURN l_CHAR ;
  END C_TRDT_Common;

  FUNCTION C_TRDT_OptionsExecution                    RETURN CHAR DETERMINISTIC  IS          ---- 期权执行
      l_CHAR  CHAR(1);
  BEGIN
    l_CHAR  := '1';
    RETURN l_CHAR ;
  END C_TRDT_OptionsExecution;

  FUNCTION C_TRDT_OTC                                 RETURN CHAR DETERMINISTIC  IS          ---- OTC成交
      l_CHAR  CHAR(1);
  BEGIN
    l_CHAR  := '2';
    RETURN l_CHAR ;
  END C_TRDT_OTC;

  FUNCTION C_TRDT_EFPDerived                          RETURN CHAR DETERMINISTIC  IS          ---- 期转现衍生成交
      l_CHAR  CHAR(1);
  BEGIN
    l_CHAR  := '3';
    RETURN l_CHAR ;
  END C_TRDT_EFPDerived;

  FUNCTION C_TRDT_CombinationDerived                  RETURN CHAR DETERMINISTIC  IS          ---- 组合衍生成交
      l_CHAR  CHAR(1);
  BEGIN
    l_CHAR  := '4';
    RETURN l_CHAR ;
  END C_TRDT_CombinationDerived;
  --------------------------------分项资金类型--------------------------------
  FUNCTION C_FPID_B003                  RETURN CHAR DETERMINISTIC  IS   ---- 交易所利息
      l_CHAR  CHAR(4);
  BEGIN
    l_CHAR  := 'B003';
    RETURN l_CHAR ;
  END C_FPID_B003;
  --------------------------------手续费收取方式--------------------------------
  FUNCTION C_FAS_ByTrade                                RETURN CHAR DETERMINISTIC IS   ---- 按交易收取
    l_CHAR  CHAR(1);
  BEGIN
    l_CHAR  := '1';
    RETURN l_CHAR ;
  END C_FAS_ByTrade;

  FUNCTION C_FAS_ByDeliv                                RETURN CHAR DETERMINISTIC IS   ---- 按交割收取
      l_CHAR  CHAR(1);
  BEGIN
    l_CHAR  := '2';
    RETURN l_CHAR ;
  END C_FAS_ByDeliv;

  FUNCTION C_FAS_None                                   RETURN CHAR DETERMINISTIC IS    ---- 不收
      l_CHAR  CHAR(1);
  BEGIN
    l_CHAR  := '3';
    RETURN l_CHAR ;
  END C_FAS_None;

  FUNCTION C_FAS_FixFee                                 RETURN CHAR DETERMINISTIC IS  ---- 按指定手续费收取
      l_CHAR  CHAR(1);
  BEGIN
    l_CHAR  := '4';
    RETURN l_CHAR ;
  END C_FAS_FixFee;

  FUNCTION C_ESPI_CZCEOptExerFeeType                    RETURN CHAR DETERMINISTIC IS  ---- 郑商所行权手续费收取方式
      l_CHAR  CHAR(1);
  BEGIN
    l_CHAR  := 'c';
    RETURN l_CHAR ;
  END C_ESPI_CZCEOptExerFeeType;
  --------------------------------CZCEOptExerFeeType 郑商所行权手续费收取方式--------------------------------
  FUNCTION C_COEFT_ByOExer                 RETURN CHAR DETERMINISTIC IS           ----期权行权时收取
      l_CHAR  CHAR(1);
  BEGIN
    l_CHAR  := '1';
    RETURN l_CHAR ;
  END C_COEFT_ByOExer;

  FUNCTION C_COEFT_ByFOpen                 RETURN CHAR DETERMINISTIC IS           ----期货开仓时收取
      l_CHAR  CHAR(1);
  BEGIN
    l_CHAR  := '2';
    RETURN l_CHAR ;
  END C_COEFT_ByFOpen;

  FUNCTION C_COEFT_ByBoth                  RETURN CHAR DETERMINISTIC IS             ----期权行权和期货开仓都收取
      l_CHAR  CHAR(1);
  BEGIN
    l_CHAR  := '3';
    RETURN l_CHAR ;
  END C_COEFT_ByBoth;
  --------------------------------定义买卖方向--------------------------------
  FUNCTION C_D_Buy                         RETURN CHAR DETERMINISTIC IS            ---- 买
      l_CHAR  CHAR(1);
  BEGIN
    l_CHAR  := '0';
    RETURN l_CHAR ;
  END C_D_Buy;

  FUNCTION C_D_Sell                        RETURN CHAR DETERMINISTIC IS         ---- 卖
      l_CHAR  CHAR(1);
  BEGIN
    l_CHAR  := '1';
    RETURN l_CHAR ;
  END C_D_Sell;

  --------------------------------定义投资者范围--------------------------------

  FUNCTION C_IR_All    RETURN CHAR 	     DETERMINISTIC  IS				---- 所有
		l_CHAR CHAR(1);
  BEGIN
	l_CHAR :='1';
	RETURN l_CHAR;
  END C_IR_ALL;

  FUNCTION C_IR_Group  RETURN CHAR 	     DETERMINISTIC  IS					---- 客户类(包含本组)
	    l_CHAR CHAR(1);
  BEGIN
	l_CHAR :='2';
	RETURN l_CHAR;
  END C_IR_GROUP;

  FUNCTION C_IR_Single RETURN CHAR 	     DETERMINISTIC   IS					---- 单一客户
		l_CHAR CHAR(1);
  BEGIN
	l_CHAR :='3';
	RETURN l_CHAR;
  END C_IR_Single;

    --------------------------------定义缺省的常量IS--------------------------------


  FUNCTION DEFAULT_BROKERID              RETURN t_Broker.BrokerID%TYPE     DETERMINISTIC   IS           ---- 缺省经纪公司编号
		l_CHAR t_Broker.BrokerID%TYPE;
  BEGIN
	l_CHAR :='0000';
	RETURN l_CHAR;
  END DEFAULT_BROKERID;

  FUNCTION DEFAULT_INVESTORID            RETURN t_Investor.InvestorID%TYPE DETERMINISTIC   IS        ---- 缺省投资者编号
		l_CHAR t_Investor.InvestorID%TYPE;
  BEGIN
	l_CHAR :='00000000';
	RETURN l_CHAR;
  END DEFAULT_INVESTORID;

  FUNCTION DEFAULT_INVESTUNITID            RETURN  t_investunit.investunitid%TYPE DETERMINISTIC   IS        ---- 缺省投资单元编号
		l_CHAR  t_investunit.investunitid%TYPE;
  BEGIN
	l_CHAR :='00000000';
	RETURN l_CHAR;
  END DEFAULT_INVESTUNITID;

  FUNCTION DEFAULT_ADMIN                 RETURN t_BrokerUser.UserID%TYPE   DETERMINISTIC	IS           ---- 缺省管理员帐号
		l_CHAR t_BrokerUser.UserID%TYPE ;
  BEGIN
	l_CHAR :='admin';
	RETURN l_CHAR;
  END DEFAULT_ADMIN;

  FUNCTION DEFAULT_EXCHANGE              RETURN t_Exchange.ExchangeID%TYPE DETERMINISTIC	IS            ---- 缺省交易所
		l_CHAR t_Exchange.ExchangeID%TYPE;
  BEGIN
	l_CHAR :='0000';
	RETURN l_CHAR;
  END DEFAULT_EXCHANGE;

  FUNCTION DEFAULT_CSRC                  RETURN t_Exchange.ExchangeID%TYPE DETERMINISTIC	IS            ---- 中国证监会代码
		l_CHAR t_Exchange.ExchangeID%TYPE;
  BEGIN
	l_CHAR :='CSRC';
	RETURN l_CHAR;
  END DEFAULT_CSRC;

	FUNCTION DEFAULT_FROZENGROUPID         RETURN t_InvestorGroup.InvestorGroupID%TYPE DETERMINISTIC	IS   ---- 默认休眠账户组ID
		l_CHAR t_InvestorGroup.InvestorGroupID%TYPE;
  BEGIN
	l_CHAR :='ZZZZZZZZZZZZ';
	RETURN l_CHAR;
  END DEFAULT_FROZENGROUPID;


  --------------------------------接入机构状态ORGANSTATUS--------------------------------
  FUNCTION C_FBS_Ready            RETURN CHAR 	     DETERMINISTIC IS ---- 启用
		l_CHAR CHAR(1);
  BEGIN
	  l_CHAR :='0';
	  RETURN l_CHAR;
  END C_FBS_Ready;

  FUNCTION C_FBS_CheckIn          RETURN CHAR 	     DETERMINISTIC IS---- 签到
		l_CHAR CHAR(1);
  BEGIN
	  l_CHAR :='1';
	  RETURN l_CHAR;
  END C_FBS_CheckIn;

  FUNCTION C_FBS_CheckOut         RETURN CHAR 	     DETERMINISTIC IS ---- 签退
		l_CHAR CHAR(1);
  BEGIN
	  l_CHAR :='2';
	  RETURN l_CHAR;
  END C_FBS_CheckOut;

  FUNCTION C_FBS_FundFile         RETURN CHAR 	     DETERMINISTIC IS ---- 对帐文件已到达
		l_CHAR CHAR(1);
  BEGIN
	  l_CHAR :='3';
	  RETURN l_CHAR;
  END C_FBS_FundFile;

  FUNCTION C_FBS_CheckDetail      RETURN CHAR 	     DETERMINISTIC IS ---- 对帐
		l_CHAR CHAR(1);
  BEGIN
	  l_CHAR :='4';
	  RETURN l_CHAR;
  END C_FBS_CheckDetail;

  FUNCTION C_FBS_DayEndClean      RETURN CHAR 	     DETERMINISTIC IS ---- 日终清理
		l_CHAR CHAR(1);
  BEGIN
	  l_CHAR :='5';
	  RETURN l_CHAR;
  END C_FBS_DayEndClean;

  FUNCTION C_FBS_Invalid          RETURN CHAR 	     DETERMINISTIC IS ---- 注销
		l_CHAR CHAR(1);
  BEGIN
	  l_CHAR :='9';
	  RETURN l_CHAR;
  END C_FBS_Invalid;

  --------------------------------货币质押--------------------------------
  FUNCTION C_FMT_Mortgage         RETURN CHAR 	     DETERMINISTIC IS  ---- 质押
		l_CHAR CHAR(1);
  BEGIN
	  l_CHAR :='1';
	  RETURN l_CHAR;
  END C_FMT_Mortgage;

  FUNCTION C_FMT_Redemption       RETURN CHAR 	     DETERMINISTIC IS ---- 解质
		l_CHAR CHAR(1);
  BEGIN
	  l_CHAR :='2';
	  RETURN l_CHAR;
  END C_FMT_Redemption;
  --------------------------------返回码定义--------------------------------
  FUNCTION C_S_OK                 RETURN CHAR 	     DETERMINISTIC IS             ---- 执行成功
		l_CHAR CHAR(1);
  BEGIN
	  l_CHAR :='0';
	  RETURN l_CHAR;
  END C_S_OK;

  FUNCTION C_S_FAILED             RETURN CHAR 	     DETERMINISTIC IS             ---- 执行失败
		l_CHAR CHAR(1);
  BEGIN
	  l_CHAR :='1';
	  RETURN l_CHAR;
  END C_S_FAILED;

  FUNCTION C_S_NODEAL             RETURN CHAR 	     DETERMINISTIC IS             ---- 未处理
		l_CHAR CHAR(1);
  BEGIN
	  l_CHAR :='2';
	  RETURN l_CHAR;
  END C_S_NODEAL;

  --------------------------------交易所代码--------------------------------

  FUNCTION C_EXCHANGEID_CFFEX      RETURN CHAR 	     DETERMINISTIC IS          ---- 中国金融交易所代码
		l_CHAR CHAR(8);
  BEGIN
	  l_CHAR :='CFFEX';
	  RETURN l_CHAR;
  END C_EXCHANGEID_CFFEX;

  FUNCTION C_EXCHANGEID_SHFE       RETURN CHAR 	     DETERMINISTIC IS          ---- 上海期货交易所代码
		l_CHAR CHAR(8);
  BEGIN
	  l_CHAR :='SHFE';
	  RETURN l_CHAR;
  END C_EXCHANGEID_SHFE;

  FUNCTION C_EXCHANGEID_CZCE       RETURN CHAR 	     DETERMINISTIC IS          ---- 郑州商品交易所代码
		l_CHAR CHAR(8);
  BEGIN
	  l_CHAR :='CZCE';
	  RETURN l_CHAR;
  END C_EXCHANGEID_CZCE;

  FUNCTION C_EXCHANGEID_DCE        RETURN CHAR 	     DETERMINISTIC IS           ---- 大连商品交易所代码
		l_CHAR CHAR(8);
  BEGIN
	  l_CHAR :='DCE';
	  RETURN l_CHAR;
  END C_EXCHANGEID_DCE;

  FUNCTION C_EXCHANGEID_INE        RETURN CHAR 	     DETERMINISTIC IS            ---- 能源中心交易所代码
		l_CHAR CHAR(8);
  BEGIN
	  l_CHAR :='INE';
	  RETURN l_CHAR;
  END C_EXCHANGEID_INE;

  FUNCTION C_EXCHANGEID_SSE        RETURN CHAR 	     DETERMINISTIC IS            ---- 上海证券交易所代码
		l_CHAR CHAR(8);
  BEGIN
	  l_CHAR :='SSE';
	  RETURN l_CHAR;
  END C_EXCHANGEID_SSE;

  FUNCTION C_EXCHANGEID_SZE        RETURN CHAR 	     DETERMINISTIC IS            ---- 深圳证券交易所代码
		l_CHAR CHAR(8);
  BEGIN
	  l_CHAR :='SZE';
	  RETURN l_CHAR;
  END C_EXCHANGEID_SZE;
  --------------------------------郑商所成交方式(交易所接口中的数据)--------------------------------
  FUNCTION C_Czce_Trade_Normal         RETURN CHAR 	     DETERMINISTIC IS  -- 正常
		l_CHAR CHAR(1);
  BEGIN
	  l_CHAR :='N';
	  RETURN l_CHAR;
  END C_Czce_Trade_Normal;

  FUNCTION C_Czce_Trade_Force          RETURN CHAR 	     DETERMINISTIC IS  -- 强平
		l_CHAR CHAR(1);
  BEGIN
	  l_CHAR :='C';
	  RETURN l_CHAR;
  END C_Czce_Trade_Force;

  FUNCTION C_Czce_Trade_EFP            RETURN CHAR 	     DETERMINISTIC IS  -- 期转现
		l_CHAR CHAR(1);
  BEGIN
	  l_CHAR :='Q';
	  RETURN l_CHAR;
  END C_Czce_Trade_EFP;

  FUNCTION C_Czce_Trade_Last           RETURN CHAR 	     DETERMINISTIC IS  -- 最后交易日对冲
		l_CHAR CHAR(1);
  BEGIN
	  l_CHAR :='P';
	  RETURN l_CHAR;
  END C_Czce_Trade_Last;

  FUNCTION C_Czce_Trade_MarketMaker    RETURN CHAR 	     DETERMINISTIC IS  -- 做市商响应
		l_CHAR CHAR(1);
  BEGIN
	  l_CHAR :='R';
	  RETURN l_CHAR;
  END C_Czce_Trade_MarketMaker;

  FUNCTION C_Czce_Trade_Strike         RETURN CHAR 	     DETERMINISTIC IS  -- 期权执行
		l_CHAR CHAR(1);
  BEGIN
	  l_CHAR :='O';
	  RETURN l_CHAR;
  END C_Czce_Trade_Strike;

  ---- 反洗钱可疑/大额交易明细表业务标示号(T_AMLSSTrade/T_AMLSHTrade.DepositSeqNo)
  FUNCTION SBC_AMLTradeDepositSeqNo         RETURN CHAR 	     DETERMINISTIC IS
		l_CHAR t_businessseq.businesstype%TYPE;
  BEGIN
	  l_CHAR :='AMLTradeDepositSeqNo';
	  RETURN l_CHAR;
  END SBC_AMLTradeDepositSeqNo;
  ---- 其它需要说明的信息计数器
  FUNCTION SBC_CSRCOtherInfoSeq         RETURN CHAR 	     DETERMINISTIC IS
		l_CHAR t_businessseq.businesstype%TYPE;
  BEGIN
	  l_CHAR :='CSRCOtherInfoSeq';
	  RETURN l_CHAR;
  END SBC_CSRCOtherInfoSeq;
  ---- InvestorID计数器
  FUNCTION SBC_InvestorID         RETURN CHAR 	     DETERMINISTIC IS
		l_CHAR t_businessseq.businesstype%TYPE;
  BEGIN
	  l_CHAR :='InvestorID';
	  RETURN l_CHAR;
  END SBC_InvestorID;
  ---- AccountID计数器
  FUNCTION SBC_AccountID         RETURN CHAR 	     DETERMINISTIC IS
		l_CHAR t_businessseq.businesstype%TYPE;
  BEGIN
	  l_CHAR :='AccountID';
	  RETURN l_CHAR;
  END SBC_AccountID;
  ---- 投资者货币质押操作流水号(T_O_InvestorFundMortgage.operateno)
  FUNCTION SBC_O_InvestorFundMortgage         RETURN CHAR 	     DETERMINISTIC IS
		l_CHAR t_businessseq.businesstype%TYPE;
  BEGIN
	  l_CHAR :='O_InvestorFundMortgage';
	  RETURN l_CHAR;
  END SBC_O_InvestorFundMortgage;


  ---- 开户审核序列号
  FUNCTION SBC_O_OpenInvestorID         RETURN CHAR 	     DETERMINISTIC IS
		l_CHAR t_businessseq.businesstype%TYPE;
  BEGIN
	  l_CHAR :='O_OpenInvestorID';
	  RETURN l_CHAR;
  END SBC_O_OpenInvestorID;

  ---- 投资者货币质押复核序列号(T_R_INVESTORFUNDMortgage.BusinessSeqNo)
  FUNCTION SBC_R_InvestorFundMortgage         RETURN CHAR 	     DETERMINISTIC IS
		l_CHAR t_businessseq.businesstype%TYPE;
  BEGIN
	  l_CHAR :='R_InvestorFundMortgage';
	  RETURN l_CHAR;
  END SBC_R_investorFundMortgage;


  ---- 投资者结算参数流水表流水号（T_R_InvestorSettleParam.BusinessSeqNo）
  FUNCTION SBC_R_InvestorSettleParam         RETURN CHAR 	     DETERMINISTIC IS
		l_CHAR t_businessseq.businesstype%TYPE;
  BEGIN
	  l_CHAR :='R_InvestorSettleParam';
	  RETURN l_CHAR;
  END SBC_R_InvestorSettleParam;

  ----  交易所结算参数流水表流水号（T_R_ExchangeSettleParam.BusinessSeqNo）
  FUNCTION SBC_R_ExchangeSettleParam         RETURN CHAR 	     DETERMINISTIC IS
		l_CHAR t_businessseq.businesstype%TYPE;
  BEGIN
	  l_CHAR :='R_ExchangeSettleParam';
	  RETURN l_CHAR;
  END SBC_R_ExchangeSettleParam;

  ---- 复核管理序列号(t_checkhis.ApplyNo)
  FUNCTION SBC_CheckHis         RETURN CHAR 	     DETERMINISTIC IS
		l_CHAR t_businessseq.businesstype%TYPE;
  BEGIN
	  l_CHAR :='t_CheckHis';
	  RETURN l_CHAR;
  END SBC_CheckHis;

  ---- 投资者适当性题目计数器(T_Question.QuestionID)
  FUNCTION SBC_PaperIDFromLocal         RETURN CHAR 	     DETERMINISTIC IS
		l_CHAR t_businessseq.businesstype%TYPE;
  BEGIN
	  l_CHAR :='SBC_PaperIDFromLocal';
	  RETURN l_CHAR;
  END SBC_PaperIDFromLocal;

    ---- 投资者适当性问卷计数器(T_Paper.PaperID)
  FUNCTION SBC_PaperIDFromCloud         RETURN CHAR 	     DETERMINISTIC IS
		l_CHAR t_businessseq.businesstype%TYPE;
  BEGIN
	  l_CHAR :='SBC_PaperIDFromCloud';
	  RETURN l_CHAR;
  END SBC_PaperIDFromCloud;

    ---- 投资者适当性问卷计数器(T_Paper.PaperID)
  FUNCTION SBC_QuestionID         RETURN CHAR 	     DETERMINISTIC IS
		l_CHAR t_businessseq.businesstype%TYPE;
  BEGIN
	  l_CHAR :='SBC_QuestionID';
	  RETURN l_CHAR;
  END SBC_QuestionID;

  ---- 投资者适当性问卷计数器(T_Paper.PaperID)
  FUNCTION SBC_ProprietySeq         RETURN CHAR 	     DETERMINISTIC IS
		l_CHAR t_businessseq.businesstype%TYPE;
  BEGIN
	  l_CHAR :='SBC_ProprietySeq';
	  RETURN l_CHAR;
  END SBC_ProprietySeq;

    ---- 投资者适当性问卷计数器(T_Paper.PaperID)
  FUNCTION SBC_ProprietyInterfaceSeq         RETURN CHAR 	     DETERMINISTIC IS
		l_CHAR t_businessseq.businesstype%TYPE;
  BEGIN
	  l_CHAR :='SBC_ProprietyInterfaceSeq';
	  RETURN l_CHAR;
  END SBC_ProprietyInterfaceSeq;


  ---- 客户风险评级复核管理序列号
  FUNCTION SBC_CRACheckHis         RETURN CHAR 	     DETERMINISTIC IS
		l_CHAR t_businessseq.businesstype%TYPE;
  BEGIN
	  l_CHAR :='t_CRACheckHis';
	  RETURN l_CHAR;
  END SBC_CRACheckHis;
  ---- 交易所出入金流水号(T_O_ExchangeFundChange.operateno)
  FUNCTION SBC_O_ExchangeFundChange         RETURN CHAR 	     DETERMINISTIC IS
		l_CHAR t_businessseq.businesstype%TYPE;
  BEGIN
	  l_CHAR :='O_ExchangeFundChange';
	  RETURN l_CHAR;
  END SBC_O_ExchangeFundChange;
  ----交易所出入金复核序列号(T_ExchangeFundChange.DepositSeqNo)
  FUNCTION SBC_ExchangeFundChange         RETURN CHAR 	     DETERMINISTIC IS
		l_CHAR t_businessseq.businesstype%TYPE;
  BEGIN
	  l_CHAR :='T_ExchangeFundChange';
	  RETURN l_CHAR;
  END SBC_ExchangeFundChange;
  ---- 交割流水（手续费）序列号 (t_InvstDelivFeeSerial.BusinessSeqNo)
  FUNCTION SBC_InvstDelivFeeSerial         RETURN CHAR 	     DETERMINISTIC IS
		l_CHAR t_businessseq.businesstype%TYPE;
  BEGIN
	  l_CHAR :='t_InvstDelivFeeSerial';
	  RETURN l_CHAR;
  END SBC_InvstDelivFeeSerial;
  ---- 交割流水（保证金）序列号 (t_InvstDelivVolSerial.BusinessSeqNo)
  FUNCTION SBC_InvstDelivVolSerial         RETURN CHAR 	     DETERMINISTIC IS
		l_CHAR t_businessseq.businesstype%TYPE;
  BEGIN
	  l_CHAR :='t_InvstDelivVolSerial';
	  RETURN l_CHAR;
  END SBC_InvstDelivVolSerial;
  ---- 投资者手工出入金复核序列号（T_R_InvestorFundChange.BusinessSeqNo）
  FUNCTION SBC_R_investorFundChange         RETURN CHAR 	     DETERMINISTIC IS
		l_CHAR t_businessseq.businesstype%TYPE;
  BEGIN
	  l_CHAR :='R_investorFundChange';
	  RETURN l_CHAR;
  END SBC_R_investorFundChange;
  ---- 投资者实物质押复核顺序号(T_R_InvestorMortgage.BusinessSeqNo)
  FUNCTION SBC_R_InvestorMortgage         RETURN CHAR 	     DETERMINISTIC IS
		l_CHAR t_businessseq.businesstype%TYPE;
  BEGIN
	  l_CHAR :='R_InvestorMortgage';
	  RETURN l_CHAR;
  END SBC_R_InvestorMortgage;

  ---- 投资者交易所交易编码申请表流水号(T_INVESTOREXCHANGEAPPLY)
  FUNCTION SBC_InvestorExchangeApply         RETURN CHAR 	     DETERMINISTIC IS
		l_CHAR t_businessseq.businesstype%TYPE;
  BEGIN
	  l_CHAR :='t_InvestorExchangeApply';
	  RETURN l_CHAR;
  END SBC_InvestorExchangeApply;

  ---- 资金冻结的序列号
  FUNCTION SBC_FrozenDepositNo         RETURN CHAR 	     DETERMINISTIC IS
		l_CHAR t_businessseq.businesstype%TYPE;
  BEGIN
	  l_CHAR :='FrozenDepositNo';
	  RETURN l_CHAR;
  END SBC_FrozenDepositNo;

  ---- 反洗钱复核申请流水计数器
  FUNCTION SBC_AMLApplyNo         RETURN CHAR 	     DETERMINISTIC IS
		l_CHAR t_businessseq.businesstype%TYPE;
  BEGIN
	  l_CHAR :='AMLApplyNo';
	  RETURN l_CHAR;
  END SBC_AMLApplyNo;

  ---- 反洗钱记录序列号计数器
  FUNCTION SBC_AmlSequence         RETURN CHAR 	     DETERMINISTIC IS
		l_CHAR t_businessseq.businesstype%TYPE;
  BEGIN
	  l_CHAR :='AmlSequence';
	  RETURN l_CHAR;
  END SBC_AmlSequence;
  ---- 反洗钱压缩包序列号计数器
  FUNCTION SBC_AmlZipSequence         RETURN CHAR 	     DETERMINISTIC IS
		l_CHAR t_businessseq.businesstype%TYPE;
  BEGIN
	  l_CHAR :='AmlZipSequence';
	  RETURN l_CHAR;
  END SBC_AmlZipSequence;
  ---- 投资者结算单序列号
  FUNCTION SBC_InvestorBillSeqNo         RETURN CHAR 	     DETERMINISTIC IS
		l_CHAR t_businessseq.businesstype%TYPE;
  BEGIN
	  l_CHAR :='InvestorBillSeqNo';
	  RETURN l_CHAR;
  END SBC_InvestorBillSeqNo;
  ---- 结算回退任务号（t_settletaskrecord.ReturnSequenceNO）
  FUNCTION SBC_ReturnSequenceNO         RETURN CHAR 	     DETERMINISTIC IS
		l_CHAR t_businessseq.businesstype%TYPE;
  BEGIN
	  l_CHAR :='ReturnSequenceNO';
	  RETURN l_CHAR;
  END SBC_ReturnSequenceNO;
  ---- 结算任务号
  FUNCTION SBC_SettleTaskID         RETURN CHAR 	     DETERMINISTIC IS
		l_CHAR t_businessseq.businesstype%TYPE;
  BEGIN
	  l_CHAR :='SettleTaskID';
	  RETURN l_CHAR;
  END SBC_SettleTaskID;
  ---- 统一开户ProcessID
  FUNCTION SBC_UnionOpenAccount         RETURN CHAR 	     DETERMINISTIC IS
		l_CHAR t_businessseq.businesstype%TYPE;
  BEGIN
	  l_CHAR :='UnionOpenAccount';
	  RETURN l_CHAR;
  END SBC_UnionOpenAccount;

  ---- 统一开户XMLFileNameSeq
  FUNCTION SBC_UOAFileSeq         RETURN CHAR 	     DETERMINISTIC IS
		l_CHAR t_businessseq.businesstype%TYPE;
  BEGIN
	  l_CHAR :='UOAFileSeq';
	  RETURN l_CHAR;
  END SBC_UOAFileSeq;

  ---- 投资者手工出入金操作流水号（T_O_InvestorFundChange.operateno）
  FUNCTION SBC_O_InvestorFundChange         RETURN CHAR 	     DETERMINISTIC IS
		l_CHAR t_businessseq.businesstype%TYPE;
  BEGIN
	  l_CHAR :='O_InvestorFundChange';
	  RETURN l_CHAR;
  END SBC_O_investorFundChange;

  ---- 投资者实物质押操作流水号（T_o_InvestorMortgage.operateno）
  FUNCTION SBC_O_InvestorMortgage         RETURN CHAR 	     DETERMINISTIC IS
		l_CHAR t_businessseq.businesstype%TYPE;
  BEGIN
	  l_CHAR :='O_InvestorMortgage';
	  RETURN l_CHAR;
  END SBC_O_InvestorMortgage;

  ---- 报送工具计数器
  FUNCTION SBC_GenFile         RETURN CHAR 	     DETERMINISTIC IS
		l_CHAR t_businessseq.businesstype%TYPE;
  BEGIN
	  l_CHAR :='GenFile';
	  RETURN l_CHAR;
  END SBC_GenFile;

  ---- 增量备份计数器
  FUNCTION SBC_IncrBackup         RETURN CHAR 	     DETERMINISTIC IS
		l_CHAR t_businessseq.businesstype%TYPE;
  BEGIN
	  l_CHAR :='IncrBackup';
	  RETURN l_CHAR;
  END SBC_IncrBackup;

  ---- TBCommand计数器
  FUNCTION SBC_TBCommand         RETURN CHAR 	     DETERMINISTIC IS
		l_CHAR t_businessseq.businesstype%TYPE;
  BEGIN
	  l_CHAR :='TBCommand';
	  RETURN l_CHAR;
  END SBC_TBCommand;

  ---- RiskTBCommand计数器
  FUNCTION SBC_RiskTBCommand         RETURN CHAR 	     DETERMINISTIC IS
		l_CHAR t_businessseq.businesstype%TYPE;
  BEGIN
	  l_CHAR :='RiskTBCommand';
	  RETURN l_CHAR;
  END SBC_RiskTBCommand;

  ---- 日初同步交易顺序号
  FUNCTION SBC_SyncSettlementNO         RETURN CHAR        DETERMINISTIC IS
    l_CHAR t_businessseq.businesstype%TYPE;
  BEGIN
    l_CHAR :='SyncSettlementNO';
    RETURN l_CHAR;
  END SBC_SyncSettlementNo;
  ---- 动态令牌导入批次编号
  FUNCTION SBC_OTPImportSequenceID         RETURN CHAR        DETERMINISTIC IS
    l_CHAR t_businessseq.businesstype%TYPE;
  BEGIN
    l_CHAR :='OTPImportSequenceID';
    RETURN l_CHAR;
  END SBC_OTPImportSequenceID;
  ---- 系统状态切换计数器
  FUNCTION SBC_SwitchFlag         RETURN CHAR        DETERMINISTIC IS
    l_CHAR t_businessseq.businesstype%TYPE;
  BEGIN
    l_CHAR :='SwitchFlag';
    RETURN l_CHAR;
  END SBC_SwitchFlag;
  ---- 二次结算标志
  FUNCTION SBC_SecondSettle         RETURN CHAR        DETERMINISTIC IS
    l_CHAR t_businessseq.businesstype%TYPE;
  BEGIN
    l_CHAR :='SecondSettle';
    RETURN l_CHAR;
  END SBC_SecondSettle;
  ---- 特殊权限策略序列号(T_SpecTRStrategy.STRATEGYID)
  FUNCTION SBC_SpecTRStrategyID         RETURN CHAR        DETERMINISTIC IS
    l_CHAR t_businessseq.businesstype%TYPE;
  BEGIN
    l_CHAR :='SpecTRStrategyID';
    RETURN l_CHAR;
  END SBC_SpecTRStrategyID;
  ---- 特殊权限审核序列号(T_O_MUTITRADINGRIGHT.OPERATENO)
  FUNCTION SBC_MutiTRCheckNo         RETURN CHAR        DETERMINISTIC IS
    l_CHAR t_businessseq.businesstype%TYPE;
  BEGIN
    l_CHAR :='MutiTRCheckNo';
    RETURN l_CHAR;
  END SBC_MutiTRCheckNo;
  ---- AssetInvestorID计数器
  FUNCTION SBC_AssetInvestorID         RETURN CHAR 	     DETERMINISTIC IS
		l_CHAR t_businessseq.businesstype%TYPE;
  BEGIN
	  l_CHAR :='AssetInvestorID';
	  RETURN l_CHAR;
  END SBC_AssetInvestorID;

  FUNCTION C_Fund_In  RETURN CHAR 	     DETERMINISTIC IS
    l_chFD  t_investorfundchange.funddirection%TYPE;
  BEGIN
    l_chFD := '1';
    RETURN l_chFD;
  END C_Fund_In;

  FUNCTION C_Fund_Out  RETURN CHAR 	     DETERMINISTIC IS
    l_chFD  t_investorfundchange.funddirection%TYPE;
  BEGIN
    l_chFD := '2';
    RETURN l_chFD;
  END C_Fund_Out;

  FUNCTION UD_True  RETURN CHAR 	     DETERMINISTIC IS
    l_chUD  t_seq_process.cfmmcreturncode%TYPE;
  BEGIN
    l_chUD := '0';
    RETURN l_chUD;
  END UD_True;

    ---- 业务类型
  FUNCTION UBT_Request  RETURN CHAR 	     DETERMINISTIC IS
    l_ch  CHAR(1);
  BEGIN
    l_ch := '1';
    RETURN l_ch;
  END UBT_Request;

  FUNCTION UBT_Response  RETURN CHAR 	     DETERMINISTIC IS
    l_ch  CHAR(1);
  BEGIN
    l_ch := '2';
    RETURN l_ch;
  END UBT_Response;

  FUNCTION UBT_Notice  RETURN CHAR 	     DETERMINISTIC IS
    l_ch  CHAR(1);
  BEGIN
    l_ch := '3';
    RETURN l_ch;
  END UBT_Notice;

  ---- 客户类型
  FUNCTION UCT_ALL  RETURN CHAR 	     DETERMINISTIC IS
    l_ch  CHAR(1);
  BEGIN
    l_ch := '0';
    RETURN l_ch;
  END UCT_ALL;

  FUNCTION UCT_Person  RETURN CHAR 	     DETERMINISTIC IS
    l_ch  CHAR(1);
  BEGIN
    l_ch := '1';
    RETURN l_ch;
  END UCT_Person;

  FUNCTION UCT_Company  RETURN CHAR 	     DETERMINISTIC IS
    l_ch  CHAR(1);
  BEGIN
    l_ch := '2';
    RETURN l_ch;
  END UCT_Company;

  FUNCTION UCT_SpecialOrgan  RETURN CHAR 	     DETERMINISTIC IS
    l_ch  CHAR(1);
  BEGIN
    l_ch := '4';
    RETURN l_ch;
  END UCT_SpecialOrgan;

  FUNCTION UCT_Asset  RETURN CHAR 	     DETERMINISTIC IS
    l_ch  CHAR(1);
  BEGIN
    l_ch := '5';
    RETURN l_ch;
  END UCT_Asset;

   ---- 发送标志
  FUNCTION USF_NotSend  RETURN CHAR 	     DETERMINISTIC IS
    l_ch  CHAR(1);
  BEGIN
    l_ch := '0';
    RETURN l_ch;
  END USF_NotSend;

  FUNCTION USF_Send  RETURN CHAR 	     DETERMINISTIC IS
    l_ch  CHAR(1);
  BEGIN
    l_ch := '1';
    RETURN l_ch;
  END USF_Send;


  FUNCTION UPS_InfoEdit  RETURN CHAR 	     DETERMINISTIC IS
    l_chUPS_InfoEdit  t_seq_process.processstatus%TYPE;
  BEGIN
    l_chUPS_InfoEdit := '1';
    RETURN l_chUPS_InfoEdit;
  END UPS_InfoEdit;

  FUNCTION UPS_InfoChecking  RETURN CHAR 	     DETERMINISTIC IS
    l_chUPS_InfoChecking  t_seq_process.processstatus%TYPE;
  BEGIN
    l_chUPS_InfoChecking := '2';
    RETURN l_chUPS_InfoChecking;
  END UPS_InfoChecking;

  FUNCTION UPS_InfoPass  RETURN CHAR 	     DETERMINISTIC IS
    l_chUPS_InfoPass  t_seq_process.processstatus%TYPE;
  BEGIN
    l_chUPS_InfoPass := '3';
    RETURN l_chUPS_InfoPass;
  END UPS_InfoPass;

  FUNCTION UPS_InfoFail  RETURN CHAR 	     DETERMINISTIC IS
    l_chUPS_InfoFail  t_seq_process.processstatus%TYPE;
  BEGIN
    l_chUPS_InfoFail := '4';
    RETURN l_chUPS_InfoFail;
  END UPS_InfoFail;

  FUNCTION UPS_IDCardFail  RETURN CHAR 	     DETERMINISTIC IS
    l_chUPS_IDCardFail  t_seq_process.processstatus%TYPE;
  BEGIN
    l_chUPS_IDCardFail := '5';
    RETURN l_chUPS_IDCardFail;
  END UPS_IDCardFail;

  FUNCTION UPS_IDCardPass  RETURN CHAR 	     DETERMINISTIC IS
    l_chUPS_IDCardPass  t_seq_process.processstatus%TYPE;
  BEGIN
    l_chUPS_IDCardPass := '6';
    RETURN l_chUPS_IDCardPass;
  END UPS_IDCardPass;

  FUNCTION UPS_ExChecking  RETURN CHAR 	     DETERMINISTIC IS
    l_chUPS_ExChecking  t_seq_process.processstatus%TYPE;
  BEGIN
    l_chUPS_ExChecking := '7';
    RETURN l_chUPS_ExChecking;
  END UPS_ExChecking;

  FUNCTION UPS_ExApplyPass  RETURN CHAR 	     DETERMINISTIC IS
    l_chUPS_ExApplyPass  t_seq_process.processstatus%TYPE;
  BEGIN
    l_chUPS_ExApplyPass := '8';
    RETURN l_chUPS_ExApplyPass;
  END UPS_ExApplyPass;

  FUNCTION UPS_ExApplyFail  RETURN CHAR 	     DETERMINISTIC IS
    l_chUPS_ExApplyFail  t_seq_process.processstatus%TYPE;
  BEGIN
    l_chUPS_ExApplyFail := '9';
    RETURN l_chUPS_ExApplyFail;
  END UPS_ExApplyFail;


  FUNCTION UPT_ApplyTradingCode       RETURN CHAR 	     DETERMINISTIC IS                    ---- 申请交易编码
     l_chUPT_ApplyTradingCode t_seq_process.processtype%TYPE;
  BEGIN
	  l_chUPT_ApplyTradingCode :='1';
	  RETURN l_chUPT_ApplyTradingCode;
  END UPT_ApplyTradingCode;

  FUNCTION UPT_CancelTradingCode      RETURN CHAR 	     DETERMINISTIC IS                    ---- 撤销交易编码
    l_chUPT_ApplyTradingCode t_seq_process.processtype%TYPE;
  BEGIN
	  l_chUPT_ApplyTradingCode :='2';
	  RETURN l_chUPT_ApplyTradingCode;
  END UPT_CancelTradingCode;

  FUNCTION UPT_ModifyIDCard           RETURN CHAR 	     DETERMINISTIC IS                    ---- 修改身份信息
  l_chUPT_ApplyTradingCode t_seq_process.processtype%TYPE;
  BEGIN
	  l_chUPT_ApplyTradingCode :='3';
	  RETURN l_chUPT_ApplyTradingCode;
  END UPT_ModifyIDCard;

  FUNCTION UPT_ModifyNoIDCard         RETURN CHAR 	     DETERMINISTIC IS                    ---- 修改一般信息
    l_chUPT_ApplyTradingCode t_seq_process.processtype%TYPE;
  BEGIN
	  l_chUPT_ApplyTradingCode :='4';
	  RETURN l_chUPT_ApplyTradingCode;
  END UPT_ModifyNoIDCard;

  FUNCTION UPT_ExchOpenBak            RETURN CHAR 	     DETERMINISTIC IS                    ---- 交易所开户报备
    l_chUPT_ApplyTradingCode t_seq_process.processtype%TYPE;
  BEGIN
	  l_chUPT_ApplyTradingCode :='5';
	  RETURN l_chUPT_ApplyTradingCode;
  END UPT_ExchOpenBak;

  FUNCTION UPT_ExchCancelBak          RETURN CHAR 	     DETERMINISTIC IS                    ---- 交易所销户报备
    l_chUPT_ApplyTradingCode t_seq_process.processtype%TYPE;
  BEGIN
	  l_chUPT_ApplyTradingCode :='6';
	  RETURN l_chUPT_ApplyTradingCode;
  END UPT_ExchCancelBak;

  FUNCTION UPT_StandardAccount        RETURN CHAR 	     DETERMINISTIC IS                    ---- 补报规范资料
  l_chUPT_ApplyTradingCode t_seq_process.processtype%TYPE;
  BEGIN
	  l_chUPT_ApplyTradingCode :='7';
	  RETURN l_chUPT_ApplyTradingCode;
  END UPT_StandardAccount;

  FUNCTION UPT_FreezeAccount          RETURN CHAR 	     DETERMINISTIC IS                    ---- 账户休眠
    l_chUPT_ApplyTradingCode t_seq_process.processtype%TYPE;
  BEGIN
	  l_chUPT_ApplyTradingCode :='8';
	  RETURN l_chUPT_ApplyTradingCode;
  END UPT_FreezeAccount;

  FUNCTION UPT_ActiveFreezeAccount    RETURN CHAR 	     DETERMINISTIC IS                    ---- 激活休眠账户
    l_chUPT_ApplyTradingCode t_seq_process.processtype%TYPE;
  BEGIN
	  l_chUPT_ApplyTradingCode :='9';
	  RETURN l_chUPT_ApplyTradingCode;
  END UPT_ActiveFreezeAccount;

  FUNCTION UPT_RelieveOpenLimit       RETURN CHAR 	     DETERMINISTIC IS
     l_chUPT_ApplyTradingCode t_seq_process.processtype%TYPE;
  BEGIN
	  l_chUPT_ApplyTradingCode :='10';
	  RETURN l_chUPT_ApplyTradingCode;
  END UPT_RelieveOpenLimit;

  ---- 日志操作方法
  FUNCTION ELEM_ADD       RETURN CHAR 	     DETERMINISTIC IS  ---- 增加
     l_ch t_eventlog.eventmode%TYPE;
  BEGIN
	  l_ch  :='1';
	  RETURN l_ch;
  END ELEM_ADD;

  FUNCTION ELEM_UPDATE       RETURN CHAR 	     DETERMINISTIC IS  ---- 修改
     l_ch t_eventlog.eventmode%TYPE;
  BEGIN
	  l_ch  :='2';
	  RETURN l_ch;
  END ELEM_UPDATE;

  FUNCTION ELEM_DELETE       RETURN CHAR 	     DETERMINISTIC IS  ---- 删除
     l_ch t_eventlog.eventmode%TYPE;
  BEGIN
	  l_ch  :='3';
	  RETURN l_ch;
  END ELEM_DELETE;

  FUNCTION ELEM_CHECK       RETURN CHAR 	     DETERMINISTIC IS  ---- 复核
     l_ch t_eventlog.eventmode%TYPE;
  BEGIN
	  l_ch  :='4';
	  RETURN l_ch;
  END ELEM_CHECK;

  FUNCTION ELEM_COPY       RETURN CHAR 	     DETERMINISTIC IS  ---- 复制
     l_ch t_eventlog.eventmode%TYPE;
  BEGIN
	  l_ch  :='5';
	  RETURN l_ch;
  END ELEM_COPY;

  ---- 日志业务操作类型
  FUNCTION ELET_ExchMarginRate       RETURN CHAR 	     DETERMINISTIC IS  ---- 交易所合约保证金率
     l_ch t_eventlog.eventtype%TYPE;
  BEGIN
	  l_ch  :='ExchMarginRate';
	  RETURN l_ch;
  END ELET_ExchMarginRate;

  FUNCTION ELET_InstrMarginRate       RETURN CHAR 	     DETERMINISTIC IS  ---- 投资者合约保证金率
     l_ch t_eventlog.eventtype%TYPE;
  BEGIN
	  l_ch  :='InstrMarginRate';
	  RETURN l_ch;
  END ELET_InstrMarginRate;

  FUNCTION ELET_ExchMarginRateAdjust       RETURN CHAR 	     DETERMINISTIC IS  ---- 交易所合约保证金率调整
     l_ch t_eventlog.eventtype%TYPE;
  BEGIN
	  l_ch  :='ExchMarginRateAdjust';
	  RETURN l_ch;
  END ELET_ExchMarginRateAdjust;

  FUNCTION ELET_InstrMarginRateAdjust       RETURN CHAR 	     DETERMINISTIC IS  ---- 投资者合约保证金率调
     l_ch t_eventlog.eventtype%TYPE;
  BEGIN
	  l_ch  :='InstrMarginRateAdjust';
	  RETURN l_ch;
  END ELET_InstrMarginRateAdjust;

  FUNCTION ELET_CurrExchMarginRate       RETURN CHAR 	     DETERMINISTIC IS  ---- 当前交易所合约保证金率
     l_ch t_eventlog.eventtype%TYPE;
  BEGIN
	  l_ch  :='CurrExchMarginRate';
	  RETURN l_ch;
  END ELET_CurrExchMarginRate;

  FUNCTION ELET_CurrInstrMarginRate       RETURN CHAR 	     DETERMINISTIC IS  ---- 投资者当前合约保证金率
     l_ch t_eventlog.eventtype%TYPE;
  BEGIN
	  l_ch  :='CurrInstrMarginRate';
	  RETURN l_ch;
  END ELET_CurrInstrMarginRate;

  FUNCTION ELET_FinalInstrMarginRate       RETURN CHAR 	     DETERMINISTIC IS  ---- 投资者最终合约保证金率
     l_ch t_eventlog.eventtype%TYPE;
  BEGIN
	  l_ch  :='FinalInstrMarginRate';
	  RETURN l_ch;
  END ELET_FinalInstrMarginRate;

  FUNCTION ELET_CurrExchMarginRateAdj       RETURN CHAR 	     DETERMINISTIC IS  ---- 当前交易所合约保证金率调整
     l_ch t_eventlog.eventtype%TYPE;
  BEGIN
	  l_ch  :='CurrExchMarginRateAdj';
	  RETURN l_ch;
  END ELET_CurrExchMarginRateAdj;

  FUNCTION ELET_NextExchMarginRateAdj       RETURN CHAR 	     DETERMINISTIC IS  ---- 下一交易日交易所合约保证金率调整
     l_ch t_eventlog.eventtype%TYPE;
  BEGIN
	  l_ch  :='NextExchMarginRateAdj';
	  RETURN l_ch;
  END ELET_NextExchMarginRateAdj;

  FUNCTION ELET_CurrInstrMarginRateAdj       RETURN CHAR 	     DETERMINISTIC IS  ---- 当前投资者合约保证金率调
     l_ch t_eventlog.eventtype%TYPE;
  BEGIN
	  l_ch  :='CurrInstrMarginRateAdj';
	  RETURN l_ch;
  END ELET_CurrInstrMarginRateAdj;

  FUNCTION ELET_MarginRateModel       RETURN CHAR 	     DETERMINISTIC IS  ---- 保证金率模板
     l_ch t_eventlog.eventtype%TYPE;
  BEGIN
	  l_ch  :='MarginRateModel';
	  RETURN l_ch;
  END ELET_MarginRateModel;

  --FUNCTION ELET_ExchCommRate       RETURN CHAR 	     DETERMINISTIC IS  ---- 交易所合约手续费率
  --   l_ch t_eventlog.eventtype%TYPE;
  --BEGIN
	--  l_ch  :='ExchCommRate';
	--  RETURN l_ch;
  --END ELET_ExchCommRate;

  --FUNCTION ELET_InstrCommRate       RETURN CHAR 	     DETERMINISTIC IS  ---- 投资者合约手续费率
  --   l_ch t_eventlog.eventtype%TYPE;
  --BEGIN
	--  l_ch  :='InstrCommRate';
	--  RETURN l_ch;
  --END ELET_InstrCommRate;

  FUNCTION ELET_CurrExchCommRate       RETURN CHAR 	     DETERMINISTIC IS  ---- 当前交易所合约手续费率
     l_ch t_eventlog.eventtype%TYPE;
  BEGIN
	  l_ch  :='CurrExchCommRate';
	  RETURN l_ch;
  END ELET_CurrExchCommRate;

  FUNCTION ELET_CurrExchTransferCommRate       RETURN CHAR 	     DETERMINISTIC IS  ---- 当前交易所合约移仓手续费率
     l_ch t_eventlog.eventtype%TYPE;
  BEGIN
	  l_ch  :='CurrExchTransferCommRate';
	  RETURN l_ch;
  END ELET_CurrExchTransferCommRate;

  FUNCTION ELET_CurrInstrCommRate       RETURN CHAR 	     DETERMINISTIC IS  ---- 当前投资者合约手续费率
     l_ch t_eventlog.eventtype%TYPE;
  BEGIN
	  l_ch  :='CurrInstrCommRate';
	  RETURN l_ch;
  END ELET_CurrInstrCommRate;

    FUNCTION ELET_CurrInstrSettleCommRate       RETURN CHAR 	     DETERMINISTIC IS  ---- 当前投资者合约结算手续费率
     l_ch t_eventlog.eventtype%TYPE;
  BEGIN
	  l_ch  :='CurrInstrSettleCommRate';
	  RETURN l_ch;
  END ELET_CurrInstrSettleCommRate;

    FUNCTION ELET_CurrInstrTransferCommRate       RETURN CHAR 	     DETERMINISTIC IS  ---- 当前投资者合约移仓手续费率
     l_ch t_eventlog.eventtype%TYPE;
  BEGIN
	  l_ch  :='CurrInstrTransferCommRate';
	  RETURN l_ch;
  END ELET_CurrInstrTransferCommRate;

    FUNCTION ELET_CurrInstrGUARFundCommRate       RETURN CHAR 	     DETERMINISTIC IS  ---- 当前投资者合约保障基金手续费率
     l_ch t_eventlog.eventtype%TYPE;
  BEGIN
	  l_ch  :='CurrInstrGUARFundCommRate';
	  RETURN l_ch;
  END ELET_CurrInstrGUARFundCommRate;

  FUNCTION ELET_InvestorGroup       RETURN CHAR 	     DETERMINISTIC IS  ---- 投资者组
     l_ch t_eventlog.eventtype%TYPE;
  BEGIN
	  l_ch  :='InvestorGroup';
	  RETURN l_ch;
  END ELET_InvestorGroup;

  FUNCTION ELET_RateTemplate       RETURN CHAR 	     DETERMINISTIC IS  ---- 保证金率模型
     l_ch t_eventlog.eventtype%TYPE;
  BEGIN
	  l_ch  :='RateTemplate';
	  RETURN l_ch;
  END ELET_RateTemplate;

  FUNCTION ELET_CommRateModel       RETURN CHAR 	     DETERMINISTIC IS  ---- 手续费率模板
     l_ch t_eventlog.eventtype%TYPE;
  BEGIN
	  l_ch  :='CommRateModel';
	  RETURN l_ch;
  END ELET_CommRateModel;

  FUNCTION ELET_CommRateTpl       RETURN CHAR 	     DETERMINISTIC IS  ---- 手续费率模型
     l_ch t_eventlog.eventtype%TYPE;
  BEGIN
	  l_ch  :='CommRateTemplate';
	  RETURN l_ch;
  END ELET_CommRateTpl;

  FUNCTION ELET_CurrOpCffexEGuarantee       RETURN CHAR 	     DETERMINISTIC IS  ---- 中金所期权最低保障系数
     l_ch t_eventlog.eventtype%TYPE;
  BEGIN
	  l_ch  :='CurrOpCffexEGuarantee';
	  RETURN l_ch;
  END ELET_CurrOpCffexEGuarantee;

  FUNCTION ELET_CurrOpCffexEMargin       RETURN CHAR 	     DETERMINISTIC IS  ---- 中金所股指期权合约保证金调整系数
     l_ch t_eventlog.eventtype%TYPE;
  BEGIN
	  l_ch  :='CurrOpCffexEMargin';
	  RETURN l_ch;
  END ELET_CurrOpCffexEMargin;

  FUNCTION ELET_CurrOpCffexIGuarantee       RETURN CHAR 	     DETERMINISTIC IS  ---- 投资者期权中金所最低保障系数
     l_ch t_eventlog.eventtype%TYPE;
  BEGIN
	  l_ch  :='CurrOpCffexIGuarantee';
	  RETURN l_ch;
  END ELET_CurrOpCffexIGuarantee;

  FUNCTION ELET_CurrOpCffexIMargin       RETURN CHAR 	     DETERMINISTIC IS  ---- 投资者中金所股指期权合约保证金调整系数
     l_ch t_eventlog.eventtype%TYPE;
  BEGIN
	  l_ch  :='CurrOpCffexIMargin';
	  RETURN l_ch;
  END ELET_CurrOpCffexIMargin;

  FUNCTION ELET_CurrOpShfeExchMargin       RETURN CHAR 	     DETERMINISTIC IS  ---- 上期所当前期权最小保证金
     l_ch t_eventlog.eventtype%TYPE;
  BEGIN
	  l_ch  :='CurrOpShfeExchMargin';
	  RETURN l_ch;
  END ELET_CurrOpShfeExchMargin;

  FUNCTION ELET_CurrOpShfeInstrMargin       RETURN CHAR 	     DETERMINISTIC IS  ---- 上期所当前投资者期权最小保证金表
     l_ch t_eventlog.eventtype%TYPE;
  BEGIN
	  l_ch  :='CurrOpShfeInstrMargin';
	  RETURN l_ch;
  END ELET_CurrOpShfeInstrMargin;

  FUNCTION ELET_CurrOpExchCommRate       RETURN CHAR 	     DETERMINISTIC IS  ---- 当前交易所合约手续费率
     l_ch t_eventlog.eventtype%TYPE;
  BEGIN
	  l_ch  :='CurrOpExchCommRate';
	  RETURN l_ch;
  END ELET_CurrOpExchCommRate;

  FUNCTION ELET_CurrOpInstrCommRate       RETURN CHAR 	     DETERMINISTIC IS  ---- 当前投资者合约手续费率
     l_ch t_eventlog.eventtype%TYPE;
  BEGIN
	  l_ch  :='CurrOpInstrCommRate';
	  RETURN l_ch;
  END ELET_CurrOpInstrCommRate;

  FUNCTION ELET_CurrOpShfeInstrDelta       RETURN CHAR 	     DETERMINISTIC IS  ---- 上期所投资者Delta风险度
     l_ch t_eventlog.eventtype%TYPE;
  BEGIN
	  l_ch  :='CurrOpShfeInstrDelta';
	  RETURN l_ch;
  END ELET_CurrOpShfeInstrDelta;

  FUNCTION ELET_InstrOptStrikeOffset       RETURN CHAR 	     DETERMINISTIC IS  ---- 投资者期权执行偏移量
     l_ch t_eventlog.eventtype%TYPE;
  BEGIN
	  l_ch  :='InstrOptStrikeOffset';
	  RETURN l_ch;
  END ELET_InstrOptStrikeOffset;

  FUNCTION ELET_InvstOptSettleCommRate       RETURN CHAR 	     DETERMINISTIC IS  ---- 投资者期权结算手续费率
     l_ch t_eventlog.eventtype%TYPE;
  BEGIN
	  l_ch  :='InvstOptSettleCommRate';
	  RETURN l_ch;
  END ELET_InvstOptSettleCommRate;

  FUNCTION ELET_InvstOptTransferCommRate       RETURN CHAR 	     DETERMINISTIC IS  ---- 投资者期权移仓手续费率
     l_ch t_eventlog.eventtype%TYPE;
  BEGIN
	  l_ch  :='InvstOptTransferCommRate';
	  RETURN l_ch;
  END ELET_InvstOptTransferCommRate;

  FUNCTION ELET_ExchOptTransferCommRate       RETURN CHAR 	     DETERMINISTIC IS  ---- 交易所期权移仓手续费率
     l_ch t_eventlog.eventtype%TYPE;
  BEGIN
	  l_ch  :='ExchOptTransferCommRate';
	  RETURN l_ch;
  END ELET_ExchOptTransferCommRate;


  FUNCTION ELET_OptionCffexIndexPrice       RETURN CHAR 	     DETERMINISTIC IS  ---- 中金所现货指数期权价格信息
     l_ch t_eventlog.eventtype%TYPE;
  BEGIN
	  l_ch  :='OptionCffexIndexPrice';
	  RETURN l_ch;
  END ELET_OptionCffexIndexPrice;

  FUNCTION ELET_TradeMarginRateUL       RETURN CHAR 	     DETERMINISTIC IS  ---- 投资者交易期权合约保证金率调整
     l_ch t_eventlog.eventtype%TYPE;
  BEGIN
	  l_ch  :='TradeMarginRateUL';
	  RETURN l_ch;
  END ELET_TradeMarginRateUL;

  FUNCTION ELET_SettleMarginRateUL       RETURN CHAR 	     DETERMINISTIC IS  ---- 投资者结算期权合约保证金率调整
     l_ch t_eventlog.eventtype%TYPE;
  BEGIN
	  l_ch  :='SettleMarginRateUL';
	  RETURN l_ch;
  END ELET_SettleMarginRateUL;

  FUNCTION ELET_RationSync       RETURN CHAR 	     DETERMINISTIC IS  ---- 手续费率盘中实时同步
     l_ch t_eventlog.eventtype%TYPE;
  BEGIN
	  l_ch  :='RationSync';
	  RETURN l_ch;
  END ELET_RationSync;

  FUNCTION ELET_CombInstrumentGuard       RETURN CHAR 	     DETERMINISTIC IS  ---- 中金所组合合约安全系数设置
     l_ch t_eventlog.eventtype%TYPE;
  BEGIN
	  l_ch  :='CombInstrumentGuard';
	  RETURN l_ch;
  END ELET_CombInstrumentGuard;

  FUNCTION ELET_ExchFutCommRateApply       RETURN CHAR 	     DETERMINISTIC IS  ---- 交易所期货手续费应用
     l_ch t_eventlog.eventtype%TYPE;
  BEGIN
	  l_ch  :='ExchFutCommRateApply';
	  RETURN l_ch;
  END ELET_ExchFutCommRateApply;

  FUNCTION ELET_ExchOptCommRateApply       RETURN CHAR 	     DETERMINISTIC IS  ---- 交易所期权手续费应用
     l_ch t_eventlog.eventtype%TYPE;
  BEGIN
	  l_ch  :='ExchOptCommRateApply';
	  RETURN l_ch;
  END ELET_ExchOptCommRateApply;

  FUNCTION ELET_InvstFutFloatCommRate       RETURN CHAR 	     DETERMINISTIC IS  ---- 投资者期货浮动手续费率设置
     l_ch t_eventlog.eventtype%TYPE;
  BEGIN
	  l_ch  :='InvstFutFloatCommRate';
	  RETURN l_ch;
  END ELET_InvstFutFloatCommRate;

  FUNCTION ELET_InvstOptFloatCommRate       RETURN CHAR 	     DETERMINISTIC IS  ---- 投资者期权浮动手续费率设置
     l_ch t_eventlog.eventtype%TYPE;
  BEGIN
	  l_ch  :='InvstOptFloatCommRate';
	  RETURN l_ch;
  END ELET_InvstOptFloatCommRate;


    ---- 经纪公司默认经纪公司级别的组织结构代码

  FUNCTION DEFAULT_BrokerDepartMentID       RETURN CHAR 	     DETERMINISTIC IS  ---- 默认经纪公司组织结构代码
     l_ch t_DepartMent.DepartMentID%TYPE;
  BEGIN
	  l_ch  := '00';
	  RETURN l_ch;
  END DEFAULT_BrokerDepartMentID;

  FUNCTION DEFAULT_BrokerDepartMaxClass       RETURN INT 	     DETERMINISTIC IS  ---- 默认经纪公司组织结构代码最大级别
     l_ch INT;
  BEGIN
	  l_ch  := 6;
	  RETURN l_ch;
  END DEFAULT_BrokerDepartMaxClass;

    ---- SysOperMode  系统日志操作方法

  FUNCTION SoM_ADD       RETURN CHAR 	     DETERMINISTIC IS  ---- 增加
     l_ch PKGS_DataType.STY_EnumChar;
  BEGIN
	  l_ch  := '1';
	  RETURN l_ch;
  END SoM_ADD;

  FUNCTION SoM_UPDATE       RETURN CHAR 	     DETERMINISTIC IS  ---- 修改
     l_ch PKGS_DataType.STY_EnumChar;
  BEGIN
	  l_ch  := '2';
	  RETURN l_ch;
  END SoM_UPDATE;

  FUNCTION SoM_DELETE       RETURN CHAR 	     DETERMINISTIC IS  ---- 删除
     l_ch PKGS_DataType.STY_EnumChar;
  BEGIN
	  l_ch  := '3';
	  RETURN l_ch;
  END SoM_DELETE;

  FUNCTION SoM_Copy       RETURN CHAR 	     DETERMINISTIC IS  ---- 复制
     l_ch PKGS_DataType.STY_EnumChar;
  BEGIN
	  l_ch  := '4';
	  RETURN l_ch;
  END SoM_Copy;

  FUNCTION SoM_AcTive       RETURN CHAR 	     DETERMINISTIC IS  ---- 激活
     l_ch PKGS_DataType.STY_EnumChar;
  BEGIN
	  l_ch  := '5';
	  RETURN l_ch;
  END SoM_AcTive;

  FUNCTION SoM_CanCel       RETURN CHAR 	     DETERMINISTIC IS  ---- 注销
     l_ch PKGS_DataType.STY_EnumChar;
  BEGIN
	  l_ch  := '6';
	  RETURN l_ch;
  END SoM_CanCel;

  FUNCTION SoM_ReSet       RETURN CHAR 	     DETERMINISTIC IS  ---- 重置
     l_ch PKGS_DataType.STY_EnumChar;
  BEGIN
	  l_ch  := '7';
	  RETURN l_ch;
  END SoM_ReSet;

        ---- SysOperType  系统日志操作类型

  FUNCTION SoT_UpdatePassword       RETURN CHAR 	     DETERMINISTIC IS  ---- 修改操作员密码
     l_ch PKGS_DataType.STY_EnumChar;
  BEGIN
	  l_ch  := '0';
	  RETURN l_ch;
  END SoT_UpdatePassword;

  FUNCTION SoT_UserDepartment       RETURN CHAR 	     DETERMINISTIC IS  ---- 操作员组织架构关系
     l_ch PKGS_DataType.STY_EnumChar;
  BEGIN
	  l_ch  := '1';
	  RETURN l_ch;
  END SoT_UserDepartment;

  FUNCTION SoT_RoleManager       RETURN CHAR 	     DETERMINISTIC IS  ---- 角色管理
     l_ch PKGS_DataType.STY_EnumChar;
  BEGIN
	  l_ch  := '2';
	  RETURN l_ch;
  END SoT_RoleManager;

  FUNCTION SoT_RoleFunction       RETURN CHAR 	     DETERMINISTIC IS  ---- 角色功能设置
     l_ch PKGS_DataType.STY_EnumChar;
  BEGIN
	  l_ch  := '3';
	  RETURN l_ch;
  END SoT_RoleFunction;

  FUNCTION SoT_BaseParam       RETURN CHAR 	     DETERMINISTIC IS  ---- 基础参数设置
     l_ch PKGS_DataType.STY_EnumChar;
  BEGIN
	  l_ch  := '4';
	  RETURN l_ch;
  END SoT_BaseParam;

  FUNCTION SoT_SetUserID       RETURN CHAR 	     DETERMINISTIC IS  ---- 设置操作员
     l_ch PKGS_DataType.STY_EnumChar;
  BEGIN
	  l_ch  := '5';
	  RETURN l_ch;
  END SoT_SetUserID;

  FUNCTION SoT_SetUserRole       RETURN CHAR 	     DETERMINISTIC IS  ---- 用户角色设置
     l_ch PKGS_DataType.STY_EnumChar;
  BEGIN
	  l_ch  := '6';
	  RETURN l_ch;
  END SoT_SetUserRole;

  FUNCTION SoT_UserIpRestriction       RETURN CHAR 	     DETERMINISTIC IS  ---- 用户IP限制
     l_ch PKGS_DataType.STY_EnumChar;
  BEGIN
	  l_ch  := '7';
	  RETURN l_ch;
  END SoT_UserIpRestriction;

  FUNCTION SoT_DepartmentManager       RETURN CHAR 	     DETERMINISTIC IS  ---- 组织架构管理
     l_ch PKGS_DataType.STY_EnumChar;
  BEGIN
	  l_ch  := '8';
	  RETURN l_ch;
  END SoT_DepartmentManager;

  FUNCTION SoT_DepartmentCopy       RETURN CHAR 	     DETERMINISTIC IS  ---- 组织架构向查询分类复制
     l_ch PKGS_DataType.STY_EnumChar;
  BEGIN
	  l_ch  := '9';
	  RETURN l_ch;
  END SoT_DepartmentCopy;

  FUNCTION SoT_Tradingcode       RETURN CHAR 	     DETERMINISTIC IS  ---- 交易编码管理
     l_ch PKGS_DataType.STY_EnumChar;
  BEGIN
	  l_ch  := 'A';
	  RETURN l_ch;
  END SoT_Tradingcode;

  FUNCTION SoT_InvestorStatus       RETURN CHAR 	     DETERMINISTIC IS  ---- 投资者状态维护
     l_ch PKGS_DataType.STY_EnumChar;
  BEGIN
	  l_ch  := 'B';
	  RETURN l_ch;
  END SoT_InvestorStatus;

  FUNCTION SoT_InvestorAuthority       RETURN CHAR 	     DETERMINISTIC IS  ---- 投资者权限管理
     l_ch PKGS_DataType.STY_EnumChar;
  BEGIN
	  l_ch  := 'C';
	  RETURN l_ch;
  END SoT_InvestorAuthority;

  FUNCTION SoT_PropertySet       RETURN CHAR 	     DETERMINISTIC IS  ---- 属性设置
     l_ch PKGS_DataType.STY_EnumChar;
  BEGIN
	  l_ch  := 'D';
	  RETURN l_ch;
  END SoT_PropertySet;

  FUNCTION SoT_ReSetInvestorPasswd       RETURN CHAR 	     DETERMINISTIC IS  ---- 重置投资者密码
     l_ch PKGS_DataType.STY_EnumChar;
  BEGIN
	  l_ch  := 'E';
	  RETURN l_ch;
  END SoT_ReSetInvestorPasswd;

  FUNCTION SoT_InvestorPersonalityInfo       RETURN CHAR 	     DETERMINISTIC IS  ---- 投资者个性信息维护
     l_ch PKGS_DataType.STY_EnumChar;
  BEGIN
	  l_ch  := 'F';
	  RETURN l_ch;
  END SoT_InvestorPersonalityInfo;

  FUNCTION SoT_DataExport       RETURN CHAR 	     DETERMINISTIC IS  ---- 数据导出
     l_ch PKGS_DataType.STY_EnumChar;
  BEGIN
	  l_ch  := 'G';
	  RETURN l_ch;
  END SoT_DataExport;

  FUNCTION SoT_FileGenAndDownLoad       RETURN CHAR 	     DETERMINISTIC IS  ----文件生成与下载
     l_ch PKGS_DataType.STY_EnumChar;
  BEGIN
	  l_ch  := 'H';
	  RETURN l_ch;
  END SoT_FileGenAndDownLoad;

  FUNCTION SoT_SettleSystemParam       RETURN CHAR 	     DETERMINISTIC IS  ---- 结算参数设置
     l_ch PKGS_DataType.STY_EnumChar;
  BEGIN
	  l_ch  := 'I';
	  RETURN l_ch;
  END SoT_SettleSystemParam;

  FUNCTION SoT_TradeSystemParam       RETURN CHAR 	     DETERMINISTIC IS  ---- 交易参数设置
     l_ch PKGS_DataType.STY_EnumChar;
  BEGIN
	  l_ch  := 'M';
	  RETURN l_ch;
  END SoT_TradeSystemParam;

  FUNCTION SoT_FundPlatformParam      RETURN CHAR 	     DETERMINISTIC IS  ---- 资金平台参数设置
     l_ch PKGS_DataType.STY_EnumChar;
  BEGIN
	  l_ch  := 'N';
	  RETURN l_ch;
  END SoT_FundPlatformParam;


 --------------------------------- 组合持仓类型-----------------------------------

  FUNCTION ComBineType_Spd       RETURN CHAR 	     DETERMINISTIC IS  ---- 跨期套利
     l_ch char(24);
  BEGIN
	  l_ch  := 'SPD';
	  RETURN l_ch;
  END ComBineType_Spd;

  FUNCTION ComBineType_Bul       RETURN CHAR 	     DETERMINISTIC IS  ---- 垂直买权套利
     l_ch char(24);
  BEGIN
	  l_ch  := 'BUL';
	  RETURN l_ch;
  END ComBineType_Bul;

  FUNCTION ComBineType_Ber       RETURN CHAR 	     DETERMINISTIC IS  ---- 垂直卖权套利
     l_ch char(24);
  BEGIN
	  l_ch  := 'BER';
	  RETURN l_ch;
  END ComBineType_Ber;

  FUNCTION ComBineType_Std       RETURN CHAR 	     DETERMINISTIC IS  ---- 跨式
     l_ch char(24);
  BEGIN
	  l_ch  := 'STD';
	  RETURN l_ch;
  END ComBineType_Std;

  FUNCTION ComBineType_Stg       RETURN CHAR 	     DETERMINISTIC IS   ---- 宽跨式
     l_ch char(24);
  BEGIN
	  l_ch  := 'STG';
	  RETURN l_ch;
  END ComBineType_Stg ;

  FUNCTION ComBineType_Prt       RETURN CHAR 	     DETERMINISTIC IS  ---- 备兑组合持仓
     l_ch char(24);
  BEGIN
	  l_ch  := 'PRT';
	  RETURN l_ch;
  END ComBineType_Prt;

  FUNCTION ComBineType_Ips       RETURN CHAR 	     DETERMINISTIC IS  ---- 时间价差组合持仓
     l_ch char(24);
  BEGIN
	  l_ch  := 'IPS';
	  RETURN l_ch;
  END ComBineType_Ips;

  FUNCTION ComBineType_Opl       RETURN CHAR 	     DETERMINISTIC IS  ---- 期权对锁组合持仓
     l_ch char(24);
  BEGIN
	  l_ch  := 'OPL';
	  RETURN l_ch;
  END ComBineType_Opl;


  ------------------------- 经纪公司结算状态  --------------------------------------

  FUNCTION STS_Initialize       RETURN CHAR 	     DETERMINISTIC IS  ---- 初始化
     l_ch char(1);
  BEGIN
	  l_ch  := '0';
	  RETURN l_ch;
  END STS_Initialize;

  FUNCTION STS_Settlementing       RETURN CHAR 	     DETERMINISTIC IS  ---- 结算中
     l_ch char(1);
  BEGIN
	  l_ch  := '1';
	RETURN l_ch;
  END STS_Settlementing;

  FUNCTION STS_Settlemented       RETURN CHAR 	     DETERMINISTIC IS  ---- 已结算
     l_ch char(1);
  BEGIN
	  l_ch  := '2';
	  RETURN l_ch;
  END STS_Settlemented;

  FUNCTION STS_Finished       RETURN CHAR 	     DETERMINISTIC IS  ---- 结算完成
     l_ch char(1);
  BEGIN
	  l_ch  := '3';
	  RETURN l_ch;
  END STS_Finished;

  ------------------------------- 结算单生成状态 ------------------------------

  FUNCTION BGS_None       RETURN CHAR 	     DETERMINISTIC IS  ---- 不生成
     l_ch char(1);
  BEGIN
	  l_ch  := '0';
	  RETURN l_ch;
  END BGS_None;

  FUNCTION BGS_NoGeneratedSTANT       RETURN CHAR 	     DETERMINISTIC IS  ---- 未生成
     l_ch char(1);
  BEGIN
	  l_ch  := '1';
	RETURN l_ch;
  END BGS_NoGeneratedSTANT;

  FUNCTION BGS_Generated       RETURN CHAR 	     DETERMINISTIC IS  ---- 已生成
     l_ch char(1);
  BEGIN
	  l_ch  := '2';
	  RETURN l_ch;
  END BGS_Generated;

 -------------------- 结算确认数据归档状态-------------------------------------------------

  FUNCTION SAS_UnArchived       RETURN CHAR 	     DETERMINISTIC IS  ---- 未归档数据
     l_ch char(1);
  BEGIN
	  l_ch  := '0';
	  RETURN l_ch;
  END SAS_UnArchived;

  FUNCTION SAS_Archiving       RETURN CHAR 	     DETERMINISTIC IS  ---- 数据归档中
     l_ch char(1);
  BEGIN
	  l_ch  := '1';
	RETURN l_ch;
  END SAS_Archiving;

  FUNCTION SAS_Archived       RETURN CHAR 	     DETERMINISTIC IS  ---- 已归档数据
     l_ch char(1);
  BEGIN
	  l_ch  := '2';
	  RETURN l_ch;
  END SAS_Archived;

  FUNCTION SAS_ArchiveFail       RETURN CHAR 	     DETERMINISTIC IS  ---- 归档数据失败
     l_ch char(1);
  BEGIN
	  l_ch  := '3';
	  RETURN l_ch;
   END SAS_ArchiveFail;

 --------------------------- 反洗钱抽取状态  -------------------------------------------------------
  FUNCTION Aml_Draw       RETURN CHAR 	     DETERMINISTIC IS  ---- 未抽取
     l_ch char(1);
  BEGIN
	  l_ch  := '0';
	  RETURN l_ch;
  END Aml_Draw;

  FUNCTION Aml_Drawing       RETURN CHAR 	     DETERMINISTIC IS  ---- 抽取中
     l_ch char(1);
  BEGIN
	  l_ch  := '1';
	RETURN l_ch;
  END Aml_Drawing;

  FUNCTION Aml_Drawed       RETURN CHAR 	     DETERMINISTIC IS  ---- 抽取完成
     l_ch char(1);
  BEGIN
	  l_ch  := '2';
	  RETURN l_ch;
  END Aml_Drawed;


 --------------------------------- 系统参数----------------------------------------------------------------------

  FUNCTION SPI_InvestorIDMinLength       RETURN CHAR 	     DETERMINISTIC IS  ---- 投资者代码最小长度
     l_ch char(1);
  BEGIN
	  l_ch  := '1';
	  RETURN l_ch;
  END SPI_InvestorIDMinLength;

  FUNCTION SPI_AccountIDMinLength       RETURN CHAR 	     DETERMINISTIC IS  ---- 投资者帐号代码最小长度
     l_ch char(1);
  BEGIN
	  l_ch  := '2';
	RETURN l_ch;
  END SPI_AccountIDMinLength;

  FUNCTION SPI_UserRightLogon       RETURN CHAR 	     DETERMINISTIC IS  ---- 投资者开户默认登录权限
     l_ch char(1);
  BEGIN
	  l_ch  := '3';
	  RETURN l_ch;
  END SPI_UserRightLogon;

  FUNCTION SPI_SettlementBillTrade       RETURN CHAR 	     DETERMINISTIC IS  ---- 投资者交易结算单成交汇总方式
     l_ch char(1);
  BEGIN
	  l_ch  := '4';
	  RETURN l_ch;
   END SPI_SettlementBillTrade;

  FUNCTION SPI_TradingCode       RETURN CHAR 	     DETERMINISTIC IS  ---- 统一开户是否默认更新交易编码
     l_ch char(1);
  BEGIN
	  l_ch  := '5';
	  RETURN l_ch;
  END SPI_TradingCode;

  FUNCTION SPI_CheckFund       RETURN CHAR 	     DETERMINISTIC IS  ---- 结算是否判断存在未复核的出入金和分项资金
     l_ch char(1);
  BEGIN
	  l_ch  := '6';
	RETURN l_ch;
  END SPI_CheckFund;

  FUNCTION SPI_CommModelRight       RETURN CHAR 	     DETERMINISTIC IS  ---- 是否启用手续费模板数据权限
     l_ch char(1);
  BEGIN
	  l_ch  := '7';
	  RETURN l_ch;
  END SPI_CommModelRight;

  FUNCTION SPI_MarginModelRight       RETURN CHAR 	     DETERMINISTIC IS  ---- 是否启用保证金模板数据权限
     l_ch char(1);
  BEGIN
	  l_ch  := '9';
	  RETURN l_ch;
   END SPI_MarginModelRight;

  FUNCTION SPI_IsStandardActive       RETURN CHAR 	     DETERMINISTIC IS  ---- 是否十分是是否规范账户才能激活
     l_ch char(1);
  BEGIN
	  l_ch  := '8';
	  RETURN l_ch;
  END SPI_IsStandardActive;

  FUNCTION SPI_InvestorIDType       RETURN CHAR 	     DETERMINISTIC IS  ----  投资者代码输入类型:0 是任意字符,1 必须为0-9数字
     l_ch char(1);
  BEGIN
	  l_ch  := 'a';
	RETURN l_ch;
  END SPI_InvestorIDType;

  FUNCTION SPI_InvestorPwdModel       RETURN CHAR 	     DETERMINISTIC IS  ---- 开户密码录入方式
     l_ch char(1);
  BEGIN
	  l_ch  := 'I';
	  RETURN l_ch;
  END SPI_InvestorPwdModel;

  FUNCTION SPI_FreezeMaxReMain       RETURN CHAR 	     DETERMINISTIC IS  ---- 休眠户最高权益
     l_ch char(1);
  BEGIN
	  l_ch  := 'r';
	  RETURN l_ch;
   END SPI_FreezeMaxReMain;

  FUNCTION SPI_IsSync               RETURN CHAR 	     DETERMINISTIC IS  ---- 手续费操作是否实时上场
     l_ch char(1);
  BEGIN
	  l_ch  := 'A';
	  RETURN l_ch;
  END SPI_IsSync;

  FUNCTION SPI_SysSetParamID       RETURN t_EnummetaData.EnumvalueType%TYPE 	     DETERMINISTIC IS  ----  系统参数
     l_ch t_EnummetaData.EnumvalueType%TYPE;
  BEGIN
	  l_ch  := 'SystemParamID';
	RETURN l_ch;
  END SPI_SysSetParamID;

  FUNCTION SPI_RelieveOpenLimit       RETURN CHAR 	     DETERMINISTIC IS  ---- 系统参数
     l_ch char(1);
  BEGIN
	  l_ch  := 'O';
	  RETURN l_ch;
  END SPI_RelieveOpenLimit;

  FUNCTION SPI_IsStandardFreeze       RETURN CHAR 	     DETERMINISTIC IS  ---- 是否规范用户才能休眠
     l_ch char(1);
  BEGIN
	  l_ch  := 'X';
	  RETURN l_ch;
  END SPI_IsStandardFreeze;


  FUNCTION SPI_CZCENormalProductHedge       RETURN CHAR 	     DETERMINISTIC IS  ---- 郑商所普通品种是否开放套保交易
     l_ch char(1);
  BEGIN
	  l_ch  := 'B';
	  RETURN l_ch;
  END SPI_CZCENormalProductHedge;

  FUNCTION SPI_InvestorCloseDtl       RETURN CHAR 	     DETERMINISTIC IS  ---- 投资者平仓明细汇总方式
     l_ch char(1);
  BEGIN
	  l_ch  := 'c';
	  RETURN l_ch;
   END SPI_InvestorCloseDtl;

  ------------------------------ 交易系统参数代码-------------------------------------------------------------


  FUNCTION TPID_EncryptionStandard       RETURN CHAR 	     DETERMINISTIC IS  ---- 系统加密算法
     l_ch char(1);
  BEGIN
	  l_ch  := 'E';
	  RETURN l_ch;
  END TPID_EncryptionStandard;

  FUNCTION TPID_RiskMode       RETURN CHAR 	     DETERMINISTIC IS  ---- 系统风险算法
     l_ch char(1);
  BEGIN
	  l_ch  := 'R';
	  RETURN l_ch;
  END TPID_RiskMode;


  FUNCTION TPID_RiskModeGlobal       RETURN CHAR 	     DETERMINISTIC IS  ---- 系统风险算法是否全局
     l_ch char(1);
  BEGIN
	  l_ch  := 'G';
	  RETURN l_ch;
  END TPID_RiskModeGlobal;

  FUNCTION TPID_TradeParamID       RETURN t_EnummetaData.EnumvalueType%TYPE 	     DETERMINISTIC IS  ----  交易参数
     l_ch t_EnummetaData.EnumvalueType%TYPE;
  BEGIN
	  l_ch  := 'TradeParamID';
	RETURN l_ch;
  END TPID_TradeParamID;

  /*FUNCTION TPID_ForQuoteTimeInterval       RETURN CHAR 	     DETERMINISTIC IS  ---- 询价限制时间设置
     l_ch char(1);
  BEGIN
	  l_ch  := 'Q';
	  RETURN l_ch;
  END TPID_ForQuoteTimeInterval;*/   --V1.2.3废弃

  FUNCTION TPID_MortgageProportioningMul       RETURN CHAR 	     DETERMINISTIC IS  ---- 质押配比乘数设置
     l_ch char(1);
  BEGIN
	  l_ch  := 'a';
	  RETURN l_ch;
  END TPID_MortgageProportioningMul;

  FUNCTION TPID_IsFuturePosiLimit       RETURN CHAR 	     DETERMINISTIC IS  ---- 日内开仓及下单撤单频率控制
     l_ch char(1);
  BEGIN
	  l_ch  := 'B';
	  RETURN l_ch;
  END TPID_IsFuturePosiLimit;


 -------------------------------------- 风险警戒率计算方法-----------------------------------------------

  FUNCTION RM_MarginDeposit       RETURN CHAR 	     DETERMINISTIC IS  ---- 保证金/总权益
     l_ch char(1);
  BEGIN
	  l_ch  := '1';
	  RETURN l_ch;
  END RM_MarginDeposit;

  FUNCTION RM_DepositMargin       RETURN CHAR 	     DETERMINISTIC IS  ----  总权益/保证金
     l_ch char(1);
  BEGIN
	  l_ch  := '2';
	RETURN l_ch;
  END RM_DepositMargin;

  FUNCTION RM_MarginDepositRate       RETURN CHAR 	     DETERMINISTIC IS  ---- 保证金/总权益*100
     l_ch char(1);
  BEGIN
	  l_ch  := '3';
	  RETURN l_ch;
  END RM_MarginDepositRate;

  FUNCTION RM_DepositMarginRate       RETURN CHAR 	     DETERMINISTIC IS  ---- 总权益/保证金*100
     l_ch char(1);
  BEGIN
	  l_ch  := '4';
	  RETURN l_ch;
   END RM_DepositMarginRate;

  ----------------------- 定义数据同步状态 -------------------------------------------------

  FUNCTION DS_Asynchronous       RETURN CHAR 	     DETERMINISTIC IS  ---- 未同步
     l_ch char(1);
  BEGIN
	  l_ch  := '0';
	  RETURN l_ch;
  END DS_Asynchronous;

  FUNCTION DS_Synchronizing       RETURN CHAR 	     DETERMINISTIC IS  ----  同步中
     l_ch char(1);
  BEGIN
	  l_ch  := '1';
	RETURN l_ch;
  END DS_Synchronizing;

  FUNCTION DS_Synchronized       RETURN CHAR 	     DETERMINISTIC IS  ----已同步
     l_ch char(1);
  BEGIN
	  l_ch  := '2';
	  RETURN l_ch;
  END DS_Synchronized;

  -------------------------- 用户类型 BrokerUserType ----------------------------------------

  FUNCTION BUT_Investor       RETURN CHAR 	     DETERMINISTIC IS  ---- 投资者
     l_ch char(1);
  BEGIN
	  l_ch  := '0';
	  RETURN l_ch;
  END BUT_Investor;

  FUNCTION BUT_BrokerUser       RETURN CHAR 	     DETERMINISTIC IS  ----  操作员
     l_ch char(1);
  BEGIN
	  l_ch  := '1';
	RETURN l_ch;
  END BUT_BrokerUser;

  -------------------------------- 复核流程-------------------------------------------------------------


  FUNCTION CHF_Instgroup       RETURN CHAR 	     DETERMINISTIC IS  ---- 投资者组复核
     l_ch char(1);
  BEGIN
	  l_ch  := '0';
	  RETURN l_ch;
  END CHF_Instgroup;

  FUNCTION CHF_InstRate       RETURN CHAR 	     DETERMINISTIC IS  ----  投资者手续费率复核
     l_ch char(1);
  BEGIN
	  l_ch  := '1';
	RETURN l_ch;
  END CHF_InstRate;

  FUNCTION CHF_InstCommRateModel       RETURN CHAR 	     DETERMINISTIC IS  ----投资者手续费率模板关系复核
     l_ch char(1);
  BEGIN
	  l_ch  := '2';
	  RETURN l_ch;
  END CHF_InstCommRateModel;

  -------------------------------- 定义组织机构投资者范围   -------------------------------------------------
  FUNCTION DR_All       RETURN CHAR 	     DETERMINISTIC IS  ---- 所有
     l_ch char(1);
  BEGIN
	  l_ch  := '1';
	  RETURN l_ch;
  END DR_All;

  FUNCTION DR_Group       RETURN CHAR 	     DETERMINISTIC IS  ---- 组织架构
     l_ch char(1);
  BEGIN
	  l_ch  := '2';
	RETURN l_ch;
  END DR_Group;

  FUNCTION DR_Single       RETURN CHAR 	     DETERMINISTIC IS  ----单一客户
     l_ch char(1);
  BEGIN
	  l_ch  := '3';
	  RETURN l_ch;
  END DR_Single;

  -------------------------------- 操作员范围   -------------------------------------------------
  FUNCTION UR_All       RETURN CHAR 	     DETERMINISTIC IS  ---- 所有
     l_ch char(1);
  BEGIN
	  l_ch  := '0';
	  RETURN l_ch;
  END UR_All;

  FUNCTION UR_Single       RETURN CHAR 	     DETERMINISTIC IS  ---- 单一操作员
     l_ch char(1);
  BEGIN
	  l_ch  := '1';
	RETURN l_ch;
  END UR_Single;

 -------------------------------- 交易所状态   -------------------------------------------------
  FUNCTION ES_NonActive       RETURN CHAR 	     DETERMINISTIC IS  ---- 不活跃
     l_ch char(1);
  BEGIN
	  l_ch  := '1';
	  RETURN l_ch;
  END ES_NonActive;

  FUNCTION ES_Startup       RETURN CHAR 	     DETERMINISTIC IS  ---- 启动
     l_ch char(1);
  BEGIN
	  l_ch  := '2';
	RETURN l_ch;
  END ES_Startup;

    FUNCTION ES_Initialize       RETURN CHAR 	     DETERMINISTIC IS  ---- 交易开始初始化
     l_ch char(1);
  BEGIN
	  l_ch  := '3';
	  RETURN l_ch;
  END ES_Initialize;

  FUNCTION ES_Initialized       RETURN CHAR 	     DETERMINISTIC IS  ---- 交易完成初始化
     l_ch char(1);
  BEGIN
	  l_ch  := '4';
	RETURN l_ch;
  END ES_Initialized;

    FUNCTION ES_Close       RETURN CHAR 	     DETERMINISTIC IS  ---- 收市开始
     l_ch char(1);
  BEGIN
	  l_ch  := '5';
	  RETURN l_ch;
  END ES_Close;

  FUNCTION ES_Closed       RETURN CHAR 	     DETERMINISTIC IS  ---- 收市完成
     l_ch char(1);
  BEGIN
	  l_ch  := '6';
	RETURN l_ch;
  END ES_Closed;

    FUNCTION ES_Settlement       RETURN CHAR 	     DETERMINISTIC IS  ---- 结算
     l_ch char(1);
  BEGIN
	  l_ch  := '7';
	  RETURN l_ch;
  END ES_Settlement;

  FUNCTION ES_YesterdaySettlement       RETURN CHAR 	     DETERMINISTIC IS
     l_ch char(1);
  BEGIN
	  l_ch  := 'a';
	RETURN l_ch;
  END ES_YesterdaySettlement;

  -------------------------------- 平今免收手续费阈值   ----------------------------------
  FUNCTION CT_CommRate       RETURN pkgs_datatype.STY_Ratio 	     DETERMINISTIC IS
     l_ch pkgs_datatype.STY_Ratio;
  BEGIN
	  l_ch  := 0.000001;
	  RETURN l_ch;
  END CT_CommRate;

 -------------------------------- 定义开平标志   -------------------------------------------------
  FUNCTION OF_Open       RETURN pkgs_datatype.STY_EnumChar 	     DETERMINISTIC IS                       ---- 开仓
     l_ch pkgs_datatype.STY_EnumChar;
  BEGIN
	  l_ch  := '0';
	  RETURN l_ch;
  END OF_Open;

  FUNCTION OF_Close       RETURN pkgs_datatype.STY_EnumChar 	     DETERMINISTIC IS                          ---- 平仓
     l_ch pkgs_datatype.STY_EnumChar;
  BEGIN
	  l_ch  := '1';
	  RETURN l_ch;
  END OF_Close;

  FUNCTION OF_ForceClose       RETURN pkgs_datatype.STY_EnumChar 	     DETERMINISTIC IS                      ---- 强平
     l_ch pkgs_datatype.STY_EnumChar;
  BEGIN
	  l_ch  := '2';
	  RETURN l_ch;
  END OF_ForceClose;

  FUNCTION OF_CloseToday       RETURN pkgs_datatype.STY_EnumChar 	     DETERMINISTIC IS                       ---- 平今
     l_ch pkgs_datatype.STY_EnumChar;
  BEGIN
	  l_ch  := '3';
	  RETURN l_ch;
  END OF_CloseToday;

  FUNCTION OF_CloseYesterday       RETURN pkgs_datatype.STY_EnumChar 	     DETERMINISTIC IS                      ---- 平昨
     l_ch pkgs_datatype.STY_EnumChar;
  BEGIN
	  l_ch  := '4';
	  RETURN l_ch;
  END OF_CloseYesterday;

  FUNCTION OF_ForceOff       RETURN pkgs_datatype.STY_EnumChar 	     DETERMINISTIC IS                            ---- 强减
     l_ch pkgs_datatype.STY_EnumChar;
  BEGIN
	  l_ch  := '5';
	  RETURN l_ch;
  END OF_ForceOff;

  FUNCTION OF_LocalForceClose       RETURN pkgs_datatype.STY_EnumChar 	     DETERMINISTIC IS                      ---- 本地强平
     l_ch pkgs_datatype.STY_EnumChar;
  BEGIN
	  l_ch  := '6';
	  RETURN l_ch;
  END OF_LocalForceClose;

  FUNCTION OF_CloseTodayAndYesterday       RETURN pkgs_datatype.STY_EnumChar 	     DETERMINISTIC IS               ---- 包括平今和平昨
     l_ch pkgs_datatype.STY_EnumChar;
  BEGIN
	  l_ch  := 'z';
	  RETURN l_ch;
  END OF_CloseTodayAndYesterday;

 -------------------------------- 产品类型   -------------------------------------------------
   FUNCTION PC_Futures       RETURN pkgs_datatype.STY_EnumChar 	     DETERMINISTIC IS                          ---- 期货
     l_ch pkgs_datatype.STY_EnumChar;
  BEGIN
	  l_ch  := '1';
	  RETURN l_ch;
  END PC_Futures;

  FUNCTION PC_Options       RETURN pkgs_datatype.STY_EnumChar 	     DETERMINISTIC IS                      ---- 期货期权
     l_ch pkgs_datatype.STY_EnumChar;
  BEGIN
	  l_ch  := '2';
	  RETURN l_ch;
  END PC_Options;

  FUNCTION PC_Combination       RETURN pkgs_datatype.STY_EnumChar 	     DETERMINISTIC IS                       ---- 组合
     l_ch pkgs_datatype.STY_EnumChar;
  BEGIN
	  l_ch  := '3';
	  RETURN l_ch;
  END PC_Combination;

  FUNCTION PC_Spot       RETURN pkgs_datatype.STY_EnumChar 	     DETERMINISTIC IS                      ---- 期转现
     l_ch pkgs_datatype.STY_EnumChar;
  BEGIN
	  l_ch  := '4';
	  RETURN l_ch;
  END PC_Spot;

  FUNCTION PC_EFP       RETURN pkgs_datatype.STY_EnumChar 	     DETERMINISTIC IS                            ---- 现货期权
     l_ch pkgs_datatype.STY_EnumChar;
  BEGIN
	  l_ch  := '5';
	  RETURN l_ch;
  END PC_EFP;

  FUNCTION PC_SpotOption       RETURN pkgs_datatype.STY_EnumChar 	     DETERMINISTIC IS                      ---- 本地强平
     l_ch pkgs_datatype.STY_EnumChar;
  BEGIN
	  l_ch  := '6';
	  RETURN l_ch;
  END PC_SpotOption;

  -------------------------------- 报表产品类型   -------------------------------------------------
  FUNCTION RPC_Futures       RETURN pkgs_datatype.STY_EnumChar 	     DETERMINISTIC IS                          ---- 商品期货
     l_ch pkgs_datatype.STY_EnumChar;
  BEGIN
	  l_ch  := '1';
	  RETURN l_ch;
  END RPC_Futures;

  FUNCTION RPC_Options       RETURN pkgs_datatype.STY_EnumChar 	     DETERMINISTIC IS                      ---- 期货期权
     l_ch pkgs_datatype.STY_EnumChar;
  BEGIN
	  l_ch  := '2';
	  RETURN l_ch;
  END RPC_Options;

  FUNCTION RPC_Combination       RETURN pkgs_datatype.STY_EnumChar 	     DETERMINISTIC IS                       ---- 组合
     l_ch pkgs_datatype.STY_EnumChar;
  BEGIN
	  l_ch  := '3';
	  RETURN l_ch;
  END RPC_Combination;

  FUNCTION RPC_Spot       RETURN pkgs_datatype.STY_EnumChar 	     DETERMINISTIC IS                      ---- 即期
     l_ch pkgs_datatype.STY_EnumChar;
  BEGIN
	  l_ch  := '4';
	  RETURN l_ch;
  END RPC_Spot;

  FUNCTION RPC_EFP       RETURN pkgs_datatype.STY_EnumChar 	     DETERMINISTIC IS                            ---- 期转现
     l_ch pkgs_datatype.STY_EnumChar;
  BEGIN
	  l_ch  := '5';
	  RETURN l_ch;
  END RPC_EFP;

  FUNCTION RPC_SpotOption       RETURN pkgs_datatype.STY_EnumChar 	     DETERMINISTIC IS                      ---- 现货期权
     l_ch pkgs_datatype.STY_EnumChar;
  BEGIN
	  l_ch  := '6';
	  RETURN l_ch;
  END RPC_SpotOption;

  FUNCTION RPC_FinancialFutures       RETURN pkgs_datatype.STY_EnumChar 	     DETERMINISTIC IS                      ---- 金融期货
     l_ch pkgs_datatype.STY_EnumChar;
  BEGIN
	  l_ch  := '7';
	  RETURN l_ch;
  END RPC_FinancialFutures;

  -------------------------------- 结算初始化状态   -------------------------------------------------
  FUNCTION IS_UnInitialize       RETURN pkgs_datatype.STY_EnumChar 	     DETERMINISTIC IS                          ---- 结算初始化未开始
     l_ch pkgs_datatype.STY_EnumChar;
  BEGIN
	  l_ch  := '0';
	  RETURN l_ch;
  END IS_UnInitialize;

  FUNCTION IS_Initialize       RETURN pkgs_datatype.STY_EnumChar 	     DETERMINISTIC IS                      ---- 结算初始化中
     l_ch pkgs_datatype.STY_EnumChar;
  BEGIN
	  l_ch  := '1';
	  RETURN l_ch;
  END IS_Initialize;

  FUNCTION IS_Initialized       RETURN pkgs_datatype.STY_EnumChar 	     DETERMINISTIC IS                       ---- 结算初始化完成
     l_ch pkgs_datatype.STY_EnumChar;
  BEGIN
	  l_ch  := '2';
	  RETURN l_ch;
  END IS_Initialized;
  -------------------------------- 数据归档状态   -------------------------------------------------
  FUNCTION SS_UnSaveData       RETURN pkgs_datatype.STY_EnumChar 	     DETERMINISTIC IS                          ---- 数据未归档
     l_ch pkgs_datatype.STY_EnumChar;
  BEGIN
	  l_ch  := '0';
	  RETURN l_ch;
  END SS_UnSaveData;

  FUNCTION SS_SaveDatad       RETURN pkgs_datatype.STY_EnumChar 	     DETERMINISTIC IS                      ---- 数据已归档
     l_ch pkgs_datatype.STY_EnumChar;
  BEGIN
	  l_ch  := '1';
	  RETURN l_ch;
  END SS_SaveDatad;

    -------------------------------- 定义合约生命周期状态   -------------------------------------------------
  FUNCTION IP_NotStart       RETURN pkgs_datatype.STY_EnumChar 	     DETERMINISTIC IS                          ---- 未上市
     l_ch pkgs_datatype.STY_EnumChar;
  BEGIN
	  l_ch  := '0';
	  RETURN l_ch;
  END IP_NotStart;

  FUNCTION IP_Started       RETURN pkgs_datatype.STY_EnumChar 	     DETERMINISTIC IS                          ---- 上市
     l_ch pkgs_datatype.STY_EnumChar;
  BEGIN
	  l_ch  := '1';
	  RETURN l_ch;
  END IP_Started;

  FUNCTION IP_Pause       RETURN pkgs_datatype.STY_EnumChar 	     DETERMINISTIC IS                      ---- 停牌
     l_ch pkgs_datatype.STY_EnumChar;
  BEGIN
	  l_ch  := '2';
	  RETURN l_ch;
  END IP_Pause;

  FUNCTION IP_Expired       RETURN pkgs_datatype.STY_EnumChar 	     DETERMINISTIC IS                       ---- 到期
     l_ch pkgs_datatype.STY_EnumChar;
  BEGIN
	  l_ch  := '3';
	  RETURN l_ch;
  END IP_Expired;

   -------------------------------- 数据备份状态   -------------------------------------------------
  FUNCTION BUS_UnBak       RETURN pkgs_datatype.STY_EnumChar 	     DETERMINISTIC IS                          ---- 未生成备份数据
     l_ch pkgs_datatype.STY_EnumChar;
  BEGIN
	  l_ch  := '0';
	  RETURN l_ch;
  END BUS_UnBak;

  FUNCTION BUS_Bak       RETURN pkgs_datatype.STY_EnumChar 	     DETERMINISTIC IS                          ---- 备份数据生成中
     l_ch pkgs_datatype.STY_EnumChar;
  BEGIN
	  l_ch  := '1';
	  RETURN l_ch;
  END BUS_Bak;

  FUNCTION BUS_BakUped       RETURN pkgs_datatype.STY_EnumChar 	     DETERMINISTIC IS                      ---- 已生成备份数据
     l_ch pkgs_datatype.STY_EnumChar;
  BEGIN
	  l_ch  := '2';
	  RETURN l_ch;
  END BUS_BakUped;

  FUNCTION BUS_BakFail       RETURN pkgs_datatype.STY_EnumChar 	     DETERMINISTIC IS                       ---- 备份数据失败
     l_ch pkgs_datatype.STY_EnumChar;
  BEGIN
	  l_ch  := '3';
	  RETURN l_ch;
  END BUS_BakFail;

  -------------------------------- 报表数据生成状态   -------------------------------------------------
  FUNCTION RS_NoCreate       RETURN pkgs_datatype.STY_EnumChar 	     DETERMINISTIC IS                          ---- 未生成报表数据
     l_ch pkgs_datatype.STY_EnumChar;
  BEGIN
	  l_ch  := '0';
	  RETURN l_ch;
  END RS_NoCreate;

  FUNCTION RS_Create       RETURN pkgs_datatype.STY_EnumChar 	     DETERMINISTIC IS                          ---- 报表数据生成中
     l_ch pkgs_datatype.STY_EnumChar;
  BEGIN
	  l_ch  := '1';
	  RETURN l_ch;
  END RS_Create;

  FUNCTION RS_Created       RETURN pkgs_datatype.STY_EnumChar 	     DETERMINISTIC IS                      ---- 已生成报表数据
     l_ch pkgs_datatype.STY_EnumChar;
  BEGIN
	  l_ch  := '2';
	  RETURN l_ch;
  END RS_Created;

  FUNCTION RS_CreateFail       RETURN pkgs_datatype.STY_EnumChar 	     DETERMINISTIC IS                       ---- 生成报表数据失败
     l_ch pkgs_datatype.STY_EnumChar;
  BEGIN
	  l_ch  := '3';
	  RETURN l_ch;
  END RS_CreateFail;

  -------------------------------- 特殊产品类型   -------------------------------------------------
  FUNCTION SPT_CzceHedge       RETURN pkgs_datatype.STY_EnumChar 	     DETERMINISTIC IS                          ---- 郑商所套保产品
     l_ch pkgs_datatype.STY_EnumChar;
  BEGIN
	  l_ch  := '1';
	  RETURN l_ch;
  END SPT_CzceHedge;

  FUNCTION SPT_IneForeignCurrency       RETURN pkgs_datatype.STY_EnumChar 	     DETERMINISTIC IS                      ---- 能源中心外币交易产品
     l_ch pkgs_datatype.STY_EnumChar;
  BEGIN
	  l_ch  := '2';
	  RETURN l_ch;
  END SPT_IneForeignCurrency;

  FUNCTION SPT_DceOpenClose       RETURN pkgs_datatype.STY_EnumChar 	     DETERMINISTIC IS                       ---- 大连短线开平仓产品
     l_ch pkgs_datatype.STY_EnumChar;
  BEGIN
	  l_ch  := '3';
	  RETURN l_ch;
  END SPT_DceOpenClose;

  ---- 定义银期枚举值 Status
  FUNCTION   FB_ErrorID                                    RETURN    NUMBER  DETERMINISTIC IS
     l_ch NUMBER(8);
  BEGIN
	  l_ch  := 0;
	  RETURN l_ch;
  END FB_ErrorID;

  ---- 转帐流水状态TransferStatus
  FUNCTION   FBTS_Normal        RETURN  pkgs_datatype.STY_EnumChar 	     DETERMINISTIC IS   ---- 正常
     l_ch pkgs_datatype.STY_EnumChar ;
  BEGIN
	  l_ch  := '0';
	  RETURN l_ch;
  END FBTS_Normal;

  FUNCTION   FBTS_Repealed      RETURN  pkgs_datatype.STY_EnumChar DETERMINISTIC IS             ---- 被冲正
     l_ch pkgs_datatype.STY_EnumChar ;
  BEGIN
	  l_ch  := '1';
	  RETURN l_ch;
  END FBTS_Repealed;

  ---- 账户状态 accountstatus
  FUNCTION   FBAS_False         RETURN  PKGS_DataType.STY_Bool 	     DETERMINISTIC IS      ---- False
     l_ch PKGS_DataType.STY_Bool ;
  BEGIN
	  l_ch  := 0;
	  RETURN l_ch;
  END FBAS_False;


  FUNCTION   FBAS_True         RETURN  PKGS_DataType.STY_Bool 	     DETERMINISTIC IS      ---- True
     l_ch PKGS_DataType.STY_Bool ;
  BEGIN
	  l_ch  := 1;
	  RETURN l_ch;
  END FBAS_True;

 -------------------------------- 用户类型   -------------------------------------------------
  FUNCTION UT_Investor       RETURN pkgs_datatype.STY_EnumChar 	     DETERMINISTIC IS                          ---- 投资者
     l_ch pkgs_datatype.STY_EnumChar;
  BEGIN
	  l_ch  := '0';
	  RETURN l_ch;
  END UT_Investor;

  FUNCTION UT_Operator       RETURN pkgs_datatype.STY_EnumChar 	     DETERMINISTIC IS                      ---- 操作员
     l_ch pkgs_datatype.STY_EnumChar;
  BEGIN
	  l_ch  := '1';
	  RETURN l_ch;
  END UT_Operator;

   ----存管文件是否生存
  FUNCTION   FG_NoCreate                                          RETURN  pkgs_datatype.STY_EnumChar 	   DETERMINISTIC IS     ---- 未生成
       l_ch pkgs_datatype.STY_EnumChar;
  BEGIN
	  l_ch  := '0';
	  RETURN l_ch;
  END FG_NoCreate;

  FUNCTION   FG_Create                                            RETURN  pkgs_datatype.STY_EnumChar 	   DETERMINISTIC IS    ---- 已生成
       l_ch pkgs_datatype.STY_EnumChar;
  BEGIN
	  l_ch  := '1';
	  RETURN l_ch;
  END FG_Create;

  ---- CZCENormalProductHedge 郑商所普通品种是否开放套保交易
  FUNCTION   CNPH_No                                            RETURN  pkgs_datatype.STY_EnumChar 	   DETERMINISTIC IS    ---- 不开放
       l_ch pkgs_datatype.STY_EnumChar;
  BEGIN
	  l_ch  := '0';
	  RETURN l_ch;
  END CNPH_No;

  FUNCTION   CNPH_Yes                                            RETURN  pkgs_datatype.STY_EnumChar 	   DETERMINISTIC IS    ---- 开放
       l_ch pkgs_datatype.STY_EnumChar;
  BEGIN
	  l_ch  := '1';
	  RETURN l_ch;
  END CNPH_Yes;

  ---- 定义产品生命周期状态
  FUNCTION   PP_Active                                            RETURN  pkgs_datatype.STY_EnumChar 	   DETERMINISTIC IS    ---- 开放
       l_ch pkgs_datatype.STY_EnumChar;
  BEGIN
	  l_ch  := '1';
	  RETURN l_ch;
  END PP_Active;

  FUNCTION   PP_NonActive                                            RETURN  pkgs_datatype.STY_EnumChar 	   DETERMINISTIC IS  ---- 开放
       l_ch pkgs_datatype.STY_EnumChar;
  BEGIN
	  l_ch  := '2';
	  RETURN l_ch;
  END PP_NonActive;

  FUNCTION   PP_Canceled                                            RETURN  pkgs_datatype.STY_EnumChar 	   DETERMINISTIC IS    ---- 开放
       l_ch pkgs_datatype.STY_EnumChar;
  BEGIN
	  l_ch  := '3';
	  RETURN l_ch;
  END PP_Canceled;



  ---- 资金状态
  FUNCTION   FS_Record                                            RETURN  pkgs_datatype.STY_EnumChar 	   DETERMINISTIC IS    ---- 已录入
       l_ch pkgs_datatype.STY_EnumChar;
  BEGIN
	  l_ch  := '1';
	  RETURN l_ch;
  END FS_Record;

  FUNCTION   FS_Check                                            RETURN  pkgs_datatype.STY_EnumChar 	   DETERMINISTIC IS    ---- 已复核
       l_ch pkgs_datatype.STY_EnumChar;
  BEGIN
	  l_ch  := '2';
	  RETURN l_ch;
  END FS_Check;

  FUNCTION   FS_Charge                                            RETURN  pkgs_datatype.STY_EnumChar 	   DETERMINISTIC IS    ---- 已冲销
       l_ch pkgs_datatype.STY_EnumChar;
  BEGIN
	  l_ch  := '3';
	  RETURN l_ch;
  END FS_Charge;

  ---- 郑商所结算方式
  FUNCTION   CST_Upload                                            RETURN  pkgs_datatype.STY_EnumChar 	   DETERMINISTIC IS    ---- 通过上传交易所下发文件结算
       l_ch pkgs_datatype.STY_EnumChar;
  BEGIN
	  l_ch  := '0';
	  RETURN l_ch;
  END CST_Upload;

  FUNCTION   CST_Trade                                            RETURN  pkgs_datatype.STY_EnumChar 	   DETERMINISTIC IS    ---- 通过成交结算
       l_ch pkgs_datatype.STY_EnumChar;
  BEGIN
	  l_ch  := '1';
	  RETURN l_ch;
  END CST_Trade;

  ---- DceComMarginType 上期所大额单边保证金算法

  FUNCTION   DCMT_No                                            RETURN  pkgs_datatype.STY_EnumChar 	   DETERMINISTIC IS    ---- 大商所套利保证金是否优惠:不优惠
       l_ch pkgs_datatype.STY_EnumChar;
  BEGIN
	  l_ch  := '0';
	  RETURN l_ch;
  END DCMT_No;

  FUNCTION   DCMT_Yes                                            RETURN  pkgs_datatype.STY_EnumChar 	   DETERMINISTIC IS    ---- 大商所套利保证金是否优惠:优惠
       l_ch pkgs_datatype.STY_EnumChar;
  BEGIN
	  l_ch  := '1';
	  RETURN l_ch;
  END DCMT_Yes;

  ---- 交易统计表，按投资者范围统计方式
  FUNCTION   BIR_Property                                            RETURN  pkgs_datatype.STY_EnumChar 	   DETERMINISTIC IS    ---- 按属性统计
       l_ch pkgs_datatype.STY_EnumChar;
  BEGIN
	  l_ch  := '1';
	  RETURN l_ch;
  END BIR_Property;

  FUNCTION   BIR_All                                            RETURN  pkgs_datatype.STY_EnumChar 	   DETERMINISTIC IS    ---- 所有
       l_ch pkgs_datatype.STY_EnumChar;
  BEGIN
	  l_ch  := '2';
	  RETURN l_ch;
  END BIR_All;

  FUNCTION   PTE_Futures                                            RETURN  pkgs_datatype.STY_EnumChar 	   DETERMINISTIC IS    ---- 期货
       l_ch pkgs_datatype.STY_EnumChar;
  BEGIN
	  l_ch  := '1';
	  RETURN l_ch;
  END PTE_Futures;

  FUNCTION   PTE_Options                                            RETURN  pkgs_datatype.STY_EnumChar 	   DETERMINISTIC IS    ---- 期货
       l_ch pkgs_datatype.STY_EnumChar;
  BEGIN
	  l_ch  := '2';
	  RETURN l_ch;
  END PTE_Options;

  ---- 定义投资者范围
  FUNCTION   IR_All                                            RETURN  pkgs_datatype.STY_EnumChar 	   DETERMINISTIC IS    ---- 所有
       l_ch pkgs_datatype.STY_EnumChar;
  BEGIN
	  l_ch  := '1';
	  RETURN l_ch;
  END IR_All;

  FUNCTION   IR_Group                                            RETURN  pkgs_datatype.STY_EnumChar 	   DETERMINISTIC IS    ---- 客户类(包含本组)
       l_ch pkgs_datatype.STY_EnumChar;
  BEGIN
	  l_ch  := '2';
	  RETURN l_ch;
  END IR_Group;

  FUNCTION   IR_Single                                            RETURN  pkgs_datatype.STY_EnumChar 	   DETERMINISTIC IS    ---- 单一客户
       l_ch pkgs_datatype.STY_EnumChar;
  BEGIN
	  l_ch  := '3';
	  RETURN l_ch;
  END IR_Single;

  FUNCTION   FSM_Product                                            RETURN  pkgs_datatype.STY_EnumChar 	   DETERMINISTIC IS    ---- 按产品统计
       l_ch pkgs_datatype.STY_EnumChar;
  BEGIN
	  l_ch  := '1';
	  RETURN l_ch;
  END FSM_Product;

  FUNCTION   FSM_Exchange                                            RETURN  pkgs_datatype.STY_EnumChar 	   DETERMINISTIC IS    ---- 按交易所统计
       l_ch pkgs_datatype.STY_EnumChar;
  BEGIN
	  l_ch  := '2';
	  RETURN l_ch;
  END FSM_Exchange;

  FUNCTION   FSM_All                                            RETURN  pkgs_datatype.STY_EnumChar 	   DETERMINISTIC IS    ----所有
       l_ch pkgs_datatype.STY_EnumChar;
  BEGIN
	  l_ch  := '3';
	  RETURN l_ch;
  END FSM_All;

  ---- 投资者结算参数
  FUNCTION   ISPI_BaseMargin                                            RETURN  pkgs_datatype.STY_EnumChar 	   DETERMINISTIC IS    ----基础保证金
       l_ch pkgs_datatype.STY_EnumChar;
  BEGIN
	  l_ch  := '1';
	  RETURN l_ch;
  END ISPI_BaseMargin;

  FUNCTION   ISPI_LowestInterest                                            RETURN  pkgs_datatype.STY_EnumChar 	   DETERMINISTIC IS    ----最低权益标准
       l_ch pkgs_datatype.STY_EnumChar;
  BEGIN
	  l_ch  := '2';
	  RETURN l_ch;
  END ISPI_LowestInterest;

  FUNCTION   ISPI_RiskRateWay                                            RETURN  pkgs_datatype.STY_EnumChar 	   DETERMINISTIC IS    ----风险警戒率计算方法(0：客户权益/保证金占用；1：保证金占用/客户权益)
       l_ch pkgs_datatype.STY_EnumChar;
  BEGIN
	  l_ch  := '3';
	  RETURN l_ch;
  END ISPI_RiskRateWay;

  FUNCTION   ISPI_MortgageRatio                                            RETURN  pkgs_datatype.STY_EnumChar 	   DETERMINISTIC IS    ----质押比例
       l_ch pkgs_datatype.STY_EnumChar;
  BEGIN
	  l_ch  := '4';
	  RETURN l_ch;
  END ISPI_MortgageRatio;

  FUNCTION   ISPI_MarginWay                                            RETURN  pkgs_datatype.STY_EnumChar 	   DETERMINISTIC IS    ----保证金算法
       l_ch pkgs_datatype.STY_EnumChar;
  BEGIN
	  l_ch  := '5';
	  RETURN l_ch;
  END ISPI_MarginWay;

  FUNCTION   ISPI_RemainCalWay                                            RETURN  pkgs_datatype.STY_EnumChar 	   DETERMINISTIC IS    ----结算准备金计算方法(0：质押金额不能开仓；1：质押金额可开仓)
       l_ch pkgs_datatype.STY_EnumChar;
  BEGIN
	  l_ch  := '6';
	  RETURN l_ch;
  END ISPI_RemainCalWay;

  FUNCTION   ISPI_PrepaCalWay                                            RETURN  pkgs_datatype.STY_EnumChar 	   DETERMINISTIC IS    ----开仓准备金计算方法(0：所有资金都可以用来开仓；1：用于开仓的准备金必须扣除会员结算准备金最低余额)
       l_ch pkgs_datatype.STY_EnumChar;
  BEGIN
	  l_ch  := '7';
	  RETURN l_ch;
  END ISPI_PrepaCalWay;

  FUNCTION   ISPI_MarginCallWay                                            RETURN  pkgs_datatype.STY_EnumChar 	   DETERMINISTIC IS    ----追加保证金计算方法(0：无开仓准备金；1：必须交纳一定的开仓准备金)
       l_ch pkgs_datatype.STY_EnumChar;
  BEGIN
	  l_ch  := '8';
	  RETURN l_ch;
  END ISPI_MarginCallWay;

  FUNCTION   ISPI_BillDeposit                                            RETURN  pkgs_datatype.STY_EnumChar 	   DETERMINISTIC IS    ----结算单(盯市)权益算法 (0:结存 1:结存+质押)
       l_ch pkgs_datatype.STY_EnumChar;
  BEGIN
	  l_ch  := '9';
	  RETURN l_ch;
  END ISPI_BillDeposit;

  FUNCTION ISPI_InvSetParamID     RETURN CHAR DETERMINISTIC IS
  	l_CHAR t_EnummetaData.EnumvalueType%TYPE ;
  BEGIN
	  l_CHAR :='InvestorSettlementParamID';
	  RETURN l_CHAR;
  END ISPI_InvSetParamID;

  FUNCTION ISPI_AccSetParamID     RETURN CHAR DETERMINISTIC IS
  	l_CHAR t_EnummetaData.EnumvalueType%TYPE ;
  BEGIN
	  l_CHAR :='AccountSettlementParamID';
	  RETURN l_CHAR;
  END ISPI_AccSetParamID;

  ---- 开户模式
  FUNCTION   CLM_Domestic                                            RETURN  t_Investor.clientmode%TYPE 	   DETERMINISTIC IS    ----国内客户
     l_ch   t_Investor.clientmode%TYPE;
  BEGIN
	  l_ch  := '1';
	  RETURN l_ch;
  END CLM_Domestic;

  FUNCTION   CLM_ForeignAgent                                            RETURN  t_Investor.clientmode%TYPE 	   DETERMINISTIC IS    ----独资经纪会员
       l_ch t_Investor.clientmode%TYPE;
  BEGIN
	  l_ch  := '2';
	  RETURN l_ch;
  END CLM_ForeignAgent;

  FUNCTION   CLM_ForeignIB                                            RETURN  t_Investor.clientmode%TYPE 	   DETERMINISTIC IS    ----IB模式
       l_ch t_Investor.clientmode%TYPE;
  BEGIN
	  l_ch  := '3';
	  RETURN l_ch;
  END CLM_ForeignIB;

  FUNCTION CLM_ForeignSecondAgent     RETURN t_Investor.clientmode%TYPE DETERMINISTIC IS                     -----二级代理模式
  	l_CHAR t_Investor.clientmode%TYPE ;
  BEGIN
	  l_CHAR :='4';
	  RETURN l_CHAR;
  END CLM_ForeignSecondAgent;

  FUNCTION CLM_ForeignPerson     RETURN t_Investor.clientmode%TYPE DETERMINISTIC IS                          -----境外特殊非经纪参与者
  	l_CHAR t_Investor.clientmode%TYPE ;
  BEGIN
	  l_CHAR :='5';
	  RETURN l_CHAR;
  END CLM_ForeignPerson;

  ---- 客户风险状态
  FUNCTION   IRS_Normal                                            RETURN  pkgs_datatype.STY_EnumChar 	   DETERMINISTIC IS    ----正常
       l_ch pkgs_datatype.STY_EnumChar;
  BEGIN
	  l_ch  := '1';
	  RETURN l_ch;
  END IRS_Normal;

	FUNCTION   IRS_Warn                                            RETURN  pkgs_datatype.STY_EnumChar 	   DETERMINISTIC IS    ----警告
       l_ch pkgs_datatype.STY_EnumChar;
  BEGIN
	  l_ch  := '2';
	  RETURN l_ch;
  END IRS_Warn;

  FUNCTION   IRS_Call                                            RETURN  pkgs_datatype.STY_EnumChar 	   DETERMINISTIC IS    ----追保
       l_ch pkgs_datatype.STY_EnumChar;
  BEGIN
	  l_ch  := '3';
	  RETURN l_ch;
  END IRS_Call;

  FUNCTION   IRS_Force                                            RETURN  pkgs_datatype.STY_EnumChar 	   DETERMINISTIC IS    ----强平
       l_ch pkgs_datatype.STY_EnumChar;
  BEGIN
	  l_ch  := '4';
	  RETURN l_ch;
  END IRS_Force;

  FUNCTION   IRS_Exception                                            RETURN  pkgs_datatype.STY_EnumChar 	   DETERMINISTIC IS    ----异常
       l_ch pkgs_datatype.STY_EnumChar;
  BEGIN
	  l_ch  := '5';
	  RETURN l_ch;
  END IRS_Exception;

  ---- 换汇申请状态
  FUNCTION   CSS_Entry                                            RETURN  pkgs_datatype.STY_EnumChar 	   DETERMINISTIC IS    ----已录入
       l_ch pkgs_datatype.STY_EnumChar;
  BEGIN
	  l_ch  := '1';
	  RETURN l_ch;
  END CSS_Entry;

  FUNCTION   CSS_Approve                                            RETURN  pkgs_datatype.STY_EnumChar 	   DETERMINISTIC IS    ----已审核
       l_ch pkgs_datatype.STY_EnumChar;
  BEGIN
	  l_ch  := '2';
	  RETURN l_ch;
  END CSS_Approve;

  FUNCTION   CSS_Refuse                                            RETURN  pkgs_datatype.STY_EnumChar 	   DETERMINISTIC IS    ----已拒绝
       l_ch pkgs_datatype.STY_EnumChar;
  BEGIN
	  l_ch  := '3';
	  RETURN l_ch;
  END CSS_Refuse;

  FUNCTION   CSS_Revoke                                            RETURN  pkgs_datatype.STY_EnumChar 	   DETERMINISTIC IS    ----已撤销
       l_ch pkgs_datatype.STY_EnumChar;
  BEGIN
	  l_ch  := '4';
	  RETURN l_ch;
  END CSS_Revoke;

  FUNCTION   CSS_Send                                            RETURN  pkgs_datatype.STY_EnumChar 	   DETERMINISTIC IS    ----已发送
       l_ch pkgs_datatype.STY_EnumChar;
  BEGIN
	  l_ch  := '5';
	  RETURN l_ch;
  END CSS_Send;

  FUNCTION   CSS_Success                                            RETURN  pkgs_datatype.STY_EnumChar 	   DETERMINISTIC IS    ----换汇成功
       l_ch pkgs_datatype.STY_EnumChar;
  BEGIN
	  l_ch  := '6';
	  RETURN l_ch;
  END CSS_Success;

  FUNCTION   CSS_Failure                                            RETURN  pkgs_datatype.STY_EnumChar 	   DETERMINISTIC IS    ----换汇失败
       l_ch pkgs_datatype.STY_EnumChar;
  BEGIN
	  l_ch  := '7';
	  RETURN l_ch;
  END CSS_Failure;

  ---- 换汇类型
  FUNCTION   CED_Settlement                                            RETURN  pkgs_datatype.STY_EnumChar 	   DETERMINISTIC IS    ----结汇
       l_ch pkgs_datatype.STY_EnumChar;
  BEGIN
	  l_ch  := '0';
	  RETURN l_ch;
  END CED_Settlement;

  FUNCTION   CED_Sale                                            RETURN  pkgs_datatype.STY_EnumChar 	   DETERMINISTIC IS    ----售汇
       l_ch pkgs_datatype.STY_EnumChar;
  BEGIN
	  l_ch  := '1';
	  RETURN l_ch;
  END CED_Sale;

 ---- 开户客户地域
  FUNCTION   CR_Domestic                                            RETURN  pkgs_datatype.STY_EnumChar 	   DETERMINISTIC IS    ----国内客户
       l_ch pkgs_datatype.STY_EnumChar;
  BEGIN
	  l_ch  := '1';
	  RETURN l_ch;
  END CR_Domestic;

  FUNCTION   CR_GMT                                            RETURN  pkgs_datatype.STY_EnumChar 	   DETERMINISTIC IS    ----港澳台客户
       l_ch pkgs_datatype.STY_EnumChar;
  BEGIN
	  l_ch  := '2';
	  RETURN l_ch;
  END CR_GMT;

  FUNCTION   CR_Foreign                                            RETURN  pkgs_datatype.STY_EnumChar 	   DETERMINISTIC IS    ----国外客户
       l_ch pkgs_datatype.STY_EnumChar;
  BEGIN
	  l_ch  := '3';
	  RETURN l_ch;
  END CR_Foreign;

  ---- 货币质押方向
  FUNCTION   FMD_In                                            RETURN  pkgs_datatype.STY_EnumChar 	   DETERMINISTIC IS    ----国外客户
       l_ch pkgs_datatype.STY_EnumChar;
  BEGIN
	  l_ch  := '1';
	  RETURN l_ch;
  END FMD_In;

  FUNCTION   FMD_Out                                            RETURN  pkgs_datatype.STY_EnumChar 	   DETERMINISTIC IS    ----国外客户
       l_ch pkgs_datatype.STY_EnumChar;
  BEGIN
	  l_ch  := '2';
	  RETURN l_ch;
  END FMD_Out;

  ---- 出入金方向
  FUNCTION   FD_In                                            RETURN  pkgs_datatype.STY_EnumChar 	   DETERMINISTIC IS    ----入金
       l_ch pkgs_datatype.STY_EnumChar;
  BEGIN
	  l_ch  := '1';
	  RETURN l_ch;
  END FD_In;

  FUNCTION   FD_Out                                            RETURN  pkgs_datatype.STY_EnumChar 	   DETERMINISTIC IS    ----出金
       l_ch pkgs_datatype.STY_EnumChar;
  BEGIN
	  l_ch  := '2';
	  RETURN l_ch;
  END FD_Out;

  FUNCTION   FT_Deposite                                            RETURN  pkgs_datatype.STY_EnumChar 	   DETERMINISTIC IS    ----银行存款
       l_ch pkgs_datatype.STY_EnumChar;
  BEGIN
	  l_ch  := '2';
	  RETURN l_ch;
  END FT_Deposite;

  FUNCTION   FIOT_FundIO                                            RETURN  pkgs_datatype.STY_EnumChar 	   DETERMINISTIC IS    ----出入金
       l_ch pkgs_datatype.STY_EnumChar;
  BEGIN
	  l_ch  := '1';
	  RETURN l_ch;
  END FIOT_FundIO;

  FUNCTION   FIOT_Transfer                                            RETURN  pkgs_datatype.STY_EnumChar 	   DETERMINISTIC IS    ----银证转帐
       l_ch pkgs_datatype.STY_EnumChar;
  BEGIN
	  l_ch  := '2';
	  RETURN l_ch;
  END FIOT_Transfer;

  FUNCTION   FIOT_SwapCurrency                                            RETURN  pkgs_datatype.STY_EnumChar 	   DETERMINISTIC IS    ----换汇
       l_ch pkgs_datatype.STY_EnumChar;
  BEGIN
	  l_ch  := '3';
	  RETURN l_ch;
  END FIOT_SwapCurrency;

  ---- 结算单类型
  FUNCTION   ST_Day                                            RETURN  pkgs_datatype.STY_EnumChar 	   DETERMINISTIC IS    ----日报
       l_ch pkgs_datatype.STY_EnumChar;
  BEGIN
	  l_ch  := '0';
	  RETURN l_ch;
  END ST_Day;

  FUNCTION   ST_Month                                            RETURN  pkgs_datatype.STY_EnumChar 	   DETERMINISTIC IS    ----月报
       l_ch pkgs_datatype.STY_EnumChar;
  BEGIN
	  l_ch  := '1';
	  RETURN l_ch;
  END ST_Month;

 FUNCTION   CurrencyID                                            RETURN  t_EnummetaData.EnumvalueType%TYPE 	   DETERMINISTIC IS    ----币种字符串
       l_ch t_EnummetaData.EnumvalueType%TYPE;
  BEGIN
	  l_ch  := 'CurrencyID';
	  RETURN l_ch;
  END CurrencyID;

   ---- 交易权限
  FUNCTION TR_Allow                     RETURN CHAR  DETERMINISTIC IS  ---- 可以交易
  l_CHAR  CHAR(1);
  BEGIN
    l_CHAR  := '0';
  RETURN l_CHAR ;
  END TR_Allow ;

   FUNCTION TR_CloseOnly                     RETURN CHAR  DETERMINISTIC IS  ---- 只能平仓
  l_CHAR  CHAR(1);
  BEGIN
    l_CHAR  := '1';
  RETURN l_CHAR ;
  END TR_CloseOnly ;

  FUNCTION TR_Forbidden                     RETURN CHAR  DETERMINISTIC IS  ---- 不能交易
  l_CHAR  CHAR(1);
  BEGIN
    l_CHAR  := '2';
  RETURN l_CHAR ;
  END TR_Forbidden ;
  ---- 银期签约状态
  FUNCTION OOD_Open                         RETURN CHAR  DETERMINISTIC IS  ---- 签约
  l_CHAR  CHAR(1);
  BEGIN
    l_CHAR  := '1';
  RETURN l_CHAR ;
  END OOD_Open ;

  FUNCTION OOD_Destroy                         RETURN CHAR  DETERMINISTIC IS   ---- 解约
  l_CHAR  CHAR(1);
  BEGIN
    l_CHAR  := '0';
  RETURN l_CHAR ;
  END OOD_Destroy ;

  ----基金公司投资者
  FUNCTION PIR_All                         RETURN CHAR  DETERMINISTIC IS   ---- 全部
  l_CHAR  CHAR(1);
  BEGIN
    l_CHAR  := '1';
  RETURN l_CHAR ;
  END PIR_All ;

  FUNCTION PIR_Property                         RETURN CHAR  DETERMINISTIC IS   ---- 投资者属性
  l_CHAR  CHAR(1);
  BEGIN
    l_CHAR  := '2';
  RETURN l_CHAR ;
  END PIR_Property ;

  FUNCTION PIR_Single                         RETURN CHAR  DETERMINISTIC IS   ---- 单一投资者
  l_CHAR  CHAR(1);
  BEGIN
    l_CHAR  := '3';
  RETURN l_CHAR ;
  END PIR_Single ;

  ----基金公司结算文件生成状态
  FUNCTION FIS_NoCreate                         RETURN NUMBER  DETERMINISTIC IS   ---- 未生成
  l_Num  NUMBER(1);
  BEGIN
    l_Num  := '0';
  RETURN l_Num ;
  END FIS_NoCreate ;

  FUNCTION FIS_Created                         RETURN NUMBER  DETERMINISTIC IS   ---- 已生成
  l_Num  NUMBER(1);
  BEGIN
    l_Num  := 1;
  RETURN l_Num ;
  END FIS_Created ;

  FUNCTION FIS_Failed                         RETURN NUMBER  DETERMINISTIC IS   ---- 生成失败
  l_Num  NUMBER(1);
  BEGIN
    l_Num  := 2;
  RETURN l_Num ;
  END FIS_Failed ;
  ------------当前系统类型------------->>
  FUNCTION C_ST_CTP                        RETURN CHAR DETERMINISTIC IS           ---- CTP
  l_Char  CHAR(255);
  BEGIN
    l_Char  :='CTP';
  RETURN l_Char ;
  END C_ST_CTP ;

  FUNCTION C_ST_CTP2                       RETURN CHAR DETERMINISTIC IS            ---- CTP2
  l_Char  CHAR(255);
  BEGIN
    l_Char  :='CTP2';
  RETURN l_Char ;
  END C_ST_CTP2 ;
  ------------当前系统类型-------------<<
  ---- 结算成交单汇总方式
  FUNCTION SBT_ByTradingdayInst                         RETURN CHAR  DETERMINISTIC IS   ---- 同日同合约
  l_CHAR  CHAR(1);
  BEGIN
    l_CHAR  := '0';
  RETURN l_CHAR ;
  END SBT_ByTradingdayInst;

  FUNCTION SBT_ByTraInstPrice                         RETURN CHAR  DETERMINISTIC IS   ---- 同日同合约同价格
  l_CHAR  CHAR(1);
  BEGIN
    l_CHAR  := '1';
  RETURN l_CHAR ;
  END SBT_ByTraInstPrice;

  FUNCTION SBT_ByInstrument                         RETURN CHAR  DETERMINISTIC IS   ---- 同合约
  l_CHAR  CHAR(1);
  BEGIN
    l_CHAR  := '2';
  RETURN l_CHAR ;
  END SBT_ByInstrument;

  ---- 客户风险通知类型
  FUNCTION NOTETYPE_TradeSettleBill                         RETURN CHAR  DETERMINISTIC IS   ---- 交易结算单
  l_CHAR  CHAR(1);
  BEGIN
    l_CHAR  := '1';
  RETURN l_CHAR ;
  END NOTETYPE_TradeSettleBill;

  FUNCTION NOTETYPE_TradeSettleMonth                         RETURN CHAR  DETERMINISTIC IS   ---- 交易结算月报
  l_CHAR  CHAR(1);
  BEGIN
    l_CHAR  := '2';
  RETURN l_CHAR ;
  END NOTETYPE_TradeSettleMonth;

  FUNCTION NOTETYPE_CallMarginNotes                         RETURN CHAR  DETERMINISTIC IS   ---- 追加保证金通知书
  l_CHAR  CHAR(1);
  BEGIN
    l_CHAR  := '3';
  RETURN l_CHAR ;
  END NOTETYPE_CallMarginNotes;

  FUNCTION NOTETYPE_ForceCloseNotes                         RETURN CHAR  DETERMINISTIC IS   ---- 强行平仓通知书
  l_CHAR  CHAR(1);
  BEGIN
    l_CHAR  := '4';
  RETURN l_CHAR ;
  END NOTETYPE_ForceCloseNotes;

  FUNCTION NOTETYPE_TradeNotes                         RETURN CHAR  DETERMINISTIC IS   ---- 成交通知书
  l_CHAR  CHAR(1);
  BEGIN
    l_CHAR  := '5';
  RETURN l_CHAR ;
  END NOTETYPE_TradeNotes;

  FUNCTION NOTETYPE_DelivNotes                         RETURN CHAR  DETERMINISTIC IS   ---- 交割通知书
  l_CHAR  CHAR(1);
  BEGIN
    l_CHAR  := '6';
  RETURN l_CHAR ;
  END NOTETYPE_DelivNotes;

  ---- 平仓明细汇总方式
  FUNCTION ICD_ByTradingdayInst                         RETURN CHAR  DETERMINISTIC IS   ---- 同日同合约
  l_CHAR  CHAR(1);
  BEGIN
    l_CHAR  := '0';
  RETURN l_CHAR ;
  END ICD_ByTradingdayInst;

  FUNCTION ICD_ByTraInstPrice                         RETURN CHAR  DETERMINISTIC IS   ---- 同日同合约同价格
  l_CHAR  CHAR(1);
  BEGIN
    l_CHAR  := '1';
  RETURN l_CHAR ;
  END ICD_ByTraInstPrice;

  FUNCTION ICD_ByInstrument                         RETURN CHAR  DETERMINISTIC IS   ---- 同合约
  l_CHAR  CHAR(1);
  BEGIN
    l_CHAR  := '2';
  RETURN l_CHAR ;
  END ICD_ByInstrument;

  --------------------------------定义结算范围业务ID--------------------------------

  FUNCTION SC_InvestorFundChange                   RETURN CHAR DETERMINISTIC IS           ---- 投资者手工出入金流水
  l_CHAR  CHAR(12);
  BEGIN
    l_CHAR  := 'InvstFundChg';
  RETURN l_CHAR ;
  END SC_InvestorFundChange;

  FUNCTION SC_EpaymentTransfer                     RETURN CHAR DETERMINISTIC IS        ---- 投资者银期出入金流水
    l_CHAR  CHAR(12);
  BEGIN
    l_CHAR  := 'EpayTrans';
  RETURN l_CHAR ;
  END SC_EpaymentTransfer;

  FUNCTION SC_ExchangeFundChange                   RETURN CHAR DETERMINISTIC IS           ---- 经纪公司出入金流水
    l_CHAR  CHAR(12);
  BEGIN
    l_CHAR  := 'ExchFundChg';
  RETURN l_CHAR ;
  END SC_ExchangeFundChange;

  FUNCTION SC_SpecPartFundChange                   RETURN CHAR DETERMINISTIC IS           ---- 特参交易所出入金流水
    l_CHAR  CHAR(12);
  BEGIN
    l_CHAR  := 'SpecFundChg';
  RETURN l_CHAR ;
  END SC_SpecPartFundChange;

  FUNCTION SC_InvestorMortgage                         RETURN CHAR DETERMINISTIC IS          ---- 质押流水
    l_CHAR  CHAR(12);
  BEGIN
    l_CHAR  := 'InvstMort';
  RETURN l_CHAR ;
  END SC_InvestorMortgage;

  FUNCTION SC_InvestorFundMortgage                        RETURN CHAR DETERMINISTIC IS            ---- 货币质押流水
    l_CHAR  CHAR(12);
  BEGIN
    l_CHAR  := 'FundMort';
  RETURN l_CHAR ;
  END SC_InvestorFundMortgage;

  FUNCTION SC_Frozen                        RETURN CHAR DETERMINISTIC IS            ---- 冻结资金流水
    l_CHAR  CHAR(12);
  BEGIN
    l_CHAR  := 't_Frozen';
  RETURN l_CHAR ;
  END SC_Frozen;

  FUNCTION SC_OFrozen                       RETURN CHAR DETERMINISTIC IS            ---- 冻结资金操作流水
    l_CHAR  CHAR(12);
  BEGIN
    l_CHAR  := 'O_Frozen';
  RETURN l_CHAR ;
  END SC_OFrozen;

  FUNCTION SC_CurrencySwap                   RETURN CHAR DETERMINISTIC IS           ---- 换汇
  l_CHAR  CHAR(12);
  BEGIN
    l_CHAR  := 'CurrencySwap';
  RETURN l_CHAR ;
  END SC_CurrencySwap;
  -----------------------------文件标识------------------------------------
 /*
 t_SseOptInstrumentBaseInfo  	期权合约基础信息	　SSE	　I
t_SseOptClosePrice          	期权收盘价格文件	　SSE	　H
t_SseOpCapital              	上证所衍生品保证金账户数据	　SSE	　C
t_SseOpInstrumentAccount    	上证所期权合约账户全体数据	　SSE	　A
t_SseOpSettleInfo           	上证所期权结算明细	　SSE	　S
t_SseOpNoticeInfo           	衍生品通知信息文件	　SSE	　T
t_SseOpBusinessResponse     	衍生品业务回报文件	　SSE	　R
t_SseOpInstrAccChange       	衍生品合约账户变动数据文件	　SSE	　Z
t_SseOpDeliverInfo          	上证所期权资金净额交收	　SSE	　D
t_SseOpStockDeliverinfo     	上证所期权证券净额交收	　SSE	　E
 */
  ----以下文件标识为个股系统使用，部分标识CTP柜台不会使用
  FUNCTION C_FI_SSEOPTInstr RETURN CHAR DETERMINISTIC IS ---- 期权合约基础信息
    l_SettleFund  CHAR(1);
  BEGIN
    l_SettleFund  := 'I';
    RETURN l_SettleFund ;
  END C_FI_SSEOPTInstr;

  FUNCTION C_FI_SSEOPTClosePrice RETURN CHAR DETERMINISTIC IS ---- 期权收盘价格文件
    l_SettleFund  CHAR(1);
  BEGIN
    l_SettleFund  := 'H';
    RETURN l_SettleFund ;
  END C_FI_SSEOPTClosePrice;


  FUNCTION C_FI_SSEOPTFund RETURN CHAR DETERMINISTIC IS ---- 上证所衍生品保证金账户数据
    l_SettleFund  CHAR(1);
  BEGIN
    l_SettleFund  := 'C';
    RETURN l_SettleFund ;
  END C_FI_SSEOPTFund;

  FUNCTION C_FI_SSEOPTPositionChange RETURN CHAR DETERMINISTIC IS ---- 上证所期权持仓变动数据
    l_SettleFund  CHAR(1);
  BEGIN
    l_SettleFund  := 'P';
    RETURN l_SettleFund ;
  END C_FI_SSEOPTPositionChange;

  FUNCTION C_FI_SSEOPTPosition RETURN CHAR DETERMINISTIC IS ---- 上证所期权持仓数据
    l_SettleFund  CHAR(1);
  BEGIN
    l_SettleFund  := 'Q';
    RETURN l_SettleFund ;
  END C_FI_SSEOPTPosition;

  FUNCTION C_FI_SSEOPTTrade RETURN CHAR DETERMINISTIC IS ---- 上证所期权结算明细
    l_SettleFund  CHAR(1);
  BEGIN
    l_SettleFund  := 'S';
    RETURN l_SettleFund ;
  END C_FI_SSEOPTTrade;
    FUNCTION C_FI_SSENoticeInfo RETURN CHAR DETERMINISTIC IS ---- 衍生品通知信息
    l_SettleFund  CHAR(1);
  BEGIN
    l_SettleFund  := 'T';
    RETURN l_SettleFund ;
  END C_FI_SSENoticeInfo;
    FUNCTION C_FI_SSEBussinessResponse RETURN CHAR DETERMINISTIC IS ---- 上证所业务回报
    l_SettleFund  CHAR(1);
  BEGIN
    l_SettleFund  := 'R';
    RETURN l_SettleFund ;
  END C_FI_SSEBussinessResponse;
  FUNCTION C_FI_SSEZHRZ RETURN CHAR DETERMINISTIC IS ---- 证券账户业务日终回报文件
    l_SettleFund  CHAR(1);
  BEGIN
    l_SettleFund  := 'Z';
    RETURN l_SettleFund ;
  END C_FI_SSEZHRZ;

  FUNCTION C_FI_SSEOPTDeliverInfo RETURN CHAR DETERMINISTIC IS ---- 上证所期权净额交收
    l_SettleFund  CHAR(1);
  BEGIN
    l_SettleFund  := 'D';
    RETURN l_SettleFund ;
  END C_FI_SSEOPTDeliverInfo;

  FUNCTION C_FI_SSEOPTStockDeliverinfo RETURN CHAR DETERMINISTIC IS ---- 上证所期权证券净额交收
    l_SettleFund  CHAR(1);
  BEGIN
    l_SettleFund  := 'E';
    RETURN l_SettleFund ;
  END C_FI_SSEOPTStockDeliverinfo;

  FUNCTION C_FI_OPTFUNDCHANGE RETURN CHAR DETERMINISTIC IS ---- 个股期权资金变动
    l_SettleFund  CHAR(1);
  BEGIN
    l_SettleFund  := 'M';
    RETURN l_SettleFund ;
  END C_FI_OPTFUNDCHANGE;

  FUNCTION C_FI_OPTCOMPOSITION RETURN CHAR DETERMINISTIC IS ---- 个股期权组合持仓明细
    l_SettleFund  CHAR(1);
  BEGIN
    l_SettleFund  := 'J';
    RETURN l_SettleFund ;
  END C_FI_OPTCOMPOSITION;

  FUNCTION C_FI_OPTMARGINDTL RETURN CHAR DETERMINISTIC IS ---- 个股期权保证金明细
    l_SettleFund  CHAR(1);
  BEGIN
    l_SettleFund  := 'K';
    RETURN l_SettleFund ;
  END C_FI_OPTMARGINDTL;


  --------现券
  FUNCTION C_FI_SSESPOTInstrument RETURN CHAR DETERMINISTIC IS ---- 上证所产品信息
    l_SettleInstr  CHAR(1);
  BEGIN
    l_SettleInstr  := 'J';
    RETURN l_SettleInstr ;
  END C_FI_SSESPOTInstrument;
  --------银期换汇类型---------
  FUNCTION FBEBT_PL RETURN CHAR DETERMINISTIC IS ---- 盈亏换汇
    l_CHAR  CHAR(2);
  BEGIN
    l_CHAR  := 'C1';
    RETURN l_CHAR ;
  END FBEBT_PL;
  FUNCTION FBEBT_Manual RETURN CHAR DETERMINISTIC IS ---- 手工换汇
    l_CHAR  CHAR(2);
  BEGIN
    l_CHAR  := 'M2';
    RETURN l_CHAR ;
  END FBEBT_Manual;
  FUNCTION FBEBT_DelivPayment RETURN CHAR DETERMINISTIC IS ---- 交割货款换汇
    l_CHAR  CHAR(2);
  BEGIN
    l_CHAR  := 'C2';
    RETURN l_CHAR ;
  END FBEBT_DelivPayment;
  ------------------------- 换汇页面控制-----------------------
  FUNCTION PageControl_Approve RETURN CHAR DETERMINISTIC  IS  ---- 审计界面
    l_CHAR  CHAR(1);
    BEGIN
    l_CHAR := '1';
    RETURN l_CHAR;
  END PageControl_Approve;
  FUNCTION PageControl_Send RETURN CHAR DETERMINISTIC  IS  ---- 审计界面
    l_CHAR  CHAR(1);
    BEGIN
    l_CHAR := '2' ;
    RETURN l_CHAR;
  END PageControl_Send;
  FUNCTION PageControl_Apply RETURN CHAR DETERMINISTIC  IS  ----- 发送界面
    l_CHAR  CHAR(1);
    BEGIN
    l_CHAR := '3';
    RETURN l_CHAR;
  END PageControl_Apply;

  FUNCTION   Aom_Investor                      RETURN  pkgs_datatype.STY_EnumChar 	   DETERMINISTIC IS    ----结汇
       l_ch pkgs_datatype.STY_EnumChar;---- 投资者
  BEGIN
	  l_ch  := '1';
	  RETURN l_ch;
  END Aom_Investor;

  FUNCTION   Aom_SecAgent                            RETURN  pkgs_datatype.STY_EnumChar 	   DETERMINISTIC IS    ----售汇
       l_ch pkgs_datatype.STY_EnumChar; ---- 二级代理
  BEGIN
	  l_ch  := '2';
	  RETURN l_ch;
  END Aom_SecAgent;

   FUNCTION   Aom_TradeMember                            RETURN  pkgs_datatype.STY_EnumChar 	   DETERMINISTIC IS    ----售汇
       l_ch pkgs_datatype.STY_EnumChar;---- 交易会员
  BEGIN
	  l_ch  := '3';
	  RETURN l_ch;
  END Aom_TradeMember;
  ---------------------------------系统用户是否为单经纪公司-----------------------------------
  FUNCTION   Sys_SingleBroker              RETURN  pkgs_datatype.STY_EnumChar 	   DETERMINISTIC IS
       l_ch pkgs_datatype.STY_EnumChar;---- 单经纪公司
  BEGIN
	  l_ch  := '1';
	  RETURN l_ch;
  END Sys_SingleBroker;

  FUNCTION   Sys_MultiBroker               RETURN  pkgs_datatype.STY_EnumChar 	   DETERMINISTIC IS
       l_ch pkgs_datatype.STY_EnumChar; ---- 多经纪公司
  BEGIN
	  l_ch  := '0';
	  RETURN l_ch;
  END Sys_MultiBroker;
  ------------------------------------- 投资者费率类型----------------------
  FUNCTION   RATE_All              RETURN  pkgs_datatype.STY_EnumChar 	   DETERMINISTIC IS
       l_ch pkgs_datatype.STY_EnumChar;---- 所有
  BEGIN
	  l_ch  := '0';
	  RETURN l_ch;
  END RATE_All;
  FUNCTION   RATE_Comm              RETURN  pkgs_datatype.STY_EnumChar 	   DETERMINISTIC IS
       l_ch pkgs_datatype.STY_EnumChar;---- 手续费率
  BEGIN
	  l_ch  := '1';
	  RETURN l_ch;
  END RATE_Comm;
  FUNCTION   RATE_Margin              RETURN  pkgs_datatype.STY_EnumChar 	   DETERMINISTIC IS
       l_ch pkgs_datatype.STY_EnumChar;---- 保证金率
  BEGIN
	  l_ch  := '2';
	  RETURN l_ch;
  END RATE_Margin;

  ----经纪公司账户是否主账户
  FUNCTION   IMCA_MainClearAccount              RETURN  pkgs_datatype.STY_EnumChar 	   DETERMINISTIC IS
       l_ch pkgs_datatype.STY_EnumChar;---- 是主账户
  BEGIN
	  l_ch  := '1';
	  RETURN l_ch;
  END IMCA_MainClearAccount;
  FUNCTION   IMCA_SubClearAccount              RETURN  pkgs_datatype.STY_EnumChar 	   DETERMINISTIC IS
       l_ch pkgs_datatype.STY_EnumChar;---- 非主账户
  BEGIN
	  l_ch  := '0';
	  RETURN l_ch;
  END IMCA_SubClearAccount;
  ---- 中金所交叉汇率单位币种表示方式
  FUNCTION   CFFEXRateUnit    RETURN  t_EnummetaData.EnumvalueType%TYPE    DETERMINISTIC IS
       l_ch t_EnummetaData.EnumvalueType%TYPE ;
  BEGIN
	  l_ch  := 'CFFEXRateUnit';
	  RETURN l_ch;
  END CFFEXRateUnit;
  ---------------------------------- 中金所组合持仓类型------------------------------------
  FUNCTION   C_ComBineType_FuS    RETURN  t_CffexPositionComDtl.ComBineType%TYPE     DETERMINISTIC IS
       l_ch t_CffexPositionComDtl.ComBineType%TYPE  ;
  BEGIN
	  l_ch  := 'future';
	  RETURN l_ch;
  END C_ComBineType_FuS;


  FUNCTION   C_ComBineType_FCS    RETURN  t_CffexPositionComDtl.ComBineType%TYPE     DETERMINISTIC IS
       l_ch t_CffexPositionComDtl.ComBineType%TYPE  ;
  BEGIN
	  l_ch  := 'future_calendar';
	  RETURN l_ch;
  END C_ComBineType_FCS;

  FUNCTION   C_ComBineType_BuC    RETURN  t_CffexPositionComDtl.ComBineType%TYPE     DETERMINISTIC IS
       l_ch t_CffexPositionComDtl.ComBineType%TYPE  ;
  BEGIN
	  l_ch  := 'bull_call';
	  RETURN l_ch;
  END C_ComBineType_BuC;

  FUNCTION   C_ComBineType_BeC    RETURN  t_CffexPositionComDtl.ComBineType%TYPE     DETERMINISTIC IS
       l_ch t_CffexPositionComDtl.ComBineType%TYPE  ;
  BEGIN
	  l_ch  := 'bear_call';
	  RETURN l_ch;
  END C_ComBineType_BeC;

    FUNCTION   C_ComBineType_BuP    RETURN  t_CffexPositionComDtl.ComBineType%TYPE     DETERMINISTIC IS
       l_ch t_CffexPositionComDtl.ComBineType%TYPE  ;
  BEGIN
	  l_ch  := 'bull_put';
	  RETURN l_ch;
  END C_ComBineType_BuP;

  FUNCTION   C_ComBineType_BeP    RETURN  t_CffexPositionComDtl.ComBineType%TYPE     DETERMINISTIC IS
       l_ch t_CffexPositionComDtl.ComBineType%TYPE  ;
  BEGIN
	  l_ch  := 'bear_put';
	  RETURN l_ch;
  END C_ComBineType_BeP;

  FUNCTION   C_ComBineType_StS    RETURN  t_CffexPositionComDtl.ComBineType%TYPE     DETERMINISTIC IS
       l_ch t_CffexPositionComDtl.ComBineType%TYPE  ;
  BEGIN
	  l_ch  := 'straddle_strangle';
	  RETURN l_ch;
  END C_ComBineType_StS;

  FUNCTION   C_ComBineType_InS    RETURN  t_CffexPositionComDtl.ComBineType%TYPE     DETERMINISTIC IS
       l_ch t_CffexPositionComDtl.ComBineType%TYPE  ;
  BEGIN
	  l_ch  := 'intercom';
	  RETURN l_ch;
  END C_ComBineType_InS;
   FUNCTION   C_ComBineType_ICS    RETURN  t_CffexPositionComDtl.ComBineType%TYPE     DETERMINISTIC IS
       l_ch t_CffexPositionComDtl.ComBineType%TYPE  ;
  BEGIN
	  l_ch  := 'intercom_calender';
	  RETURN l_ch;
  END C_ComBineType_ICS;

  FUNCTION   C_ComBineType_CoC    RETURN  t_CffexPositionComDtl.ComBineType%TYPE     DETERMINISTIC IS
       l_ch t_CffexPositionComDtl.ComBineType%TYPE  ;
  BEGIN
	  l_ch  := 'covered_call';
	  RETURN l_ch;
  END C_ComBineType_CoC;

  FUNCTION   C_ComBineType_SSC    RETURN  t_CffexPositionComDtl.ComBineType%TYPE     DETERMINISTIC IS
       l_ch t_CffexPositionComDtl.ComBineType%TYPE  ;
  BEGIN
	  l_ch  := 'synthetic_short_call';
	  RETURN l_ch;
  END C_ComBineType_SSC;

  FUNCTION   C_ComBineType_OCS    RETURN  t_CffexPositionComDtl.ComBineType%TYPE     DETERMINISTIC IS
       l_ch t_CffexPositionComDtl.ComBineType%TYPE  ;
  BEGIN
	  l_ch  := 'option_calendar';
	  RETURN l_ch;
  END C_ComBineType_OCS;

  ---------------------------------- 大商所组合持仓类型------------------------------------
  FUNCTION   D_ComBineType_SPL    RETURN  t_InvstPositionComDtl.ComBineType%TYPE     DETERMINISTIC IS
       l_ch t_InvstPositionComDtl.ComBineType%TYPE  ;
  BEGIN
	  l_ch  := '0';
	  RETURN l_ch;
  END D_ComBineType_SPL;

  FUNCTION   D_ComBineType_OPL    RETURN  t_InvstPositionComDtl.ComBineType%TYPE     DETERMINISTIC IS
       l_ch t_InvstPositionComDtl.ComBineType%TYPE  ;
  BEGIN
	  l_ch  := '1';
	  RETURN l_ch;
  END D_ComBineType_OPL;

  FUNCTION   D_ComBineType_SP    RETURN  t_InvstPositionComDtl.ComBineType%TYPE     DETERMINISTIC IS
       l_ch t_InvstPositionComDtl.ComBineType%TYPE  ;
  BEGIN
	  l_ch  := '2';
	  RETURN l_ch;
  END D_ComBineType_SP;

  FUNCTION   D_ComBineType_SPC    RETURN  t_InvstPositionComDtl.ComBineType%TYPE     DETERMINISTIC IS
       l_ch t_InvstPositionComDtl.ComBineType%TYPE  ;
  BEGIN
	  l_ch  := '3';
	  RETURN l_ch;
  END D_ComBineType_SPC;

  FUNCTION   D_ComBineType_BLS    RETURN  t_InvstPositionComDtl.ComBineType%TYPE     DETERMINISTIC IS
       l_ch t_InvstPositionComDtl.ComBineType%TYPE  ;
  BEGIN
	  l_ch  := '4';
	  RETURN l_ch;
  END D_ComBineType_BLS;

  FUNCTION   D_ComBineType_BES    RETURN  t_InvstPositionComDtl.ComBineType%TYPE     DETERMINISTIC IS
       l_ch t_InvstPositionComDtl.ComBineType%TYPE  ;
  BEGIN
	  l_ch  := '5';
	  RETURN l_ch;
  END D_ComBineType_BES;

  FUNCTION   D_ComBineType_CAS    RETURN  t_InvstPositionComDtl.ComBineType%TYPE     DETERMINISTIC IS
       l_ch t_InvstPositionComDtl.ComBineType%TYPE  ;
  BEGIN
	  l_ch  := '6';
	  RETURN l_ch;
  END D_ComBineType_CAS;

  FUNCTION   D_ComBineType_STD    RETURN  t_InvstPositionComDtl.ComBineType%TYPE     DETERMINISTIC IS
       l_ch t_InvstPositionComDtl.ComBineType%TYPE  ;
  BEGIN
	  l_ch  := '7';
	  RETURN l_ch;
  END D_ComBineType_STD;

  FUNCTION   D_ComBineType_STG    RETURN  t_InvstPositionComDtl.ComBineType%TYPE     DETERMINISTIC IS
       l_ch t_InvstPositionComDtl.ComBineType%TYPE  ;
  BEGIN
	  l_ch  := '8';
	  RETURN l_ch;
  END D_ComBineType_STG;

  FUNCTION   D_ComBineType_BFO    RETURN  t_InvstPositionComDtl.ComBineType%TYPE     DETERMINISTIC IS
       l_ch t_InvstPositionComDtl.ComBineType%TYPE  ;
  BEGIN
	  l_ch  := '9';
	  RETURN l_ch;
  END D_ComBineType_BFO;

  FUNCTION   D_ComBineType_SFO    RETURN  t_InvstPositionComDtl.ComBineType%TYPE     DETERMINISTIC IS
       l_ch t_InvstPositionComDtl.ComBineType%TYPE  ;
  BEGIN
	  l_ch  := '10';
	  RETURN l_ch;
  END D_ComBineType_SFO;

   ----交易所处理状态----->>
  FUNCTION ERC_Success RETURN pkgs_datatype.STY_RETCODE DETERMINISTIC IS
    l_number pkgs_datatype.STY_RETCODE;
  BEGIN
    l_number := 0;
    RETURN l_number;
  END ERC_Success;

  FUNCTION ERC_NotSuccess RETURN pkgs_datatype.STY_RETCODE DETERMINISTIC IS
    l_number pkgs_datatype.STY_RETCODE;
  BEGIN
    l_number := -1;
    RETURN l_number;
  END ERC_NotSuccess;
  ----交易所处理状态-----<<

  --是否使用上期所期权最小保证金结算保证金率 0 不使用；1：使用；
  FUNCTION UseShfeOptSettleMarginRate RETURN PKGS_DataType.STY_Bool DETERMINISTIC IS
    l_nBool  PKGS_DataType.STY_Bool;
  BEGIN
   l_nBool  := 0;
	  RETURN l_nBool;
  END UseShfeOptSettleMarginRate;


	---- 上期所非交易持仓变动明细文件
  ---- 持仓变动类型
  FUNCTION   PCT_OpPositionHedge              RETURN  pkgs_datatype.STY_EnumChar 	   DETERMINISTIC IS
       l_ch pkgs_datatype.STY_EnumChar;---- 期权持仓对冲
  BEGIN
	  l_ch  := '1';
	  RETURN l_ch;
  END PCT_OpPositionHedge;
  FUNCTION   PCT_OptionStrike              RETURN  pkgs_datatype.STY_EnumChar 	   DETERMINISTIC IS
       l_ch pkgs_datatype.STY_EnumChar;---- 期权执行
  BEGIN
	  l_ch  := '2';
	  RETURN l_ch;
  END PCT_OptionStrike;
  FUNCTION   PCT_PositionHedge              RETURN  pkgs_datatype.STY_EnumChar 	   DETERMINISTIC IS
       l_ch pkgs_datatype.STY_EnumChar;---- 期货持仓对冲
  BEGIN
	  l_ch  := '3';
	  RETURN l_ch;
  END PCT_PositionHedge;
  FUNCTION   PCT_SwitchToDeliv              RETURN  pkgs_datatype.STY_EnumChar 	   DETERMINISTIC IS
       l_ch pkgs_datatype.STY_EnumChar;---- 转入交割
  BEGIN
	  l_ch  := '4';
	  RETURN l_ch;
  END PCT_SwitchToDeliv;
  FUNCTION   PCT_TransferPos              RETURN  pkgs_datatype.STY_EnumChar 	   DETERMINISTIC IS
       l_ch pkgs_datatype.STY_EnumChar;---- 移仓
  BEGIN
	  l_ch  := '5';
	  RETURN l_ch;
  END PCT_TransferPos;

  FUNCTION DCESIX_ON RETURN PKGS_DataType.STY_Bool DETERMINISTIC IS
    l_ch PKGS_DataType.STY_Bool;     ---- 是否启用大商所六期
  BEGIN
	  l_ch := 1;       ---- 长期打开
	  RETURN l_ch;
  END DCESIX_ON;

  FUNCTION InstitutionExtraCode RETURN T_Investorproprietyexinfo.Institutionextracode%TYPE DETERMINISTIC IS
    l_ch T_Investorproprietyexinfo.InstitutionExtraCode%TYPE  ;
  BEGIN
	  l_ch := 'None';       ---- 默认值
	  RETURN l_ch;
  END InstitutionExtraCode;

  FUNCTION Progress_CFFEX RETURN NUMBER DETERMINISTIC IS
    l_num NUMBER(2);
  BEGIN
    l_num := 64;
    RETURN l_num;
  END Progress_CFFEX;

  FUNCTION Progress_CZCE RETURN NUMBER DETERMINISTIC IS
    l_num NUMBER(2);
  BEGIN
    l_num := 44;
    RETURN l_num;
  END Progress_CZCE;

  FUNCTION Progress_DCE RETURN NUMBER DETERMINISTIC IS
    l_num NUMBER(2);
  BEGIN
    IF DCESIX_ON = C_BOOL_TRUE THEN
      l_num := 53;
    ELSE
      l_num := 51;
    END IF;
    RETURN l_num;
  END Progress_DCE;

  FUNCTION Progress_INE RETURN NUMBER DETERMINISTIC IS
    l_num NUMBER(2);
  BEGIN
    l_num := 50;
    RETURN l_num;
  END Progress_INE;

  FUNCTION Progress_SHFE RETURN NUMBER DETERMINISTIC IS
    l_num NUMBER(2);
  BEGIN
    l_num := 62;
    RETURN l_num;
  END Progress_SHFE;

  FUNCTION Progress_None RETURN NUMBER DETERMINISTIC IS
    l_num NUMBER(1);
  BEGIN
    l_num := 0;
    RETURN l_num;
  END Progress_None;

  FUNCTION Progress_SettleIn RETURN NUMBER DETERMINISTIC IS
    l_num NUMBER(1);
  BEGIN
    l_num := 1;
    RETURN l_num;
  END Progress_SettleIn;

  FUNCTION Progress_Settle RETURN NUMBER DETERMINISTIC IS
    l_num NUMBER(1);
  BEGIN
    l_num := 2;
    RETURN l_num;
  END Progress_Settle;

  FUNCTION Progress_SettleOut RETURN NUMBER DETERMINISTIC IS
    l_num NUMBER(1);
  BEGIN
    l_num := 3;
    RETURN l_num;
  END Progress_SettleOut;

  FUNCTION Progress_Done RETURN NUMBER DETERMINISTIC IS
    l_num NUMBER(1);
  BEGIN
    l_num := 4;
    RETURN l_num;
  END Progress_Done;

  FUNCTION Progress_Error RETURN NUMBER DETERMINISTIC IS
    l_num NUMBER(1);
  BEGIN
    l_num := 9;
    RETURN l_num;
  END Progress_Error;

  --- 交易有而结算没有的枚举值
  FUNCTION TAS_InTradeSys     RETURN NUMBER DETERMINISTIC IS     ---- tas产品编号(在交易系统中)
    l_num NUMBER(1);
  BEGIN
    l_num := 7;
    RETURN l_num;
  END TAS_InTradeSys;

  FUNCTION TAS_InExchangeSys     RETURN NUMBER DETERMINISTIC IS     ---- tas产品编号(在交易所中)
    l_num NUMBER(1);
  BEGIN
    l_num := 6;
    RETURN l_num;
  END TAS_InExchangeSys;

END PKGS_Constants;
/

