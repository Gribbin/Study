create TYPE BODY Ty_Bank IS

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_Bank RETURN SELF AS RESULT IS
  BEGIN
    RETURN;
  END;

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2 IS
    l_string VARCHAR2(4000);
  BEGIN
    l_string:='ty_Bank('
      || 'BankID=>' || '''' || trim(BankID) || '''' --结算银行代码
      || ',BankName=>' || '''' || trim(BankName) || '''' --结算银行名称
      || ')';


    RETURN l_string;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN NULL;
  END;



END;
/

