create TYPE BODY Ty_AmlCheckNiSsCus IS

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_AmlCheckNiSsCus RETURN SELF AS RESULT IS
  BEGIN
    RETURN;
  END;

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2 IS
    l_string VARCHAR2(4000);
  BEGIN
    l_string:='ty_AmlCheckNiSsCus('
      || 'TradingDay=>' || '''' || trim(TradingDay) || '''' --交易日期
      || ',ApplyNo=>' || NVL(to_char(ApplyNo),'NULL')--流水号
      || ',FlowID=>' || '''' || trim(FlowID) || '''' --流程ID
      || ',ApplyOperate=>' || '''' || trim(ApplyOperate) || '''' --触发流程操作
      || ',AMLCheckStatus=>' || '''' || trim(AMLCheckStatus) || '''' --审核状态
      || ',BrokerID=>' || '''' || trim(BrokerID) || '''' --经纪公司代码
      || ',InvestorID=>' || '''' || trim(InvestorID) || '''' --投资者代码
      || ',CharacterID=>' || '''' || trim(CharacterID) || '''' --可疑特征代码
      || ',TouchDay=>' || '''' || trim(TouchDay) || '''' --可疑交易发生日期
      || ',DrawDay=>' || '''' || trim(DrawDay) || '''' --检查日期
      || ',DataSource=>' || '''' || trim(DataSource) || '''' --数据来源
      || ',SEVC=>' || '''' || trim(SEVC) || '''' --可疑主体职业（对私）或行业（对公）
      || ',SENM=>' || '''' || trim(SENM) || '''' --可疑主体姓名/名称
      || ',SETP=>' || '''' || trim(SETP) || '''' --可疑主体身份证件/证明文件类型
      || ',SEID=>' || '''' || trim(SEID) || '''' --可疑主体身份证件/证明文件号码
      || ',STNT=>' || '''' || trim(STNT) || '''' --可疑主体国籍
      || ',SCTL=>' || '''' || trim(SCTL) || '''' --可疑主体联系电话
      || ',SEAR=>' || '''' || trim(SEAR) || '''' --可疑主体住址/经营地址
      || ',SEEI=>' || '''' || trim(SEEI) || '''' --可疑主体其他联系方式
      || ',SCAC=>' || '''' || trim(SCAC) || '''' --可疑主体期货账号
      || ',FDAC=>' || '''' || trim(FDAC) || '''' --可疑主体资金账户号码
      || ',STAI=>' || '''' || trim(STAI) || '''' --可疑主体结算账户号码以及开户行名称
      || ',TAAC=>' || '''' || trim(TAAC) || '''' --账户总资产
      || ',OATM=>' || '''' || trim(OATM) || '''' --客户账户开立时间
      || ',CATM=>' || '''' || trim(CATM) || '''' --客户账户销户时间
      || ',SRNM=>' || '''' || trim(SRNM) || '''' --可疑主体法定代表人姓名
      || ',SRIT=>' || '''' || trim(SRIT) || '''' --可疑主体法定代表人身份证件类型
      || ',SRID=>' || '''' || trim(SRID) || '''' --可疑主体法定代表人身份证件号码
      || ',SCNM=>' || '''' || trim(SCNM) || '''' --可疑主体控股股东或实际控制人名称
      || ',SCIT=>' || '''' || trim(SCIT) || '''' --可疑主体控股股东或实际控制人身份证件/证明文件类型
      || ',SCID=>' || '''' || trim(SCID) || '''' --可疑主体控股股东或实际控制人身份证件/证明文件号码
      || ')';


    RETURN l_string;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN NULL;
  END;



END;
/

