create TYPE Ty_BizNotice AS OBJECT
(
    BrokerID CHAR(10),  --经纪公司代码
    Content VARCHAR2(4000),  --消息正文
    SequenceLabel CHAR(1),  --经纪公司通知内容序列号

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_BizNotice RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

