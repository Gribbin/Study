create TYPE Ty_AmlNiSsCus AS OBJECT
(
    BrokerID CHAR(10),  --经纪公司代码
    InvestorID CHAR(12),  --投资者代码
    CharacterID CHAR(4),  --可疑特征代码
    TouchDay CHAR(8),  --可疑交易发生日期
    DrawDay CHAR(8),  --检查日期
    DataSource VARCHAR2(5),  --数据来源
    SEVC VARCHAR2(50),  --可疑主体职业（对私）或行业（对公）
    SENM VARCHAR2(30),  --可疑主体姓名/名称
    SETP VARCHAR2(30),  --可疑主体身份证件/证明文件类型
    SEID VARCHAR2(50),  --可疑主体身份证件/证明文件号码
    STNT VARCHAR2(5),  --可疑主体国籍
    SCTL VARCHAR2(30),  --可疑主体联系电话
    SEAR VARCHAR2(200),  --可疑主体住址/经营地址
    SEEI VARCHAR2(100),  --可疑主体其他联系方式
    SCAC VARCHAR2(100),  --可疑主体期货账号
    FDAC VARCHAR2(100),  --可疑主体资金账户号码
    STAI VARCHAR2(500),  --可疑主体结算账户号码以及开户行名称
    TAAC VARCHAR2(20),  --账户总资产
    OATM VARCHAR2(30),  --客户账户开立时间
    CATM VARCHAR2(30),  --客户账户销户时间
    SRNM VARCHAR2(30),  --可疑主体法定代表人姓名
    SRIT VARCHAR2(30),  --可疑主体法定代表人身份证件类型
    SRID VARCHAR2(50),  --可疑主体法定代表人身份证件号码
    SCNM VARCHAR2(30),  --可疑主体控股股东或实际控制人名称
    SCIT VARCHAR2(30),  --可疑主体控股股东或实际控制人身份证件/证明文件类型
    SCID VARCHAR2(50),  --可疑主体控股股东或实际控制人身份证件/证明文件号码

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_AmlNiSsCus RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

