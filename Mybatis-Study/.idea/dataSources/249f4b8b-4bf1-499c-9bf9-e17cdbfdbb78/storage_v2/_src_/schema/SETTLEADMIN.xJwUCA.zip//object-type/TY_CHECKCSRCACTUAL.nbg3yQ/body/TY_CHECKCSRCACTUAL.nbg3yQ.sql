create TYPE BODY Ty_CheckCSRCActual IS

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_CheckCSRCActual RETURN SELF AS RESULT IS
  BEGIN
    RETURN;
  END;

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2 IS
    l_string VARCHAR2(4000);
  BEGIN
    l_string:='ty_CheckCSRCActual('
      || 'IsSame=>' || '''' || trim(IsSame) || '''' --是否相同
      || ',TradingDay=>' || '''' || trim(TradingDay) || '''' --交易日
      || ',InvestorID=>' || '''' || trim(InvestorID) || '''' --投资者编码
      || ',InvestorName=>' || '''' || trim(InvestorName) || '''' --投资者名称
      || ',CurrencyID=>' || '''' || trim(CurrencyID) || '''' --币种
      || ',diffvalue=>' || NVL(to_char(diffvalue),'NULL')--差额
      || ',Actual=>' || NVL(to_char(Actual),'NULL')--盈亏
      || ',PositionProfitByDate=>' || NVL(to_char(PositionProfitByDate),'NULL')--持仓盈亏(逐日盯市)
      || ',CloseProfitByDate=>' || NVL(to_char(CloseProfitByDate),'NULL')--平仓盯市盈亏
      || ',deposit=>' || NVL(to_char(deposit),'NULL')--权益
      || ',ExerProfit=>' || NVL(to_char(ExerProfit),'NULL')--行权盈亏
      || ')';


    RETURN l_string;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN NULL;
  END;



END;
/

