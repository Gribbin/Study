create PACKAGE BODY PKGI_CheckManager  IS
  /*************************************************************************
  $spDesc 查询复核流程设置
  *************************************************************************/
  PROCEDURE up_GetCheckFlow
  (
     io_TypeCheckFlow IN OUT NOCOPY TY_CHECKFLOW  --复核流程设置信息类型
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nPageCount OUT NOCOPY INT  --返回页码
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_CheckManager.up_GetCheckFlow';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '查询复核流程设置';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '流程管理', '查询复核流程设置');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_CheckManager.up_GetCheckFlow(' ||
                           io_TypeCheckFlow.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nPageCount'
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_CheckManager.up_GetCheckFlow(
                               io_TypeCheckFlow
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nPageCount
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_GetCheckFlow;

  /*************************************************************************
  $spDesc 查询复核流程设置
  *************************************************************************/
  PROCEDURE up_QryCheckFlows
  (
     i_TypeCheckFlow IN TY_CHECKFLOW  --复核流程设置信息类型
    ,i_Ty_Page IN TY_PAGE  --分页查询输入
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作源代码
    ,o_CheckFlowCursor OUT NOCOPY PKGS_DATATYPE.TYPEREFCURSOR  --返回信息游标
    ,o_nPageCount OUT NOCOPY INT  --返回页码
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回码
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_CheckManager.up_QryCheckFlows';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '查询复核流程设置';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '流程管理', '查询复核流程设置');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_CheckManager.up_QryCheckFlows(' ||
                           i_TypeCheckFlow.uf_toString()
                      || ',' ||
                           i_Ty_Page.uf_toString()
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_CheckFlowCursor'
                      || ',' ||
                        'o_nPageCount'
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_CheckManager.up_QryCheckFlows(
                               i_TypeCheckFlow
                              ,i_Ty_Page
                              ,i_chLanguage
                              ,o_CheckFlowCursor
                              ,o_nPageCount
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_QryCheckFlows;

  /*************************************************************************
  $spDesc 设置投资者组复核信息
  *************************************************************************/
  PROCEDURE up_UpdCheckFlow
  (
     io_TypeCheckFlow IN OUT NOCOPY TY_CHECKFLOW  --复核流程设置信息类型
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_CheckManager.up_UpdCheckFlow';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '设置投资者组复核信息';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '流程管理', '设置投资者组复核信息');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_CheckManager.up_UpdCheckFlow(' ||
                           io_TypeCheckFlow.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_CheckManager.up_UpdCheckFlow(
                               io_TypeCheckFlow
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_UpdCheckFlow;

  /*************************************************************************
  $spDesc 创建投资者手续费率信息到中间表
  *************************************************************************/
  PROCEDURE up_InsCheckCommRate
  (
     io_TypeInvstFutCommRate IN OUT NOCOPY TY_O_INVSTFUTCOMMRATE  --投资者手续费率复核类型
    ,i_CheckContent IN PKGS_DATATYPE.STY_RETMSG  --更新信息
    ,i_ApplyOperate IN PKGS_DATATYPE.STY_ENUMCHAR  --复核操作方法
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_CheckManager.up_InsCheckCommRate';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '创建投资者手续费率信息到中间表';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '流程管理', '创建投资者手续费率信息到中间表');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_CheckManager.up_InsCheckCommRate(' ||
                           io_TypeInvstFutCommRate.uf_toString()
                      || ',' ||
                           '''' || trim(i_CheckContent) || ''''
                      || ',' ||
                           '''' || trim(i_ApplyOperate) || ''''
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_CheckManager.up_InsCheckCommRate(
                               io_TypeInvstFutCommRate
                              ,i_CheckContent
                              ,i_ApplyOperate
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_InsCheckCommRate;

  /*************************************************************************
  $spDesc 创建投资者期权手续费率信息到中间表
  *************************************************************************/
  PROCEDURE up_InsCheckOptCommRate
  (
     io_TypeInvstOptCommRate IN OUT NOCOPY TY_O_INVSTOPTCOMMRATE  --投资者期权手续费率复核类型
    ,i_CheckContent IN PKGS_DATATYPE.STY_RETMSG  --更新信息
    ,i_ApplyOperate IN PKGS_DATATYPE.STY_ENUMCHAR  --复核操作方法
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_CheckManager.up_InsCheckOptCommRate';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '创建投资者期权手续费率信息到中间表';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '流程管理', '创建投资者期权手续费率信息到中间表');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_CheckManager.up_InsCheckOptCommRate(' ||
                           io_TypeInvstOptCommRate.uf_toString()
                      || ',' ||
                           '''' || trim(i_CheckContent) || ''''
                      || ',' ||
                           '''' || trim(i_ApplyOperate) || ''''
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_CheckManager.up_InsCheckOptCommRate(
                               io_TypeInvstOptCommRate
                              ,i_CheckContent
                              ,i_ApplyOperate
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_InsCheckOptCommRate;

  /*************************************************************************
  $spDesc 创建投资者期货结算手续费率信息到中间表
  *************************************************************************/
  PROCEDURE up_InsCheckFutSettleComm
  (
     io_TypeInvstFutSettleComm IN OUT NOCOPY TY_O_INVSTFUTSETTLECOMMRATE  --投资者期权结算手续费率复核类型
    ,i_CheckContent IN PKGS_DATATYPE.STY_RETMSG  --更新信息
    ,i_ApplyOperate IN PKGS_DATATYPE.STY_ENUMCHAR  --复核操作方法
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_CheckManager.up_InsCheckFutSettleComm';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '创建投资者期货结算手续费率信息到中间表';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '流程管理', '创建投资者期货结算手续费率信息到中间表');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_CheckManager.up_InsCheckFutSettleComm(' ||
                           io_TypeInvstFutSettleComm.uf_toString()
                      || ',' ||
                           '''' || trim(i_CheckContent) || ''''
                      || ',' ||
                           '''' || trim(i_ApplyOperate) || ''''
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_CheckManager.up_InsCheckFutSettleComm(
                               io_TypeInvstFutSettleComm
                              ,i_CheckContent
                              ,i_ApplyOperate
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_InsCheckFutSettleComm;

  /*************************************************************************
  $spDesc 创建投资者期权结算手续费率信息到中间表
  *************************************************************************/
  PROCEDURE up_InsCheckOptSettleComm
  (
     io_TypeInvstOptSettleComm IN OUT NOCOPY TY_O_INVSTOPTSETTLECOMMRATE  --投资者期权结算手续费率复核类型
    ,i_CheckContent IN PKGS_DATATYPE.STY_RETMSG  --更新信息
    ,i_ApplyOperate IN PKGS_DATATYPE.STY_ENUMCHAR  --复核操作方法
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_CheckManager.up_InsCheckOptSettleComm';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '创建投资者期权结算手续费率信息到中间表';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '流程管理', '创建投资者期权结算手续费率信息到中间表');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_CheckManager.up_InsCheckOptSettleComm(' ||
                           io_TypeInvstOptSettleComm.uf_toString()
                      || ',' ||
                           '''' || trim(i_CheckContent) || ''''
                      || ',' ||
                           '''' || trim(i_ApplyOperate) || ''''
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_CheckManager.up_InsCheckOptSettleComm(
                               io_TypeInvstOptSettleComm
                              ,i_CheckContent
                              ,i_ApplyOperate
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_InsCheckOptSettleComm;

  /*************************************************************************
  $spDesc 创建投资者期货移仓手续费率信息到中间表
  *************************************************************************/
  PROCEDURE up_InsCheckInvstFutTransComm
  (
     io_TypeInvstFutTransComm IN OUT NOCOPY TY_O_INVSTFUTTRANSFERCOMMRATE  --投资者期权结算手续费率复核类型
    ,i_CheckContent IN PKGS_DATATYPE.STY_RETMSG  --更新信息
    ,i_ApplyOperate IN PKGS_DATATYPE.STY_ENUMCHAR  --复核操作方法
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_CheckManager.up_InsCheckInvstFutTransComm';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '创建投资者期货移仓手续费率信息到中间表';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '流程管理', '创建投资者期货移仓手续费率信息到中间表');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_CheckManager.up_InsCheckInvstFutTransComm(' ||
                           io_TypeInvstFutTransComm.uf_toString()
                      || ',' ||
                           '''' || trim(i_CheckContent) || ''''
                      || ',' ||
                           '''' || trim(i_ApplyOperate) || ''''
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_CheckManager.up_InsCheckInvstFutTransComm(
                               io_TypeInvstFutTransComm
                              ,i_CheckContent
                              ,i_ApplyOperate
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_InsCheckInvstFutTransComm;

  /*************************************************************************
  $spDesc 创建投资者期权移仓手续费率信息到中间表
  *************************************************************************/
  PROCEDURE up_InsCheckInvstOptTransComm
  (
     io_TypeInvstOptTransComm IN OUT NOCOPY TY_O_INVSTOPTTRANSFERCOMMRATE  --投资者期权结算手续费率复核类型
    ,i_CheckContent IN PKGS_DATATYPE.STY_RETMSG  --更新信息
    ,i_ApplyOperate IN PKGS_DATATYPE.STY_ENUMCHAR  --复核操作方法
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_CheckManager.up_InsCheckInvstOptTransComm';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '创建投资者期权移仓手续费率信息到中间表';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '流程管理', '创建投资者期权移仓手续费率信息到中间表');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_CheckManager.up_InsCheckInvstOptTransComm(' ||
                           io_TypeInvstOptTransComm.uf_toString()
                      || ',' ||
                           '''' || trim(i_CheckContent) || ''''
                      || ',' ||
                           '''' || trim(i_ApplyOperate) || ''''
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_CheckManager.up_InsCheckInvstOptTransComm(
                               io_TypeInvstOptTransComm
                              ,i_CheckContent
                              ,i_ApplyOperate
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_InsCheckInvstOptTransComm;

  /*************************************************************************
  $spDesc 创建投资者期货保障金手续费率信息到中间表
  *************************************************************************/
  PROCEDURE up_InsCheckInvstFutGUARFComm
  (
     io_TypeInvstFutGUARFComm IN OUT NOCOPY TY_O_INVSTFUTGUARFUNDCOMMRATE  --投资者期权结算手续费率复核类型
    ,i_CheckContent IN PKGS_DATATYPE.STY_RETMSG  --更新信息
    ,i_ApplyOperate IN PKGS_DATATYPE.STY_ENUMCHAR  --复核操作方法
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_CheckManager.up_InsCheckInvstFutGUARFComm';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '创建投资者期货保障金手续费率信息到中间表';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '流程管理', '创建投资者期货保障金手续费率信息到中间表');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_CheckManager.up_InsCheckInvstFutGUARFComm(' ||
                           io_TypeInvstFutGUARFComm.uf_toString()
                      || ',' ||
                           '''' || trim(i_CheckContent) || ''''
                      || ',' ||
                           '''' || trim(i_ApplyOperate) || ''''
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_CheckManager.up_InsCheckInvstFutGUARFComm(
                               io_TypeInvstFutGUARFComm
                              ,i_CheckContent
                              ,i_ApplyOperate
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_InsCheckInvstFutGUARFComm;

  /*************************************************************************
  $spDesc 创建投资者期货浮动手续费率中间表
  *************************************************************************/
  PROCEDURE up_InsCheckFloatFutCom
  (
     io_TyCheckFloatFutCom IN OUT NOCOPY TY_O_FLOATINVSTFUTCOMMRATE  --投资者期货浮动手续费率复核类型
    ,i_CheckContent IN PKGS_DATATYPE.STY_RETMSG  --更新信息
    ,i_ApplyOperate IN PKGS_DATATYPE.STY_ENUMCHAR  --复核操作方法
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_CheckManager.up_InsCheckFloatFutCom';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '创建投资者期货浮动手续费率中间表';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '流程管理', '创建投资者期货浮动手续费率中间表');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_CheckManager.up_InsCheckFloatFutCom(' ||
                           io_TyCheckFloatFutCom.uf_toString()
                      || ',' ||
                           '''' || trim(i_CheckContent) || ''''
                      || ',' ||
                           '''' || trim(i_ApplyOperate) || ''''
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_CheckManager.up_InsCheckFloatFutCom(
                               io_TyCheckFloatFutCom
                              ,i_CheckContent
                              ,i_ApplyOperate
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_InsCheckFloatFutCom;

  /*************************************************************************
  $spDesc 创建投资者期权浮动手续费率中间表
  *************************************************************************/
  PROCEDURE up_InsCheckFloatOptCom
  (
     io_TyCheckFloatOptCom IN OUT NOCOPY TY_O_FLOATINVSTOPTCOMMRATE  --投资者期权浮动手续费率复核类型
    ,i_CheckContent IN PKGS_DATATYPE.STY_RETMSG  --更新信息
    ,i_ApplyOperate IN PKGS_DATATYPE.STY_ENUMCHAR  --复核操作方法
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_CheckManager.up_InsCheckFloatOptCom';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '创建投资者期权浮动手续费率中间表';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '流程管理', '创建投资者期权浮动手续费率中间表');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_CheckManager.up_InsCheckFloatOptCom(' ||
                           io_TyCheckFloatOptCom.uf_toString()
                      || ',' ||
                           '''' || trim(i_CheckContent) || ''''
                      || ',' ||
                           '''' || trim(i_ApplyOperate) || ''''
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_CheckManager.up_InsCheckFloatOptCom(
                               io_TyCheckFloatOptCom
                              ,i_CheckContent
                              ,i_ApplyOperate
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_InsCheckFloatOptCom;

  /*************************************************************************
  $spDesc 创建复核流水
  *************************************************************************/
  PROCEDURE up_InsCheckHis
  (
     io_TypeCheckHis IN OUT NOCOPY TY_CHECKHIS  --复核流水类型
    ,i_operate IN PKGS_DATATYPE.STY_ENUMCHAR  --复核执行操作
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_CheckManager.up_InsCheckHis';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '创建复核流水';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '流程管理', '创建复核流水');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_CheckManager.up_InsCheckHis(' ||
                           io_TypeCheckHis.uf_toString()
                      || ',' ||
                           '''' || trim(i_operate) || ''''
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_CheckManager.up_InsCheckHis(
                               io_TypeCheckHis
                              ,i_operate
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_InsCheckHis;

  /*************************************************************************
  $spDesc 归档终结流程
  *************************************************************************/
  PROCEDURE up_ArchiveCheckFlows
  (
     i_BrokerID IN PKGS_DATATYPE.STY_BROKERID  --经纪公司代码
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_CheckManager.up_ArchiveCheckFlows';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '归档终结流程';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '流程管理', '归档终结流程');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_CheckManager.up_ArchiveCheckFlows(' ||
                           '''' || trim(i_BrokerID) || ''''
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_CheckManager.up_ArchiveCheckFlows(
                               i_BrokerID
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_ArchiveCheckFlows;

  /*************************************************************************
  $spDesc 将复核信息更新到最终表
  *************************************************************************/
  PROCEDURE up_InsCheckTarget
  (
     io_TypeCheckHis IN OUT NOCOPY TY_CHECKHIS  --复核流水类型
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_CheckManager.up_InsCheckTarget';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '将复核信息更新到最终表';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '流程管理', '将复核信息更新到最终表');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_CheckManager.up_InsCheckTarget(' ||
                           io_TypeCheckHis.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_CheckManager.up_InsCheckTarget(
                               io_TypeCheckHis
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_InsCheckTarget;

  /*************************************************************************
  $spDesc 创建投资者组信息到中间表
  *************************************************************************/
  PROCEDURE up_InsCheckInvestorGroup
  (
     io_TypeInvstorGroup IN OUT NOCOPY TY_O_INVESTORGROUP  --投资者组复核类型
    ,i_CheckContent IN PKGS_DATATYPE.STY_RETMSG  --更新信息
    ,i_ApplyOperate IN PKGS_DATATYPE.STY_ENUMCHAR  --复核操作方法
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_CheckManager.up_InsCheckInvestorGroup';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '创建投资者组信息到中间表';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '流程管理', '创建投资者组信息到中间表');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_CheckManager.up_InsCheckInvestorGroup(' ||
                           io_TypeInvstorGroup.uf_toString()
                      || ',' ||
                           '''' || trim(i_CheckContent) || ''''
                      || ',' ||
                           '''' || trim(i_ApplyOperate) || ''''
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_CheckManager.up_InsCheckInvestorGroup(
                               io_TypeInvstorGroup
                              ,i_CheckContent
                              ,i_ApplyOperate
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_InsCheckInvestorGroup;

  /*************************************************************************
  $spDesc 查询投资者复核信息
  *************************************************************************/
  PROCEDURE up_GetCheckInvestorGroup
  (
     io_TypeInvestorGroup IN OUT NOCOPY TY_O_INVESTORGROUP  --投资者组复核类型
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nPageCount OUT NOCOPY INT  --返回页码
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_CheckManager.up_GetCheckInvestorGroup';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '查询投资者复核信息';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '流程管理', '查询投资者复核信息');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_CheckManager.up_GetCheckInvestorGroup(' ||
                           io_TypeInvestorGroup.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nPageCount'
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_CheckManager.up_GetCheckInvestorGroup(
                               io_TypeInvestorGroup
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nPageCount
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_GetCheckInvestorGroup;

  /*************************************************************************
  $spDesc 查询投资者复核信息
  *************************************************************************/
  PROCEDURE up_QryCheckInvestorGroup
  (
     i_TypeInvestorGroup IN TY_O_INVESTORGROUP  --投资者组复核类型
    ,i_Ty_Page IN TY_PAGE  --分页查询输入
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作源代码
    ,o_InvestorGroupCursor OUT NOCOPY PKGS_DATATYPE.TYPEREFCURSOR  --返回信息游标
    ,o_nPageCount OUT NOCOPY INT  --返回页码
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回码
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_CheckManager.up_QryCheckInvestorGroup';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '查询投资者复核信息';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '流程管理', '查询投资者复核信息');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_CheckManager.up_QryCheckInvestorGroup(' ||
                           i_TypeInvestorGroup.uf_toString()
                      || ',' ||
                           i_Ty_Page.uf_toString()
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_InvestorGroupCursor'
                      || ',' ||
                        'o_nPageCount'
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_CheckManager.up_QryCheckInvestorGroup(
                               i_TypeInvestorGroup
                              ,i_Ty_Page
                              ,i_chLanguage
                              ,o_InvestorGroupCursor
                              ,o_nPageCount
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_QryCheckInvestorGroup;

  /*************************************************************************
  $spDesc 复核同意
  *************************************************************************/
  PROCEDURE up_ApproveCheckHis
  (
     io_TypeCheckHis IN OUT NOCOPY TYT_CHECKHIS  --复核流水类型
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_CheckManager.up_ApproveCheckHis';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '复核同意';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '流程管理', '复核同意');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_CheckManager.up_ApproveCheckHis(' ||
                           PKGS_Tyt2STRING.uf_Tyt2String(io_TypeCheckHis)
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_CheckManager.up_ApproveCheckHis(
                               io_TypeCheckHis
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_ApproveCheckHis;

  /*************************************************************************
  $spDesc 复核拒绝
  *************************************************************************/
  PROCEDURE up_RefuseCheckHis
  (
     io_TypeCheckHis IN OUT NOCOPY TYT_CHECKHIS  --复核流水类型
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_CheckManager.up_RefuseCheckHis';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '复核拒绝';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '流程管理', '复核拒绝');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_CheckManager.up_RefuseCheckHis(' ||
                           PKGS_Tyt2STRING.uf_Tyt2String(io_TypeCheckHis)
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_CheckManager.up_RefuseCheckHis(
                               io_TypeCheckHis
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_RefuseCheckHis;

  /*************************************************************************
  $spDesc 复核作废
  *************************************************************************/
  PROCEDURE up_CancelCheckHis
  (
     io_TypeCheckHis IN OUT NOCOPY TYT_CHECKHIS  --复核流水类型
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_CheckManager.up_CancelCheckHis';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '复核作废';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '流程管理', '复核作废');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_CheckManager.up_CancelCheckHis(' ||
                           PKGS_Tyt2STRING.uf_Tyt2String(io_TypeCheckHis)
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_CheckManager.up_CancelCheckHis(
                               io_TypeCheckHis
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_CancelCheckHis;

  /*************************************************************************
  $spDesc 查询单条复核信息
  *************************************************************************/
  PROCEDURE up_GetCheckHis
  (
     io_TypeCheckHis IN OUT NOCOPY TY_CHECKHIS  --复核流水类型
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nPageCount OUT NOCOPY INT  --返回页码
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_CheckManager.up_GetCheckHis';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '查询单条复核信息';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '流程管理', '查询单条复核信息');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_CheckManager.up_GetCheckHis(' ||
                           io_TypeCheckHis.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nPageCount'
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_CheckManager.up_GetCheckHis(
                               io_TypeCheckHis
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nPageCount
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_GetCheckHis;

  /*************************************************************************
  $spDesc 查询复核流水历史
  *************************************************************************/
  PROCEDURE up_QryCheckHis
  (
     i_TypeCheckHis IN TY_CHECKHIS  --复核流水类型
    ,i_Ty_Page IN TY_PAGE  --分页查询输入
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作源代码
    ,o_DetailCursor OUT NOCOPY PKGS_DATATYPE.TYPEREFCURSOR  --返回信息游标
    ,o_nPageCount OUT NOCOPY INT  --返回页码
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回码
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_CheckManager.up_QryCheckHis';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '查询复核流水历史';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '流程管理', '查询复核流水历史');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_CheckManager.up_QryCheckHis(' ||
                           i_TypeCheckHis.uf_toString()
                      || ',' ||
                           i_Ty_Page.uf_toString()
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_DetailCursor'
                      || ',' ||
                        'o_nPageCount'
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_CheckManager.up_QryCheckHis(
                               i_TypeCheckHis
                              ,i_Ty_Page
                              ,i_chLanguage
                              ,o_DetailCursor
                              ,o_nPageCount
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_QryCheckHis;

  /*************************************************************************
  $spDesc 创建投资者手续费率信息到中间表
  *************************************************************************/
  PROCEDURE up_InsCheckinvestorcommodel
  (
     io_TypeInvstCommModel IN OUT NOCOPY TY_O_INVSTCOMMMODEL  --投资者手续费率复核类型
    ,i_CheckContent IN PKGS_DATATYPE.STY_RETMSG  --更新信息
    ,i_ApplyOperate IN PKGS_DATATYPE.STY_ENUMCHAR  --复核操作方法
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_CheckManager.up_InsCheckinvestorcommodel';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '创建投资者手续费率信息到中间表';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '流程管理', '创建投资者手续费率信息到中间表');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_CheckManager.up_InsCheckinvestorcommodel(' ||
                           io_TypeInvstCommModel.uf_toString()
                      || ',' ||
                           '''' || trim(i_CheckContent) || ''''
                      || ',' ||
                           '''' || trim(i_ApplyOperate) || ''''
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_CheckManager.up_InsCheckinvestorcommodel(
                               io_TypeInvstCommModel
                              ,i_CheckContent
                              ,i_ApplyOperate
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_InsCheckinvestorcommodel;

  /*************************************************************************
  $spDesc 查询复核流水历史
  *************************************************************************/
  PROCEDURE up_TQMQryCheckHis
  (
     i_TypeCheckHis IN TY_CHECKHIS  --复核流水类型
    ,i_Ty_Page IN TY_PAGE  --分页查询输入
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作源代码
    ,o_CheckHisCursor OUT NOCOPY PKGS_DATATYPE.TYPEREFCURSOR  --返回信息游标
    ,o_nPageCount OUT NOCOPY INT  --返回页码
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回码
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_CheckManager.up_TQMQryCheckHis';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '查询复核流水历史';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '流程管理', '查询复核流水历史');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_CheckManager.up_TQMQryCheckHis(' ||
                           i_TypeCheckHis.uf_toString()
                      || ',' ||
                           i_Ty_Page.uf_toString()
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_CheckHisCursor'
                      || ',' ||
                        'o_nPageCount'
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_CheckManager.up_TQMQryCheckHis(
                               i_TypeCheckHis
                              ,i_Ty_Page
                              ,i_chLanguage
                              ,o_CheckHisCursor
                              ,o_nPageCount
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_TQMQryCheckHis;

  /*************************************************************************
  $spDesc 查询复核信息明细
  *************************************************************************/
  PROCEDURE up_QryCheckHisLatest
  (
     i_TypeCheckHis IN TYT_CHECKHIS  --复核流水类型
    ,i_Ty_Page IN TY_PAGE  --分页查询输入
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作源代码
    ,o_CheckHisCursor OUT NOCOPY PKGS_DATATYPE.TYPEREFCURSOR  --返回信息游标
    ,o_nPageCount OUT NOCOPY INT  --返回页码
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回码
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_CheckManager.up_QryCheckHisLatest';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '查询复核信息明细';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '流程管理', '查询复核信息明细');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_CheckManager.up_QryCheckHisLatest(' ||
                           PKGS_Tyt2STRING.uf_Tyt2String(i_TypeCheckHis)
                      || ',' ||
                           i_Ty_Page.uf_toString()
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_CheckHisCursor'
                      || ',' ||
                        'o_nPageCount'
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_CheckManager.up_QryCheckHisLatest(
                               i_TypeCheckHis
                              ,i_Ty_Page
                              ,i_chLanguage
                              ,o_CheckHisCursor
                              ,o_nPageCount
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_QryCheckHisLatest;

  /*************************************************************************
  $spDesc 查询最新状态复核信息
  *************************************************************************/
  PROCEDURE up_QueryCheckHisLatest
  (
     i_TypeCheckHis IN TY_QUERYCHECKHISLATEST  --复核流水类型
    ,i_Ty_Page IN TY_PAGE  --分页查询输入
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作源代码
    ,o_CheckHisCursor OUT NOCOPY PKGS_DATATYPE.TYPEREFCURSOR  --返回信息游标
    ,o_nPageCount OUT NOCOPY INT  --返回页码
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回码
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_CheckManager.up_QueryCheckHisLatest';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '查询最新状态复核信息';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '流程管理', '查询最新状态复核信息');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_CheckManager.up_QueryCheckHisLatest(' ||
                           i_TypeCheckHis.uf_toString()
                      || ',' ||
                           i_Ty_Page.uf_toString()
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_CheckHisCursor'
                      || ',' ||
                        'o_nPageCount'
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_CheckManager.up_QueryCheckHisLatest(
                               i_TypeCheckHis
                              ,i_Ty_Page
                              ,i_chLanguage
                              ,o_CheckHisCursor
                              ,o_nPageCount
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_QueryCheckHisLatest;

  /*************************************************************************
  $spDesc 获取操作员有权限的复核投资者
  *************************************************************************/
  PROCEDURE up_GenCheckInvestor
  (
     i_BrokerID IN  PKGS_DATATYPE.STY_BROKERID  --经纪公司代码
    ,i_InvestorRange IN  PKGS_DATATYPE.STY_INVESTORRANGE  --投资者范围
    ,i_InvestorID IN  PKGS_DATATYPE.STY_INVESTORID  --投资者代码
    ,i_partyString IN  PKGS_DATATYPE.STY_INVSTPARTY  --投资者属性
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_CheckManager.up_GenCheckInvestor';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '获取操作员有权限的复核投资者';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '流程管理', '获取操作员有权限的复核投资者');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_CheckManager.up_GenCheckInvestor(' ||
                           '''' || trim(i_BrokerID) || ''''
                      || ',' ||
                           '''' || trim(i_InvestorRange) || ''''
                      || ',' ||
                           '''' || trim(i_InvestorID) || ''''
                      || ',' ||
                           '''' || trim(i_partyString) || ''''
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_CheckManager.up_GenCheckInvestor(
                               i_BrokerID
                              ,i_InvestorRange
                              ,i_InvestorID
                              ,i_partyString
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_GenCheckInvestor;

  /*************************************************************************
  $spDesc 验证操作员对投资者组是否有操作权限
  *************************************************************************/
  PROCEDURE up_ValidateCheckInvestor
  (
     i_BrokerID IN  PKGS_DATATYPE.STY_BROKERID  --经纪公司代码
    ,i_InvestorRange IN  PKGS_DATATYPE.STY_INVESTORRANGE  --投资者范围
    ,i_InvestorID IN  PKGS_DATATYPE.STY_INVESTORID  --投资者代码
    ,i_FlowID IN   T_CHECKFLOW.FLOWID%TYPE  --复核流程代码
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_CheckManager.up_ValidateCheckInvestor';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '验证操作员对投资者组是否有操作权限';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '流程管理', '验证操作员对投资者组是否有操作权限');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_CheckManager.up_ValidateCheckInvestor(' ||
                           '''' || trim(i_BrokerID) || ''''
                      || ',' ||
                           '''' || trim(i_InvestorRange) || ''''
                      || ',' ||
                           '''' || trim(i_InvestorID) || ''''
                      || ',' ||
                           '''' || trim(i_FlowID) || ''''
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_CheckManager.up_ValidateCheckInvestor(
                               i_BrokerID
                              ,i_InvestorRange
                              ,i_InvestorID
                              ,i_FlowID
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_ValidateCheckInvestor;

END PKGI_CheckManager;
/

