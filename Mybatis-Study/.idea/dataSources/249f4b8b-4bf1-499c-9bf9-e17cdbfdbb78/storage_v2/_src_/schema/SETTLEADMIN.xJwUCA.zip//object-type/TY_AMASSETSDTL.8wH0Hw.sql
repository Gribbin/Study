create TYPE Ty_AmAssetsDtl AS OBJECT
(
    TradingDay CHAR(10),  --交易日
    ParticipantID CHAR(10),  --会员代码
    InvestorID CHAR(12),  --客户内部资金账户
    InvTargetType CHAR(4),  --投资标的类型
    Actual NUMBER(15,3),  --上日盈亏
    Deposit NUMBER(15,3),  --上日净值
    CurrencyID CHAR(3),  --币种
    IsMultiple CHAR(1),  --是否为特定多个客户资产管理计划
    Memo CHAR(40),  --说明
    ProductCode CHAR(12),  --产品编码

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_AmAssetsDtl RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

