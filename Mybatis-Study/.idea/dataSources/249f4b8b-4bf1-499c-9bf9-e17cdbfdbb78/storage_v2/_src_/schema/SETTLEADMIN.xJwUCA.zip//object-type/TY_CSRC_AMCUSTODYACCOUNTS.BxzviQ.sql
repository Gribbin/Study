create TYPE Ty_CSRC_AmCustodyAccounts AS OBJECT
(
    TradingDay CHAR(10),  --交易日
    ParticipantID CHAR(10),  --会员代码
    InvestorID CHAR(12),  --客户内部资金账户
    TrusteeAmName VARCHAR2(400),  --托管机构名称
    TrusteeAmAccount CHAR(22),  --托管账户
    TrusteeAmAccountName VARCHAR2(400),  --托管账户户名
    SettleAmName VARCHAR2(400),  --结算机构名称
    SettleAmAccount CHAR(22),  --资管结算账户
    CurrencyID CHAR(3),  --币种
    Memo CHAR(40),  --说明

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_CSRC_AmCustodyAccounts RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

