create TYPE Ty_CAPInvstAmAccount AS OBJECT
(
    BrokerID CHAR(10),  --经纪公司代码
    InvestorID CHAR(12),  --投资者代码
    AmName VARCHAR2(400),  --机构名称
    AmType CHAR(1),  --机构类型
    AmAccount CHAR(22),  --投资账户
    Memo CHAR(40),  --说明

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_CAPInvstAmAccount RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

