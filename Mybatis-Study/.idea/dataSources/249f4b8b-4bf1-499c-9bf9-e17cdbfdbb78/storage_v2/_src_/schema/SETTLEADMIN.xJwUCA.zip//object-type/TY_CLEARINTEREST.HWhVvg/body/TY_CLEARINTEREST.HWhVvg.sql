create TYPE BODY Ty_ClearInterest IS

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_ClearInterest RETURN SELF AS RESULT IS
  BEGIN
    RETURN;
  END;

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2 IS
    l_string VARCHAR2(4000);
  BEGIN
    l_string:='ty_ClearInterest('
      || 'BrokerID=>' || '''' || trim(BrokerID) || '''' --经纪公司代码
      || ',ClearIntNo=>' || NVL(to_char(ClearIntNo),'NULL')--结息操作编号
      || ',AccountID=>' || '''' || trim(AccountID) || '''' --资金账号
      || ',CurrencyID=>' || '''' || trim(CurrencyID) || '''' --资金账号币种
      || ',EndDate=>' || '''' || trim(EndDate) || '''' --结息结束日期
      || ',ClearIntScope=>' || '''' || trim(ClearIntScope) || '''' --计息范围
      || ',EliminateType=>' || '''' || trim(EliminateType) || '''' --剔除方式
      || ',Interest=>' || NVL(to_char(Interest),'NULL')--利息金额
      || ',OperatorID=>' || '''' || trim(OperatorID) || '''' --操作员代码
      || ',OpDate=>' || '''' || trim(OpDate) || '''' --操作日期
      || ',OpTime=>' || '''' || trim(OpTime) || '''' --操作时间
      || ')';


    RETURN l_string;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN NULL;
  END;



END;
/

