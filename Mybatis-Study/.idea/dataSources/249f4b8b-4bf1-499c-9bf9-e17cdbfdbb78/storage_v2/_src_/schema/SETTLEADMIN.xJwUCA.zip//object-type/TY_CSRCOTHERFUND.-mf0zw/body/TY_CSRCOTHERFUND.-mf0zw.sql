create TYPE BODY Ty_CSRCOtherFund IS

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_CSRCOtherFund RETURN SELF AS RESULT IS
  BEGIN
    RETURN;
  END;

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2 IS
    l_string VARCHAR2(4000);
  BEGIN
    l_string:='ty_CSRCOtherFund('
      || 'BrokerID=>' || '''' || trim(BrokerID) || '''' --经纪公司代码
      || ',TradingDay=>' || '''' || trim(TradingDay) || '''' --交易日
      || ',InvestorID=>' || '''' || trim(InvestorID) || '''' --投资者代码
      || ',ExchangeID=>' || '''' || trim(ExchangeID) || '''' --交易所代码
      || ',FundProjectID=>' || '''' || trim(FundProjectID) || '''' --资金项目编号
      || ',ClientID=>' || '''' || trim(ClientID) || '''' --客户编码
      || ',OrgDeposit=>' || NVL(to_char(OrgDeposit),'NULL')--原资金金额
      || ',Deposit=>' || NVL(to_char(Deposit),'NULL')--录入资金金额
      || ',Memo=>' || '''' || trim(Memo) || '''' --备注
      || ',OperatorID=>' || '''' || trim(OperatorID) || '''' --录入员代码
      || ',OperateDate=>' || '''' || trim(OperateDate) || '''' --录入日期
      || ',OperateTime=>' || '''' || trim(OperateTime) || '''' --录入时间
      || ',CheckerID=>' || '''' || trim(CheckerID) || '''' --复核员代码
      || ',CheckDate=>' || '''' || trim(CheckDate) || '''' --复核日期
      || ',CheckTime=>' || '''' || trim(CheckTime) || '''' --复核时间
      || ')';


    RETURN l_string;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN NULL;
  END;



END;
/

