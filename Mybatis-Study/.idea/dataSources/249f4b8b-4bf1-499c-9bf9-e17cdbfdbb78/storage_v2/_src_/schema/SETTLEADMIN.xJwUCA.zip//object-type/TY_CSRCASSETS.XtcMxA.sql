create TYPE Ty_CSRCAssets AS OBJECT
(
    TradingDay CHAR(8),  --交易日
    BrokerID CHAR(10),  --经纪公司代码
    InvestorID CHAR(12),  --客户内部资金账户
    Actual NUMBER(15,3),  --当日盈亏
    Deposit NUMBER(15,3),  --净值总额
    CurrencyID CHAR(3),  --币种
    Memo CHAR(40),  --说明
    InvTargetType CHAR(4),  --投资标的类型
    ProductCode CHAR(12),  --产品编码

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_CSRCAssets RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

