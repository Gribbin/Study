create TYPE BODY Ty_CSRCDataSend IS

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_CSRCDataSend RETURN SELF AS RESULT IS
  BEGIN
    RETURN;
  END;

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2 IS
    l_string VARCHAR2(4000);
  BEGIN
    l_string:='ty_CSRCDataSend('
      || 'TradingDay=>' || '''' || trim(TradingDay) || '''' --交易日
      || ',ParticipantID=>' || '''' || trim(ParticipantID) || '''' --会员代码
      || ',IsConfirm=>' || '''' || trim(IsConfirm) || '''' --是否保证发送成功
      || ',IsSend=>' || '''' || trim(IsSend) || '''' --是否已经发送
      || ')';


    RETURN l_string;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN NULL;
  END;



END;
/

