create TYPE Ty_CAPInvstAmCustodyAcc AS OBJECT
(
    BrokerID CHAR(10),  --经纪公司代码
    InvestorID CHAR(12),  --投资者代码
    TrusteeAmName VARCHAR2(400),  --托管机构名称
    TrusteeAmAccount CHAR(22),  --托管账户
    TrusteeAmAccountName VARCHAR2(400),  --托管账户户名
    SettleAmName VARCHAR2(400),  --结算机构名称
    SettleAmAccount CHAR(22),  --资管结算账户
    CurrencyID CHAR(3),  --币种

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_CAPInvstAmCustodyAcc RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

