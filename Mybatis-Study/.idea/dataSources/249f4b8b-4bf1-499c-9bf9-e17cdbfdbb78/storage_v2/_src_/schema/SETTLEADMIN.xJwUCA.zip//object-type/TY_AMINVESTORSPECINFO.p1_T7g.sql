create TYPE Ty_AMInvestorSpecInfo AS OBJECT
(
    BrokerID CHAR(10),  --经纪公司代码
    InvestorID CHAR(12),  --投资者代码
    AssetmgrClientType CHAR(1),  --资产管理客户类型
    AssetmgrType CHAR(1),  --投资类型
    AssetmgrCFullName VARCHAR2(100),  --代理资产管理业务的期货公司全称
    AssetmgrFund NUMBER(22,6),  --委托资金
    AssetmgrApprovalNO CHAR(50),  --资产管理业务批文号
    AssetmgrStartDate CHAR(8),  --起始委托时间
    AssetmgrFinishDate CHAR(8),  --终止委托时间
    AssetmgrName VARCHAR2(80),  --资产管理业务负责人姓名
    AssetmgrPhoneCountryCode CHAR(10),  --资产管理业务负责人联系电话国家代码
    AssetmgrPhoneAreaCode CHAR(10),  --资产管理业务负责人联系电话区号
    AssetmgrTelephone CHAR(40),  --资产管理业务负责人联系电话电话号码
    AssetmgrIdentifiedCardType CHAR(1),  --资产管理业务负责人证件类型
    AssetmgrIdentifiedCardNo CHAR(50),  --资产管理业务负责人证件号码
    AssetmgrInstitution CHAR(1),  --资产管理业务的经营机构
    AssetmgrPlanName CHAR(100),  --资产管理计划名称
    SubscriberExtracode CHAR(50),  --委托人附加码
    TrusteeName CHAR(100),  --托（保）管人名称

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_AMInvestorSpecInfo RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

