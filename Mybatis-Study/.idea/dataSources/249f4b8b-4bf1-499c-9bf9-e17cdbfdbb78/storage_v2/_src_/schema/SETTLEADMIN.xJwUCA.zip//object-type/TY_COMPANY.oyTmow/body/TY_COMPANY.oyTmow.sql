create TYPE BODY Ty_Company IS

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_Company RETURN SELF AS RESULT IS
  BEGIN
    RETURN;
  END;

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2 IS
    l_string VARCHAR2(4000);
  BEGIN
    l_string:='ty_Company('
      || 'BrokerID=>' || '''' || trim(BrokerID) || '''' --经纪公司代码
      || ',InvestorID=>' || '''' || trim(InvestorID) || '''' --投资者代码
      || ',TaxNo=>' || '''' || trim(TaxNo) || '''' --税务登记号
      || ',TaxNoStart=>' || '''' || trim(TaxNoStart) || '''' --税务登记号有效期（起）
      || ',TaxNoEnd=>' || '''' || trim(TaxNoEnd) || '''' --税务登记号有效期（止）
      || ',Corporation=>' || '''' || trim(Corporation) || '''' --法人代表
      || ',Linkman=>' || '''' || trim(Linkman) || '''' --联系人
      || ',LinkmanIdType=>' || '''' || trim(LinkmanIdType) || '''' --法人代表证件类型
      || ',LinkmanIdNo=>' || '''' || trim(LinkmanIdNo) || '''' --法人代表证件号码
      || ',LinkmanNoStart=>' || '''' || trim(LinkmanNoStart) || '''' --营业执照有效期（起）
      || ',LinkmanNoEnd=>' || '''' || trim(LinkmanNoEnd) || '''' --证营业执照有效期（止）
      || ',LicenseNo=>' || '''' || trim(LicenseNo) || '''' --统一社会信用代码
      || ',LicenseNoStart=>' || '''' || trim(LicenseNoStart) || '''' --营业执照有效期（起）
      || ',LicenseNoEnd=>' || '''' || trim(LicenseNoEnd) || '''' --证营业执照有效期（止）
      || ',CompanyType=>' || '''' || trim(CompanyType) || '''' --企业性质
      || ',Capital=>' || NVL(to_char(Capital),'NULL')--注册资本
      || ',CapitalCurrency=>' || '''' || trim(CapitalCurrency) || '''' --注册资本货币
      || ',WebSite=>' || '''' || trim(WebSite) || '''' --网址
      || ',HasBoard=>' || '''' || trim(HasBoard) || '''' --是否有董事会
      || ',BusinessPeriod=>' || '''' || trim(BusinessPeriod) || '''' --经营期限
      || ',InvestorNameEng=>' || '''' || trim(InvestorNameEng) || '''' --投资者英文名称
      || ',CorporateIdentifiedCardType=>' || '''' || trim(CorporateIdentifiedCardType) || '''' --法人代表证件类型
      || ',CorporateIdentifiedCardNo=>' || '''' || trim(CorporateIdentifiedCardNo) || '''' --法人代表证件号码
      || ',CorporateNoStart=>' || '''' || trim(CorporateNoStart) || '''' --法人代表证件有效期（起）
      || ',CorporateNoEnd=>' || '''' || trim(CorporateNoEnd) || '''' --法人代表证件有效期（止）
      || ',CorporatePhoneCountryCode=>' || '''' || trim(CorporatePhoneCountryCode) || '''' --法人代表国家代码
      || ',CorporatePhoneAreaCode=>' || '''' || trim(CorporatePhoneAreaCode) || '''' --法人代表区号
      || ',CorporateTelephone=>' || '''' || trim(CorporateTelephone) || '''' --法人代表联系电话
      || ',CorporateCountry=>' || '''' || trim(CorporateCountry) || '''' --法人代表身份归属国家或地区
      || ',CorporateProvince=>' || '''' || trim(CorporateProvince) || '''' --法人代表所在省
      || ',CorporateCity=>' || '''' || trim(CorporateCity) || '''' --法人代表所在市
      || ',CorporateAddress=>' || '''' || trim(CorporateAddress) || '''' --法人代表所在地
      || ',CorporateBirthDay=>' || '''' || trim(CorporateBirthDay) || '''' --法人代表出生日期
      || ',CorporateZipCode=>' || '''' || trim(CorporateZipCode) || '''' --法人代表邮政编码
      || ',CorporateNational=>' || '''' || trim(CorporateNational) || '''' --法人代表身份归属国家/地区
      || ',CorporateNationalProvince=>' || '''' || trim(CorporateNationalProvince) || '''' --法人代表所在省
      || ',CorporateNationalCity=>' || '''' || trim(CorporateNationalCity) || '''' --法人代表所在市
      || ',CorporateSex=>' || '''' || trim(CorporateSex) || '''' --法人代表性别
      || ',InstitutionExtraCode=>' || '''' || trim(InstitutionExtraCode) || '''' --附加码
      || ',RegistryCountry=>' || '''' || trim(RegistryCountry) || '''' --注册国家
      || ',RegistryProvince=>' || '''' || trim(RegistryProvince) || '''' --注册省州
      || ',RegistryCity=>' || '''' || trim(RegistryCity) || '''' --注册城市
      || ',RegistryAddress=>' || '''' || trim(RegistryAddress) || '''' --注册地址
      || ')';


    RETURN l_string;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN NULL;
  END;



END;
/

