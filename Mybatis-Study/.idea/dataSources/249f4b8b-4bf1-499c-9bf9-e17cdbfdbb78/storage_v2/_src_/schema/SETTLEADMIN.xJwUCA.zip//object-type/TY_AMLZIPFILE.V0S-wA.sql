create TYPE Ty_AMLZipFile AS OBJECT
(
    BrokerID CHAR(10),  --经纪公司代码
    AMLGenSeqID NUMBER(8),  --文件生成事件序列号
    ZipNumber NUMBER(4),  --zip包编号
    XMLAmount NUMBER(4),  --xml报文数量
    Appendix CHAR(256),  --附件文件名

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_AMLZipFile RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

