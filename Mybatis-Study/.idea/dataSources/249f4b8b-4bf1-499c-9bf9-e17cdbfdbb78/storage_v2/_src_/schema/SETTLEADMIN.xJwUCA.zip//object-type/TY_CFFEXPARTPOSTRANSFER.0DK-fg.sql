create TYPE Ty_CFFEXPartPosTransfer AS OBJECT
(
    TradingDay CHAR(8),  --交易日
    ExchangeID CHAR(8),  --交易所代码
    ParticipantID CHAR(10),  --会员代码
    ClientID CHAR(10),  --投资者号
    TradePartID CHAR(10),  --所属交易会员号
    ExchangeInstID CHAR(30),  --合约代码
    TradePartAbbr CHAR(8),  --所属交易会员简称
    BTransferPosAmt NUMBER(20),  --多头移仓量
    STransferPosAmt NUMBER(20),  --空头移仓量
    MarginChange NUMBER(22,6),  --保证金变化
    TransferOutSettlePartID CHAR(10),  --移出结算会员
    TransferInSettlePartID CHAR(10),  --移入结算会员

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_CFFEXPartPosTransfer RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

