create TYPE Ty_CRARiskIndex AS OBJECT
(
    BrokerID CHAR(10),  --经纪商代码
    RiskFactorID NUMBER(8),  --风险因素ID
    RiskIndexID NUMBER(8),  --指标ID
    RiskIndexName VARCHAR2(50),  --名称
    RiskIndexWeight NUMBER(8),  --权重
    RiskIndexLevel NUMBER(8),  --分级
    IsAddItem CHAR(1),  --是否附加项

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_CRARiskIndex RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

