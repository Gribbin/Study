create TYPE BODY Ty_CAPInvstBasicInfo IS

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_CAPInvstBasicInfo RETURN SELF AS RESULT IS
  BEGIN
    RETURN;
  END;

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2 IS
    l_string VARCHAR2(4000);
  BEGIN
    l_string:='ty_CAPInvstBasicInfo('
      || 'BrokerID=>' || '''' || trim(BrokerID) || '''' --经纪公司代码
      || ',InvestorID=>' || '''' || trim(InvestorID) || '''' --投资者代码
      || ',InvestorName=>' || '''' || trim(InvestorName) || '''' --投资者名称
      || ',InvestorType=>' || '''' || trim(InvestorType) || '''' --投资者类型
      || ',DepartmentID=>' || '''' || trim(DepartmentID) || '''' --组织架构代码
      || ',IsEmail=>' || '''' || trim(IsEmail) || '''' --是否接收电子邮件
      || ',IsSMS=>' || '''' || trim(IsSMS) || '''' --是否接收短信
      || ',IsUsingOTP=>' || '''' || trim(IsUsingOTP) || '''' --是否使用令牌
      || ',ClientRegion=>' || '''' || trim(ClientRegion) || '''' --开户客户地域
      || ',ClientMode=>' || '''' || trim(ClientMode) || '''' --开户模式
      || ',RiskLevel=>' || '''' || trim(RiskLevel) || '''' --风险等级
      || ',ContractCode=>' || '''' || trim(ContractCode) || '''' --合同编号
      || ',InvestorFullName=>' || '''' || trim(InvestorFullName) || '''' --投资者全称
      || ',BrokerSecAgentID=>' || '''' || trim(BrokerSecAgentID) || '''' --境外中介机构资金账号
      || ',AgencyRegId=>' || '''' || trim(AgencyRegId) || '''' --监控中心分配的境外中介机构代码
      || ',Telephone=>' || '''' || trim(Telephone) || '''' --联系电话
      || ',PhoneCountryCode=>' || '''' || trim(PhoneCountryCode) || '''' --国家代码
      || ',PhoneAreaCode=>' || '''' || trim(PhoneAreaCode) || '''' --区号
      || ',Fax=>' || '''' || trim(Fax) || '''' --传真
      || ',Mobile=>' || '''' || trim(Mobile) || '''' --移动电话
      || ',ZipCode=>' || '''' || trim(ZipCode) || '''' --邮政编码
      || ',EMail=>' || '''' || trim(EMail) || '''' --电子邮件
      || ',IdentifiedCardType=>' || '''' || trim(IdentifiedCardType) || '''' --证件类型
      || ',IdentifiedCardNo=>' || '''' || trim(IdentifiedCardNo) || '''' --证件号码
      || ',Classify=>' || '''' || trim(Classify) || '''' --客户分类码
      || ',Nationality=>' || '''' || trim(Nationality) || '''' --国籍国家
      || ',Country=>' || '''' || trim(Country) || '''' --联系地址中的国家
      || ',Province=>' || '''' || trim(Province) || '''' --联系地址中的省州
      || ',City=>' || '''' || trim(City) || '''' --联系地址中的城市
      || ',Region=>' || '''' || trim(Region) || '''' --区
      || ',Address=>' || '''' || trim(Address) || '''' --联系地址
      || ',OriginalCardNO=>' || '''' || trim(OriginalCardNO) || '''' --原始证件号码
      || ',Memo=>' || '''' || trim(Memo) || '''' --备注
      || ',BirthDay=>' || '''' || trim(BirthDay) || '''' --出生日期
      || ',Sex=>' || '''' || trim(Sex) || '''' --性别
      || ',Position=>' || '''' || trim(Position) || '''' --职务
      || ',OrganType=>' || '''' || trim(OrganType) || '''' --单位性质
      || ',TaxNo=>' || '''' || trim(TaxNo) || '''' --税务登记号
      || ',Corporation=>' || '''' || trim(Corporation) || '''' --法人代表
      || ',Linkman=>' || '''' || trim(Linkman) || '''' --联系人
      || ',LicenseNo=>' || '''' || trim(LicenseNo) || '''' --统一社会信用代码
      || ',CompanyType=>' || '''' || trim(CompanyType) || '''' --企业性质
      || ',Capital=>' || NVL(to_char(Capital),'NULL')--注册资本
      || ',CapitalCurrency=>' || '''' || trim(CapitalCurrency) || '''' --注册资本货币
      || ',RegistryCountry=>' || '''' || trim(RegistryCountry) || '''' --注册国家
      || ',LedgerManageName=>' || '''' || trim(LedgerManageName) || '''' --产品名称
      || ',AssetmgrClientType=>' || '''' || trim(AssetmgrClientType) || '''' --资产管理客户类型
      || ',AssetmgrType=>' || '''' || trim(AssetmgrType) || '''' --投资类型
      || ',AssetmgrInstitution=>' || '''' || trim(AssetmgrInstitution) || '''' --资产管理业务的经营机构
      || ',AssetmgrPlanName=>' || '''' || trim(AssetmgrPlanName) || '''' --资产管理计划名称
      || ',SubscriberExtracode=>' || '''' || trim(SubscriberExtracode) || '''' --委托人附加码
      || ',TrusteeName=>' || '''' || trim(TrusteeName) || '''' --托（保）管人名称
      || ',BusinessScope=>' || '''' || trim(BusinessScope) || '''' --经营范围
      || ',OpenDate=>' || '''' || trim(OpenDate) || '''' --开户日期
      || ')';


    RETURN l_string;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN NULL;
  END;



END;
/

