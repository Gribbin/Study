create TYPE Ty_AmlInvstChangeChkParam AS OBJECT
(
    BrokerID CHAR(10),  --经纪公司代码
    AmlinvstchangeChkParamID CHAR(32),  --识别身份变更参数代码
    AmlInvstchangeChkParamName CHAR(64),  --识别身份变更参数名称
    isActive NUMBER(1),  --是否启用

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_AmlInvstChangeChkParam RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

