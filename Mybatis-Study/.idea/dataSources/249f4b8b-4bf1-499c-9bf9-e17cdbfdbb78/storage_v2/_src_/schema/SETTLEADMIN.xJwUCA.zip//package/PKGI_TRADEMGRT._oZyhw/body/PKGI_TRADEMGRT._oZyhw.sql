create PACKAGE BODY PKGI_TradeMgrt  IS
  /*************************************************************************
  $spDesc 新增虚拟组织
  *************************************************************************/
  PROCEDURE up_InsParty
  (
     io_tyParty IN OUT TY_PARTY  --虚拟组织
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_InsParty';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '新增虚拟组织';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '新增虚拟组织');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_InsParty(' ||
                           io_tyParty.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_InsParty(
                               io_tyParty
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_InsParty;

  /*************************************************************************
  $spDesc 修改虚拟组织
  *************************************************************************/
  PROCEDURE up_UpdParty
  (
     io_tyParty IN OUT TY_PARTY  --虚拟组织
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_UpdParty';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '修改虚拟组织';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '修改虚拟组织');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_UpdParty(' ||
                           io_tyParty.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_UpdParty(
                               io_tyParty
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_UpdParty;

  /*************************************************************************
  $spDesc 删除虚拟组织
  *************************************************************************/
  PROCEDURE up_DelParty
  (
     io_tyParty IN OUT TY_PARTY  --虚拟组织
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_DelParty';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '删除虚拟组织';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '删除虚拟组织');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_DelParty(' ||
                           io_tyParty.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_DelParty(
                               io_tyParty
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_DelParty;

  /*************************************************************************
  $spDesc 查询虚拟组织
  *************************************************************************/
  PROCEDURE up_GetParty
  (
     io_tyParty IN OUT TY_PARTY  --虚拟组织
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_GetParty';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '查询虚拟组织';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '查询虚拟组织');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_GetParty(' ||
                           io_tyParty.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_GetParty(
                               io_tyParty
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_GetParty;

  /*************************************************************************
  $spDesc 查询虚拟组织
  *************************************************************************/
  PROCEDURE up_QryParty
  (
     i_tyParty IN TY_PARTY  --查询条件
    ,i_tyPage IN  TY_PAGE  --分页信息
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_curParty OUT NOCOPY PKGS_DATATYPE.TYPEREFCURSOR  --查询结果游标
    ,o_nCount OUT PKGS_DATATYPE.STY_COUNT  --记录数
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_QryParty';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '查询虚拟组织';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '查询虚拟组织');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_QryParty(' ||
                           i_tyParty.uf_toString()
                      || ',' ||
                           i_tyPage.uf_toString()
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_curParty'
                      || ',' ||
                        'o_nCount'
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_QryParty(
                               i_tyParty
                              ,i_tyPage
                              ,i_chLanguage
                              ,o_curParty
                              ,o_nCount
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_QryParty;

  /*************************************************************************
  $spDesc 查询虚拟组织
  *************************************************************************/
  PROCEDURE up_QueryInvestorParty
  (
     i_tyParty IN TY_PARTY  --查询条件
    ,i_tyPage IN  TY_PAGE  --分页信息
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_curParty OUT NOCOPY PKGS_DATATYPE.TYPEREFCURSOR  --查询结果游标
    ,o_nCount OUT PKGS_DATATYPE.STY_COUNT  --记录数
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_QueryInvestorParty';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '查询虚拟组织';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '查询虚拟组织');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_QueryInvestorParty(' ||
                           i_tyParty.uf_toString()
                      || ',' ||
                           i_tyPage.uf_toString()
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_curParty'
                      || ',' ||
                        'o_nCount'
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_QueryInvestorParty(
                               i_tyParty
                              ,i_tyPage
                              ,i_chLanguage
                              ,o_curParty
                              ,o_nCount
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_QueryInvestorParty;

  /*************************************************************************
  $spDesc 新增组织架构
  *************************************************************************/
  PROCEDURE up_InsDepartment
  (
     io_tyDepartment IN OUT TY_DEPARTMENT  --组织架构
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_InsDepartment';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '新增组织架构';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '新增组织架构');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_InsDepartment(' ||
                           io_tyDepartment.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_InsDepartment(
                               io_tyDepartment
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_InsDepartment;

  /*************************************************************************
  $spDesc 修改组织架构
  *************************************************************************/
  PROCEDURE up_UpdDepartment
  (
     io_tyDepartment IN OUT TY_DEPARTMENT  --组织架构
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_UpdDepartment';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '修改组织架构';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '修改组织架构');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_UpdDepartment(' ||
                           io_tyDepartment.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_UpdDepartment(
                               io_tyDepartment
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_UpdDepartment;

  /*************************************************************************
  $spDesc 删除组织架构
  *************************************************************************/
  PROCEDURE up_DelDepartment
  (
     io_tyDepartment IN OUT TY_DEPARTMENT  --组织架构
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_DelDepartment';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '删除组织架构';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '删除组织架构');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_DelDepartment(' ||
                           io_tyDepartment.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_DelDepartment(
                               io_tyDepartment
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_DelDepartment;

  /*************************************************************************
  $spDesc 查询组织架构
  *************************************************************************/
  PROCEDURE up_GetDepartment
  (
     io_tyDepartment IN OUT TY_DEPARTMENT  --组织架构
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_GetDepartment';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '查询组织架构';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '查询组织架构');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_GetDepartment(' ||
                           io_tyDepartment.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_GetDepartment(
                               io_tyDepartment
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_GetDepartment;

  /*************************************************************************
  $spDesc 查询组织架构
  *************************************************************************/
  PROCEDURE up_QryDepartment
  (
     i_tyDepartment IN TY_DEPARTMENT  --查询条件
    ,i_tyPage IN  TY_PAGE  --分页信息
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_curDepartment OUT NOCOPY PKGS_DATATYPE.TYPEREFCURSOR  --查询结果游标
    ,o_nCount OUT PKGS_DATATYPE.STY_COUNT  --记录数
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_QryDepartment';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '查询组织架构';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '查询组织架构');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_QryDepartment(' ||
                           i_tyDepartment.uf_toString()
                      || ',' ||
                           i_tyPage.uf_toString()
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_curDepartment'
                      || ',' ||
                        'o_nCount'
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_QryDepartment(
                               i_tyDepartment
                              ,i_tyPage
                              ,i_chLanguage
                              ,o_curDepartment
                              ,o_nCount
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_QryDepartment;

  /*************************************************************************
  $spDesc 投资者组织架构与属性查询
  *************************************************************************/
  PROCEDURE up_QueryInstdiffDepartParty
  (
     i_tyQueryInstdiffDepartParty IN TY_QUERYINSTDIFFDEPARTPARTY  --查询条件
    ,i_tyPage IN  TY_PAGE  --分页信息
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_curDepartment OUT NOCOPY PKGS_DATATYPE.TYPEREFCURSOR  --查询结果游标
    ,o_nCount OUT PKGS_DATATYPE.STY_COUNT  --记录数
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_QueryInstdiffDepartParty';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '投资者组织架构与属性查询';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '投资者组织架构与属性查询');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_QueryInstdiffDepartParty(' ||
                           i_tyQueryInstdiffDepartParty.uf_toString()
                      || ',' ||
                           i_tyPage.uf_toString()
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_curDepartment'
                      || ',' ||
                        'o_nCount'
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_QueryInstdiffDepartParty(
                               i_tyQueryInstdiffDepartParty
                              ,i_tyPage
                              ,i_chLanguage
                              ,o_curDepartment
                              ,o_nCount
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_QueryInstdiffDepartParty;

  /*************************************************************************
  $spDesc 查询组织架构下对应的投资者
  *************************************************************************/
  PROCEDURE up_QryInvestorDepartMent
  (
     i_tyDepartment IN TY_DEPARTMENT  --查询条件
    ,i_tyPage IN  TY_PAGE  --分页信息
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_curDepartment OUT NOCOPY PKGS_DATATYPE.TYPEREFCURSOR  --查询结果游标
    ,o_nCount OUT PKGS_DATATYPE.STY_COUNT  --记录数
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_QryInvestorDepartMent';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '查询组织架构下对应的投资者';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '查询组织架构下对应的投资者');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_QryInvestorDepartMent(' ||
                           i_tyDepartment.uf_toString()
                      || ',' ||
                           i_tyPage.uf_toString()
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_curDepartment'
                      || ',' ||
                        'o_nCount'
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_QryInvestorDepartMent(
                               i_tyDepartment
                              ,i_tyPage
                              ,i_chLanguage
                              ,o_curDepartment
                              ,o_nCount
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_QryInvestorDepartMent;

  /*************************************************************************
  $spDesc 删除投资者组织架构
  *************************************************************************/
  PROCEDURE up_DelInvestorDepartMent
  (
     io_tyInvestor IN OUT TY_INVESTOR  --投资者
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_DelInvestorDepartMent';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '删除投资者组织架构';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '删除投资者组织架构');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_DelInvestorDepartMent(' ||
                           io_tyInvestor.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_DelInvestorDepartMent(
                               io_tyInvestor
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_DelInvestorDepartMent;

  /*************************************************************************
  $spDesc 修改投资者组织架构
  *************************************************************************/
  PROCEDURE up_UpdInvestorDepartMent
  (
     io_tyInvestor IN OUT TY_INVESTOR  --投资者
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_UpdInvestorDepartMent';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '修改投资者组织架构';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '修改投资者组织架构');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_UpdInvestorDepartMent(' ||
                           io_tyInvestor.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_UpdInvestorDepartMent(
                               io_tyInvestor
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_UpdInvestorDepartMent;

  /*************************************************************************
  $spDesc 新增投资者属性关系
  *************************************************************************/
  PROCEDURE up_InsInvestorPartyMap
  (
     io_tyInvestorPartyMap IN OUT TY_INVESTORPARTYMAP  --投资者属性关系
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_InsInvestorPartyMap';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '新增投资者属性关系';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '新增投资者属性关系');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_InsInvestorPartyMap(' ||
                           io_tyInvestorPartyMap.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_InsInvestorPartyMap(
                               io_tyInvestorPartyMap
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_InsInvestorPartyMap;

  /*************************************************************************
  $spDesc 修改投资者属性关系
  *************************************************************************/
  PROCEDURE up_UpdInvestorPartyMap
  (
     io_tyInvestorPartyMap IN OUT TY_INVESTORPARTYMAP  --投资者属性关系
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_UpdInvestorPartyMap';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '修改投资者属性关系';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '修改投资者属性关系');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_UpdInvestorPartyMap(' ||
                           io_tyInvestorPartyMap.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_UpdInvestorPartyMap(
                               io_tyInvestorPartyMap
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_UpdInvestorPartyMap;

  /*************************************************************************
  $spDesc 删除投资者属性关系
  *************************************************************************/
  PROCEDURE up_DelInvestorPartyMap
  (
     io_InvestorPartyMap IN OUT TY_INVESTORPARTYMAP  --投资者属性关系
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_DelInvestorPartyMap';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '删除投资者属性关系';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '删除投资者属性关系');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_DelInvestorPartyMap(' ||
                           io_InvestorPartyMap.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_DelInvestorPartyMap(
                               io_InvestorPartyMap
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_DelInvestorPartyMap;

  /*************************************************************************
  $spDesc 查询投资者属性关系
  *************************************************************************/
  PROCEDURE up_GetInvestorPartyMap
  (
     io_tyInvestorPartyMap IN OUT TY_INVESTORPARTYMAP  --投资者属性关系
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_GetInvestorPartyMap';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '查询投资者属性关系';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '查询投资者属性关系');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_GetInvestorPartyMap(' ||
                           io_tyInvestorPartyMap.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_GetInvestorPartyMap(
                               io_tyInvestorPartyMap
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_GetInvestorPartyMap;

  /*************************************************************************
  $spDesc 查询投资者属性关系
  *************************************************************************/
  PROCEDURE up_GettInvestorPartyMap
  (
     io_tyInvestorPartyMap IN OUT TY_INVESTORPARTYMAP  --投资者属性关系
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,o_partyID OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --属性ID
    ,o_partyName OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --属性名称
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_GettInvestorPartyMap';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '查询投资者属性关系';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '查询投资者属性关系');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_GettInvestorPartyMap(' ||
                           io_tyInvestorPartyMap.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                        'o_partyID'
                      || ',' ||
                        'o_partyName'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_GettInvestorPartyMap(
                               io_tyInvestorPartyMap
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              ,o_partyID
                              ,o_partyName
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_GettInvestorPartyMap;

  /*************************************************************************
  $spDesc 查询投资者属性关系
  *************************************************************************/
  PROCEDURE up_QryInvestorPartyMap
  (
     i_tyInvestorPartyMap IN TY_INVESTORPARTYMAP  --查询条件
    ,i_tyPage IN  TY_PAGE  --分页信息
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_curInvestorPartyMap OUT NOCOPY PKGS_DATATYPE.TYPEREFCURSOR  --查询结果游标
    ,o_nCount OUT PKGS_DATATYPE.STY_COUNT  --记录数
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_QryInvestorPartyMap';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '查询投资者属性关系';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '查询投资者属性关系');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_QryInvestorPartyMap(' ||
                           i_tyInvestorPartyMap.uf_toString()
                      || ',' ||
                           i_tyPage.uf_toString()
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_curInvestorPartyMap'
                      || ',' ||
                        'o_nCount'
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_QryInvestorPartyMap(
                               i_tyInvestorPartyMap
                              ,i_tyPage
                              ,i_chLanguage
                              ,o_curInvestorPartyMap
                              ,o_nCount
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_QryInvestorPartyMap;

  /*************************************************************************
  $spDesc 新增投资者组和属性关系
  *************************************************************************/
  PROCEDURE up_InsInvestorGroupPartyMap
  (
     io_tyInvestorGroupPartyMap IN OUT TY_INVESTORGROUPPARTYMAP  -- 投资者组和属性关系
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_InsInvestorGroupPartyMap';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '新增投资者组和属性关系 ';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '新增投资者组和属性关系 ');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_InsInvestorGroupPartyMap(' ||
                           io_tyInvestorGroupPartyMap.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_InsInvestorGroupPartyMap(
                               io_tyInvestorGroupPartyMap
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_InsInvestorGroupPartyMap;

  /*************************************************************************
  $spDesc 修改 投资者组和属性关系
  *************************************************************************/
  PROCEDURE up_UpdInvestorGroupPartyMap
  (
     io_tyInvestorGroupPartyMap IN OUT TY_INVESTORGROUPPARTYMAP  -- 投资者组和属性关系
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_UpdInvestorGroupPartyMap';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '修改 投资者组和属性关系 ';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '修改 投资者组和属性关系 ');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_UpdInvestorGroupPartyMap(' ||
                           io_tyInvestorGroupPartyMap.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_UpdInvestorGroupPartyMap(
                               io_tyInvestorGroupPartyMap
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_UpdInvestorGroupPartyMap;

  /*************************************************************************
  $spDesc 删除 投资者组和属性关系
  *************************************************************************/
  PROCEDURE up_DelInvestorGroupPartyMap
  (
     io_InvestorGroupPartyMap IN OUT TY_INVESTORGROUPPARTYMAP  -- 投资者组和属性关系
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_DelInvestorGroupPartyMap';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '删除 投资者组和属性关系 ';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '删除 投资者组和属性关系 ');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_DelInvestorGroupPartyMap(' ||
                           io_InvestorGroupPartyMap.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_DelInvestorGroupPartyMap(
                               io_InvestorGroupPartyMap
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_DelInvestorGroupPartyMap;

  /*************************************************************************
  $spDesc 查询投资者组和属性关系
  *************************************************************************/
  PROCEDURE up_GetInvestorGroupPartyMap
  (
     io_tyInvestorGroupPartyMap IN OUT TY_INVESTORGROUPPARTYMAP  -- 投资者组和属性关系
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_GetInvestorGroupPartyMap';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '查询投资者组和属性关系 ';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '查询投资者组和属性关系 ');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_GetInvestorGroupPartyMap(' ||
                           io_tyInvestorGroupPartyMap.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_GetInvestorGroupPartyMap(
                               io_tyInvestorGroupPartyMap
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_GetInvestorGroupPartyMap;

  /*************************************************************************
  $spDesc 查询投资者组和属性关系
  *************************************************************************/
  PROCEDURE up_QryInvestorGroupPartyMap
  (
     i_tyInvestorGroupPartyMap IN TY_INVESTORGROUPPARTYMAP  --查询条件
    ,i_tyPage IN  TY_PAGE  --分页信息
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_curInvestGrPartyMap OUT NOCOPY PKGS_DATATYPE.TYPEREFCURSOR  --查询结果游标
    ,o_nCount OUT PKGS_DATATYPE.STY_COUNT  --记录数
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_QryInvestorGroupPartyMap';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '查询投资者组和属性关系 ';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '查询投资者组和属性关系 ');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_QryInvestorGroupPartyMap(' ||
                           i_tyInvestorGroupPartyMap.uf_toString()
                      || ',' ||
                           i_tyPage.uf_toString()
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_curInvestGrPartyMap'
                      || ',' ||
                        'o_nCount'
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_QryInvestorGroupPartyMap(
                               i_tyInvestorGroupPartyMap
                              ,i_tyPage
                              ,i_chLanguage
                              ,o_curInvestGrPartyMap
                              ,o_nCount
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_QryInvestorGroupPartyMap;

  /*************************************************************************
  $spDesc 新增投资者组
  *************************************************************************/
  PROCEDURE up_InsInvestorGroup
  (
     io_tyInvestorGroup IN OUT TY_INVESTORGROUP  --投资者组
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_InsInvestorGroup';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '新增投资者组';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '新增投资者组');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_InsInvestorGroup(' ||
                           io_tyInvestorGroup.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_InsInvestorGroup(
                               io_tyInvestorGroup
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_InsInvestorGroup;

  /*************************************************************************
  $spDesc 修改投资者组
  *************************************************************************/
  PROCEDURE up_UpdInvestorGroup
  (
     io_tyInvestorGroup IN OUT TY_INVESTORGROUP  --投资者组
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_UpdInvestorGroup';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '修改投资者组';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '修改投资者组');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_UpdInvestorGroup(' ||
                           io_tyInvestorGroup.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_UpdInvestorGroup(
                               io_tyInvestorGroup
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_UpdInvestorGroup;

  /*************************************************************************
  $spDesc 删除投资者组
  *************************************************************************/
  PROCEDURE up_DelInvestorGroup
  (
     io_InvestorGroup IN OUT TY_INVESTORGROUP  --投资者组
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_DelInvestorGroup';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '删除投资者组';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '删除投资者组');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_DelInvestorGroup(' ||
                           io_InvestorGroup.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_DelInvestorGroup(
                               io_InvestorGroup
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_DelInvestorGroup;

  /*************************************************************************
  $spDesc 查询投资者组
  *************************************************************************/
  PROCEDURE up_GetInvestorGroup
  (
     io_tyInvestorGroup IN OUT TY_INVESTORGROUP  --投资者组
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_GetInvestorGroup';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '查询投资者组';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '查询投资者组');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_GetInvestorGroup(' ||
                           io_tyInvestorGroup.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_GetInvestorGroup(
                               io_tyInvestorGroup
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_GetInvestorGroup;

  /*************************************************************************
  $spDesc 查询投资者组
  *************************************************************************/
  PROCEDURE up_QryInvestorGroup
  (
     i_tyInvestorGroup IN TY_INVESTORGROUP  --查询条件
    ,i_tyPage IN  TY_PAGE  --分页信息
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_curInvestorGroup OUT NOCOPY PKGS_DATATYPE.TYPEREFCURSOR  --查询结果游标
    ,o_nCount OUT PKGS_DATATYPE.STY_COUNT  --记录数
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_QryInvestorGroup';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '查询投资者组';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '查询投资者组');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_QryInvestorGroup(' ||
                           i_tyInvestorGroup.uf_toString()
                      || ',' ||
                           i_tyPage.uf_toString()
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_curInvestorGroup'
                      || ',' ||
                        'o_nCount'
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_QryInvestorGroup(
                               i_tyInvestorGroup
                              ,i_tyPage
                              ,i_chLanguage
                              ,o_curInvestorGroup
                              ,o_nCount
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_QryInvestorGroup;

  /*************************************************************************
  $spDesc 查询投资者投资者组关系
  *************************************************************************/
  PROCEDURE up_QryPermInstGroup
  (
     i_tyInvestor IN TY_INVESTOR  --查询条件
    ,i_tyPage IN  TY_PAGE  --分页信息
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_curInvestor OUT NOCOPY PKGS_DATATYPE.TYPEREFCURSOR  --查询结果游标
    ,o_nCount OUT PKGS_DATATYPE.STY_COUNT  --记录数
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_QryPermInstGroup';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '查询投资者投资者组关系';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '查询投资者投资者组关系');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_QryPermInstGroup(' ||
                           i_tyInvestor.uf_toString()
                      || ',' ||
                           i_tyPage.uf_toString()
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_curInvestor'
                      || ',' ||
                        'o_nCount'
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_QryPermInstGroup(
                               i_tyInvestor
                              ,i_tyPage
                              ,i_chLanguage
                              ,o_curInvestor
                              ,o_nCount
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_QryPermInstGroup;

  /*************************************************************************
  $spDesc 删除投资者和投资者组的关系
  *************************************************************************/
  PROCEDURE up_DelInvestorRelation
  (
     io_tyInvestor IN OUT TY_INVESTOR  --投资者信息
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_DelInvestorRelation';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '删除投资者和投资者组的关系';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '删除投资者和投资者组的关系');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_DelInvestorRelation(' ||
                           io_tyInvestor.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_DelInvestorRelation(
                               io_tyInvestor
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_DelInvestorRelation;

  /*************************************************************************
  $spDesc 更新投资者和投资者组的关系
  *************************************************************************/
  PROCEDURE up_UpdInvestorGroupInfor
  (
     io_tyInvestor IN OUT TY_INVESTOR  --投资者信息
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_UpdInvestorGroupInfor';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '更新投资者和投资者组的关系';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '更新投资者和投资者组的关系');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_UpdInvestorGroupInfor(' ||
                           io_tyInvestor.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_UpdInvestorGroupInfor(
                               io_tyInvestor
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_UpdInvestorGroupInfor;

  /*************************************************************************
  $spDesc 更新投资者和投资者组的关系
  *************************************************************************/
  PROCEDURE up_UpdInvestorGroupRelation
  (
     io_tyInvestor IN OUT TY_INVESTOR  --投资者信息
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_UpdInvestorGroupRelation';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '更新投资者和投资者组的关系';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '更新投资者和投资者组的关系');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_UpdInvestorGroupRelation(' ||
                           io_tyInvestor.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_UpdInvestorGroupRelation(
                               io_tyInvestor
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_UpdInvestorGroupRelation;

  /*************************************************************************
  $spDesc 增加组织架构与属性
  *************************************************************************/
  PROCEDURE up_InsDepartmentPartyMap
  (
     io_tyDepartmentPartyMap IN OUT TY_DEPARTMENTPARTYMAP  --组织架构与属性
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_InsDepartmentPartyMap';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '增加组织架构与属性';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '增加组织架构与属性');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_InsDepartmentPartyMap(' ||
                           io_tyDepartmentPartyMap.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_InsDepartmentPartyMap(
                               io_tyDepartmentPartyMap
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_InsDepartmentPartyMap;

  /*************************************************************************
  $spDesc 修改织框架与属性
  *************************************************************************/
  PROCEDURE up_UpdDepartmentPartyMap
  (
     io_tyDepartmentPartyMap IN OUT TY_DEPARTMENTPARTYMAP  --织框架与属性
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_UpdDepartmentPartyMap';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '修改织框架与属性';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '修改织框架与属性');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_UpdDepartmentPartyMap(' ||
                           io_tyDepartmentPartyMap.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_UpdDepartmentPartyMap(
                               io_tyDepartmentPartyMap
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_UpdDepartmentPartyMap;

  /*************************************************************************
  $spDesc 删除织框架与属性
  *************************************************************************/
  PROCEDURE up_DelDepartmentPartyMap
  (
     io_tyDepartmentPartyMap IN OUT TY_DEPARTMENTPARTYMAP  --织框架与属性
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_DelDepartmentPartyMap';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '删除织框架与属性';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '删除织框架与属性');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_DelDepartmentPartyMap(' ||
                           io_tyDepartmentPartyMap.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_DelDepartmentPartyMap(
                               io_tyDepartmentPartyMap
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_DelDepartmentPartyMap;

  /*************************************************************************
  $spDesc 查询织框架与属性
  *************************************************************************/
  PROCEDURE up_GetDepartmentPartyMap
  (
     io_tyDepartmentPartyMap IN OUT TY_DEPARTMENTPARTYMAP  --织框架与属性
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_GetDepartmentPartyMap';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '查询织框架与属性';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '查询织框架与属性');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_GetDepartmentPartyMap(' ||
                           io_tyDepartmentPartyMap.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_GetDepartmentPartyMap(
                               io_tyDepartmentPartyMap
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_GetDepartmentPartyMap;

  /*************************************************************************
  $spDesc 查询织框架与属性
  *************************************************************************/
  PROCEDURE up_QryDepartmentPartyMap
  (
     i_tyDepartmentPartyMap IN TY_DEPARTMENTPARTYMAP  --查询条件
    ,i_tyPage IN  TY_PAGE  --分页信息
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_curDepartmentPartyMap OUT NOCOPY PKGS_DATATYPE.TYPEREFCURSOR  --查询结果游标
    ,o_nCount OUT PKGS_DATATYPE.STY_COUNT  --记录数
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_QryDepartmentPartyMap';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '查询织框架与属性';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '查询织框架与属性');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_QryDepartmentPartyMap(' ||
                           i_tyDepartmentPartyMap.uf_toString()
                      || ',' ||
                           i_tyPage.uf_toString()
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_curDepartmentPartyMap'
                      || ',' ||
                        'o_nCount'
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_QryDepartmentPartyMap(
                               i_tyDepartmentPartyMap
                              ,i_tyPage
                              ,i_chLanguage
                              ,o_curDepartmentPartyMap
                              ,o_nCount
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_QryDepartmentPartyMap;

  /*************************************************************************
  $spDesc 查询织框架与属性
  *************************************************************************/
  PROCEDURE up_GettDepartmentPartyMap
  (
     io_tyDepartmentPartyMap IN OUT TY_DEPARTMENTPARTYMAP  --织框架与属性
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,o_PartyID OUT NOCOPY TMP_DEPARTMENTPARTYMAP.PARTYID%TYPE  --属性ID
    ,o_PartyName OUT NOCOPY TMP_DEPARTMENTPARTYMAP.PARTYNAME%TYPE  --属性名称
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_GettDepartmentPartyMap';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '查询织框架与属性';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '查询织框架与属性');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_GettDepartmentPartyMap(' ||
                           io_tyDepartmentPartyMap.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                        'o_PartyID'
                      || ',' ||
                        'o_PartyName'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_GettDepartmentPartyMap(
                               io_tyDepartmentPartyMap
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              ,o_PartyID
                              ,o_PartyName
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_GettDepartmentPartyMap;

  /*************************************************************************
  $spDesc 查询组织架构与属性关系信息
  *************************************************************************/
  PROCEDURE up_QueryDepartmentPartyMap
  (
     i_tyQueryDepartmentPartyMap IN TY_QUERYDEPARTMENTPARTYMAP  --查询条件
    ,i_tyPage IN  TY_PAGE  --分页信息
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_curQueryDepartmentPartyMap OUT NOCOPY PKGS_DATATYPE.TYPEREFCURSOR  --查询结果游标
    ,o_nCount OUT PKGS_DATATYPE.STY_COUNT  --记录数
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_QueryDepartmentPartyMap';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '查询组织架构与属性关系信息';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '查询组织架构与属性关系信息');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_QueryDepartmentPartyMap(' ||
                           i_tyQueryDepartmentPartyMap.uf_toString()
                      || ',' ||
                           i_tyPage.uf_toString()
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_curQueryDepartmentPartyMap'
                      || ',' ||
                        'o_nCount'
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_QueryDepartmentPartyMap(
                               i_tyQueryDepartmentPartyMap
                              ,i_tyPage
                              ,i_chLanguage
                              ,o_curQueryDepartmentPartyMap
                              ,o_nCount
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_QueryDepartmentPartyMap;

  /*************************************************************************
  $spDesc 更新组织架构与属性关系设置
  *************************************************************************/
  PROCEDURE up_updatedepartmentPartyMap
  (
     i_BrokerID IN PKGS_DATATYPE.STY_BROKERID  --经纪公司代码
    ,i_PartyString IN  PKGS_DATATYPE.STY_PARTYSTRING  --投资者属性
    ,i_DepartMentId IN  T_DEPARTMENT.DEPARTMENTID%TYPE  --组织架构编号
    ,i_chFunctionCode IN PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_updatedepartmentPartyMap';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '更新组织架构与属性关系设置';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '更新组织架构与属性关系设置');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_updatedepartmentPartyMap(' ||
                           '''' || trim(i_BrokerID) || ''''
                      || ',' ||
                           '''' || trim(i_PartyString) || ''''
                      || ',' ||
                           '''' || trim(i_DepartMentId) || ''''
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_updatedepartmentPartyMap(
                               i_BrokerID
                              ,i_PartyString
                              ,i_DepartMentId
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_updatedepartmentPartyMap;

  /*************************************************************************
  $spDesc 新增市场行情
  *************************************************************************/
  PROCEDURE up_InsMarketData
  (
     i_BrokerID IN PKGS_DATATYPE.STY_BROKERID  --经纪公司代码
    ,io_tyMarketData IN OUT TY_MARKETDATA  --市场行情
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_InsMarketData';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '新增市场行情';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '新增市场行情');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_InsMarketData(' ||
                           '''' || trim(i_BrokerID) || ''''
                      || ',' ||
                           io_tyMarketData.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_InsMarketData(
                               i_BrokerID
                              ,io_tyMarketData
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_InsMarketData;

  /*************************************************************************
  $spDesc 修改市场行情
  *************************************************************************/
  PROCEDURE up_UpdMarketData
  (
     i_BrokerID IN PKGS_DATATYPE.STY_BROKERID  --经纪公司代码
    ,io_tyMarketData IN OUT TY_MARKETDATA  --市场行情
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_UpdMarketData';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '修改市场行情';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '修改市场行情');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_UpdMarketData(' ||
                           '''' || trim(i_BrokerID) || ''''
                      || ',' ||
                           io_tyMarketData.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_UpdMarketData(
                               i_BrokerID
                              ,io_tyMarketData
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_UpdMarketData;

  /*************************************************************************
  $spDesc 查询市场行情
  *************************************************************************/
  PROCEDURE up_QryMarketData
  (
     i_tyMarketData IN TY_MARKETDATA  --查询条件
    ,i_tyPage IN  TY_PAGE  --分页信息
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_curMarketData OUT NOCOPY PKGS_DATATYPE.TYPEREFCURSOR  --查询结果游标
    ,o_nCount OUT PKGS_DATATYPE.STY_COUNT  --记录数
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_QryMarketData';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '查询市场行情';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '查询市场行情');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_QryMarketData(' ||
                           i_tyMarketData.uf_toString()
                      || ',' ||
                           i_tyPage.uf_toString()
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_curMarketData'
                      || ',' ||
                        'o_nCount'
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_QryMarketData(
                               i_tyMarketData
                              ,i_tyPage
                              ,i_chLanguage
                              ,o_curMarketData
                              ,o_nCount
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_QryMarketData;

  /*************************************************************************
  $spDesc 查询市场行情
  *************************************************************************/
  PROCEDURE up_QueryMarketData
  (
     i_BrokerID IN PKGS_DATATYPE.STY_BROKERID  --经纪公司代码
    ,i_tyQueryMarketData IN TY_QUERYMARKETDATA  --查询条件
    ,i_tyPage IN  TY_PAGE  --分页信息
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_curMarketData OUT NOCOPY PKGS_DATATYPE.TYPEREFCURSOR  --查询结果游标
    ,o_nCount OUT PKGS_DATATYPE.STY_COUNT  --记录数
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_QueryMarketData';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '查询市场行情';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '查询市场行情');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_QueryMarketData(' ||
                           '''' || trim(i_BrokerID) || ''''
                      || ',' ||
                           i_tyQueryMarketData.uf_toString()
                      || ',' ||
                           i_tyPage.uf_toString()
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_curMarketData'
                      || ',' ||
                        'o_nCount'
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_QueryMarketData(
                               i_BrokerID
                              ,i_tyQueryMarketData
                              ,i_tyPage
                              ,i_chLanguage
                              ,o_curMarketData
                              ,o_nCount
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_QueryMarketData;

  /*************************************************************************
  $spDesc 新增指数合约
  *************************************************************************/
  PROCEDURE up_InsMDInstrument
  (
     io_tyMDInstrument IN OUT TY_MDINSTRUMENT  --指数合约
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_InsMDInstrument';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '新增指数合约';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '新增指数合约');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_InsMDInstrument(' ||
                           io_tyMDInstrument.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_InsMDInstrument(
                               io_tyMDInstrument
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_InsMDInstrument;

  /*************************************************************************
  $spDesc 删除指数合约
  *************************************************************************/
  PROCEDURE up_DelMDInstrument
  (
     io_tyMDInstrument IN OUT TY_MDINSTRUMENT  --织框架与属性
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_DelMDInstrument';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '删除指数合约';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '删除指数合约');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_DelMDInstrument(' ||
                           io_tyMDInstrument.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_DelMDInstrument(
                               io_tyMDInstrument
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_DelMDInstrument;

  /*************************************************************************
  $spDesc 修改指数合约
  *************************************************************************/
  PROCEDURE up_UpdMDInstrument
  (
     io_tyMDInstrument IN OUT TY_MDINSTRUMENT  --指数合约
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_UpdMDInstrument';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '修改指数合约';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '修改指数合约');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_UpdMDInstrument(' ||
                           io_tyMDInstrument.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_UpdMDInstrument(
                               io_tyMDInstrument
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_UpdMDInstrument;

  /*************************************************************************
  $spDesc 查询指数合约
  *************************************************************************/
  PROCEDURE up_QryMDInstrument
  (
     i_tyMDInstrument IN TY_MDINSTRUMENT  --查询条件
    ,i_tyPage IN  TY_PAGE  --分页信息
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_curMDInstrument OUT NOCOPY PKGS_DATATYPE.TYPEREFCURSOR  --查询结果游标
    ,o_nCount OUT PKGS_DATATYPE.STY_COUNT  --记录数
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_QryMDInstrument';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '查询指数合约';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '查询指数合约');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_QryMDInstrument(' ||
                           i_tyMDInstrument.uf_toString()
                      || ',' ||
                           i_tyPage.uf_toString()
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_curMDInstrument'
                      || ',' ||
                        'o_nCount'
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_QryMDInstrument(
                               i_tyMDInstrument
                              ,i_tyPage
                              ,i_chLanguage
                              ,o_curMDInstrument
                              ,o_nCount
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_QryMDInstrument;

  /*************************************************************************
  $spDesc 新增特殊交易规则产品
  *************************************************************************/
  PROCEDURE up_InsSpecDealProduct
  (
     io_tySpecDealProduct IN OUT TY_SPECDEALPRODUCT  --系统参数
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_InsSpecDealProduct';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '新增特殊交易规则产品 ';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '新增特殊交易规则产品 ');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_InsSpecDealProduct(' ||
                           io_tySpecDealProduct.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_InsSpecDealProduct(
                               io_tySpecDealProduct
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_InsSpecDealProduct;

  /*************************************************************************
  $spDesc 删除特殊交易规则产品
  *************************************************************************/
  PROCEDURE up_DelSpecDealProduct
  (
     io_tySpecDealProduct IN OUT TY_SPECDEALPRODUCT  --系统参数
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_DelSpecDealProduct';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '删除特殊交易规则产品 ';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '删除特殊交易规则产品 ');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_DelSpecDealProduct(' ||
                           io_tySpecDealProduct.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_DelSpecDealProduct(
                               io_tySpecDealProduct
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_DelSpecDealProduct;

  /*************************************************************************
  $spDesc 修改特殊交易规则产品
  *************************************************************************/
  PROCEDURE up_UpdSpecDealProduct
  (
     io_tySpecDealProduct IN OUT TY_SPECDEALPRODUCT  --系统参数
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_UpdSpecDealProduct';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '修改特殊交易规则产品 ';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '修改特殊交易规则产品 ');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_UpdSpecDealProduct(' ||
                           io_tySpecDealProduct.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_UpdSpecDealProduct(
                               io_tySpecDealProduct
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_UpdSpecDealProduct;

  /*************************************************************************
  $spDesc 查询特殊交易规则产品
  *************************************************************************/
  PROCEDURE up_QrySpecDealProduct
  (
     i_tySpecDealProduct IN TY_SPECDEALPRODUCT  --查询条件
    ,i_tyPage IN  TY_PAGE  --分页信息
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_curSpecDealProduct OUT NOCOPY PKGS_DATATYPE.TYPEREFCURSOR  --查询结果游标
    ,o_nCount OUT PKGS_DATATYPE.STY_COUNT  --记录数
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_QrySpecDealProduct';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '查询特殊交易规则产品 ';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '查询特殊交易规则产品 ');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_QrySpecDealProduct(' ||
                           i_tySpecDealProduct.uf_toString()
                      || ',' ||
                           i_tyPage.uf_toString()
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_curSpecDealProduct'
                      || ',' ||
                        'o_nCount'
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_QrySpecDealProduct(
                               i_tySpecDealProduct
                              ,i_tyPage
                              ,i_chLanguage
                              ,o_curSpecDealProduct
                              ,o_nCount
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_QrySpecDealProduct;

  /*************************************************************************
  $spDesc 修改交易日历
  *************************************************************************/
  PROCEDURE up_UpdCalendar
  (
     io_tyCalendar IN OUT TY_CALENDAR  --系统参数
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_UpdCalendar';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '修改交易日历 ';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '修改交易日历 ');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_UpdCalendar(' ||
                           io_tyCalendar.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_UpdCalendar(
                               io_tyCalendar
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_UpdCalendar;

  /*************************************************************************
  $spDesc 查询交易日历
  *************************************************************************/
  PROCEDURE up_QryCalendar
  (
     i_tyCalendar IN TY_CALENDAR  --查询条件
    ,i_tyPage IN  TY_PAGE  --分页信息
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_curCalendar OUT NOCOPY PKGS_DATATYPE.TYPEREFCURSOR  --查询结果游标
    ,o_nCount OUT PKGS_DATATYPE.STY_COUNT  --记录数
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_QryCalendar';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '查询交易日历 ';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '查询交易日历 ');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_QryCalendar(' ||
                           i_tyCalendar.uf_toString()
                      || ',' ||
                           i_tyPage.uf_toString()
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_curCalendar'
                      || ',' ||
                        'o_nCount'
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_QryCalendar(
                               i_tyCalendar
                              ,i_tyPage
                              ,i_chLanguage
                              ,o_curCalendar
                              ,o_nCount
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_QryCalendar;

  /*************************************************************************
  $spDesc 新增产品
  *************************************************************************/
  PROCEDURE up_InsProduct
  (
     io_tyProductAndProductAttr IN OUT TY_PRODUCTANDPRODUCTATTR  --系统参数
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_InsProduct';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '新增产品 ';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '新增产品 ');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_InsProduct(' ||
                           io_tyProductAndProductAttr.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_InsProduct(
                               io_tyProductAndProductAttr
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_InsProduct;

  /*************************************************************************
  $spDesc 删除产品
  *************************************************************************/
  PROCEDURE up_DelProduct
  (
     io_tyProductAndProductAttr IN OUT TY_PRODUCTANDPRODUCTATTR  --系统参数
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_DelProduct';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '删除产品 ';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '删除产品 ');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_DelProduct(' ||
                           io_tyProductAndProductAttr.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_DelProduct(
                               io_tyProductAndProductAttr
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_DelProduct;

  /*************************************************************************
  $spDesc 修改产品
  *************************************************************************/
  PROCEDURE up_UpdProduct
  (
     io_tyProductAndProductAttr IN OUT TY_PRODUCTANDPRODUCTATTR  --系统参数
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_UpdProduct';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '修改产品 ';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '修改产品 ');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_UpdProduct(' ||
                           io_tyProductAndProductAttr.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_UpdProduct(
                               io_tyProductAndProductAttr
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_UpdProduct;

  /*************************************************************************
  $spDesc 查询产品
  *************************************************************************/
  PROCEDURE up_QryProduct
  (
     i_tyProductAndProductAttr IN TY_PRODUCTANDPRODUCTATTR  --查询条件
    ,i_tyPage IN  TY_PAGE  --分页信息
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_curProductAndProductAttr OUT NOCOPY PKGS_DATATYPE.TYPEREFCURSOR  --查询结果游标
    ,o_nCount OUT PKGS_DATATYPE.STY_COUNT  --记录数
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_QryProduct';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '查询产品 ';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '查询产品 ');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_QryProduct(' ||
                           i_tyProductAndProductAttr.uf_toString()
                      || ',' ||
                           i_tyPage.uf_toString()
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_curProductAndProductAttr'
                      || ',' ||
                        'o_nCount'
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_QryProduct(
                               i_tyProductAndProductAttr
                              ,i_tyPage
                              ,i_chLanguage
                              ,o_curProductAndProductAttr
                              ,o_nCount
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_QryProduct;

  /*************************************************************************
  $spDesc 查询产品
  *************************************************************************/
  PROCEDURE up_GetProduct
  (
     io_tyProductAndProductAttr IN OUT TY_PRODUCTANDPRODUCTATTR  --系统参数
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_GetProduct';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '查询产品';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '查询产品');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_GetProduct(' ||
                           io_tyProductAndProductAttr.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_GetProduct(
                               io_tyProductAndProductAttr
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_GetProduct;

  /*************************************************************************
  $spDesc 检测产品或合约是否存在
  *************************************************************************/
  PROCEDURE up_CheckProduct
  (
     i_typroductandproductattr IN TY_PRODUCTANDPRODUCTATTR  --查询条件
    ,i_tyPage IN  TY_PAGE  --分页信息
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_curProductAndProductAttr OUT NOCOPY PKGS_DATATYPE.TYPEREFCURSOR  --查询结果游标
    ,o_nCount OUT PKGS_DATATYPE.STY_COUNT  --记录数
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_CheckProduct';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '检测产品或合约是否存在 ';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '检测产品或合约是否存在 ');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_CheckProduct(' ||
                           i_typroductandproductattr.uf_toString()
                      || ',' ||
                           i_tyPage.uf_toString()
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_curProductAndProductAttr'
                      || ',' ||
                        'o_nCount'
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_CheckProduct(
                               i_typroductandproductattr
                              ,i_tyPage
                              ,i_chLanguage
                              ,o_curProductAndProductAttr
                              ,o_nCount
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_CheckProduct;

  /*************************************************************************
  $spDesc 更新上期所合约信息
  *************************************************************************/
  PROCEDURE up_UpdSHFEInstrumentInfo
  (
     i_InstrumentID IN  PKGS_DATATYPE.STY_INSTRUMENTID  --产品合约代码
    ,i_CheckInstrType IN  PKGS_DATATYPE.STY_ENUMCHAR  --结果类型
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_UpdSHFEInstrumentInfo';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '更新上期所合约信息 ';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '更新上期所合约信息 ');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_UpdSHFEInstrumentInfo(' ||
                           '''' || trim(i_InstrumentID) || ''''
                      || ',' ||
                           '''' || trim(i_CheckInstrType) || ''''
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_UpdSHFEInstrumentInfo(
                               i_InstrumentID
                              ,i_CheckInstrType
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_UpdSHFEInstrumentInfo;

  /*************************************************************************
  $spDesc 查询上期所合约信息
  *************************************************************************/
  PROCEDURE up_QrySHFEInstrumentInfo
  (
     i_CheckInstrType IN  PKGS_DATATYPE.STY_ENUMCHAR  --合约比较类型
    ,i_ExchangeID IN  PKGS_DATATYPE.STY_EXCHANGEID  --交易所代码
    ,i_tyPage IN  TY_PAGE  --分页信息
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_curSHFEInstrumentInfo OUT NOCOPY PKGS_DATATYPE.TYPEREFCURSOR  --查询结果游标
    ,o_nCount OUT PKGS_DATATYPE.STY_COUNT  --记录数
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_QrySHFEInstrumentInfo';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '查询上期所合约信息';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '查询上期所合约信息');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_QrySHFEInstrumentInfo(' ||
                           '''' || trim(i_CheckInstrType) || ''''
                      || ',' ||
                           '''' || trim(i_ExchangeID) || ''''
                      || ',' ||
                           i_tyPage.uf_toString()
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_curSHFEInstrumentInfo'
                      || ',' ||
                        'o_nCount'
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_QrySHFEInstrumentInfo(
                               i_CheckInstrType
                              ,i_ExchangeID
                              ,i_tyPage
                              ,i_chLanguage
                              ,o_curSHFEInstrumentInfo
                              ,o_nCount
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_QrySHFEInstrumentInfo;

  /*************************************************************************
  $spDesc 新增期货合约
  *************************************************************************/
  PROCEDURE up_InsFutInstrument
  (
     io_tyFutInsAndInsTraAttr IN OUT TY_FUTINSANDINSTRAATTR  --系统参数
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_InsFutInstrument';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '新增期货合约';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '新增期货合约');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_InsFutInstrument(' ||
                           io_tyFutInsAndInsTraAttr.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_InsFutInstrument(
                               io_tyFutInsAndInsTraAttr
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_InsFutInstrument;

  /*************************************************************************
  $spDesc 删除期货合约
  *************************************************************************/
  PROCEDURE up_DelFutInstrument
  (
     io_tyFutInsAndInsTraAttr IN OUT TY_FUTINSANDINSTRAATTR  --系统参数
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_DelFutInstrument';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '删除期货合约 ';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '删除期货合约 ');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_DelFutInstrument(' ||
                           io_tyFutInsAndInsTraAttr.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_DelFutInstrument(
                               io_tyFutInsAndInsTraAttr
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_DelFutInstrument;

  /*************************************************************************
  $spDesc 修改期货合约
  *************************************************************************/
  PROCEDURE up_UpdFutInstrument
  (
     io_tyFutInsAndInsTraAttr IN OUT TY_FUTINSANDINSTRAATTR  --系统参数
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_UpdFutInstrument';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '修改期货合约 ';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '修改期货合约 ');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_UpdFutInstrument(' ||
                           io_tyFutInsAndInsTraAttr.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_UpdFutInstrument(
                               io_tyFutInsAndInsTraAttr
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_UpdFutInstrument;

  /*************************************************************************
  $spDesc 查询期货合约
  *************************************************************************/
  PROCEDURE up_QryFutInstrument
  (
     i_tyFutInsAndInsTraAttr IN TY_FUTINSANDINSTRAATTR  --查询条件
    ,i_tyPage IN  TY_PAGE  --分页信息
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_curFutInsAndInsTraAttr OUT NOCOPY PKGS_DATATYPE.TYPEREFCURSOR  --查询结果游标
    ,o_nCount OUT PKGS_DATATYPE.STY_COUNT  --记录数
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_QryFutInstrument';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '查询期货合约 ';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '查询期货合约 ');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_QryFutInstrument(' ||
                           i_tyFutInsAndInsTraAttr.uf_toString()
                      || ',' ||
                           i_tyPage.uf_toString()
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_curFutInsAndInsTraAttr'
                      || ',' ||
                        'o_nCount'
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_QryFutInstrument(
                               i_tyFutInsAndInsTraAttr
                              ,i_tyPage
                              ,i_chLanguage
                              ,o_curFutInsAndInsTraAttr
                              ,o_nCount
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_QryFutInstrument;

  /*************************************************************************
  $spDesc 查询期货合约
  *************************************************************************/
  PROCEDURE up_GetFutInstrument
  (
     io_tyFutInsAndInsTraAttr IN OUT TY_FUTINSANDINSTRAATTR  --系统参数
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_GetFutInstrument';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '查询期货合约';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '查询期货合约');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_GetFutInstrument(' ||
                           io_tyFutInsAndInsTraAttr.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_GetFutInstrument(
                               io_tyFutInsAndInsTraAttr
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_GetFutInstrument;

  /*************************************************************************
  $spDesc 由产品生成合约
  *************************************************************************/
  PROCEDURE up_GenFutInstrumentByProduct
  (
     i_tyProduct IN TY_PRODUCT  --查询条件
    ,i_tyPage IN  TY_PAGE  --分页信息
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_FutInsAndInsTraAttr OUT NOCOPY TY_FUTINSANDINSTRAATTR  --查询结果类型
    ,o_nCount OUT PKGS_DATATYPE.STY_COUNT  --记录数
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_DeliveryYear IN PKGS_DATATYPE.STY_YEAR  --交割年份
    ,i_DeliveryMonth IN PKGS_DATATYPE.STY_MONTH  --交割月份
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_GenFutInstrumentByProduct';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '由产品生成合约';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '由产品生成合约');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_GenFutInstrumentByProduct(' ||
                           i_tyProduct.uf_toString()
                      || ',' ||
                           i_tyPage.uf_toString()
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_FutInsAndInsTraAttr'
                      || ',' ||
                        'o_nCount'
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_DeliveryYear) || ''''
                      || ',' ||
                           '''' || trim(i_DeliveryMonth) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_GenFutInstrumentByProduct(
                               i_tyProduct
                              ,i_tyPage
                              ,i_chLanguage
                              ,o_FutInsAndInsTraAttr
                              ,o_nCount
                              ,o_nRetCode
                              ,o_varRetMsg
                              ,i_DeliveryYear
                              ,i_DeliveryMonth
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_GenFutInstrumentByProduct;

  /*************************************************************************
  $spDesc 新增期权合约
  *************************************************************************/
  PROCEDURE up_InsOptInstrument
  (
     io_tyOptInsAndInsTraAttr IN OUT TY_OPTINSANDINSTRAATTR  --系统参数
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_InsOptInstrument';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '新增期权合约';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '新增期权合约');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_InsOptInstrument(' ||
                           io_tyOptInsAndInsTraAttr.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_InsOptInstrument(
                               io_tyOptInsAndInsTraAttr
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_InsOptInstrument;

  /*************************************************************************
  $spDesc 删除期权合约
  *************************************************************************/
  PROCEDURE up_DelOptInstrument
  (
     io_tyOptInsAndInsTraAttr IN OUT TY_OPTINSANDINSTRAATTR  --系统参数
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_DelOptInstrument';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '删除期权合约 ';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '删除期权合约 ');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_DelOptInstrument(' ||
                           io_tyOptInsAndInsTraAttr.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_DelOptInstrument(
                               io_tyOptInsAndInsTraAttr
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_DelOptInstrument;

  /*************************************************************************
  $spDesc 修改期权合约
  *************************************************************************/
  PROCEDURE up_UpdOptInstrument
  (
     io_tyOptInsAndInsTraAttr IN OUT TY_OPTINSANDINSTRAATTR  --系统参数
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_UpdOptInstrument';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '修改期权合约 ';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '修改期权合约 ');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_UpdOptInstrument(' ||
                           io_tyOptInsAndInsTraAttr.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_UpdOptInstrument(
                               io_tyOptInsAndInsTraAttr
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_UpdOptInstrument;

  /*************************************************************************
  $spDesc 查询期权合约
  *************************************************************************/
  PROCEDURE up_QryOptInstrument
  (
     i_tyOptInsAndInsTraAttr IN TY_OPTINSANDINSTRAATTR  --查询条件
    ,i_tyPage IN  TY_PAGE  --分页信息
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_curOptInsAndInsTraAttr OUT NOCOPY PKGS_DATATYPE.TYPEREFCURSOR  --查询结果游标
    ,o_nCount OUT PKGS_DATATYPE.STY_COUNT  --记录数
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_QryOptInstrument';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '查询期权合约 ';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '查询期权合约 ');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_QryOptInstrument(' ||
                           i_tyOptInsAndInsTraAttr.uf_toString()
                      || ',' ||
                           i_tyPage.uf_toString()
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_curOptInsAndInsTraAttr'
                      || ',' ||
                        'o_nCount'
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_QryOptInstrument(
                               i_tyOptInsAndInsTraAttr
                              ,i_tyPage
                              ,i_chLanguage
                              ,o_curOptInsAndInsTraAttr
                              ,o_nCount
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_QryOptInstrument;

  /*************************************************************************
  $spDesc 查询期权合约
  *************************************************************************/
  PROCEDURE up_GetOptInstrument
  (
     io_tyOptInsAndInsTraAttr IN OUT TY_OPTINSANDINSTRAATTR  --系统参数
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_GetOptInstrument';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '查询期权合约';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '查询期权合约');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_GetOptInstrument(' ||
                           io_tyOptInsAndInsTraAttr.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_GetOptInstrument(
                               io_tyOptInsAndInsTraAttr
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_GetOptInstrument;

  /*************************************************************************
  $spDesc 由产品生成期权合约
  *************************************************************************/
  PROCEDURE up_GenOptInstrumentByProduct
  (
     i_tyProduct IN TY_PRODUCT  --查询条件
    ,i_tyPage IN  TY_PAGE  --分页信息
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,io_OptInsAndInsTraAttr IN OUT TY_OPTINSANDINSTRAATTR  --查询结果类型
    ,o_nCount OUT PKGS_DATATYPE.STY_COUNT  --记录数
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_DeliveryYear IN PKGS_DATATYPE.STY_YEAR  --交割年份
    ,i_DeliveryMonth IN PKGS_DATATYPE.STY_MONTH  --交割月份
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_GenOptInstrumentByProduct';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '由产品生成期权合约';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '由产品生成期权合约');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_GenOptInstrumentByProduct(' ||
                           i_tyProduct.uf_toString()
                      || ',' ||
                           i_tyPage.uf_toString()
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                           io_OptInsAndInsTraAttr.uf_toString()
                      || ',' ||
                        'o_nCount'
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_DeliveryYear) || ''''
                      || ',' ||
                           '''' || trim(i_DeliveryMonth) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_GenOptInstrumentByProduct(
                               i_tyProduct
                              ,i_tyPage
                              ,i_chLanguage
                              ,io_OptInsAndInsTraAttr
                              ,o_nCount
                              ,o_nRetCode
                              ,o_varRetMsg
                              ,i_DeliveryYear
                              ,i_DeliveryMonth
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_GenOptInstrumentByProduct;

  /*************************************************************************
  $spDesc 查询经纪公可提资金算法表
  *************************************************************************/
  PROCEDURE up_QryBrokerWithdrawAlm
  (
     i_tyBrokerWithdrawAlm IN TY_BROKERWITHDRAWALM  --查询条件
    ,i_tyPage IN  TY_PAGE  --分页信息
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_curBrokerWithdrawAlm OUT NOCOPY PKGS_DATATYPE.TYPEREFCURSOR  --查询结果游标
    ,o_nCount OUT PKGS_DATATYPE.STY_COUNT  --记录数
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_QryBrokerWithdrawAlm';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '查询经纪公可提资金算法表';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '查询经纪公可提资金算法表');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_QryBrokerWithdrawAlm(' ||
                           i_tyBrokerWithdrawAlm.uf_toString()
                      || ',' ||
                           i_tyPage.uf_toString()
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_curBrokerWithdrawAlm'
                      || ',' ||
                        'o_nCount'
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_QryBrokerWithdrawAlm(
                               i_tyBrokerWithdrawAlm
                              ,i_tyPage
                              ,i_chLanguage
                              ,o_curBrokerWithdrawAlm
                              ,o_nCount
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_QryBrokerWithdrawAlm;

  /*************************************************************************
  $spDesc 更新经纪公可提资金算法表
  *************************************************************************/
  PROCEDURE up_UpdBrokerWithdrawAlm
  (
     io_tyBrokerWithdrawAlm IN OUT TY_BROKERWITHDRAWALM  --系统参数
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_UpdBrokerWithdrawAlm';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '更新经纪公可提资金算法表 ';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '更新经纪公可提资金算法表 ');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_UpdBrokerWithdrawAlm(' ||
                           io_tyBrokerWithdrawAlm.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_UpdBrokerWithdrawAlm(
                               io_tyBrokerWithdrawAlm
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_UpdBrokerWithdrawAlm;

  /*************************************************************************
  $spDesc 查询经纪公可提资金算法表
  *************************************************************************/
  PROCEDURE up_GetBrokerWithdrawAlm
  (
     io_tyBrokerWithdrawAlm IN OUT TY_BROKERWITHDRAWALM  --系统参数
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_GetBrokerWithdrawAlm';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '查询经纪公可提资金算法表';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '查询经纪公可提资金算法表');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_GetBrokerWithdrawAlm(' ||
                           io_tyBrokerWithdrawAlm.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_GetBrokerWithdrawAlm(
                               io_tyBrokerWithdrawAlm
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_GetBrokerWithdrawAlm;

  /*************************************************************************
  $spDesc 查询经纪公司保证金算法表信息
  *************************************************************************/
  PROCEDURE up_GetBrokerMarginAlm
  (
     io_tyBrokerMarginAlm IN OUT TY_BROKERMARGINALM  --系统参数
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_GetBrokerMarginAlm';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '查询经纪公司保证金算法表信息';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '查询经纪公司保证金算法表信息');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_GetBrokerMarginAlm(' ||
                           io_tyBrokerMarginAlm.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_GetBrokerMarginAlm(
                               io_tyBrokerMarginAlm
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_GetBrokerMarginAlm;

  /*************************************************************************
  $spDesc 修改经纪公司保证金算法表信息
  *************************************************************************/
  PROCEDURE up_UpdBrokerMarginAlm
  (
     io_tyBrokerMarginAlm IN OUT TY_BROKERMARGINALM  --系统参数
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_UpdBrokerMarginAlm';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '修改经纪公司保证金算法表信息 ';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '修改经纪公司保证金算法表信息 ');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_UpdBrokerMarginAlm(' ||
                           io_tyBrokerMarginAlm.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_UpdBrokerMarginAlm(
                               io_tyBrokerMarginAlm
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_UpdBrokerMarginAlm;

  /*************************************************************************
  $spDesc 查询交易所结算参数
  *************************************************************************/
  PROCEDURE up_QryExchangeSettleParam
  (
     i_tyExchangeSettleParam IN TY_EXCHANGESETTLEPARAM  --查询条件交易所结算参数
    ,i_tyPage IN  TY_PAGE  --分页信息
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_curExchangeSettleParam OUT NOCOPY PKGS_DATATYPE.TYPEREFCURSOR  --查询结果游标
    ,o_nCount OUT PKGS_DATATYPE.STY_COUNT  --记录数
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_QryExchangeSettleParam';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '查询交易所结算参数';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '查询交易所结算参数');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_QryExchangeSettleParam(' ||
                           i_tyExchangeSettleParam.uf_toString()
                      || ',' ||
                           i_tyPage.uf_toString()
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_curExchangeSettleParam'
                      || ',' ||
                        'o_nCount'
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_QryExchangeSettleParam(
                               i_tyExchangeSettleParam
                              ,i_tyPage
                              ,i_chLanguage
                              ,o_curExchangeSettleParam
                              ,o_nCount
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_QryExchangeSettleParam;

  /*************************************************************************
  $spDesc 修改交易所结算参数
  *************************************************************************/
  PROCEDURE up_UpdExchangeSettleParam
  (
     io_tyExchangeSettleParam IN OUT TY_EXCHANGESETTLEPARAM  --系统参数
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_UpdExchangeSettleParam';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '修改交易所结算参数 ';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '修改交易所结算参数 ');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_UpdExchangeSettleParam(' ||
                           io_tyExchangeSettleParam.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_UpdExchangeSettleParam(
                               io_tyExchangeSettleParam
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_UpdExchangeSettleParam;

  /*************************************************************************
  $spDesc 新增交易所结算参数
  *************************************************************************/
  PROCEDURE up_InsExchangeSettleParam
  (
     io_tyExchangeSettleParam IN OUT TY_EXCHANGESETTLEPARAM  --交易所结算参数
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_InsExchangeSettleParam';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '新增交易所结算参数 ';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '新增交易所结算参数 ');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_InsExchangeSettleParam(' ||
                           io_tyExchangeSettleParam.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_InsExchangeSettleParam(
                               io_tyExchangeSettleParam
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_InsExchangeSettleParam;

  /*************************************************************************
  $spDesc 删除交易所结算参数
  *************************************************************************/
  PROCEDURE up_DelExchangeSettleParam
  (
     io_tyExchangeSettleParam IN OUT TY_EXCHANGESETTLEPARAM  --交易所结算参数
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_DelExchangeSettleParam';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '删除交易所结算参数  ';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '删除交易所结算参数  ');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_DelExchangeSettleParam(' ||
                           io_tyExchangeSettleParam.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_DelExchangeSettleParam(
                               io_tyExchangeSettleParam
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_DelExchangeSettleParam;

  /*************************************************************************
  $spDesc 查询交易所结算参数
  *************************************************************************/
  PROCEDURE up_GetExchangeSettleParam
  (
     io_tyExchangeSettleParam IN OUT TY_EXCHANGESETTLEPARAM  --交易所结算参数
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_GetExchangeSettleParam';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '查询交易所结算参数 ';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '查询交易所结算参数 ');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_GetExchangeSettleParam(' ||
                           io_tyExchangeSettleParam.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_GetExchangeSettleParam(
                               io_tyExchangeSettleParam
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_GetExchangeSettleParam;

  /*************************************************************************
  $spDesc 查询风险参数设置表
  *************************************************************************/
  PROCEDURE up_GetRiskParameter
  (
     io_tyRiskParameter IN OUT TY_RISKPARAMETER  --系统参数
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_GetRiskParameter';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '查询风险参数设置表';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '查询风险参数设置表');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_GetRiskParameter(' ||
                           io_tyRiskParameter.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_GetRiskParameter(
                               io_tyRiskParameter
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_GetRiskParameter;

  /*************************************************************************
  $spDesc 修改查风险参数设置表
  *************************************************************************/
  PROCEDURE up_UpdRiskParameter
  (
     io_tyRiskParameter IN OUT TY_RISKPARAMETER  --系统参数
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_UpdRiskParameter';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '修改查风险参数设置表 ';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '修改查风险参数设置表 ');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_UpdRiskParameter(' ||
                           io_tyRiskParameter.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_UpdRiskParameter(
                               io_tyRiskParameter
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_UpdRiskParameter;

  /*************************************************************************
  $spDesc 新增保证金存管经纪公司代码会员号对应关系信息
  *************************************************************************/
  PROCEDURE up_InsCSRCPartBroker
  (
     io_tyCSRCPartBroker IN OUT TY_CSRCPARTBROKER  --系统参数
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_InsCSRCPartBroker';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '新增保证金存管经纪公司代码会员号对应关系信息';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '新增保证金存管经纪公司代码会员号对应关系信息');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_InsCSRCPartBroker(' ||
                           io_tyCSRCPartBroker.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_InsCSRCPartBroker(
                               io_tyCSRCPartBroker
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_InsCSRCPartBroker;

  /*************************************************************************
  $spDesc 查询保证金存管经纪公司代码会员号对应关系信息
  *************************************************************************/
  PROCEDURE up_GetCSRCPartBroker
  (
     io_tyCSRCPartBroker IN OUT TY_CSRCPARTBROKER  --系统参数
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_GetCSRCPartBroker';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '查询保证金存管经纪公司代码会员号对应关系信息';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '查询保证金存管经纪公司代码会员号对应关系信息');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_GetCSRCPartBroker(' ||
                           io_tyCSRCPartBroker.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_GetCSRCPartBroker(
                               io_tyCSRCPartBroker
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_GetCSRCPartBroker;

  /*************************************************************************
  $spDesc 查询保证金存管经纪公司代码会员号对应关系信息
  *************************************************************************/
  PROCEDURE up_QryCSRCPartBroker
  (
     i_tyCSRCPartBroker IN TY_CSRCPARTBROKER  --查询条件
    ,i_tyPage IN  TY_PAGE  --分页信息
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_curCSRCPartBroker OUT NOCOPY PKGS_DATATYPE.TYPEREFCURSOR  --查询结果游标
    ,o_nCount OUT PKGS_DATATYPE.STY_COUNT  --记录数
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_QryCSRCPartBroker';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '查询保证金存管经纪公司代码会员号对应关系信息 ';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '查询保证金存管经纪公司代码会员号对应关系信息 ');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_QryCSRCPartBroker(' ||
                           i_tyCSRCPartBroker.uf_toString()
                      || ',' ||
                           i_tyPage.uf_toString()
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_curCSRCPartBroker'
                      || ',' ||
                        'o_nCount'
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_QryCSRCPartBroker(
                               i_tyCSRCPartBroker
                              ,i_tyPage
                              ,i_chLanguage
                              ,o_curCSRCPartBroker
                              ,o_nCount
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_QryCSRCPartBroker;

  /*************************************************************************
  $spDesc 新增云开户经纪公司代码会员号对应关系
  *************************************************************************/
  PROCEDURE up_InsCloudPartBroker
  (
     io_tyCloudPartBroker IN OUT TY_CLOUDPARTBROKER  --云开户经纪公司代码会员号对应关系
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_InsCloudPartBroker';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '新增云开户经纪公司代码会员号对应关系';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '新增云开户经纪公司代码会员号对应关系');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_InsCloudPartBroker(' ||
                           io_tyCloudPartBroker.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_InsCloudPartBroker(
                               io_tyCloudPartBroker
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_InsCloudPartBroker;

  /*************************************************************************
  $spDesc 查询云开户经纪公司代码会员号对应关系
  *************************************************************************/
  PROCEDURE up_GetCloudPartBroker
  (
     io_tyCloudPartBroker IN OUT TY_CLOUDPARTBROKER  --云开户经纪公司代码会员号对应关系
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_GetCloudPartBroker';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '查询云开户经纪公司代码会员号对应关系';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '查询云开户经纪公司代码会员号对应关系');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_GetCloudPartBroker(' ||
                           io_tyCloudPartBroker.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_GetCloudPartBroker(
                               io_tyCloudPartBroker
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_GetCloudPartBroker;

  /*************************************************************************
  $spDesc 新增经纪公司代码和保证金监管统一编码对应关系
  *************************************************************************/
  PROCEDURE up_InsCFMMCPartBroker
  (
     io_tyCFMMCPartBroker IN OUT TY_CFMMCPARTBROKER  --经纪公司代码和保证金监管统一编码对应关系
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_InsCFMMCPartBroker';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '新增经纪公司代码和保证金监管统一编码对应关系';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '新增经纪公司代码和保证金监管统一编码对应关系');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_InsCFMMCPartBroker(' ||
                           io_tyCFMMCPartBroker.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_InsCFMMCPartBroker(
                               io_tyCFMMCPartBroker
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_InsCFMMCPartBroker;

  /*************************************************************************
  $spDesc 修改经纪公司代码和保证金监管统一编码对应关系
  *************************************************************************/
  PROCEDURE up_UpdCFMMCPartBroker
  (
     io_tyCFMMCPartBroker IN OUT TY_CFMMCPARTBROKER  --经纪公司代码和保证金监管统一编码对应关系
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_UpdCFMMCPartBroker';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '修改经纪公司代码和保证金监管统一编码对应关系';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '修改经纪公司代码和保证金监管统一编码对应关系');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_UpdCFMMCPartBroker(' ||
                           io_tyCFMMCPartBroker.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_UpdCFMMCPartBroker(
                               io_tyCFMMCPartBroker
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_UpdCFMMCPartBroker;

  /*************************************************************************
  $spDesc 删除经纪公司代码和保证金监管统一编码对应关系
  *************************************************************************/
  PROCEDURE up_DelCFMMCPartBroker
  (
     io_tyCFMMCPartBroker IN OUT TY_CFMMCPARTBROKER  --经纪公司代码和保证金监管统一编码对应关系
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_DelCFMMCPartBroker';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '删除经纪公司代码和保证金监管统一编码对应关系';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '删除经纪公司代码和保证金监管统一编码对应关系');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_DelCFMMCPartBroker(' ||
                           io_tyCFMMCPartBroker.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_DelCFMMCPartBroker(
                               io_tyCFMMCPartBroker
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_DelCFMMCPartBroker;

  /*************************************************************************
  $spDesc 查询经纪公司代码和保证金监管统一编码对应关系
  *************************************************************************/
  PROCEDURE up_GetCFMMCPartBroker
  (
     io_tyCFMMCPartBroker IN OUT TY_CFMMCPARTBROKER  --经纪公司代码和保证金监管统一编码对应关系
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_GetCFMMCPartBroker';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '查询经纪公司代码和保证金监管统一编码对应关系';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '查询经纪公司代码和保证金监管统一编码对应关系');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_GetCFMMCPartBroker(' ||
                           io_tyCFMMCPartBroker.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_GetCFMMCPartBroker(
                               io_tyCFMMCPartBroker
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_GetCFMMCPartBroker;

  /*************************************************************************
  $spDesc 查询经纪公司代码和保证金监管统一编码对应关系
  *************************************************************************/
  PROCEDURE up_QryCFMMCPartBroker
  (
     i_tyCFMMCPartBroker IN TY_CFMMCPARTBROKER  --查询条件
    ,i_tyPage IN  TY_PAGE  --分页信息
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_curCFMMCPartBroker OUT NOCOPY PKGS_DATATYPE.TYPEREFCURSOR  --查询结果游标
    ,o_nCount OUT PKGS_DATATYPE.STY_COUNT  --记录数
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_QryCFMMCPartBroker';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '查询经纪公司代码和保证金监管统一编码对应关系';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '查询经纪公司代码和保证金监管统一编码对应关系');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_QryCFMMCPartBroker(' ||
                           i_tyCFMMCPartBroker.uf_toString()
                      || ',' ||
                           i_tyPage.uf_toString()
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_curCFMMCPartBroker'
                      || ',' ||
                        'o_nCount'
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_QryCFMMCPartBroker(
                               i_tyCFMMCPartBroker
                              ,i_tyPage
                              ,i_chLanguage
                              ,o_curCFMMCPartBroker
                              ,o_nCount
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_QryCFMMCPartBroker;

  /*************************************************************************
  $spDesc 新增交易系统参数表信息
  *************************************************************************/
  PROCEDURE up_InsTradeParam
  (
     io_tyTradeParam IN OUT TY_TRADEPARAM  --交易系统参数表信息
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_InsTradeParam';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '新增交易系统参数表信息';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '新增交易系统参数表信息');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_InsTradeParam(' ||
                           io_tyTradeParam.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_InsTradeParam(
                               io_tyTradeParam
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_InsTradeParam;

  /*************************************************************************
  $spDesc 修改交易系统参数表信息
  *************************************************************************/
  PROCEDURE up_UpdTradeParam
  (
     io_tyTradeParam IN OUT TY_TRADEPARAM  --交易系统参数表信息
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_UpdTradeParam';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '修改交易系统参数表信息';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '修改交易系统参数表信息');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_UpdTradeParam(' ||
                           io_tyTradeParam.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_UpdTradeParam(
                               io_tyTradeParam
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_UpdTradeParam;

  /*************************************************************************
  $spDesc 删除交易系统参数表信息
  *************************************************************************/
  PROCEDURE up_DelTradeParam
  (
     io_tyTradeParam IN OUT TY_TRADEPARAM  --交易系统参数表信息
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_DelTradeParam';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '删除交易系统参数表信息';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '删除交易系统参数表信息');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_DelTradeParam(' ||
                           io_tyTradeParam.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_DelTradeParam(
                               io_tyTradeParam
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_DelTradeParam;

  /*************************************************************************
  $spDesc 查询交易系统参数表信息
  *************************************************************************/
  PROCEDURE up_GetTradeParam
  (
     io_tyTradeParam IN OUT TY_TRADEPARAM  --交易系统参数表信息
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_GetTradeParam';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '查询交易系统参数表信息';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '查询交易系统参数表信息');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_GetTradeParam(' ||
                           io_tyTradeParam.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_GetTradeParam(
                               io_tyTradeParam
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_GetTradeParam;

  /*************************************************************************
  $spDesc 查询交易系统参数表信息
  *************************************************************************/
  PROCEDURE up_QryTradeParam
  (
     i_tyTradeParam IN TY_TRADEPARAM  --查询条件
    ,i_tyPage IN  TY_PAGE  --分页信息
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_curTradeParam OUT NOCOPY PKGS_DATATYPE.TYPEREFCURSOR  --查询结果游标
    ,o_nCount OUT PKGS_DATATYPE.STY_COUNT  --记录数
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_QryTradeParam';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '查询交易系统参数表信息';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '查询交易系统参数表信息');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_QryTradeParam(' ||
                           i_tyTradeParam.uf_toString()
                      || ',' ||
                           i_tyPage.uf_toString()
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_curTradeParam'
                      || ',' ||
                        'o_nCount'
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_QryTradeParam(
                               i_tyTradeParam
                              ,i_tyPage
                              ,i_chLanguage
                              ,o_curTradeParam
                              ,o_nCount
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_QryTradeParam;

  /*************************************************************************
  $spDesc 新增交易系统参数表信息(SuperParam)
  *************************************************************************/
  PROCEDURE up_InsSuperParam
  (
     io_tyTradeParam IN OUT TY_TRADEPARAM  --交易系统参数表信息
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_InsSuperParam';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '新增交易系统参数表信息(SuperParam)';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '新增交易系统参数表信息(SuperParam)');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_InsSuperParam(' ||
                           io_tyTradeParam.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_InsSuperParam(
                               io_tyTradeParam
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_InsSuperParam;

  /*************************************************************************
  $spDesc 修改交易系统参数表信息(SuperParam)
  *************************************************************************/
  PROCEDURE up_UpdSuperParam
  (
     io_tyTradeParam IN OUT TY_TRADEPARAM  --交易系统参数表信息
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_UpdSuperParam';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '修改交易系统参数表信息(SuperParam)';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '修改交易系统参数表信息(SuperParam)');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_UpdSuperParam(' ||
                           io_tyTradeParam.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_UpdSuperParam(
                               io_tyTradeParam
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_UpdSuperParam;

  /*************************************************************************
  $spDesc 删除交易系统参数表信息(SuperParam)
  *************************************************************************/
  PROCEDURE up_DelSuperParam
  (
     io_tyTradeParam IN OUT TY_TRADEPARAM  --交易系统参数表信息
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_DelSuperParam';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '删除交易系统参数表信息(SuperParam)';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '删除交易系统参数表信息(SuperParam)');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_DelSuperParam(' ||
                           io_tyTradeParam.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_DelSuperParam(
                               io_tyTradeParam
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_DelSuperParam;

  /*************************************************************************
  $spDesc 查询交易系统参数表信息(SuperParam)
  *************************************************************************/
  PROCEDURE up_GetSuperParam
  (
     io_tyTradeParam IN OUT TY_TRADEPARAM  --交易系统参数表信息
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_GetSuperParam';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '查询交易系统参数表信息(SuperParam)';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '查询交易系统参数表信息(SuperParam)');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_GetSuperParam(' ||
                           io_tyTradeParam.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_GetSuperParam(
                               io_tyTradeParam
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_GetSuperParam;

  /*************************************************************************
  $spDesc 查询交易系统参数表信息(SuperParam)
  *************************************************************************/
  PROCEDURE up_QrySuperParam
  (
     i_tyTradeParam IN TY_TRADEPARAM  --查询条件
    ,i_tyPage IN  TY_PAGE  --分页信息
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_curTradeParam OUT NOCOPY PKGS_DATATYPE.TYPEREFCURSOR  --查询结果游标
    ,o_nCount OUT PKGS_DATATYPE.STY_COUNT  --记录数
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_QrySuperParam';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '查询交易系统参数表信息(SuperParam)';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '查询交易系统参数表信息(SuperParam)');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_QrySuperParam(' ||
                           i_tyTradeParam.uf_toString()
                      || ',' ||
                           i_tyPage.uf_toString()
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_curTradeParam'
                      || ',' ||
                        'o_nCount'
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_QrySuperParam(
                               i_tyTradeParam
                              ,i_tyPage
                              ,i_chLanguage
                              ,o_curTradeParam
                              ,o_nCount
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_QrySuperParam;

  /*************************************************************************
  $spDesc 查询业务操作日志信息
  *************************************************************************/
  PROCEDURE up_QrySysOperateLog
  (
     i_tySysOperateLog IN TY_QUERYSYSOPERATELOG  --查询条件
    ,i_tyPage IN  TY_PAGE  --分页信息
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_curSysOperateLog OUT NOCOPY PKGS_DATATYPE.TYPEREFCURSOR  --查询结果游标
    ,o_nCount OUT PKGS_DATATYPE.STY_COUNT  --记录数
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_QrySysOperateLog';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '查询业务操作日志信息';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '查询业务操作日志信息');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_QrySysOperateLog(' ||
                           i_tySysOperateLog.uf_toString()
                      || ',' ||
                           i_tyPage.uf_toString()
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_curSysOperateLog'
                      || ',' ||
                        'o_nCount'
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_QrySysOperateLog(
                               i_tySysOperateLog
                              ,i_tyPage
                              ,i_chLanguage
                              ,o_curSysOperateLog
                              ,o_nCount
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_QrySysOperateLog;

  /*************************************************************************
  $spDesc 增加系统参数
  *************************************************************************/
  PROCEDURE up_InsSysSettleParam
  (
     io_tySysSettleParam IN OUT TY_SYSSETTLEPARAM  --系统参数
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_InsSysSettleParam';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '增加系统参数';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '增加系统参数');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_InsSysSettleParam(' ||
                           io_tySysSettleParam.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_InsSysSettleParam(
                               io_tySysSettleParam
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_InsSysSettleParam;

  /*************************************************************************
  $spDesc 修改系统参数
  *************************************************************************/
  PROCEDURE up_UpdSysSettleParam
  (
     io_tySysSettleParam IN OUT TY_SYSSETTLEPARAM  --系统参数
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_UpdSysSettleParam';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '修改系统参数';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '修改系统参数');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_UpdSysSettleParam(' ||
                           io_tySysSettleParam.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_UpdSysSettleParam(
                               io_tySysSettleParam
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_UpdSysSettleParam;

  /*************************************************************************
  $spDesc 删除系统参数
  *************************************************************************/
  PROCEDURE up_DelSysSettleParam
  (
     io_tySysSettleParam IN OUT TY_SYSSETTLEPARAM  --系统参数
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_DelSysSettleParam';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '删除系统参数';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '删除系统参数');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_DelSysSettleParam(' ||
                           io_tySysSettleParam.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_DelSysSettleParam(
                               io_tySysSettleParam
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_DelSysSettleParam;

  /*************************************************************************
  $spDesc 查询系统参数
  *************************************************************************/
  PROCEDURE up_GetSysSettleParam
  (
     io_tySysSettleParam IN OUT TY_SYSSETTLEPARAM  --系统参数
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_GetSysSettleParam';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '查询系统参数';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '查询系统参数');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_GetSysSettleParam(' ||
                           io_tySysSettleParam.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_GetSysSettleParam(
                               io_tySysSettleParam
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_GetSysSettleParam;

  /*************************************************************************
  $spDesc 查询系统参数
  *************************************************************************/
  PROCEDURE up_QrySysSettleParam
  (
     i_tySysSettleParam IN TY_SYSSETTLEPARAM  --查询条件
    ,i_tyPage IN  TY_PAGE  --分页信息
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_curSysSettleParam OUT NOCOPY PKGS_DATATYPE.TYPEREFCURSOR  --查询结果游标
    ,o_nCount OUT PKGS_DATATYPE.STY_COUNT  --记录数
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_QrySysSettleParam';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '查询系统参数';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '查询系统参数');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_QrySysSettleParam(' ||
                           i_tySysSettleParam.uf_toString()
                      || ',' ||
                           i_tyPage.uf_toString()
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_curSysSettleParam'
                      || ',' ||
                        'o_nCount'
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_QrySysSettleParam(
                               i_tySysSettleParam
                              ,i_tyPage
                              ,i_chLanguage
                              ,o_curSysSettleParam
                              ,o_nCount
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_QrySysSettleParam;

  /*************************************************************************
  $spDesc 查询系统参数
  *************************************************************************/
  PROCEDURE up_QuerySysSettleParam
  (
     i_tySysSettleParam IN TY_SYSSETTLEPARAM  --查询条件
    ,i_tyPage IN  TY_PAGE  --分页信息
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_curSysSettleParam OUT NOCOPY PKGS_DATATYPE.TYPEREFCURSOR  --查询结果游标
    ,o_nCount OUT PKGS_DATATYPE.STY_COUNT  --记录数
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_QuerySysSettleParam';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '查询系统参数';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '查询系统参数');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_QuerySysSettleParam(' ||
                           i_tySysSettleParam.uf_toString()
                      || ',' ||
                           i_tyPage.uf_toString()
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_curSysSettleParam'
                      || ',' ||
                        'o_nCount'
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_QuerySysSettleParam(
                               i_tySysSettleParam
                              ,i_tyPage
                              ,i_chLanguage
                              ,o_curSysSettleParam
                              ,o_nCount
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_QuerySysSettleParam;

  /*************************************************************************
  $spDesc 新增交易席位
  *************************************************************************/
  PROCEDURE up_InsTrader
  (
     io_tyTrader IN OUT TY_TRADER  --交易席位
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_InsTrader';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '新增交易席位';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '新增交易席位');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_InsTrader(' ||
                           io_tyTrader.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_InsTrader(
                               io_tyTrader
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_InsTrader;

  /*************************************************************************
  $spDesc 修改交易席位
  *************************************************************************/
  PROCEDURE up_UpdTrader
  (
     io_tyTrader IN OUT TY_TRADER  --交易席位
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_UpdTrader';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '修改交易席位';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '修改交易席位');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_UpdTrader(' ||
                           io_tyTrader.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_UpdTrader(
                               io_tyTrader
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_UpdTrader;

  /*************************************************************************
  $spDesc 删除交易席位
  *************************************************************************/
  PROCEDURE up_DelTrader
  (
     io_tyTrader IN OUT TY_TRADER  --交易席位
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_DelTrader';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '删除交易席位';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '删除交易席位');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_DelTrader(' ||
                           io_tyTrader.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_DelTrader(
                               io_tyTrader
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_DelTrader;

  /*************************************************************************
  $spDesc 查询交易席位
  *************************************************************************/
  PROCEDURE up_GetTrader
  (
     io_tyTrader IN OUT TY_TRADER  --交易席位
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_GetTrader';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '查询交易席位';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '查询交易席位');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_GetTrader(' ||
                           io_tyTrader.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_GetTrader(
                               io_tyTrader
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_GetTrader;

  /*************************************************************************
  $spDesc 查询交易席位
  *************************************************************************/
  PROCEDURE up_QryTrader
  (
     i_tyTrader IN TY_TRADER  --查询条件
    ,i_tyPage IN  TY_PAGE  --分页信息
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_curTrader OUT NOCOPY PKGS_DATATYPE.TYPEREFCURSOR  --查询结果游标
    ,o_nCount OUT PKGS_DATATYPE.STY_COUNT  --记录数
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_QryTrader';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '查询交易席位';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '查询交易席位');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_QryTrader(' ||
                           i_tyTrader.uf_toString()
                      || ',' ||
                           i_tyPage.uf_toString()
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_curTrader'
                      || ',' ||
                        'o_nCount'
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_QryTrader(
                               i_tyTrader
                              ,i_tyPage
                              ,i_chLanguage
                              ,o_curTrader
                              ,o_nCount
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_QryTrader;

  /*************************************************************************
  $spDesc 新增增量备份数据
  *************************************************************************/
  PROCEDURE up_InsBakFile
  (
     io_tyBakFile IN OUT TY_BAKFILE  --增量备份数据表
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_InsBakFile';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '新增增量备份数据';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '新增增量备份数据');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_InsBakFile(' ||
                           io_tyBakFile.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_InsBakFile(
                               io_tyBakFile
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_InsBakFile;

  /*************************************************************************
  $spDesc 修改增量备份数据
  *************************************************************************/
  PROCEDURE up_UpdBakFile
  (
     io_tyBakFile IN OUT TY_BAKFILE  --增量备份数据表
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_UpdBakFile';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '修改增量备份数据';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '修改增量备份数据');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_UpdBakFile(' ||
                           io_tyBakFile.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_UpdBakFile(
                               io_tyBakFile
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_UpdBakFile;

  /*************************************************************************
  $spDesc 删除增量备份数据
  *************************************************************************/
  PROCEDURE up_DelBakFile
  (
     io_tyBakFile IN OUT TY_BAKFILE  --增量备份数据表
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_DelBakFile';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '删除增量备份数据';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '删除增量备份数据');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_DelBakFile(' ||
                           io_tyBakFile.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_DelBakFile(
                               io_tyBakFile
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_DelBakFile;

  /*************************************************************************
  $spDesc 查询增量备份数据
  *************************************************************************/
  PROCEDURE up_GetBakFile
  (
     io_tyBakFile IN OUT TY_BAKFILE  --增量备份数据表
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_GetBakFile';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '查询增量备份数据';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '查询增量备份数据');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_GetBakFile(' ||
                           io_tyBakFile.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_GetBakFile(
                               io_tyBakFile
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_GetBakFile;

  /*************************************************************************
  $spDesc 查询增量备份数据
  *************************************************************************/
  PROCEDURE up_QryBakFile
  (
     i_tyBakFile IN TY_BAKFILE  --查询条件
    ,i_tyPage IN  TY_PAGE  --分页信息
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_curBakFile OUT NOCOPY PKGS_DATATYPE.TYPEREFCURSOR  --查询结果游标
    ,o_nCount OUT PKGS_DATATYPE.STY_COUNT  --记录数
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_QryBakFile';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '查询增量备份数据';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '查询增量备份数据');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_QryBakFile(' ||
                           i_tyBakFile.uf_toString()
                      || ',' ||
                           i_tyPage.uf_toString()
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_curBakFile'
                      || ',' ||
                        'o_nCount'
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_QryBakFile(
                               i_tyBakFile
                              ,i_tyPage
                              ,i_chLanguage
                              ,o_curBakFile
                              ,o_nCount
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_QryBakFile;

  /*************************************************************************
  $spDesc 经纪公司成交量查询
  *************************************************************************/
  PROCEDURE up_QueryBrokerVolume
  (
     i_tyQueryBrokerVolume IN TY_QUERYBROKERVOLUME  --查询条件
    ,i_tyPage IN  TY_PAGE  --分页信息
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_curBakFile OUT NOCOPY PKGS_DATATYPE.TYPEREFCURSOR  --查询结果游标
    ,o_nCount OUT PKGS_DATATYPE.STY_COUNT  --记录数
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_QueryBrokerVolume';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '经纪公司成交量查询';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '经纪公司成交量查询');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_QueryBrokerVolume(' ||
                           i_tyQueryBrokerVolume.uf_toString()
                      || ',' ||
                           i_tyPage.uf_toString()
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_curBakFile'
                      || ',' ||
                        'o_nCount'
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_QueryBrokerVolume(
                               i_tyQueryBrokerVolume
                              ,i_tyPage
                              ,i_chLanguage
                              ,o_curBakFile
                              ,o_nCount
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_QueryBrokerVolume;

  /*************************************************************************
  $spDesc 新增操作员组织架构关系
  *************************************************************************/
  PROCEDURE up_InsDepartmentUser
  (
     io_tyDepartmentUser IN OUT TY_DEPARTMENTUSER  --操作员组织架构关系
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_InsDepartmentUser';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '新增操作员组织架构关系';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '新增操作员组织架构关系');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_InsDepartmentUser(' ||
                           io_tyDepartmentUser.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_InsDepartmentUser(
                               io_tyDepartmentUser
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_InsDepartmentUser;

  /*************************************************************************
  $spDesc 修改操作员组织架构关系
  *************************************************************************/
  PROCEDURE up_UpdDepartmentUser
  (
     io_tyDepartmentUser IN OUT TY_DEPARTMENTUSER  --操作员组织架构关系
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_UpdDepartmentUser';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '修改操作员组织架构关系';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '修改操作员组织架构关系');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_UpdDepartmentUser(' ||
                           io_tyDepartmentUser.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_UpdDepartmentUser(
                               io_tyDepartmentUser
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_UpdDepartmentUser;

  /*************************************************************************
  $spDesc 删除操作员组织架构关系
  *************************************************************************/
  PROCEDURE up_DelDepartmentUser
  (
     io_tyDepartmentUser IN OUT TY_DEPARTMENTUSER  --操作员组织架构关系
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_DelDepartmentUser';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '删除操作员组织架构关系';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '删除操作员组织架构关系');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_DelDepartmentUser(' ||
                           io_tyDepartmentUser.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_DelDepartmentUser(
                               io_tyDepartmentUser
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_DelDepartmentUser;

  /*************************************************************************
  $spDesc 查询操作员组织架构关系
  *************************************************************************/
  PROCEDURE up_GetDepartmentUser
  (
     io_tyDepartmentUser IN OUT TY_DEPARTMENTUSER  --操作员组织架构关系
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_GetDepartmentUser';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '查询操作员组织架构关系';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '查询操作员组织架构关系');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_GetDepartmentUser(' ||
                           io_tyDepartmentUser.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_GetDepartmentUser(
                               io_tyDepartmentUser
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_GetDepartmentUser;

  /*************************************************************************
  $spDesc 查询操作员组织架构关系
  *************************************************************************/
  PROCEDURE up_QryDepartmentUser
  (
     i_tyDepartmentUser IN TY_DEPARTMENTUSER  --查询条件
    ,i_tyPage IN  TY_PAGE  --分页信息
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_curDepartmentUser OUT NOCOPY PKGS_DATATYPE.TYPEREFCURSOR  --查询结果游标
    ,o_nCount OUT PKGS_DATATYPE.STY_COUNT  --记录数
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_QryDepartmentUser';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '查询操作员组织架构关系';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '查询操作员组织架构关系');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_QryDepartmentUser(' ||
                           i_tyDepartmentUser.uf_toString()
                      || ',' ||
                           i_tyPage.uf_toString()
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_curDepartmentUser'
                      || ',' ||
                        'o_nCount'
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_QryDepartmentUser(
                               i_tyDepartmentUser
                              ,i_tyPage
                              ,i_chLanguage
                              ,o_curDepartmentUser
                              ,o_nCount
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_QryDepartmentUser;

  /*************************************************************************
  $spDesc 新增投资者组织架构
  *************************************************************************/
  PROCEDURE up_CreateDepartmentUser
  (
     io_tyDepartmentUser IN OUT TY_DEPARTMENTUSER  --操作员组织架构关系
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_CreateDepartmentUser';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '新增投资者组织架构';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '新增投资者组织架构');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_CreateDepartmentUser(' ||
                           io_tyDepartmentUser.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_CreateDepartmentUser(
                               io_tyDepartmentUser
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_CreateDepartmentUser;

  /*************************************************************************
  $spDesc 新增投资者组织架构黑名单
  *************************************************************************/
  PROCEDURE up_InsDepartmentUserBlacklist
  (
     io_tytDepartmentuserBlacklist IN OUT TYT_DEPARTMENTUSERBLACKLIST  --操作员组织架构黑名单
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_ErrCursor OUT NOCOPY PKGS_DATATYPE.TYPEREFCURSOR  --返回错误游标
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_InsDepartmentUserBlacklist';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '新增投资者组织架构黑名单';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '新增投资者组织架构黑名单');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_InsDepartmentUserBlacklist(' ||
                           PKGS_Tyt2STRING.uf_Tyt2String(io_tytDepartmentuserBlacklist)
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_ErrCursor'
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_InsDepartmentUserBlacklist(
                               io_tytDepartmentuserBlacklist
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_ErrCursor
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_InsDepartmentUserBlacklist;

  /*************************************************************************
  $spDesc 删除操作员组织架构关系
  *************************************************************************/
  PROCEDURE up_DeleteDepartmentUser
  (
     io_tyDepartmentUser IN OUT TY_DEPARTMENTUSER  --操作员组织架构关系
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_DeleteDepartmentUser';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '删除操作员组织架构关系';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '删除操作员组织架构关系');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_DeleteDepartmentUser(' ||
                           io_tyDepartmentUser.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_DeleteDepartmentUser(
                               io_tyDepartmentUser
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_DeleteDepartmentUser;

  /*************************************************************************
  $spDesc 删除操作员组织架构黑名单
  *************************************************************************/
  PROCEDURE up_DelDepartmentUserBlacklist
  (
     i_tytDepartmentuserBlacklist IN OUT TYT_DEPARTMENTUSERBLACKLIST  --操作员组织架构黑名单
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_DelDepartmentUserBlacklist';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '删除操作员组织架构黑名单';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '删除操作员组织架构黑名单');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_DelDepartmentUserBlacklist(' ||
                           PKGS_Tyt2STRING.uf_Tyt2String(i_tytDepartmentuserBlacklist)
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_DelDepartmentUserBlacklist(
                               i_tytDepartmentuserBlacklist
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_DelDepartmentUserBlacklist;

  /*************************************************************************
  $spDesc 查询投资者组织架构
  *************************************************************************/
  PROCEDURE up_QueryDepartmentUser
  (
     i_tyQueryDepartmentUser IN TY_QUERYDEPARTMENTUSER  --查询条件
    ,i_tyPage IN  TY_PAGE  --分页信息
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_curDepartmentUser OUT NOCOPY PKGS_DATATYPE.TYPEREFCURSOR  --查询结果游标
    ,o_nCount OUT PKGS_DATATYPE.STY_COUNT  --记录数
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_QueryDepartmentUser';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '查询投资者组织架构';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '查询投资者组织架构');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_QueryDepartmentUser(' ||
                           i_tyQueryDepartmentUser.uf_toString()
                      || ',' ||
                           i_tyPage.uf_toString()
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_curDepartmentUser'
                      || ',' ||
                        'o_nCount'
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_QueryDepartmentUser(
                               i_tyQueryDepartmentUser
                              ,i_tyPage
                              ,i_chLanguage
                              ,o_curDepartmentUser
                              ,o_nCount
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_QueryDepartmentUser;

  /*************************************************************************
  $spDesc 查询投资者组织架构黑名单
  *************************************************************************/
  PROCEDURE up_QryDepartmentUserBlacklist
  (
     i_tyQryDepartmentUserBlacklist IN TY_QRYDEPARTMENTUSERBLACKLIST  --查询条件
    ,i_tyPage IN  TY_PAGE  --分页信息
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_curDepartmentUserBlacklist OUT NOCOPY PKGS_DATATYPE.TYPEREFCURSOR  --查询结果游标
    ,o_nCount OUT PKGS_DATATYPE.STY_COUNT  --记录数
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_QryDepartmentUserBlacklist';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '查询投资者组织架构黑名单';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '查询投资者组织架构黑名单');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_QryDepartmentUserBlacklist(' ||
                           i_tyQryDepartmentUserBlacklist.uf_toString()
                      || ',' ||
                           i_tyPage.uf_toString()
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_curDepartmentUserBlacklist'
                      || ',' ||
                        'o_nCount'
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_QryDepartmentUserBlacklist(
                               i_tyQryDepartmentUserBlacklist
                              ,i_tyPage
                              ,i_chLanguage
                              ,o_curDepartmentUserBlacklist
                              ,o_nCount
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_QryDepartmentUserBlacklist;

  /*************************************************************************
  $spDesc 新增操作员查询权限
  *************************************************************************/
  PROCEDURE up_InsBrokerUserQueryRight
  (
     io_tyBrokerUserQueryRight IN OUT TY_BROKERUSERQUERYRIGHT  --操作员查询权限
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_InsBrokerUserQueryRight';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '新增操作员查询权限';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '新增操作员查询权限');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_InsBrokerUserQueryRight(' ||
                           io_tyBrokerUserQueryRight.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_InsBrokerUserQueryRight(
                               io_tyBrokerUserQueryRight
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_InsBrokerUserQueryRight;

  /*************************************************************************
  $spDesc 修改操作员查询权限
  *************************************************************************/
  PROCEDURE up_UpdBrokerUserQueryRight
  (
     io_tyBrokerUserQueryRight IN OUT TY_BROKERUSERQUERYRIGHT  --操作员查询权限
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_UpdBrokerUserQueryRight';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '修改操作员查询权限';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '修改操作员查询权限');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_UpdBrokerUserQueryRight(' ||
                           io_tyBrokerUserQueryRight.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_UpdBrokerUserQueryRight(
                               io_tyBrokerUserQueryRight
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_UpdBrokerUserQueryRight;

  /*************************************************************************
  $spDesc 删除操作员查询权限
  *************************************************************************/
  PROCEDURE up_DelBrokerUserQueryRight
  (
     io_tyBrokerUserQueryRight IN OUT TY_BROKERUSERQUERYRIGHT  --操作员查询权限
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_DelBrokerUserQueryRight';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '删除操作员查询权限';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '删除操作员查询权限');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_DelBrokerUserQueryRight(' ||
                           io_tyBrokerUserQueryRight.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_DelBrokerUserQueryRight(
                               io_tyBrokerUserQueryRight
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_DelBrokerUserQueryRight;

  /*************************************************************************
  $spDesc 查询操作员查询权限
  *************************************************************************/
  PROCEDURE up_GetBrokerUserQueryRight
  (
     io_tyBrokerUserQueryRight IN OUT TY_BROKERUSERQUERYRIGHT  --操作员查询权限
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_GetBrokerUserQueryRight';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '查询操作员查询权限';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '查询操作员查询权限');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_GetBrokerUserQueryRight(' ||
                           io_tyBrokerUserQueryRight.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_GetBrokerUserQueryRight(
                               io_tyBrokerUserQueryRight
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_GetBrokerUserQueryRight;

  /*************************************************************************
  $spDesc 查询操作员查询权限
  *************************************************************************/
  PROCEDURE up_QryBrokerUserQueryRight
  (
     i_tyBrokerUserQueryRight IN TY_BROKERUSERQUERYRIGHT  --查询条件
    ,i_tyPage IN  TY_PAGE  --分页信息
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_curBrokerUserQueryRight OUT NOCOPY PKGS_DATATYPE.TYPEREFCURSOR  --查询结果游标
    ,o_nCount OUT PKGS_DATATYPE.STY_COUNT  --记录数
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_QryBrokerUserQueryRight';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '查询操作员查询权限';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '查询操作员查询权限');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_QryBrokerUserQueryRight(' ||
                           i_tyBrokerUserQueryRight.uf_toString()
                      || ',' ||
                           i_tyPage.uf_toString()
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_curBrokerUserQueryRight'
                      || ',' ||
                        'o_nCount'
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_QryBrokerUserQueryRight(
                               i_tyBrokerUserQueryRight
                              ,i_tyPage
                              ,i_chLanguage
                              ,o_curBrokerUserQueryRight
                              ,o_nCount
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_QryBrokerUserQueryRight;

  /*************************************************************************
  $spDesc 新增境外操作员银期权限
  *************************************************************************/
  PROCEDURE up_InsSeconderyAgentACIDMap
  (
     io_tySeconderyAgentACIDMap IN OUT TY_SECONDERYAGENTACIDMAP  --境外操作员银期权限
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_InsSeconderyAgentACIDMap';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '新增境外操作员银期权限';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '新增境外操作员银期权限');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_InsSeconderyAgentACIDMap(' ||
                           io_tySeconderyAgentACIDMap.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_InsSeconderyAgentACIDMap(
                               io_tySeconderyAgentACIDMap
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_InsSeconderyAgentACIDMap;

  /*************************************************************************
  $spDesc 修改境外操作员银期权限
  *************************************************************************/
  PROCEDURE up_UpdSeconderyAgentACIDMap
  (
     io_tySeconderyAgentACIDMap IN OUT TY_SECONDERYAGENTACIDMAP  --境外操作员银期权限
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_UpdSeconderyAgentACIDMap';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '修改境外操作员银期权限';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '修改境外操作员银期权限');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_UpdSeconderyAgentACIDMap(' ||
                           io_tySeconderyAgentACIDMap.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_UpdSeconderyAgentACIDMap(
                               io_tySeconderyAgentACIDMap
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_UpdSeconderyAgentACIDMap;

  /*************************************************************************
  $spDesc 删除境外操作员银期权限
  *************************************************************************/
  PROCEDURE up_DelSeconderyAgentACIDMap
  (
     io_tySeconderyAgentACIDMap IN OUT TY_SECONDERYAGENTACIDMAP  --境外操作员银期权限
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_DelSeconderyAgentACIDMap';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '删除境外操作员银期权限';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '删除境外操作员银期权限');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_DelSeconderyAgentACIDMap(' ||
                           io_tySeconderyAgentACIDMap.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_DelSeconderyAgentACIDMap(
                               io_tySeconderyAgentACIDMap
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_DelSeconderyAgentACIDMap;

  /*************************************************************************
  $spDesc 查询境外操作员银期权限
  *************************************************************************/
  PROCEDURE up_GetSeconderyAgentACIDMap
  (
     io_tySeconderyAgentACIDMap IN OUT TY_SECONDERYAGENTACIDMAP  --境外操作员银期权限
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_GetSeconderyAgentACIDMap';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '查询境外操作员银期权限';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '查询境外操作员银期权限');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_GetSeconderyAgentACIDMap(' ||
                           io_tySeconderyAgentACIDMap.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_GetSeconderyAgentACIDMap(
                               io_tySeconderyAgentACIDMap
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_GetSeconderyAgentACIDMap;

  /*************************************************************************
  $spDesc 查询境外操作员银期权限
  *************************************************************************/
  PROCEDURE up_QrySeconderyAgentACIDMap
  (
     i_tySeconderyAgentACIDMap IN TY_SECONDERYAGENTACIDMAP  --查询条件
    ,i_tyPage IN  TY_PAGE  --分页信息
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_curSeconderyAgentACIDMap OUT NOCOPY PKGS_DATATYPE.TYPEREFCURSOR  --查询结果游标
    ,o_nCount OUT PKGS_DATATYPE.STY_COUNT  --记录数
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_QrySeconderyAgentACIDMap';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '查询境外操作员银期权限';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '查询境外操作员银期权限');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_QrySeconderyAgentACIDMap(' ||
                           i_tySeconderyAgentACIDMap.uf_toString()
                      || ',' ||
                           i_tyPage.uf_toString()
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_curSeconderyAgentACIDMap'
                      || ',' ||
                        'o_nCount'
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_QrySeconderyAgentACIDMap(
                               i_tySeconderyAgentACIDMap
                              ,i_tyPage
                              ,i_chLanguage
                              ,o_curSeconderyAgentACIDMap
                              ,o_nCount
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_QrySeconderyAgentACIDMap;

  /*************************************************************************
  $spDesc 查询主二席数据同步状态信息
  *************************************************************************/
  PROCEDURE up_QryMainBrokerSyncStatus
  (
     io_TyMainBrokerSyncStatus IN OUT TY_MAINBROKERSYNCSTATUS  --查询主二席数据同步状态信息
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_QryMainBrokerSyncStatus';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '查询主二席数据同步状态信息';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '查询主二席数据同步状态信息');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_QryMainBrokerSyncStatus(' ||
                           io_TyMainBrokerSyncStatus.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_QryMainBrokerSyncStatus(
                               io_TyMainBrokerSyncStatus
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_QryMainBrokerSyncStatus;

  /*************************************************************************
  $spDesc 主席数据同步
  *************************************************************************/
  PROCEDURE up_SynFromMainBroker
  (
     i_BrokerID IN PKGS_DATATYPE.STY_BROKERID  --
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_SynFromMainBroker';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '主席数据同步';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '主席数据同步');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_SynFromMainBroker(' ||
                           '''' || trim(i_BrokerID) || ''''
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_SynFromMainBroker(
                               i_BrokerID
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_SynFromMainBroker;

  /*************************************************************************
  $spDesc 产品/合约组件定制查询
  *************************************************************************/
  PROCEDURE up_QryProductWithIns
  (
     i_ExchangeID IN PKGS_DATATYPE.STY_EXCHANGEID  --查询条件：交易所代码
    ,i_ProductClass IN PKGS_DATATYPE.STY_ENUMCHAR  --查询条件：产品类型
    ,i_ProductLifePhase IN PKGS_DATATYPE.STY_ENUMCHAR  --查询条件：产品生命周期状态
    ,i_tyPage IN  TY_PAGE  --分页信息
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_curResultProAndIns OUT NOCOPY PKGS_DATATYPE.TYPEREFCURSOR  --查询结果游标
    ,o_nCount OUT PKGS_DATATYPE.STY_COUNT  --记录数
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_QryProductWithIns';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '产品/合约组件定制查询';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '产品/合约组件定制查询');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_QryProductWithIns(' ||
                           '''' || trim(i_ExchangeID) || ''''
                      || ',' ||
                           '''' || trim(i_ProductClass) || ''''
                      || ',' ||
                           '''' || trim(i_ProductLifePhase) || ''''
                      || ',' ||
                           i_tyPage.uf_toString()
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_curResultProAndIns'
                      || ',' ||
                        'o_nCount'
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_QryProductWithIns(
                               i_ExchangeID
                              ,i_ProductClass
                              ,i_ProductLifePhase
                              ,i_tyPage
                              ,i_chLanguage
                              ,o_curResultProAndIns
                              ,o_nCount
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_QryProductWithIns;

  /*************************************************************************
  $spDesc 更新合约信息
  *************************************************************************/
  PROCEDURE up_GetLastInstrument
  (
     i_ExchangeID IN PKGS_DATATYPE.STY_EXCHANGEID  --交易所代码
    ,i_InstrumentID IN T_FUTINSTRUMENT.INSTRUMENTID%TYPE  --合约代码
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_GetLastInstrument';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '更新合约信息';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '更新合约信息');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_GetLastInstrument(' ||
                           '''' || trim(i_ExchangeID) || ''''
                      || ',' ||
                           '''' || trim(i_InstrumentID) || ''''
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_GetLastInstrument(
                               i_ExchangeID
                              ,i_InstrumentID
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_GetLastInstrument;

  /*************************************************************************
  $spDesc 交易所合约核对
  *************************************************************************/
  PROCEDURE up_QueryExchInstrumentInfo
  (
     i_ExchangeID IN PKGS_DATATYPE.STY_EXCHANGEID  --查询条件：交易所代码
    ,i_CheckInstrType IN PKGS_DATATYPE.STY_ENUMCHAR  --
    ,i_tyPage IN  TY_PAGE  --分页信息
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_curInstrumentCursor OUT NOCOPY PKGS_DATATYPE.TYPEREFCURSOR  --查询结果游标
    ,o_nCount OUT PKGS_DATATYPE.STY_COUNT  --记录数
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_QueryExchInstrumentInfo';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '交易所合约核对';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '交易所合约核对');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_QueryExchInstrumentInfo(' ||
                           '''' || trim(i_ExchangeID) || ''''
                      || ',' ||
                           '''' || trim(i_CheckInstrType) || ''''
                      || ',' ||
                           i_tyPage.uf_toString()
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_curInstrumentCursor'
                      || ',' ||
                        'o_nCount'
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_QueryExchInstrumentInfo(
                               i_ExchangeID
                              ,i_CheckInstrType
                              ,i_tyPage
                              ,i_chLanguage
                              ,o_curInstrumentCursor
                              ,o_nCount
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_QueryExchInstrumentInfo;

  /*************************************************************************
  $spDesc 新增做市商询价价差参数
  *************************************************************************/
  PROCEDURE up_InsForQuoteParam
  (
     io_tyForQuoteParam IN OUT TY_FORQUOTEPARAM  --做市商询价价差参数
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_InsForQuoteParam';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '新增做市商询价价差参数';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '新增做市商询价价差参数');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_InsForQuoteParam(' ||
                           io_tyForQuoteParam.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_InsForQuoteParam(
                               io_tyForQuoteParam
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_InsForQuoteParam;

  /*************************************************************************
  $spDesc 删除做市商询价价差参数
  *************************************************************************/
  PROCEDURE up_DelForQuoteParam
  (
     io_tyForQuoteParam IN OUT TY_FORQUOTEPARAM  --做市商询价价差参数
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_DelForQuoteParam';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '删除做市商询价价差参数';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '删除做市商询价价差参数');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_DelForQuoteParam(' ||
                           io_tyForQuoteParam.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_DelForQuoteParam(
                               io_tyForQuoteParam
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_DelForQuoteParam;

  /*************************************************************************
  $spDesc 查询做市商询价价差参数
  *************************************************************************/
  PROCEDURE up_QryForQuoteParam
  (
     i_tyForQuoteParam IN TY_FORQUOTEPARAM  --查询条件
    ,i_tyPage IN  TY_PAGE  --分页信息
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_curForQuoteParam OUT NOCOPY PKGS_DATATYPE.TYPEREFCURSOR  --查询结果游标
    ,o_nCount OUT PKGS_DATATYPE.STY_COUNT  --记录数
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_QryForQuoteParam';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '查询做市商询价价差参数';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '查询做市商询价价差参数');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_QryForQuoteParam(' ||
                           i_tyForQuoteParam.uf_toString()
                      || ',' ||
                           i_tyPage.uf_toString()
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_curForQuoteParam'
                      || ',' ||
                        'o_nCount'
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_QryForQuoteParam(
                               i_tyForQuoteParam
                              ,i_tyPage
                              ,i_chLanguage
                              ,o_curForQuoteParam
                              ,o_nCount
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_QryForQuoteParam;

  /*************************************************************************
  $spDesc 新增报单IPMac信任用户设置
  *************************************************************************/
  PROCEDURE up_InsHostingSetBrokerUser
  (
     i_tyHostingSetBrokerUser IN TY_HOSTINGSETBROKERUSER  --报单IPMac信任用户设置
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_InsHostingSetBrokerUser';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '新增报单IPMac信任用户设置';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '新增报单IPMac信任用户设置');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_InsHostingSetBrokerUser(' ||
                           i_tyHostingSetBrokerUser.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_InsHostingSetBrokerUser(
                               i_tyHostingSetBrokerUser
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_InsHostingSetBrokerUser;

  /*************************************************************************
  $spDesc 新增报单IPMac信任用户设置
  *************************************************************************/
  PROCEDURE up_DelHostingSetBrokerUser
  (
     i_tyHostingSetBrokerUser IN TY_HOSTINGSETBROKERUSER  --报单IPMac信任用户设置
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_DelHostingSetBrokerUser';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '新增报单IPMac信任用户设置';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '新增报单IPMac信任用户设置');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_DelHostingSetBrokerUser(' ||
                           i_tyHostingSetBrokerUser.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_DelHostingSetBrokerUser(
                               i_tyHostingSetBrokerUser
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_DelHostingSetBrokerUser;

  /*************************************************************************
  $spDesc 查询报单IPMac信任用户设置
  *************************************************************************/
  PROCEDURE up_QryHostingSetBrokerUser
  (
     i_tyHostingSetBrokerUser IN TY_HOSTINGSETBROKERUSER  --报单IPMac信任用户设置
    ,i_tyPage IN  TY_PAGE  --分页信息
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_HostingSetBrokerUser OUT NOCOPY PKGS_DATATYPE.TYPEREFCURSOR  --查询结果游标
    ,o_nCount OUT PKGS_DATATYPE.STY_COUNT  --记录数
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_QryHostingSetBrokerUser';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '查询报单IPMac信任用户设置';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '查询报单IPMac信任用户设置');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_QryHostingSetBrokerUser(' ||
                           i_tyHostingSetBrokerUser.uf_toString()
                      || ',' ||
                           i_tyPage.uf_toString()
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_HostingSetBrokerUser'
                      || ',' ||
                        'o_nCount'
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_QryHostingSetBrokerUser(
                               i_tyHostingSetBrokerUser
                              ,i_tyPage
                              ,i_chLanguage
                              ,o_HostingSetBrokerUser
                              ,o_nCount
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_QryHostingSetBrokerUser;

  /*************************************************************************
  $spDesc 新增资金账号分组
  *************************************************************************/
  PROCEDURE up_InsAccountGroup
  (
     io_tyAccountGroup IN OUT TY_ACCOUNTGROUP  --资金账号分组
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_InsAccountGroup';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '新增资金账号分组';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '新增资金账号分组');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_InsAccountGroup(' ||
                           io_tyAccountGroup.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_InsAccountGroup(
                               io_tyAccountGroup
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_InsAccountGroup;

  /*************************************************************************
  $spDesc 修改资金账号分组
  *************************************************************************/
  PROCEDURE up_UpdAccountGroup
  (
     io_tyAccountGroup IN OUT TY_ACCOUNTGROUP  --资金账号分组
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_UpdAccountGroup';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '修改资金账号分组';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '修改资金账号分组');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_UpdAccountGroup(' ||
                           io_tyAccountGroup.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_UpdAccountGroup(
                               io_tyAccountGroup
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_UpdAccountGroup;

  /*************************************************************************
  $spDesc 删除资金账号分组
  *************************************************************************/
  PROCEDURE up_DelAccountGroup
  (
     io_tyAccountGroup IN OUT TY_ACCOUNTGROUP  --资金账号分组
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_DelAccountGroup';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '删除资金账号分组';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '删除资金账号分组');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_DelAccountGroup(' ||
                           io_tyAccountGroup.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_DelAccountGroup(
                               io_tyAccountGroup
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_DelAccountGroup;

  /*************************************************************************
  $spDesc 查询资金账号分组
  *************************************************************************/
  PROCEDURE up_QryAccountGroup
  (
     i_tyAccountGroup IN TY_ACCOUNTGROUP  --查询条件
    ,i_tyPage IN  TY_PAGE  --分页信息
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_curAccountGroup OUT NOCOPY PKGS_DATATYPE.TYPEREFCURSOR  --查询结果游标
    ,o_nCount OUT PKGS_DATATYPE.STY_COUNT  --记录数
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_QryAccountGroup';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '查询资金账号分组';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '查询资金账号分组');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_QryAccountGroup(' ||
                           i_tyAccountGroup.uf_toString()
                      || ',' ||
                           i_tyPage.uf_toString()
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_curAccountGroup'
                      || ',' ||
                        'o_nCount'
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_QryAccountGroup(
                               i_tyAccountGroup
                              ,i_tyPage
                              ,i_chLanguage
                              ,o_curAccountGroup
                              ,o_nCount
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_QryAccountGroup;

  /*************************************************************************
  $spDesc 新增资金账号与分组映射
  *************************************************************************/
  PROCEDURE up_InsAccountGroupMap
  (
     io_tyAccountGroupMap IN OUT TY_ACCOUNTGROUPMAP  --资金账号与分组映射
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_InsAccountGroupMap';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '新增资金账号与分组映射';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '新增资金账号与分组映射');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_InsAccountGroupMap(' ||
                           io_tyAccountGroupMap.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_InsAccountGroupMap(
                               io_tyAccountGroupMap
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_InsAccountGroupMap;

  /*************************************************************************
  $spDesc 修改资金账号与分组映射
  *************************************************************************/
  PROCEDURE up_UpdAccountGroupMap
  (
     io_tyAccountGroupMap IN OUT TY_ACCOUNTGROUPMAP  --资金账号与分组映射
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_UpdAccountGroupMap';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '修改资金账号与分组映射';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '修改资金账号与分组映射');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_UpdAccountGroupMap(' ||
                           io_tyAccountGroupMap.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_UpdAccountGroupMap(
                               io_tyAccountGroupMap
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_UpdAccountGroupMap;

  /*************************************************************************
  $spDesc 删除资金账号与分组映射
  *************************************************************************/
  PROCEDURE up_DelAccountGroupMap
  (
     io_tyAccountGroupMap IN OUT TY_ACCOUNTGROUPMAP  --资金账号与分组映射
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_DelAccountGroupMap';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '删除资金账号与分组映射';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '删除资金账号与分组映射');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_DelAccountGroupMap(' ||
                           io_tyAccountGroupMap.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_DelAccountGroupMap(
                               io_tyAccountGroupMap
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_DelAccountGroupMap;

  /*************************************************************************
  $spDesc 查询资金账号与分组映射
  *************************************************************************/
  PROCEDURE up_QryAccountGroupMap
  (
     i_tyAccountGroupMap IN TY_ACCOUNTGROUPMAP  --查询条件
    ,i_tyPage IN  TY_PAGE  --分页信息
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_curAccountGroupMap OUT NOCOPY PKGS_DATATYPE.TYPEREFCURSOR  --查询结果游标
    ,o_nCount OUT PKGS_DATATYPE.STY_COUNT  --记录数
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_QryAccountGroupMap';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '查询资金账号与分组映射';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '查询资金账号与分组映射');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_QryAccountGroupMap(' ||
                           i_tyAccountGroupMap.uf_toString()
                      || ',' ||
                           i_tyPage.uf_toString()
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_curAccountGroupMap'
                      || ',' ||
                        'o_nCount'
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_QryAccountGroupMap(
                               i_tyAccountGroupMap
                              ,i_tyPage
                              ,i_chLanguage
                              ,o_curAccountGroupMap
                              ,o_nCount
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_QryAccountGroupMap;

  /*************************************************************************
  $spDesc 新增程序化交易频繁报撤单设置
  *************************************************************************/
  PROCEDURE up_Insfutureorderfreqparam
  (
     io_tyfutureorderfreqparam IN OUT TY_FUTUREORDERFREQPARAM  --程序化交易频繁报撤单设置
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_Insfutureorderfreqparam';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '新增程序化交易频繁报撤单设置';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '新增程序化交易频繁报撤单设置');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_Insfutureorderfreqparam(' ||
                           io_tyfutureorderfreqparam.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_Insfutureorderfreqparam(
                               io_tyfutureorderfreqparam
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_Insfutureorderfreqparam;

  /*************************************************************************
  $spDesc 修改程序化交易频繁报撤单设置
  *************************************************************************/
  PROCEDURE up_Updfutureorderfreqparam
  (
     io_tyfutureorderfreqparam IN OUT TY_FUTUREORDERFREQPARAM  --程序化交易频繁报撤单设置
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_Updfutureorderfreqparam';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '修改程序化交易频繁报撤单设置';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '修改程序化交易频繁报撤单设置');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_Updfutureorderfreqparam(' ||
                           io_tyfutureorderfreqparam.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_Updfutureorderfreqparam(
                               io_tyfutureorderfreqparam
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_Updfutureorderfreqparam;

  /*************************************************************************
  $spDesc 删除程序化交易频繁报撤单设置
  *************************************************************************/
  PROCEDURE up_Delfutureorderfreqparam
  (
     io_tyfutureorderfreqparam IN OUT TY_FUTUREORDERFREQPARAM  --程序化交易频繁报撤单设置
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_Delfutureorderfreqparam';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '删除程序化交易频繁报撤单设置';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '删除程序化交易频繁报撤单设置');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_Delfutureorderfreqparam(' ||
                           io_tyfutureorderfreqparam.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_Delfutureorderfreqparam(
                               io_tyfutureorderfreqparam
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_Delfutureorderfreqparam;

  /*************************************************************************
  $spDesc 查询程序化交易频繁报撤单设置
  *************************************************************************/
  PROCEDURE up_Qryfutureorderfreqparam
  (
     i_tyfutureorderfreqparam IN TY_FUTUREORDERFREQPARAM  --查询条件
    ,i_tyPage IN  TY_PAGE  --分页信息
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_curAccountGroup OUT NOCOPY PKGS_DATATYPE.TYPEREFCURSOR  --查询结果游标
    ,o_nCount OUT PKGS_DATATYPE.STY_COUNT  --记录数
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_Qryfutureorderfreqparam';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '查询程序化交易频繁报撤单设置';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '查询程序化交易频繁报撤单设置');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_Qryfutureorderfreqparam(' ||
                           i_tyfutureorderfreqparam.uf_toString()
                      || ',' ||
                           i_tyPage.uf_toString()
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_curAccountGroup'
                      || ',' ||
                        'o_nCount'
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_Qryfutureorderfreqparam(
                               i_tyfutureorderfreqparam
                              ,i_tyPage
                              ,i_chLanguage
                              ,o_curAccountGroup
                              ,o_nCount
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_Qryfutureorderfreqparam;

  /*************************************************************************
  $spDesc 新增投资者日内开仓限制
  *************************************************************************/
  PROCEDURE up_InsFutureLimitPosiParam
  (
     io_tyFutureLimitPosiParam IN OUT TY_FUTURELIMITPOSIPARAM  --投资者日内开仓限制
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_InsFutureLimitPosiParam';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '新增投资者日内开仓限制';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '新增投资者日内开仓限制');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_InsFutureLimitPosiParam(' ||
                           io_tyFutureLimitPosiParam.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_InsFutureLimitPosiParam(
                               io_tyFutureLimitPosiParam
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_InsFutureLimitPosiParam;

  /*************************************************************************
  $spDesc 修改投资者日内开仓限制
  *************************************************************************/
  PROCEDURE up_UpdFutureLimitPosiParam
  (
     io_tyFutureLimitPosiParam IN OUT TY_FUTURELIMITPOSIPARAM  --投资者日内开仓限制
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_UpdFutureLimitPosiParam';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '修改投资者日内开仓限制';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '修改投资者日内开仓限制');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_UpdFutureLimitPosiParam(' ||
                           io_tyFutureLimitPosiParam.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_UpdFutureLimitPosiParam(
                               io_tyFutureLimitPosiParam
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_UpdFutureLimitPosiParam;

  /*************************************************************************
  $spDesc 删除投资者日内开仓限制
  *************************************************************************/
  PROCEDURE up_DelFutureLimitPosiParam
  (
     io_tyFutureLimitPosiParam IN OUT TY_FUTURELIMITPOSIPARAM  --投资者日内开仓限制
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_DelFutureLimitPosiParam';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '删除投资者日内开仓限制';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '删除投资者日内开仓限制');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_DelFutureLimitPosiParam(' ||
                           io_tyFutureLimitPosiParam.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_DelFutureLimitPosiParam(
                               io_tyFutureLimitPosiParam
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_DelFutureLimitPosiParam;

  /*************************************************************************
  $spDesc 查询投资者日内开仓限制
  *************************************************************************/
  PROCEDURE up_QryFutureLimitPosiParam
  (
     i_tyFutureLimitPosiParam IN TY_FUTURELIMITPOSIPARAM  --查询条件
    ,i_tyPage IN  TY_PAGE  --分页信息
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_curFutureLimitPosP OUT NOCOPY PKGS_DATATYPE.TYPEREFCURSOR  --查询结果游标
    ,o_nCount OUT PKGS_DATATYPE.STY_COUNT  --记录数
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_QryFutureLimitPosiParam';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '查询投资者日内开仓限制';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '查询投资者日内开仓限制');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_QryFutureLimitPosiParam(' ||
                           i_tyFutureLimitPosiParam.uf_toString()
                      || ',' ||
                           i_tyPage.uf_toString()
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_curFutureLimitPosP'
                      || ',' ||
                        'o_nCount'
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_QryFutureLimitPosiParam(
                               i_tyFutureLimitPosiParam
                              ,i_tyPage
                              ,i_chLanguage
                              ,o_curFutureLimitPosP
                              ,o_nCount
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_QryFutureLimitPosiParam;

  /*************************************************************************
  $spDesc 修改组合合约信息
  *************************************************************************/
  PROCEDURE up_UpdCominstrument
  (
     io_tyCominstrument IN OUT TY_COMINSTRUMENT  --组合合约类型
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_UpdCominstrument';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '修改组合合约信息';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '修改组合合约信息');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_UpdCominstrument(' ||
                           io_tyCominstrument.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_UpdCominstrument(
                               io_tyCominstrument
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_UpdCominstrument;

  /*************************************************************************
  $spDesc 查询组合合约信息
  *************************************************************************/
  PROCEDURE up_QryAllCominstruments
  (
     i_tyCominstrument IN TY_COMINSTRUMENT  --查询条件
    ,i_tyPage IN  TY_PAGE  --分页信息
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_curCominstrument OUT NOCOPY PKGS_DATATYPE.TYPEREFCURSOR  --查询结果游标
    ,o_nCount OUT PKGS_DATATYPE.STY_COUNT  --记录数
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_QryAllCominstruments';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '查询组合合约信息';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '查询组合合约信息');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_QryAllCominstruments(' ||
                           i_tyCominstrument.uf_toString()
                      || ',' ||
                           i_tyPage.uf_toString()
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_curCominstrument'
                      || ',' ||
                        'o_nCount'
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_QryAllCominstruments(
                               i_tyCominstrument
                              ,i_tyPage
                              ,i_chLanguage
                              ,o_curCominstrument
                              ,o_nCount
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_QryAllCominstruments;

  /*************************************************************************
  $spDesc  拷贝组织架构到查询分组
  *************************************************************************/
  PROCEDURE up_CopyDepartmentToQueryGroup
  (
     i_BrokerID IN PKGS_DATATYPE.STY_BROKERID  --经纪公司代码
    ,i_DepartmentID IN T_DEPARTMENT.DEPARTMENTID%TYPE  --组织架构代码
    ,i_InvestorGroupID IN T_QUERYINVESTORGROUP.INVESTORGROUPID%TYPE  --查询分组代码
    ,i_IsSave IN PKGS_DATATYPE.STY_RETCODE  --是否保留目标设置
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_CopyDepartmentToQueryGroup';
    l_varLogic  pkgs_datatype.STY_LOGIC    := ' 拷贝组织架构到查询分组';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', ' 拷贝组织架构到查询分组');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_CopyDepartmentToQueryGroup(' ||
                           '''' || trim(i_BrokerID) || ''''
                      || ',' ||
                           '''' || trim(i_DepartmentID) || ''''
                      || ',' ||
                           '''' || trim(i_InvestorGroupID) || ''''
                      || ',' ||
                           '''' || trim(i_IsSave) || ''''
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_CopyDepartmentToQueryGroup(
                               i_BrokerID
                              ,i_DepartmentID
                              ,i_InvestorGroupID
                              ,i_IsSave
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_CopyDepartmentToQueryGroup;

  /*************************************************************************
  $spDesc 新增中金所汇率
  *************************************************************************/
  PROCEDURE up_InsCffexExchangerate
  (
     io_tyCffexExchangerate IN OUT TY_CFFEXEXCHANGERATE  --中金所汇率
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_InsCffexExchangerate';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '新增中金所汇率';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '新增中金所汇率');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_InsCffexExchangerate(' ||
                           io_tyCffexExchangerate.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_InsCffexExchangerate(
                               io_tyCffexExchangerate
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_InsCffexExchangerate;

  /*************************************************************************
  $spDesc 修改中金所汇率
  *************************************************************************/
  PROCEDURE up_UpdCffexExchangerate
  (
     io_tyCffexExchangerate IN OUT TY_CFFEXEXCHANGERATE  --中金所汇率
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_UpdCffexExchangerate';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '修改中金所汇率';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '修改中金所汇率');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_UpdCffexExchangerate(' ||
                           io_tyCffexExchangerate.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_UpdCffexExchangerate(
                               io_tyCffexExchangerate
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_UpdCffexExchangerate;

  /*************************************************************************
  $spDesc 删除中金所汇率
  *************************************************************************/
  PROCEDURE up_DelCffexExchangerate
  (
     io_tyCffexExchangerate IN OUT TY_CFFEXEXCHANGERATE  --中金所汇率
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_DelCffexExchangerate';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '删除中金所汇率';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '删除中金所汇率');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_DelCffexExchangerate(' ||
                           io_tyCffexExchangerate.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_DelCffexExchangerate(
                               io_tyCffexExchangerate
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_DelCffexExchangerate;

  /*************************************************************************
  $spDesc 查询中金所汇率
  *************************************************************************/
  PROCEDURE up_QueryCffexExchangerate
  (
     i_tyCffexExchangerate IN TY_QUERYCFFEXEXCHANGERATE  --查询条件
    ,i_tyPage IN  TY_PAGE  --分页信息
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_curCffexExchangerate OUT NOCOPY PKGS_DATATYPE.TYPEREFCURSOR  --查询结果游标
    ,o_nCount OUT PKGS_DATATYPE.STY_COUNT  --记录数
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_QueryCffexExchangerate';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '查询中金所汇率';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '查询中金所汇率');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_QueryCffexExchangerate(' ||
                           i_tyCffexExchangerate.uf_toString()
                      || ',' ||
                           i_tyPage.uf_toString()
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_curCffexExchangerate'
                      || ',' ||
                        'o_nCount'
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_QueryCffexExchangerate(
                               i_tyCffexExchangerate
                              ,i_tyPage
                              ,i_chLanguage
                              ,o_curCffexExchangerate
                              ,o_nCount
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_QueryCffexExchangerate;

  /*************************************************************************
  $spDesc 新增投资者禁止行权时间段
  *************************************************************************/
  PROCEDURE up_InsExecForbiddenTime
  (
     io_tyExecForbiddenTime IN OUT TY_EXECFORBIDDENTIME  --投资者禁止行权时间段
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_InsExecForbiddenTime';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '新增投资者禁止行权时间段';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '新增投资者禁止行权时间段');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_InsExecForbiddenTime(' ||
                           io_tyExecForbiddenTime.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_InsExecForbiddenTime(
                               io_tyExecForbiddenTime
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_InsExecForbiddenTime;

  /*************************************************************************
  $spDesc 查询投资者禁止行权时间段
  *************************************************************************/
  PROCEDURE up_QryExecForbiddenTime
  (
     i_tyExecForbiddenTime IN TY_EXECFORBIDDENTIME  --查询条件
    ,i_tyPage IN  TY_PAGE  --分页信息
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_curExecForbiddenTime OUT NOCOPY PKGS_DATATYPE.TYPEREFCURSOR  --查询结果游标
    ,o_nCount OUT PKGS_DATATYPE.STY_COUNT  --记录数
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_QryExecForbiddenTime';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '查询投资者禁止行权时间段';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '查询投资者禁止行权时间段');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_QryExecForbiddenTime(' ||
                           i_tyExecForbiddenTime.uf_toString()
                      || ',' ||
                           i_tyPage.uf_toString()
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_curExecForbiddenTime'
                      || ',' ||
                        'o_nCount'
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_QryExecForbiddenTime(
                               i_tyExecForbiddenTime
                              ,i_tyPage
                              ,i_chLanguage
                              ,o_curExecForbiddenTime
                              ,o_nCount
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_QryExecForbiddenTime;

  /*************************************************************************
  $spDesc 新增中金所期转现交易席位
  *************************************************************************/
  PROCEDURE up_InsCFFEXOTCPartBrokerRec
  (
     io_tytCFFEXOTCPartBrokerRec IN OUT TYT_CFFEXOTCPARTBROKERREC  --中金所期转现交易席位
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_InsCFFEXOTCPartBrokerRec';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '新增中金所期转现交易席位';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '新增中金所期转现交易席位');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_InsCFFEXOTCPartBrokerRec(' ||
                           PKGS_Tyt2STRING.uf_Tyt2String(io_tytCFFEXOTCPartBrokerRec)
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_InsCFFEXOTCPartBrokerRec(
                               io_tytCFFEXOTCPartBrokerRec
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_InsCFFEXOTCPartBrokerRec;

  /*************************************************************************
  $spDesc 修改中金所期转现交易席位
  *************************************************************************/
  PROCEDURE up_UpdCFFEXOTCPartBrokerRec
  (
     io_CFFEXOTCPartBrokerRec IN OUT TY_CFFEXOTCPARTBROKERREC  --中金所期转现交易席位
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_UpdCFFEXOTCPartBrokerRec';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '修改中金所期转现交易席位';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '修改中金所期转现交易席位');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_UpdCFFEXOTCPartBrokerRec(' ||
                           io_CFFEXOTCPartBrokerRec.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_UpdCFFEXOTCPartBrokerRec(
                               io_CFFEXOTCPartBrokerRec
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_UpdCFFEXOTCPartBrokerRec;

  /*************************************************************************
  $spDesc 删除中金所期转现交易席位
  *************************************************************************/
  PROCEDURE up_DelCFFEXOTCPartBrokerRec
  (
     io_CFFEXOTCPartBrokerRec IN OUT TY_CFFEXOTCPARTBROKERREC  --中金所期转现交易席位
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_DelCFFEXOTCPartBrokerRec';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '删除中金所期转现交易席位';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '删除中金所期转现交易席位');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_DelCFFEXOTCPartBrokerRec(' ||
                           io_CFFEXOTCPartBrokerRec.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_DelCFFEXOTCPartBrokerRec(
                               io_CFFEXOTCPartBrokerRec
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_DelCFFEXOTCPartBrokerRec;

  /*************************************************************************
  $spDesc 查询中金所期转现交易席位
  *************************************************************************/
  PROCEDURE up_GetCFFEXOTCPartBrokerRec
  (
     io_CFFEXOTCPartBrokerRec IN OUT TY_CFFEXOTCPARTBROKERREC  --中金所期转现交易席位
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_GetCFFEXOTCPartBrokerRec';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '查询中金所期转现交易席位';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '查询中金所期转现交易席位');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_GetCFFEXOTCPartBrokerRec(' ||
                           io_CFFEXOTCPartBrokerRec.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_GetCFFEXOTCPartBrokerRec(
                               io_CFFEXOTCPartBrokerRec
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_GetCFFEXOTCPartBrokerRec;

  /*************************************************************************
  $spDesc 查询中金所期转现交易席位
  *************************************************************************/
  PROCEDURE up_QryCFFEXOTCPartBrokerRec
  (
     i_CFFEXOTCPartBrokerRec IN TY_CFFEXOTCPARTBROKERREC  --查询条件
    ,i_tyPage IN  TY_PAGE  --分页信息
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_curCFFEXOTCPartBrokerRec OUT NOCOPY PKGS_DATATYPE.TYPEREFCURSOR  --查询结果游标
    ,o_nCount OUT PKGS_DATATYPE.STY_COUNT  --记录数
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_QryCFFEXOTCPartBrokerRec';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '查询中金所期转现交易席位';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '查询中金所期转现交易席位');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_QryCFFEXOTCPartBrokerRec(' ||
                           i_CFFEXOTCPartBrokerRec.uf_toString()
                      || ',' ||
                           i_tyPage.uf_toString()
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_curCFFEXOTCPartBrokerRec'
                      || ',' ||
                        'o_nCount'
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_QryCFFEXOTCPartBrokerRec(
                               i_CFFEXOTCPartBrokerRec
                              ,i_tyPage
                              ,i_chLanguage
                              ,o_curCFFEXOTCPartBrokerRec
                              ,o_nCount
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_QryCFFEXOTCPartBrokerRec;

  /*************************************************************************
  $spDesc 查询中金所期转现可选择的交易席位
  *************************************************************************/
  PROCEDURE up_QryCFFEXOTCPartBroker4Sel
  (
     i_CFFEXOTCPartBrokerRec IN TY_CFFEXOTCPARTBROKERREC  --查询条件
    ,i_tyPage IN  TY_PAGE  --分页信息
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_curCFFEXOTCPartBroker4Sel OUT NOCOPY PKGS_DATATYPE.TYPEREFCURSOR  --查询结果游标
    ,o_nCount OUT PKGS_DATATYPE.STY_COUNT  --记录数
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_QryCFFEXOTCPartBroker4Sel';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '查询中金所期转现可选择的交易席位';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '查询中金所期转现可选择的交易席位');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_QryCFFEXOTCPartBroker4Sel(' ||
                           i_CFFEXOTCPartBrokerRec.uf_toString()
                      || ',' ||
                           i_tyPage.uf_toString()
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_curCFFEXOTCPartBroker4Sel'
                      || ',' ||
                        'o_nCount'
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_QryCFFEXOTCPartBroker4Sel(
                               i_CFFEXOTCPartBrokerRec
                              ,i_tyPage
                              ,i_chLanguage
                              ,o_curCFFEXOTCPartBroker4Sel
                              ,o_nCount
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_QryCFFEXOTCPartBroker4Sel;

  /*************************************************************************
  $spDesc 新增组合产品
  *************************************************************************/
  PROCEDURE up_InsComProduct
  (
     io_tyComProduct IN OUT TY_COMPRODUCT  --组合产品
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_InsComProduct';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '新增组合产品 ';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '新增组合产品 ');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_InsComProduct(' ||
                           io_tyComProduct.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_InsComProduct(
                               io_tyComProduct
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_InsComProduct;

  /*************************************************************************
  $spDesc 删除组合产品
  *************************************************************************/
  PROCEDURE up_DelComProduct
  (
     io_tyComProduct IN OUT TY_COMPRODUCT  --组合产品
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_DelComProduct';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '删除组合产品 ';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '删除组合产品 ');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_DelComProduct(' ||
                           io_tyComProduct.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_DelComProduct(
                               io_tyComProduct
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_DelComProduct;

  /*************************************************************************
  $spDesc 修改组合产品
  *************************************************************************/
  PROCEDURE up_UpdComProduct
  (
     io_tyComProduct IN OUT TY_COMPRODUCT  --组合产品
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_UpdComProduct';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '修改组合产品 ';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '修改组合产品 ');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_UpdComProduct(' ||
                           io_tyComProduct.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_UpdComProduct(
                               io_tyComProduct
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_UpdComProduct;

  /*************************************************************************
  $spDesc 查询组合产品
  *************************************************************************/
  PROCEDURE up_QryComProduct
  (
     i_tyComProduct IN TY_COMPRODUCT  --组合产品
    ,i_tyPage IN  TY_PAGE  --分页信息
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_curComProduct OUT NOCOPY PKGS_DATATYPE.TYPEREFCURSOR  --查询结果游标
    ,o_nCount OUT PKGS_DATATYPE.STY_COUNT  --记录数
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_QryComProduct';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '查询组合产品 ';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '查询组合产品 ');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_QryComProduct(' ||
                           i_tyComProduct.uf_toString()
                      || ',' ||
                           i_tyPage.uf_toString()
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_curComProduct'
                      || ',' ||
                        'o_nCount'
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_QryComProduct(
                               i_tyComProduct
                              ,i_tyPage
                              ,i_chLanguage
                              ,o_curComProduct
                              ,o_nCount
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_QryComProduct;

  /*************************************************************************
  $spDesc 查询组合产品
  *************************************************************************/
  PROCEDURE up_GetComProduct
  (
     io_tyComProduct IN OUT TY_COMPRODUCT  --系统参数
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_GetComProduct';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '查询组合产品';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '查询组合产品');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_GetComProduct(' ||
                           io_tyComProduct.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_GetComProduct(
                               io_tyComProduct
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_GetComProduct;

  /*************************************************************************
  $spDesc 批量更新投资者和投资者组的关系
  *************************************************************************/
  PROCEDURE up_BatsUpdInvestorRelation
  (
     io_tytInvestor IN OUT TYT_INVESTOR  --投资者列表
    ,io_tyInvestor IN OUT TY_INVESTOR  --投资者组信息
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_BatsUpdInvestorRelation';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '批量更新投资者和投资者组的关系';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '批量更新投资者和投资者组的关系');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_BatsUpdInvestorRelation(' ||
                           PKGS_Tyt2STRING.uf_Tyt2String(io_tytInvestor)
                      || ',' ||
                           io_tyInvestor.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_BatsUpdInvestorRelation(
                               io_tytInvestor
                              ,io_tyInvestor
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_BatsUpdInvestorRelation;

  /*************************************************************************
  $spDesc 查询期货新合约自动生成设置
  *************************************************************************/
  PROCEDURE up_QryFutInsAutoAdd
  (
     i_tyFutInsAutoAdd IN TY_FUTINSAUTOADD  --查询条件
    ,i_tyPage IN TY_PAGE  --分页信息
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_curFutInsAutoAdd OUT NOCOPY PKGS_DATATYPE.TYPEREFCURSOR  --查询结果游标
    ,o_nCount OUT PKGS_DATATYPE.STY_COUNT  --记录数
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_QryFutInsAutoAdd';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '查询期货新合约自动生成设置';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '查询期货新合约自动生成设置');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_QryFutInsAutoAdd(' ||
                           i_tyFutInsAutoAdd.uf_toString()
                      || ',' ||
                           i_tyPage.uf_toString()
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_curFutInsAutoAdd'
                      || ',' ||
                        'o_nCount'
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_QryFutInsAutoAdd(
                               i_tyFutInsAutoAdd
                              ,i_tyPage
                              ,i_chLanguage
                              ,o_curFutInsAutoAdd
                              ,o_nCount
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_QryFutInsAutoAdd;

  /*************************************************************************
  $spDesc 新增期货新合约自动生成设置
  *************************************************************************/
  PROCEDURE up_InsFutInsAutoAdd
  (
     io_tyFutInsAutoAdd IN OUT TY_FUTINSAUTOADD  --新合约自动生成设置
    ,i_chFunctionCode IN PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_InsFutInsAutoAdd';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '新增期货新合约自动生成设置';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '新增期货新合约自动生成设置');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_InsFutInsAutoAdd(' ||
                           io_tyFutInsAutoAdd.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_InsFutInsAutoAdd(
                               io_tyFutInsAutoAdd
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_InsFutInsAutoAdd;

  /*************************************************************************
  $spDesc 修改期货新合约自动生成设置
  *************************************************************************/
  PROCEDURE up_UpdFutInsAutoAdd
  (
     io_tyFutInsAutoAdd IN OUT TY_FUTINSAUTOADD  --新合约自动生成设置
    ,i_chFunctionCode IN PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_UpdFutInsAutoAdd';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '修改期货新合约自动生成设置';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '修改期货新合约自动生成设置');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_UpdFutInsAutoAdd(' ||
                           io_tyFutInsAutoAdd.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_UpdFutInsAutoAdd(
                               io_tyFutInsAutoAdd
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_UpdFutInsAutoAdd;

  /*************************************************************************
  $spDesc 删除期货新合约自动生成设置
  *************************************************************************/
  PROCEDURE up_DelFutInsAutoAdd
  (
     io_tyFutInsAutoAdd IN OUT TY_FUTINSAUTOADD  --新合约自动生成设置
    ,i_chFunctionCode IN PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_DelFutInsAutoAdd';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '删除期货新合约自动生成设置';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '删除期货新合约自动生成设置');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_DelFutInsAutoAdd(' ||
                           io_tyFutInsAutoAdd.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_DelFutInsAutoAdd(
                               io_tyFutInsAutoAdd
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_DelFutInsAutoAdd;

  /*************************************************************************
  $spDesc 查询询价时间限制参数
  *************************************************************************/
  PROCEDURE up_QryForQuoteFreqLimit
  (
     i_tyForQuoteFreqLimit IN TY_FORQUOTEFREQLIMIT  --查询条件
    ,i_tyPage IN TY_PAGE  --分页信息
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_curForQuoteFreqLimit OUT NOCOPY PKGS_DATATYPE.TYPEREFCURSOR  --查询结果游标
    ,o_nCount OUT PKGS_DATATYPE.STY_COUNT  --记录数
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_QryForQuoteFreqLimit';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '查询询价时间限制参数';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '查询询价时间限制参数');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_QryForQuoteFreqLimit(' ||
                           i_tyForQuoteFreqLimit.uf_toString()
                      || ',' ||
                           i_tyPage.uf_toString()
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_curForQuoteFreqLimit'
                      || ',' ||
                        'o_nCount'
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_QryForQuoteFreqLimit(
                               i_tyForQuoteFreqLimit
                              ,i_tyPage
                              ,i_chLanguage
                              ,o_curForQuoteFreqLimit
                              ,o_nCount
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_QryForQuoteFreqLimit;

  /*************************************************************************
  $spDesc 修改询价时间限制参数
  *************************************************************************/
  PROCEDURE up_UpdForQuoteFreqLimit
  (
     io_tytForQuoteFreqLimit IN OUT TYT_FORQUOTEFREQLIMIT  --询价时间限制参数
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_UpdForQuoteFreqLimit';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '修改询价时间限制参数';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '修改询价时间限制参数');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_UpdForQuoteFreqLimit(' ||
                           PKGS_Tyt2STRING.uf_Tyt2String(io_tytForQuoteFreqLimit)
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_UpdForQuoteFreqLimit(
                               io_tytForQuoteFreqLimit
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_UpdForQuoteFreqLimit;

  /*************************************************************************
  $spDesc 查询产品组和产品信息设置
  *************************************************************************/
  PROCEDURE up_QrySettleProductGroupResult
  (
     i_tySettleProductGroupRst IN TY_SETTLEPRODUCTGROUPRESULT  --查询条件
    ,i_tyPage IN TY_PAGE  --分页信息
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_curSettleProductGroupRst OUT NOCOPY PKGS_DATATYPE.TYPEREFCURSOR  --查询结果游标
    ,o_nCount OUT PKGS_DATATYPE.STY_COUNT  --记录数
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_QrySettleProductGroupResult';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '查询产品组和产品信息设置';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '查询产品组和产品信息设置');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_QrySettleProductGroupResult(' ||
                           i_tySettleProductGroupRst.uf_toString()
                      || ',' ||
                           i_tyPage.uf_toString()
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_curSettleProductGroupRst'
                      || ',' ||
                        'o_nCount'
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_QrySettleProductGroupResult(
                               i_tySettleProductGroupRst
                              ,i_tyPage
                              ,i_chLanguage
                              ,o_curSettleProductGroupRst
                              ,o_nCount
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_QrySettleProductGroupResult;

  /*************************************************************************
  $spDesc 新增产品组和产品信息设置
  *************************************************************************/
  PROCEDURE up_InsSettleProductGroupResult
  (
     i_tySettleProductGroupRst IN OUT TY_SETTLEPRODUCTGROUPRESULT  --产品组和产品信息设置
    ,i_chFunctionCode IN PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_InsSettleProductGroupResult';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '新增产品组和产品信息设置';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '新增产品组和产品信息设置');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_InsSettleProductGroupResult(' ||
                           i_tySettleProductGroupRst.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_InsSettleProductGroupResult(
                               i_tySettleProductGroupRst
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_InsSettleProductGroupResult;

  /*************************************************************************
  $spDesc 修改产品组和产品信息设置
  *************************************************************************/
  PROCEDURE up_UpdSettleProductGroupResult
  (
     i_tySettleProductGroupRst IN OUT TY_SETTLEPRODUCTGROUPRESULT  --产品组和产品信息设置
    ,i_chFunctionCode IN PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_UpdSettleProductGroupResult';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '修改产品组和产品信息设置';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '修改产品组和产品信息设置');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_UpdSettleProductGroupResult(' ||
                           i_tySettleProductGroupRst.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_UpdSettleProductGroupResult(
                               i_tySettleProductGroupRst
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_UpdSettleProductGroupResult;

  /*************************************************************************
  $spDesc 删除产品组和产品信息设置
  *************************************************************************/
  PROCEDURE up_DelSettleProductGroupResult
  (
     i_tySettleProductGroupRst IN OUT TY_SETTLEPRODUCTGROUPRESULT  --产品组和产品信息设置
    ,i_chFunctionCode IN PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_DelSettleProductGroupResult';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '删除产品组和产品信息设置';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '删除产品组和产品信息设置');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_DelSettleProductGroupResult(' ||
                           i_tySettleProductGroupRst.uf_toString()
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_DelSettleProductGroupResult(
                               i_tySettleProductGroupRst
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_DelSettleProductGroupResult;

  /*************************************************************************
  $spDesc 查询产品组下对应的产品
  *************************************************************************/
  PROCEDURE up_QryProductByGroup
  (
     i_tySettleProductGroupRelation IN TY_SETTLEPRODUCTGROUPRELATION  --查询条件
    ,i_tyPage IN TY_PAGE  --分页信息
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_curProductGroupRelation OUT NOCOPY PKGS_DATATYPE.TYPEREFCURSOR  --查询结果游标
    ,o_nCount OUT PKGS_DATATYPE.STY_COUNT  --记录数
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_TradeMgrt.up_QryProductByGroup';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '查询产品组下对应的产品';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '交易管理，经纪公司管理', '查询产品组下对应的产品');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_TradeMgrt.up_QryProductByGroup(' ||
                           i_tySettleProductGroupRelation.uf_toString()
                      || ',' ||
                           i_tyPage.uf_toString()
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_curProductGroupRelation'
                      || ',' ||
                        'o_nCount'
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_TradeMgrt.up_QryProductByGroup(
                               i_tySettleProductGroupRelation
                              ,i_tyPage
                              ,i_chLanguage
                              ,o_curProductGroupRelation
                              ,o_nCount
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_QryProductByGroup;

END PKGI_TradeMgrt;
/

