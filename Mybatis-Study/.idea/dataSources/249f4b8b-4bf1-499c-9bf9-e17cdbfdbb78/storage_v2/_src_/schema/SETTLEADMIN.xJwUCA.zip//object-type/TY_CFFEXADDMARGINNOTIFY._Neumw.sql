create TYPE Ty_CFFEXAddMarginNotify AS OBJECT
(
    TradingDay CHAR(8),  --交易日
    ExchangeID CHAR(8),  --交易所代码
    ParticipantID CHAR(10),  --会员代码
    AccountID CHAR(14),  --资金账户
    CurrencyID CHAR(3),  --资金账户币种
    Remain NUMBER(22,6),  --结算准备金余额
    CallMargin NUMBER(22,6),  --追加保证金

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_CFFEXAddMarginNotify RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

