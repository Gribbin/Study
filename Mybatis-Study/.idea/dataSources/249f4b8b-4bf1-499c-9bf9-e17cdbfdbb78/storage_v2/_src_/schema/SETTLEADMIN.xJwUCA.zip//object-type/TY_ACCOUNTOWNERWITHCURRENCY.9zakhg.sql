create TYPE Ty_AccountOwnerWithCurrency AS OBJECT
(
    BrokerID CHAR(10),  --经纪公司代码
    AccountID CHAR(14),  --资金账号代码
    CurrencyID CHAR(3),  --资金账号币种代码
    AccountOwner CHAR(12),  --属主代码
    AccountOwnerMode CHAR(1),  --属主类型
    IsActive NUMBER(1),  --是否活跃
    AccountName CHAR(80),  --账户名称
    OpenDate CHAR(8),  --开户日期
    CancelDate CHAR(8),  --销户日期
    Priority NUMBER(2),  --优先级

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_AccountOwnerWithCurrency RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

