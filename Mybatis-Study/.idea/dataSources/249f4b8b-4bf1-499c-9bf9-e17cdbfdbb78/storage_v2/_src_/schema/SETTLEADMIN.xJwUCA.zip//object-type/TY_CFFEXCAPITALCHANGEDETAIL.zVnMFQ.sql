create TYPE Ty_CFFEXCapitalChangeDetail AS OBJECT
(
    TradingDay CHAR(8),  --交易日
    ExchangeID CHAR(8),  --交易所代码
    ParticipantID CHAR(10),  --会员代码
    BillNo CHAR(14),  --票据号
    BillName CHAR(32),  --票据名称
    Deposit NUMBER(22,6),  --金额

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_CFFEXCapitalChangeDetail RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

