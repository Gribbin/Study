create TYPE Ty_ClientInfo AS OBJECT
(
    TradingDay CHAR(10),  --交易日
    ParticipantID CHAR(10),  --会员代码
    ClientInfoRecordContents CHAR(2000),  --终端信息报送文件记录内容

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_ClientInfo RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

