create TYPE Ty_AMLSHTradeHis AS OBJECT
(
    TradingDay CHAR(8),  --交易日
    BrokerID CHAR(10),  --经纪公司代码
    GenerateDay CHAR(8),  --生成日期
    GenSequenceID NUMBER(8),  --当日生成批次编号
    ReportTypeID CHAR(2),  --交易报告类型标识
    ReportType CHAR(1),  --报文类型
    AMLSHTradeID NUMBER(8),  --反洗钱大额交易序列号
    InvestorID CHAR(12),  --投资者代码
    TouchDay CHAR(8),  --大额交易发生日期
    CharacterID CHAR(4),  --大额交易特征代码
    DepositSeqNo CHAR(64),  --业务标示号
    AMLGenStatus CHAR(1),  --数据来源
    DrawDay CHAR(8),  --检查日期
    DeputyName VARCHAR2(80),  --交易代办人姓名
    DeputyCardType CHAR(80),  --代办人身份证件类型
    DeputyCardNo CHAR(50),  --交易代办人身份证件号码
    DeputyNational CHAR(30),  --代办人身份归属国家/地区
    TradingTime CHAR(8),  --交易时间
    TradingType CHAR(6),  --交易方式
    TransactClass CHAR(6),  --涉外收支交易分类与代码
    CapitalIO CHAR(2),  --资金收付标识
    TradingDestination CHAR(9),  --交易去向
    TradingScene CHAR(9),  --交易发生地
    CapitalPurpose CHAR(128),  --资金用途
    CapitalCurrency CHAR(3),  --币种
    TradeVolume NUMBER(20,3),  --交易金额
    OtherInstitutionName CHAR(64),  --对方金融机构网点名称
    OtherInstitutionType CHAR(2),  --对方金融机构代码类型
    OtherInstitutionID CHAR(12),  --对方金融机构网点代码
    OtherUserName VARCHAR2(80),  --交易对手姓名
    OtherCustomerCardType CHAR(80),  --交易对手证件类型
    OtherIdentifiedCardNo CHAR(50),  --交易对手证件号码
    OtherAccountType CHAR(4),  --交易对手账号类型
    OtherFutureAccount CHAR(21),  --交易对手账号

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_AMLSHTradeHis RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

