create TYPE BODY Ty_AmlNiReportMap IS

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_AmlNiReportMap RETURN SELF AS RESULT IS
  BEGIN
    RETURN;
  END;

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2 IS
    l_string VARCHAR2(4000);
  BEGIN
    l_string:='ty_AmlNiReportMap('
      || 'BrokerID=>' || '''' || trim(BrokerID) || '''' --经纪公司代码
      || ',ReportSeqNo=>' || '''' || trim(ReportSeqNo) || '''' --报告序号
      || ',ReportType=>' || '''' || trim(ReportType) || '''' --报告类别
      || ',CharacterID=>' || '''' || trim(CharacterID) || '''' --特征代码
      || ',TouchDay=>' || '''' || trim(TouchDay) || '''' --交易发生日期
      || ',DrawDay=>' || '''' || trim(DrawDay) || '''' --交易发生日期
      || ',InvestorID=>' || '''' || trim(InvestorID) || '''' --投资者代码
      || ',TICD=>' || '''' || trim(TICD) || '''' --业务标识号
      || ')';


    RETURN l_string;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN NULL;
  END;



END;
/

