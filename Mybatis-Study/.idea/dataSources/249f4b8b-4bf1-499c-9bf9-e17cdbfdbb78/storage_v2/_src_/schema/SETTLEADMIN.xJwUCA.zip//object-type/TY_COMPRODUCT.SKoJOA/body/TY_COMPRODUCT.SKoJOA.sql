create TYPE BODY Ty_ComProduct IS

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_ComProduct RETURN SELF AS RESULT IS
  BEGIN
    RETURN;
  END;

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2 IS
    l_string VARCHAR2(4000);
  BEGIN
    l_string:='ty_ComProduct('
      || 'ExchangeID=>' || '''' || trim(ExchangeID) || '''' --交易所代码
      || ',ComProductID=>' || '''' || trim(ComProductID) || '''' --组合产品代码
      || ',ComProductName=>' || '''' || trim(ComProductName) || '''' --组合产品名称
      || ',ComProductClass=>' || '''' || trim(ComProductClass) || '''' --组合产品类型
      || ',ComType=>' || '''' || trim(ComType) || '''' --组合类型
      || ',ProductLifePhase=>' || '''' || trim(ProductLifePhase) || '''' --产品生命周期状态
      || ',Memo=>' || '''' || trim(Memo) || '''' --备注
      || ')';


    RETURN l_string;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN NULL;
  END;



END;
/

