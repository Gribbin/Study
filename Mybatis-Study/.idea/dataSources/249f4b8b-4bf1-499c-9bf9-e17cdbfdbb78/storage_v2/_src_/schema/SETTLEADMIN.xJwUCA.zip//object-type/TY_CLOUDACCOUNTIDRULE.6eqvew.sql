create TYPE Ty_CloudAccountIDRule AS OBJECT
(
    BrokerID CHAR(10),  --经纪公司代码
    BranchCode CHAR(64),  --营业部
    Referrer CHAR(150),  --推荐人
    RuleName CHAR(60),  --关联的号段规则名称
    IsActive NUMBER(1),  --是否启用
    OperatorID CHAR(64),  --录入员代码
    OperateDate CHAR(8),  --录入日期
    OperateTime CHAR(8),  --录入时间

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_CloudAccountIDRule RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

