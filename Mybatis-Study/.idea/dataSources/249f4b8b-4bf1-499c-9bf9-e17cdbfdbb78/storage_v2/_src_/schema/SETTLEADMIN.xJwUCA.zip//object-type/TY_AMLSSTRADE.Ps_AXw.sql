create TYPE Ty_AMLSSTrade AS OBJECT
(
    BrokerID CHAR(10),  --经纪公司代码
    AMLSSTradeID NUMBER(8),  --反洗钱可疑交易序列号
    CharacterID CHAR(4),  --可疑特征代码
    TouchDay CHAR(8),  --可疑交易发生日期
    AMLGenStatus CHAR(1),  --数据来源
    InvestorID CHAR(12),  --投资者代码
    DrawDay CHAR(8),  --检查日期
    InvestorType CHAR(2),  --投资者类型
    InvestorName VARCHAR2(80),  --投资者名称
    IdentifiedCardType CHAR(2),  --证件类型
    IdentifiedCardNo CHAR(50),  --证件号码
    FutureAccount CHAR(14),  --期货账号
    FutureCurrency CHAR(3),  --期货账号币种
    AccountID CHAR(14),  --资金账户
    CurrencyID CHAR(3),  --资金账户币种
    BankAccount CHAR(40),  --结算账号
    FundInvestorName VARCHAR2(80),  --交易代办人
    FundIdentifiedCardType CHAR(2),  --交易代办人证件类型
    FundIdentifiedCardNo CHAR(50),  --交易代办人证件号码
    OrderInvestorName VARCHAR2(80),  --经办人名称
    OrderIdentifiedCardType CHAR(2),  --经办人证件类型
    OrderIdentifiedCardNo CHAR(50),  --经办人证件号码
    TradingTime CHAR(8),  --交易时间
    TradingType CHAR(6),  --交易种类
    TransactClass CHAR(6),  --涉外收支交易分类与代码
    TradeTaget CHAR(30),  --交易品种代码
    DepositSeqNo CHAR(64),  --业务标示号
    CapitalCurrency CHAR(3),  --币种
    TradeVolume NUMBER(20,3),  --交易金额
    TradeDirect CHAR(2),  --资金进出方向
    TradeModel CHAR(2),  --资金进出方式
    IsReport NUMBER(1),  --是否报送

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_AMLSSTrade RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

