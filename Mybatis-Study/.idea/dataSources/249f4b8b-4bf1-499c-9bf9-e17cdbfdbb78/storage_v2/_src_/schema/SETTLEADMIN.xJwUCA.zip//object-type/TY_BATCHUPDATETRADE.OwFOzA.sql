create TYPE Ty_BatchUpdateTrade AS OBJECT
(
    BrokerID CHAR(10),  --经纪公司代码
    ExchangeID CHAR(8),  --交易所代码
    TradeID CHAR(20),  --成交编号
    Direction CHAR(1),  --买卖方向
    InvestorID CHAR(12),  --投资者代码
    InvestUnitID CHAR(16),  --投资单元代码
    InstrumentID CHAR(30),  --合约代码
    OffsetFlag CHAR(1),  --开平标志
    HedgeFlag CHAR(1),  --投机套保标志
    ProductClass CHAR(1),  --产品类型
    FeeAcceptStyle CHAR(1),  --手续费收取方式
    TransFeeRate NUMBER(19,8),  --手续费
    ExchTransFee NUMBER(22,6),  --交易所手续费

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_BatchUpdateTrade RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

