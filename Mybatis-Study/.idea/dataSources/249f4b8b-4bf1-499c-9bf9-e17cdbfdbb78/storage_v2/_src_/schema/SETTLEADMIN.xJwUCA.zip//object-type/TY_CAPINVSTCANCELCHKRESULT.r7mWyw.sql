create TYPE Ty_CAPInvstCancelChkResult AS OBJECT
(
    BrokerID CHAR(10),  --经纪公司代码
    InvestorID CHAR(12),  --投资者代码
    InvestUnitID CHAR(16),  --投资单元代码
    ErrorNo NUMBER(1),  --校验状态
    ErrorInfo VARCHAR2(4000),  --校验结果
    SystemStatus CHAR(1),  --系统状态
    HasLastPosition NUMBER(1),  --是否存在昨持仓
    SettlementHasTodayTrade NUMBER(1),  --结算是否存在今交易
    TradeHasTodayTrade NUMBER(1),  --交易是否存在今交易
    SettlementHasSomeFund NUMBER(1),  --结算是否存在部分资金未提取
    TradeHasSomeFund NUMBER(1),  --交易是否存在部分资金未提取
    HasTodayOrder NUMBER(1),  --是否存在今日报单
    HasTodayMortgage NUMBER(1),  --是否存在今日质押

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_CAPInvstCancelChkResult RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

