create TYPE BODY Ty_AmlCheckReportHis IS

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_AmlCheckReportHis RETURN SELF AS RESULT IS
  BEGIN
    RETURN;
  END;

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2 IS
    l_string VARCHAR2(4000);
  BEGIN
    l_string:='ty_AmlCheckReportHis('
      || 'TradingDay=>' || '''' || trim(TradingDay) || '''' --交易日
      || ',BrokerID=>' || '''' || trim(BrokerID) || '''' --经纪公司代码
      || ',ApplyNo=>' || NVL(to_char(ApplyNo),'NULL')--流水号
      || ',CheckNo=>' || NVL(to_char(CheckNo),'NULL')--操作次数
      || ',FlowID=>' || '''' || trim(FlowID) || '''' --流程ID
      || ',REPORTSEQNO=>' || '''' || trim(REPORTSEQNO) || '''' --报告序号
      || ',ReportType=>' || '''' || trim(ReportType) || '''' --报告类别
      || ',ACTION=>' || '''' || trim(ACTION) || '''' --报告类别：新增，修改，删除
      || ',FILEPATH=>' || '''' || trim(FILEPATH) || '''' --报告文件存放路径
      || ',AMLCheckStatus=>' || '''' || trim(AMLCheckStatus) || '''' --审核状态
      || ',CheckMemo=>' || '''' || trim(CheckMemo) || '''' --审核情况说明
      || ',CurrCheckLevel=>' || '''' || trim(CurrCheckLevel) || '''' --当前审核级别
      || ',MaxCheckLevel=>' || '''' || trim(MaxCheckLevel) || '''' --最高审核级别
      || ',UsedStatus=>' || '''' || trim(UsedStatus) || '''' --生效状态
      || ',Applier=>' || '''' || trim(Applier) || '''' --申请人
      || ',ApplyTime=>' || '''' || trim(ApplyTime) || '''' --申请时间
      || ',IsLatest=>' || '''' || trim(IsLatest) || '''' --是否最新
      || ',OperatorID=>' || '''' || trim(OperatorID) || '''' --审核员代码
      || ',OperateDate=>' || '''' || trim(OperateDate) || '''' --审核日期
      || ',OperateTime=>' || '''' || trim(OperateTime) || '''' --审核时间
      || ',CheckContent=>' || '''' || trim(CheckContent) || '''' --审核内容
      || ',AttatchMent=>' || '''' || trim(AttatchMent) || '''' --附件
      || ')';


    RETURN l_string;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN NULL;
  END;



END;
/

