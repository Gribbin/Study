create TYPE BODY Ty_AMLCharacter IS

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_AMLCharacter RETURN SELF AS RESULT IS
  BEGIN
    RETURN;
  END;

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2 IS
    l_string VARCHAR2(4000);
  BEGIN
    l_string:='ty_AMLCharacter('
      || 'ReportTypeID=>' || '''' || trim(ReportTypeID) || '''' --报告类型
      || ',CharacterID=>' || '''' || trim(CharacterID) || '''' --特征代码
      || ',CharacterDesc=>' || '''' || trim(CharacterDesc) || '''' --特征描述
      || ',AMLGenStatus=>' || '''' || trim(AMLGenStatus) || '''' --数据来源
      || ')';


    RETURN l_string;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN NULL;
  END;



END;
/

