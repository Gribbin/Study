create TYPE BODY Ty_AmlCheckNiShCus IS

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_AmlCheckNiShCus RETURN SELF AS RESULT IS
  BEGIN
    RETURN;
  END;

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2 IS
    l_string VARCHAR2(4000);
  BEGIN
    l_string:='ty_AmlCheckNiShCus('
      || 'TradingDay=>' || '''' || trim(TradingDay) || '''' --交易日期
      || ',ApplyNo=>' || NVL(to_char(ApplyNo),'NULL')--流水号
      || ',FlowID=>' || '''' || trim(FlowID) || '''' --流程ID
      || ',ApplyOperate=>' || '''' || trim(ApplyOperate) || '''' --触发流程操作
      || ',AMLCheckStatus=>' || '''' || trim(AMLCheckStatus) || '''' --审核状态
      || ',BrokerID=>' || '''' || trim(BrokerID) || '''' --经纪公司代码
      || ',InvestorID=>' || '''' || trim(InvestorID) || '''' --投资者代码
      || ',CharacterID=>' || '''' || trim(CharacterID) || '''' --大额交易特征码
      || ',TouchDay=>' || '''' || trim(TouchDay) || '''' --交易发生日期
      || ',DrawDay=>' || '''' || trim(DrawDay) || '''' --检查日期
      || ',DataSource=>' || '''' || trim(DataSource) || '''' --数据来源
      || ',InvestorName=>' || '''' || trim(InvestorName) || '''' --客户名称
      || ',CTNT=>' || '''' || trim(CTNT) || '''' --客户国籍
      || ',IdCardType=>' || '''' || trim(IdCardType) || '''' --证件类型
      || ',IdCardNo=>' || '''' || trim(IdCardNo) || '''' --证件号码
      || ',CTVC=>' || '''' || trim(CTVC) || '''' --客户职业（对私）或客户行业（对公）
      || ',CCTL=>' || '''' || trim(CCTL) || '''' --客户联系电话
      || ',CTAR=>' || '''' || trim(CTAR) || '''' --客户住址/经营地址
      || ',CCEI=>' || '''' || trim(CCEI) || '''' --客户其他联系方式
      || ')';


    RETURN l_string;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN NULL;
  END;



END;
/

