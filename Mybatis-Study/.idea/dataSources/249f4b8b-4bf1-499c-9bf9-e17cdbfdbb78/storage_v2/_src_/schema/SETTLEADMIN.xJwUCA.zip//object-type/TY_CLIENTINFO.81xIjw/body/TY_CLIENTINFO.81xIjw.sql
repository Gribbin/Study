create TYPE BODY Ty_ClientInfo IS

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_ClientInfo RETURN SELF AS RESULT IS
  BEGIN
    RETURN;
  END;

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2 IS
    l_string VARCHAR2(4000);
  BEGIN
    l_string:='ty_ClientInfo('
      || 'TradingDay=>' || '''' || trim(TradingDay) || '''' --交易日
      || ',ParticipantID=>' || '''' || trim(ParticipantID) || '''' --会员代码
      || ',ClientInfoRecordContents=>' || '''' || trim(ClientInfoRecordContents) || '''' --终端信息报送文件记录内容
      || ')';


    RETURN l_string;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN NULL;
  END;



END;
/

