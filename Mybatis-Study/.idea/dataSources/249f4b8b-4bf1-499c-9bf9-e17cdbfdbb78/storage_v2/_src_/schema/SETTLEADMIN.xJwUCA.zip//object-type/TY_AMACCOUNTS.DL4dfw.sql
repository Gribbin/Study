create TYPE Ty_AmAccounts AS OBJECT
(
    TradingDay CHAR(10),  --交易日
    ParticipantID CHAR(10),  --会员代码
    InvestorID CHAR(12),  --客户内部资金账户
    AmName VARCHAR2(400),  --机构名称
    AmType CHAR(4),  --机构类型
    AmAccount CHAR(22),  --投资账户
    Memo CHAR(40),  --说明

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_AmAccounts RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

