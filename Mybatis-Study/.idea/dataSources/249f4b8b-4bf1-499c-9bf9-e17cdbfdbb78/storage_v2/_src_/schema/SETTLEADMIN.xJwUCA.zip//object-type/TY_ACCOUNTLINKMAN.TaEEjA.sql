create TYPE Ty_AccountLinkMan AS OBJECT
(
    BrokerID CHAR(10),  --经纪公司代码
    AccountID CHAR(14),  --投资者账号
    CurrencyID CHAR(3),  --投资者账号币种
    PersonType CHAR(1),  --联系人类型
    PersonCardType CHAR(1),  --证件类型
    PersonCardNo CHAR(50),  --证件号码
    PersonName VARCHAR2(100),  --名称
    PersonTelephone CHAR(40),  --联系电话
    PersonAddress CHAR(100),  --通讯地址
    PersonZipCode CHAR(10),  --邮政编码
    PersonSex CHAR(1),  --性别
    PersonNational CHAR(30),  --身份归属国家/地区
    NationalProvince CHAR(50),  --所在省
    NationalCity CHAR(50),  --所在市
    Priority NUMBER(2),  --优先级
    PhoneCountryCode CHAR(10),  --国家代码
    PhoneAreaCode CHAR(10),  --区号
    Country CHAR(15),  --联系地址国家或地区
    Province CHAR(50),  --联系地址省
    City CHAR(50),  --联系地址市
    IdCardValidityStart CHAR(8),  --证件有效期（起）
    IdCardValidityEnd CHAR(8),  --证件有效期（止）
    Mobile CHAR(40),  --手机
    EMail CHAR(100),  --电子邮件
    Memo CHAR(160),  --备注

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_AccountLinkMan RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

