create TYPE BODY Ty_CAPBankRelationResult IS

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_CAPBankRelationResult RETURN SELF AS RESULT IS
  BEGIN
    RETURN;
  END;

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2 IS
    l_string VARCHAR2(4000);
  BEGIN
    l_string:='ty_CAPBankRelationResult('
      || 'BankBranch=>' || '''' || trim(BankBranch) || '''' --银行账户的开户行
      || ',BankID=>' || '''' || trim(BankID) || '''' --银行代码
      || ',BankNO=>' || '''' || trim(BankNO) || '''' --银行行号
      || ',BankRelation=>' || '''' || trim(BankRelation) || '''' --解绑状态
      || ')';


    RETURN l_string;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN NULL;
  END;



END;
/

