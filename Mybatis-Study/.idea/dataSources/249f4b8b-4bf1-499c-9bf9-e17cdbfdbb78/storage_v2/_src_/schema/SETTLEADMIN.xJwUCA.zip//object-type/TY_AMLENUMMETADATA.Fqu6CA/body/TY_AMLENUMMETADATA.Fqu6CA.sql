create TYPE BODY Ty_AMLEnumMetaData IS

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_AMLEnumMetaData RETURN SELF AS RESULT IS
  BEGIN
    RETURN;
  END;

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2 IS
    l_string VARCHAR2(4000);
  BEGIN
    l_string:='ty_AMLEnumMetaData('
      || 'EnumValueID=>' || '''' || trim(EnumValueID) || '''' --枚举值代码
      || ',TagID=>' || '''' || trim(TagID) || '''' --标签名称代码
      || ',TagValue=>' || '''' || trim(TagValue) || '''' --标签字段内容
      || ',EnumValueResult=>' || '''' || trim(EnumValueResult) || '''' --枚举值结果
      || ',EnumValueDesc=>' || '''' || trim(EnumValueDesc) || '''' --枚举值说明
      || ')';


    RETURN l_string;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN NULL;
  END;



END;
/

