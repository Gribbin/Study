create TYPE Ty_CloudBranchMap AS OBJECT
(
    BrokerID CHAR(10),  --经纪公司代码
    CloudBranchCode CHAR(12),  --云平台营业部代码
    CloudBranch VARCHAR2(60),  --云平台营业部名称
    Referrer CHAR(150),  --推荐人
    CFFEXBranchCode CHAR(12),  --中金所营业部代码
    DepartmentID CHAR(12),  --组织架构
    PropertyIDs VARCHAR2(2048),  --属性

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_CloudBranchMap RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

