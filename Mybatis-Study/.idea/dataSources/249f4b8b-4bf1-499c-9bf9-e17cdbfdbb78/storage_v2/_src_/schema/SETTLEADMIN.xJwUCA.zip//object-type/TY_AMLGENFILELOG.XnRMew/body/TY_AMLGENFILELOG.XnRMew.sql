create TYPE BODY Ty_AMLGenFileLog IS

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_AMLGenFileLog RETURN SELF AS RESULT IS
  BEGIN
    RETURN;
  END;

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2 IS
    l_string VARCHAR2(4000);
  BEGIN
    l_string:='ty_AMLGenFileLog('
      || 'BrokerID=>' || '''' || trim(BrokerID) || '''' --经纪公司代码
      || ',GenerateDay=>' || '''' || trim(GenerateDay) || '''' --生成日期
      || ',GenSequenceID=>' || NVL(to_char(GenSequenceID),'NULL')--当日生成批次编号
      || ',ReportTypeID=>' || '''' || trim(ReportTypeID) || '''' --报告类型
      || ',ReportType=>' || '''' || trim(ReportType) || '''' --报文类型
      || ',AMLGenSeqID=>' || NVL(to_char(AMLGenSeqID),'NULL')--文件生成事件序列号
      || ',ReportName=>' || '''' || trim(ReportName) || '''' --报文名称
      || ',BeginDay=>' || '''' || trim(BeginDay) || '''' --检查日期
      || ',EndDay=>' || '''' || trim(EndDay) || '''' --结束检查日期
      || ',ZipAmount=>' || NVL(to_char(ZipAmount),'NULL')--压缩的数据包数量
      || ',Description=>' || '''' || trim(Description) || '''' --描述
      || ',OperatorID=>' || '''' || trim(OperatorID) || '''' --录入员代码
      || ',OperateDate=>' || '''' || trim(OperateDate) || '''' --录入日期
      || ',OperateTime=>' || '''' || trim(OperateTime) || '''' --录入时间
      || ')';


    RETURN l_string;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN NULL;
  END;



END;
/

