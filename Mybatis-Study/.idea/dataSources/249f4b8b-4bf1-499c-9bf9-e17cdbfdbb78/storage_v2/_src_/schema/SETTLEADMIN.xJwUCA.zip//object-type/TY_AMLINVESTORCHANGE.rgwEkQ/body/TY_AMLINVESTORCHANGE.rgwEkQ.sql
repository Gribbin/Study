create TYPE BODY Ty_AmlInvestorchange IS

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_AmlInvestorchange RETURN SELF AS RESULT IS
  BEGIN
    RETURN;
  END;

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2 IS
    l_string VARCHAR2(4000);
  BEGIN
    l_string:='ty_AmlInvestorchange('
      || 'BrokerID=>' || '''' || trim(BrokerID) || '''' --经纪公司代码
      || ',InvestorID=>' || '''' || trim(InvestorID) || '''' --投资者代码
      || ',AmlinvstchangeDate=>' || '''' || trim(AmlinvstchangeDate) || '''' --变更发生日期
      || ',AmlinvstchangeTime=>' || '''' || trim(AmlinvstchangeTime) || '''' --变更发生时间
      || ',AmlinvstchangeChkParamID=>' || '''' || trim(AmlinvstchangeChkParamID) || '''' --识别身份变更参数代码
      || ',AmlInvstChangeoldvalue=>' || '''' || trim(AmlInvstChangeoldvalue) || '''' --变更前内容
      || ',AmlInvstChangenewvalue=>' || '''' || trim(AmlInvstChangenewvalue) || '''' --变更后内容
      || ',AmlInvstChangeCheckMethod=>' || '''' || trim(AmlInvstChangeCheckMethod) || '''' --变更识别方法
      || ',CheckOperator=>' || '''' || trim(CheckOperator) || '''' --操作员代码
      || ',CheckOperateDate=>' || '''' || trim(CheckOperateDate) || '''' --识别日期
      || ',CheckOperateTime=>' || '''' || trim(CheckOperateTime) || '''' --识别时间
      || ',Memo=>' || '''' || trim(Memo) || '''' --备注
      || ')';


    RETURN l_string;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN NULL;
  END;



END;
/

