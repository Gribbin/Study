create TYPE Ty_CRAAreaBlackList AS OBJECT
(
    BrokerID CHAR(10),  --经纪商代码
    AreaBlackListType CHAR(1),  --地域类型
    Area CHAR(15),  --地域

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_CRAAreaBlackList RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

