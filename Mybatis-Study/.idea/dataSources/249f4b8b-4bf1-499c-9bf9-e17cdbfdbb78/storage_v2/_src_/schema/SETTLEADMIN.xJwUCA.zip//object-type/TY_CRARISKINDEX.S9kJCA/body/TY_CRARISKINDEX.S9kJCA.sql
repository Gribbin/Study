create TYPE BODY Ty_CRARiskIndex IS

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_CRARiskIndex RETURN SELF AS RESULT IS
  BEGIN
    RETURN;
  END;

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2 IS
    l_string VARCHAR2(4000);
  BEGIN
    l_string:='ty_CRARiskIndex('
      || 'BrokerID=>' || '''' || trim(BrokerID) || '''' --经纪商代码
      || ',RiskFactorID=>' || NVL(to_char(RiskFactorID),'NULL')--风险因素ID
      || ',RiskIndexID=>' || NVL(to_char(RiskIndexID),'NULL')--指标ID
      || ',RiskIndexName=>' || '''' || trim(RiskIndexName) || '''' --名称
      || ',RiskIndexWeight=>' || NVL(to_char(RiskIndexWeight),'NULL')--权重
      || ',RiskIndexLevel=>' || NVL(to_char(RiskIndexLevel),'NULL')--分级
      || ',IsAddItem=>' || '''' || trim(IsAddItem) || '''' --是否附加项
      || ')';


    RETURN l_string;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN NULL;
  END;



END;
/

