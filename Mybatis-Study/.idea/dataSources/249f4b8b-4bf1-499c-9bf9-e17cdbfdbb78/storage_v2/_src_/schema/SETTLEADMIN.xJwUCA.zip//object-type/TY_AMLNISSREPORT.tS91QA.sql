create TYPE Ty_AmlNiSsReport AS OBJECT
(
    BrokerID CHAR(10),  --经纪公司代码
    ReportSeqNo CHAR(20),  --报告序号
    Action CHAR(1),  --报告类别-新增或修改
    ReportName CHAR(39),  --报文名称
    FilePath VARCHAR2(200),  --报告文件存放路径
    GenDate CHAR(8),  --生成日期
    RICD CHAR(14),  --报告机构编码
    RPNC VARCHAR2(30),  --上报网点代码
    DETR VARCHAR2(6),  --可疑交易报告紧急程度
    TORP VARCHAR2(6),  --报送次数标志
    ORXN VARCHAR2(39),  --初次报送的可疑交易报告报文名称
    DORP VARCHAR2(6),  --报送方向
    ODRP VARCHAR2(100),  --其他报送方向
    TPTR VARCHAR2(10),  --可疑交易报告触发点
    OTPR VARCHAR2(100),  --其他可疑交易报告触发点
    STCB VARCHAR2(500),  --资金交易及客户行为情况
    AOSP VARCHAR2(500),  --疑点分析
    TOSC VARCHAR2(200),  --涉罪类型
    STCR VARCHAR2(200),  --可疑交易特征代码
    SETN VARCHAR2(10),  --可疑主体总数
    STNM VARCHAR2(10),  --可疑交易总数
    RPNM VARCHAR2(30),  --可疑交易报告的填报人员
    MIRS VARCHAR2(10),  --人工补正标志
    AttachFileOne VARCHAR2(200),  --附件
    AttachFileTwo VARCHAR2(200),  --附件
    AttachFileThree VARCHAR2(200),  --附件
    AttachFileFour VARCHAR2(200),  --附件
    AttachFileFive VARCHAR2(200),  --附件
    AttachFileSix VARCHAR2(200),  --附件
    AttachFileSeven VARCHAR2(200),  --附件
    AttachFileEight VARCHAR2(200),  --附件

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_AmlNiSsReport RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

