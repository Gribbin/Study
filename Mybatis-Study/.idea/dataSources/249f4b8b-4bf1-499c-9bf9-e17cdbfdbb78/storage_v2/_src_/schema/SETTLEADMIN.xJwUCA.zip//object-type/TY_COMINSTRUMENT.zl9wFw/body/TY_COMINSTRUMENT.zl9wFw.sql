create TYPE BODY Ty_ComInstrument IS

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_ComInstrument RETURN SELF AS RESULT IS
  BEGIN
    RETURN;
  END;

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2 IS
    l_string VARCHAR2(4000);
  BEGIN
    l_string:='ty_ComInstrument('
      || 'InstrumentID=>' || '''' || trim(InstrumentID) || '''' --合约代码
      || ',ExchangeID=>' || '''' || trim(ExchangeID) || '''' --交易所代码
      || ',InstrumentName=>' || '''' || trim(InstrumentName) || '''' --合约名称
      || ',ExchangeInstID=>' || '''' || trim(ExchangeInstID) || '''' --合约在交易所的代码
      || ',ProductID=>' || '''' || trim(ProductID) || '''' --产品代码
      || ',ProductClass=>' || '''' || trim(ProductClass) || '''' --产品类型
      || ',DeliveryYear=>' || '''' || trim(DeliveryYear) || '''' --交割年份
      || ',DeliveryMonth=>' || '''' || trim(DeliveryMonth) || '''' --交割月
      || ',MaxMarketOrderVolume=>' || NVL(to_char(MaxMarketOrderVolume),'NULL')--市价单最大下单量
      || ',MinMarketOrderVolume=>' || NVL(to_char(MinMarketOrderVolume),'NULL')--市价单最小下单量
      || ',MaxLimitOrderVolume=>' || NVL(to_char(MaxLimitOrderVolume),'NULL')--限价单最大下单量
      || ',MinLimitOrderVolume=>' || NVL(to_char(MinLimitOrderVolume),'NULL')--限价单最小下单量
      || ',VolumeMultiple=>' || NVL(to_char(VolumeMultiple),'NULL')--合约数量乘数
      || ',PriceTick=>' || NVL(to_char(PriceTick),'NULL')--最小变动价位
      || ',CreateDate=>' || '''' || trim(CreateDate) || '''' --创建日
      || ',OpenDate=>' || '''' || trim(OpenDate) || '''' --上市日
      || ',ExpireDate=>' || '''' || trim(ExpireDate) || '''' --到期日
      || ',StartDelivDate=>' || '''' || trim(StartDelivDate) || '''' --开始交割日
      || ',EndDelivDate=>' || '''' || trim(EndDelivDate) || '''' --结束交割日
      || ',InstLifePhase=>' || '''' || trim(InstLifePhase) || '''' --合约生命周期状态
      || ',IsTrading=>' || '''' || trim(IsTrading) || '''' --当前是否交易
      || ',PositionType=>' || '''' || trim(PositionType) || '''' --持仓类型
      || ',PositionDateType=>' || '''' || trim(PositionDateType) || '''' --持仓日期类型
      || ',LongMarginRatio=>' || NVL(to_char(LongMarginRatio),'NULL')--多头保证金率
      || ',ShortMarginRatio=>' || NVL(to_char(ShortMarginRatio),'NULL')--空头保证金率
      || ',MaxMarginSideAlgorithm=>' || '''' || trim(MaxMarginSideAlgorithm) || '''' --是否使用大额单边保证金算法
      || ',UnderlyingInstrID=>' || '''' || trim(UnderlyingInstrID) || '''' --基础商品代码
      || ',StrikePrice=>' || NVL(to_char(StrikePrice),'NULL')--执行价
      || ',OptionsType=>' || '''' || trim(OptionsType) || '''' --期权类型
      || ',UnderlyingMultiple=>' || NVL(to_char(UnderlyingMultiple),'NULL')--合约基础商品乘数
      || ',CombinationType=>' || '''' || trim(CombinationType) || '''' --组合类型
      || ')';


    RETURN l_string;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN NULL;
  END;



END;
/

