create TYPE BODY Ty_AmlCheckNiSsTrade IS

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_AmlCheckNiSsTrade RETURN SELF AS RESULT IS
  BEGIN
    RETURN;
  END;

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2 IS
    l_string VARCHAR2(4000);
  BEGIN
    l_string:='ty_AmlCheckNiSsTrade('
      || 'TradingDay=>' || '''' || trim(TradingDay) || '''' --交易日期
      || ',FlowID=>' || '''' || trim(FlowID) || '''' --流程ID
      || ',ApplyOperate=>' || '''' || trim(ApplyOperate) || '''' --触发流程操作
      || ',DataStatus=>' || '''' || trim(DataStatus) || '''' --数据状态
      || ',BrokerID=>' || '''' || trim(BrokerID) || '''' --经纪公司代码
      || ',CharacterID=>' || '''' || trim(CharacterID) || '''' --可疑特征代码
      || ',TouchDay=>' || '''' || trim(TouchDay) || '''' --可疑交易发生日期
      || ',DrawDay=>' || '''' || trim(DrawDay) || '''' --检查日期
      || ',DataSource=>' || '''' || trim(DataSource) || '''' --数据来源
      || ',FINC=>' || '''' || trim(FINC) || '''' --金融机构网点代码
      || ',InvestorID=>' || '''' || trim(InvestorID) || '''' --投资者代码
      || ',CTNM=>' || '''' || trim(CTNM) || '''' --客户姓名名称
      || ',CITP=>' || '''' || trim(CITP) || '''' --客户身份证件/证明文件类型
      || ',CTID=>' || '''' || trim(CTID) || '''' --客户身份证件/证明文件号码
      || ',SCAC=>' || '''' || trim(SCAC) || '''' --可疑主体期货账号
      || ',FDAC=>' || '''' || trim(FDAC) || '''' --资金账户号码
      || ',STAC=>' || '''' || trim(STAC) || '''' --结算账户号码
      || ',TSTM=>' || '''' || trim(TSTM) || '''' --交易时间
      || ',TICD=>' || '''' || trim(TICD) || '''' --业务标识号
      || ',OCTT=>' || '''' || trim(OCTT) || '''' --非柜台交易方式
      || ',OOCT=>' || '''' || trim(OOCT) || '''' --其他非柜台交易方式
      || ',OCEC=>' || '''' || trim(OCEC) || '''' --非柜台交易方式的设备代码
      || ',TOTS=>' || '''' || trim(TOTS) || '''' --交易种类
      || ',CTNO=>' || '''' || trim(CTNO) || '''' --合同编号
      || ',SRNO=>' || '''' || trim(SRNO) || '''' --流水号
      || ',TTCD=>' || '''' || trim(TTCD) || '''' --交易品种代码
      || ',TRPR=>' || '''' || trim(TRPR) || '''' --成交价格
      || ',TVOL=>' || '''' || trim(TVOL) || '''' --成交数量
      || ',CRDR=>' || '''' || trim(CRDR) || '''' --资金进出方向
      || ',CSTP=>' || '''' || trim(CSTP) || '''' --资金进出方式
      || ',CRTP=>' || '''' || trim(CRTP) || '''' --交易币种
      || ',CRAT=>' || '''' || trim(CRAT) || '''' --交易金额
      || ')';


    RETURN l_string;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN NULL;
  END;



END;
/

