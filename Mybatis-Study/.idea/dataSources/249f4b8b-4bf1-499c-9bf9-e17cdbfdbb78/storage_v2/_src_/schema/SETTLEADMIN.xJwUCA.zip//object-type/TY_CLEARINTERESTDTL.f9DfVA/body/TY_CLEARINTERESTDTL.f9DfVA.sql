create TYPE BODY Ty_ClearInterestDtl IS

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_ClearInterestDtl RETURN SELF AS RESULT IS
  BEGIN
    RETURN;
  END;

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2 IS
    l_string VARCHAR2(4000);
  BEGIN
    l_string:='ty_ClearInterestDtl('
      || 'BrokerID=>' || '''' || trim(BrokerID) || '''' --经纪公司代码
      || ',ClearIntNo=>' || NVL(to_char(ClearIntNo),'NULL')--结息操作编号
      || ',AccountID=>' || '''' || trim(AccountID) || '''' --资金账号
      || ',CurrencyID=>' || '''' || trim(CurrencyID) || '''' --资金账号币种
      || ',InvestorID=>' || '''' || trim(InvestorID) || '''' --投资者代码
      || ',BeginDate=>' || '''' || trim(BeginDate) || '''' --开始日期
      || ',EndDate=>' || '''' || trim(EndDate) || '''' --结束日期
      || ',InterestRate=>' || NVL(to_char(InterestRate),'NULL')--利率
      || ',DepositSum=>' || NVL(to_char(DepositSum),'NULL')--计息积数
      || ',InterestSum=>' || NVL(to_char(InterestSum),'NULL')--利息金额
      || ',AdjustInterest=>' || NVL(to_char(AdjustInterest),'NULL')--利息调整
      || ')';


    RETURN l_string;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN NULL;
  END;



END;
/

