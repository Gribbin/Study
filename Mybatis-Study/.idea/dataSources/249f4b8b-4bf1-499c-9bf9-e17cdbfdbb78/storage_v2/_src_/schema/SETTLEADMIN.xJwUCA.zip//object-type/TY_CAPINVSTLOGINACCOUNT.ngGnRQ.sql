create TYPE Ty_CAPInvstLoginAccount AS OBJECT
(
    BrokerID CHAR(10),  --经纪公司代码
    InvestorID CHAR(12),  --投资者代码
    InvestUnitID CHAR(16),  --投资单元代码
    LoginAccountID CHAR(14),  --投资者登录账号
    LoginAccountPassword CHAR(40),  --投资者登录密码

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_CAPInvstLoginAccount RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

