create TYPE Ty_CSRC_FundChg AS OBJECT
(
    TradingDay CHAR(10),  --交易日
    ParticipantID CHAR(10),  --会员代码
    InvestorID CHAR(12),  --客户内部资金账户
    Deposite NUMBER(15,3),  --出入金额
    InvestorBankFlag CHAR(2),  --客户期货结算账户银行统一标识
    InvestorAccountID CHAR(40),  --客户期货结算账户
    BrokerBankFlag CHAR(2),  --公司保证金专用账户银行统一标识
    BrokerAccountID CHAR(40),  --公司保证金专用账户
    Meno VARCHAR2(4000),  --备注
    IsSettlement CHAR(1),  --是否为非结算会员
    CurrencyID CHAR(3),  --币种
    FundIOType CHAR(1),  --出入金类型
    TradeDate CHAR(10),  --出入金发生日期

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_CSRC_FundChg RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

