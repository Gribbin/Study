create TYPE Ty_AmlNiShReport AS OBJECT
(
    BrokerID CHAR(10),  --经纪公司代码
    ReportSeqNo CHAR(20),  --报告序号
    Action CHAR(1),  --报告类别：新增，修改，删除
    ReportName CHAR(39),  --报告文件名称
    FilePath VARCHAR2(200),  --报告文件存放路径
    RICD CHAR(14),  --报告机构编码
    CTTN VARCHAR2(10),  --大额交易客户总数
    GenDate CHAR(8),  --生成日期
    AttachFileOne VARCHAR2(200),  --附件
    AttachFileTwo VARCHAR2(200),  --附件
    AttachFileThree VARCHAR2(200),  --附件
    AttachFileFour VARCHAR2(200),  --附件
    AttachFileFive VARCHAR2(200),  --附件
    AttachFileSix VARCHAR2(200),  --附件
    AttachFileSeven VARCHAR2(200),  --附件
    AttachFileEight VARCHAR2(200),  --附件

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_AmlNiShReport RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

