create PACKAGE BODY PKGI_Settle  IS
  /*************************************************************************
  $spDesc 并行结算2.结算数据清理
  *************************************************************************/
  PROCEDURE up_ParallelSettleInputClear
  (
     i_TradingDay IN PKGS_DATATYPE.STY_DATE  --交易日期
    ,i_BrokerID IN PKGS_DATATYPE.STY_BROKERID  --经纪公司代码
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作员代码
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回码
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_Settle.up_ParallelSettleInputClear';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '并行结算2.结算数据清理';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '结算控制平台', '并行结算2.结算数据清理');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_Settle.up_ParallelSettleInputClear(' ||
                           '''' || trim(i_TradingDay) || ''''
                      || ',' ||
                           '''' || trim(i_BrokerID) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_Settle.up_ParallelSettleInputClear(
                               i_TradingDay
                              ,i_BrokerID
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_ParallelSettleInputClear;

  /*************************************************************************
  $spDesc 并行结算2.公共结算数据输入
  *************************************************************************/
  PROCEDURE up_SettleCommonDataInput
  (
     i_TradingDay IN PKGS_DATATYPE.STY_DATE  --交易日期
    ,i_BrokerID IN PKGS_DATATYPE.STY_BROKERID  --经纪公司代码
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作员代码
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回码
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_Settle.up_SettleCommonDataInput';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '并行结算2.公共结算数据输入';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '结算控制平台', '并行结算2.公共结算数据输入');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_Settle.up_SettleCommonDataInput(' ||
                           '''' || trim(i_TradingDay) || ''''
                      || ',' ||
                           '''' || trim(i_BrokerID) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_Settle.up_SettleCommonDataInput(
                               i_TradingDay
                              ,i_BrokerID
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_SettleCommonDataInput;

  /*************************************************************************
  $spDesc 并行结算2.结算数据输入
  *************************************************************************/
  PROCEDURE up_ParallelSettleInputEx
  (
     i_BrokerID IN PKGS_DATATYPE.STY_BROKERID  --经纪公司代码
    ,i_TradingDay IN PKGS_DATATYPE.STY_DATE  --交易日期
    ,i_ExchangeID IN PKGS_DATATYPE.STY_EXCHANGEID  --交易所代码
    ,i_SettleProductGroupList IN TYT_SETTLEPRODUCTGROUPMODE  --结算对象
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作员代码
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回码
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_Settle.up_ParallelSettleInputEx';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '并行结算2.结算数据输入';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '结算控制平台', '并行结算2.结算数据输入');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_Settle.up_ParallelSettleInputEx(' ||
                           '''' || trim(i_BrokerID) || ''''
                      || ',' ||
                           '''' || trim(i_TradingDay) || ''''
                      || ',' ||
                           '''' || trim(i_ExchangeID) || ''''
                      || ',' ||
                           PKGS_Tyt2STRINGEx.uf_Tyt2String(i_SettleProductGroupList)
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_Settle.up_ParallelSettleInputEx(
                               i_BrokerID
                              ,i_TradingDay
                              ,i_ExchangeID
                              ,i_SettleProductGroupList
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_ParallelSettleInputEx;

  /*************************************************************************
  $spDesc 并行结算2.结算核心处理
  *************************************************************************/
  PROCEDURE up_ParallelSettleMain
  (
     i_BrokerID IN PKGS_DATATYPE.STY_BROKERID  --经纪公司代码
    ,i_TradingDay IN PKGS_DATATYPE.STY_DATE  --交易日期
    ,i_ExchangeID IN PKGS_DATATYPE.STY_EXCHANGEID  --交易所代码
    ,i_SettleProductGroupList IN TYT_SETTLEPRODUCTGROUPMODE  --结算对象
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作员代码
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回码
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_Settle.up_ParallelSettleMain';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '并行结算2.结算核心处理';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '结算控制平台', '并行结算2.结算核心处理');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_Settle.up_ParallelSettleMain(' ||
                           '''' || trim(i_BrokerID) || ''''
                      || ',' ||
                           '''' || trim(i_TradingDay) || ''''
                      || ',' ||
                           '''' || trim(i_ExchangeID) || ''''
                      || ',' ||
                           PKGS_Tyt2STRINGEx.uf_Tyt2String(i_SettleProductGroupList)
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_Settle.up_ParallelSettleMain(
                               i_BrokerID
                              ,i_TradingDay
                              ,i_ExchangeID
                              ,i_SettleProductGroupList
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_ParallelSettleMain;

  /*************************************************************************
  $spDesc 并行结算2.结算输出
  *************************************************************************/
  PROCEDURE up_ParallelSettleOutputEx
  (
     i_BrokerID IN PKGS_DATATYPE.STY_BROKERID  --经纪公司代码
    ,i_TradingDay IN PKGS_DATATYPE.STY_DATE  --交易日期
    ,i_SettleProductGroupList IN TYT_SETTLEPRODUCTGROUPMODE  --结算对象
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作员代码
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回码
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_Settle.up_ParallelSettleOutputEx';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '并行结算2.结算输出';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '结算控制平台', '并行结算2.结算输出');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_Settle.up_ParallelSettleOutputEx(' ||
                           '''' || trim(i_BrokerID) || ''''
                      || ',' ||
                           '''' || trim(i_TradingDay) || ''''
                      || ',' ||
                           PKGS_Tyt2STRINGEx.uf_Tyt2String(i_SettleProductGroupList)
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_Settle.up_ParallelSettleOutputEx(
                               i_BrokerID
                              ,i_TradingDay
                              ,i_SettleProductGroupList
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_ParallelSettleOutputEx;

  /*************************************************************************
  $spDesc 并行结算2.结算输出（JAVA内存结算调用接口）
  *************************************************************************/
  PROCEDURE up_ParallelSettleOutputEx4Java
  (
     i_TytSettleDate IN TYT_SETTLEDATE  --结算对象
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作源代码
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回码
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_Settle.up_ParallelSettleOutputEx4Java';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '并行结算2.结算输出（JAVA内存结算调用接口）';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '结算控制平台', '并行结算2.结算输出（JAVA内存结算调用接口）');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_Settle.up_ParallelSettleOutputEx4Java(' ||
                           PKGS_Tyt2STRING.uf_Tyt2String(i_TytSettleDate)
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_Settle.up_ParallelSettleOutputEx4Java(
                               i_TytSettleDate
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_ParallelSettleOutputEx4Java;

  /*************************************************************************
  $spDesc 并行结算2.资金计算（含结算、输出、生成换汇）
  *************************************************************************/
  PROCEDURE up_ParallelCommonFundOnly
  (
     i_BrokerID IN PKGS_DATATYPE.STY_BROKERID  --经纪公司代码
    ,i_TradingDay IN PKGS_DATATYPE.STY_DATE  --交易日期
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作员代码
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回码
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_Settle.up_ParallelCommonFundOnly';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '并行结算2.资金计算（含结算、输出、生成换汇）';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '结算控制平台', '并行结算2.资金计算（含结算、输出、生成换汇）');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_Settle.up_ParallelCommonFundOnly(' ||
                           '''' || trim(i_BrokerID) || ''''
                      || ',' ||
                           '''' || trim(i_TradingDay) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_Settle.up_ParallelCommonFundOnly(
                               i_BrokerID
                              ,i_TradingDay
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_ParallelCommonFundOnly;

  /*************************************************************************
  $spDesc 并行结算2.资金计算结算输出（JAVA内存结算调用接口）
  *************************************************************************/
  PROCEDURE up_SettleCommFundOnly4Java
  (
     i_TytSettleDate IN TYT_SETTLEDATE  --结算对象
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作源代码
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回码
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_Settle.up_SettleCommFundOnly4Java';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '并行结算2.资金计算结算输出（JAVA内存结算调用接口）';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '结算控制平台', '并行结算2.资金计算结算输出（JAVA内存结算调用接口）');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_Settle.up_SettleCommFundOnly4Java(' ||
                           PKGS_Tyt2STRING.uf_Tyt2String(i_TytSettleDate)
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_Settle.up_SettleCommFundOnly4Java(
                               i_TytSettleDate
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_SettleCommFundOnly4Java;

  /*************************************************************************
  $spDesc 更新某交易所的结算状态
  *************************************************************************/
  PROCEDURE up_SetSettleStatus
  (
     i_TytSettleDate IN TYT_SETTLEDATE  --结算对象
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作员代码
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回码
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_Settle.up_SetSettleStatus';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '更新某交易所的结算状态';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '结算控制平台', '更新某交易所的结算状态');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_Settle.up_SetSettleStatus(' ||
                           PKGS_Tyt2STRING.uf_Tyt2String(i_TytSettleDate)
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_Settle.up_SetSettleStatus(
                               i_TytSettleDate
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_SetSettleStatus;

  /*************************************************************************
  $spDesc 重置某交易所的结算状态(内存结算运维交互模块重新加载数据使用)
  *************************************************************************/
  PROCEDURE up_ResetSettlement
  (
     i_TySettleDate IN TY_SETTLEDATE  --结算对象
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作员代码
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回码
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_Settle.up_ResetSettlement';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '重置某交易所的结算状态(内存结算运维交互模块重新加载数据使用)';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '结算控制平台', '重置某交易所的结算状态(内存结算运维交互模块重新加载数据使用)');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_Settle.up_ResetSettlement(' ||
                           i_TySettleDate.uf_toString()
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_Settle.up_ResetSettlement(
                               i_TySettleDate
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_ResetSettlement;

  /*************************************************************************
  $spDesc 结算确认
  *************************************************************************/
  PROCEDURE up_SetFinishedSettlement
  (
     i_BrokerID IN PKGS_DATATYPE.STY_BROKERID  --经纪公司代码
    ,i_TradingDay IN PKGS_DATATYPE.STY_DATE  --交易日期
    ,i_ExchangeID IN PKGS_DATATYPE.STY_EXCHANGEID  --交易所代码
    ,i_SettleProductGroupList IN TYT_SETTLEPRODUCTGROUPMODE  --结算对象
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作员代码
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回码
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_Settle.up_SetFinishedSettlement';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '结算确认';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '结算控制平台', '结算确认');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_Settle.up_SetFinishedSettlement(' ||
                           '''' || trim(i_BrokerID) || ''''
                      || ',' ||
                           '''' || trim(i_TradingDay) || ''''
                      || ',' ||
                           '''' || trim(i_ExchangeID) || ''''
                      || ',' ||
                           PKGS_Tyt2STRINGEx.uf_Tyt2String(i_SettleProductGroupList)
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_Settle.up_SetFinishedSettlement(
                               i_BrokerID
                              ,i_TradingDay
                              ,i_ExchangeID
                              ,i_SettleProductGroupList
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_SetFinishedSettlement;

  /*************************************************************************
  $spDesc 结算回退
  *************************************************************************/
  PROCEDURE up_Back2UnSettled
  (
     i_BrokerID IN PKGS_DATATYPE.STY_BROKERID  --经纪公司代码
    ,i_TradingDay IN PKGS_DATATYPE.STY_DATE  --交易日期
    ,i_SettleProductGroupList IN TYT_SETTLEPRODUCTGROUPMODE  --结算对象
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作员代码
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回码
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_Settle.up_Back2UnSettled';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '结算回退';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '结算控制平台', '结算回退');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_Settle.up_Back2UnSettled(' ||
                           '''' || trim(i_BrokerID) || ''''
                      || ',' ||
                           '''' || trim(i_TradingDay) || ''''
                      || ',' ||
                           PKGS_Tyt2STRINGEx.uf_Tyt2String(i_SettleProductGroupList)
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_Settle.up_Back2UnSettled(
                               i_BrokerID
                              ,i_TradingDay
                              ,i_SettleProductGroupList
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_Back2UnSettled;

  /*************************************************************************
  $spDesc 查询结算控制平台产品组选择树数据
  *************************************************************************/
  PROCEDURE up_QryProductSettleInfo
  (
     i_tyProductSettleInfo IN TY_PRODUCTSETTLEINFO  --查询条件
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作员代码
    ,o_curDataTree OUT NOCOPY PKGS_DATATYPE.TYPEREFCURSOR  --查询结果游标
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回码
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_Settle.up_QryProductSettleInfo';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '查询结算控制平台产品组选择树数据';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '结算控制平台', '查询结算控制平台产品组选择树数据');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_Settle.up_QryProductSettleInfo(' ||
                           i_tyProductSettleInfo.uf_toString()
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_curDataTree'
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_Settle.up_QryProductSettleInfo(
                               i_tyProductSettleInfo
                              ,o_curDataTree
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_QryProductSettleInfo;

  /*************************************************************************
  $spDesc 更新结算状态
  *************************************************************************/
  PROCEDURE up_updSettleStatus
  (
     i_tyt_productStatus IN TYT_PRODUCTSTATUS  --产品
    ,i_tySettleTaskRecord IN TY_SETTLETASKRECORD  --结算任务
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作员代码
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回码
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_Settle.up_updSettleStatus';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '更新结算状态';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '结算控制平台', '更新结算状态');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_Settle.up_updSettleStatus(' ||
                           PKGS_Tyt2STRING.uf_Tyt2String(i_tyt_productStatus)
                      || ',' ||
                           i_tySettleTaskRecord.uf_toString()
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_Settle.up_updSettleStatus(
                               i_tyt_productStatus
                              ,i_tySettleTaskRecord
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_updSettleStatus;

END PKGI_Settle;
/

