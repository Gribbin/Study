create TYPE Ty_BrokerUserEvent AS OBJECT
(
    BrokerID CHAR(10),  --经纪公司代码
    UserID CHAR(15),  --用户代码
    UserEventType CHAR(1),  --用户事件类型
    EventSequenceNo NUMBER(8),  --用户事件序号
    EventDate CHAR(8),  --事件发生日期
    EventTime CHAR(8),  --事件发生时间
    UserEventInfo CHAR(1024),  --用户事件信息
    InvestorID CHAR(12),  --投资者代码
    InstrumentID CHAR(30),  --合约代码
    DRIdentityID NUMBER(4),  --交易中心代码
    ExchangeID CHAR(8),  --交易所代码
    InvestUnitID CHAR(16),  --投资单元代码

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_BrokerUserEvent RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

