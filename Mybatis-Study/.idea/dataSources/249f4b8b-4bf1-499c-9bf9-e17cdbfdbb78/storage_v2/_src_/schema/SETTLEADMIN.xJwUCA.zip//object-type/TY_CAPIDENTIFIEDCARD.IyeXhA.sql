create TYPE Ty_CAPIdentifiedCard AS OBJECT
(
    BrokerID CHAR(10),  --经纪公司代码
    InvestorID CHAR(12),  --投资者代码
    IdentifiedCardType CHAR(1),  --证件类型
    IdentifiedCardNo CHAR(50),  --证件号码
    InstitutionExtraCode CHAR(50),  --附加码
    DepartmentID CHAR(12),  --组织架构代码
    IsEmail NUMBER(1),  --是否接收电子邮件
    IsSMS NUMBER(1),  --是否接收短信
    RiskLevel CHAR(1),  --风险等级
    ContractCode CHAR(40),  --合同编号
    Memo CHAR(160),  --备注

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_CAPIdentifiedCard RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

