create TYPE BODY Ty_CheckInvestor IS

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_CheckInvestor RETURN SELF AS RESULT IS
  BEGIN
    RETURN;
  END;

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2 IS
    l_string VARCHAR2(4000);
  BEGIN
    l_string:='ty_CheckInvestor('
      || 'BrokerID=>' || '''' || trim(BrokerID) || '''' --经纪公司代码
      || ',Systype=>' || '''' || trim(Systype) || '''' --业务账户类型
      || ',InvestorID=>' || '''' || trim(InvestorID) || '''' --投资者代码
      || ',IdentifiedCardType=>' || '''' || trim(IdentifiedCardType) || '''' --证件类型
      || ',IdentifiedCardNo=>' || '''' || trim(IdentifiedCardNo) || '''' --证件号码
      || ',Mobile=>' || '''' || trim(Mobile) || '''' --手机
      || ')';


    RETURN l_string;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN NULL;
  END;



END;
/

