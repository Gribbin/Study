create TYPE BODY Ty_BrokerWithdrawAlm IS

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_BrokerWithdrawAlm RETURN SELF AS RESULT IS
  BEGIN
    RETURN;
  END;

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2 IS
    l_string VARCHAR2(4000);
  BEGIN
    l_string:='ty_BrokerWithdrawAlm('
      || 'BrokerID=>' || '''' || trim(BrokerID) || '''' --经纪公司代码
      || ',WithdrawAlgorithm=>' || '''' || trim(WithdrawAlgorithm) || '''' --可提资金算法
      || ',UsingRatio=>' || NVL(to_char(UsingRatio),'NULL')--资金使用率
      || ',IncludeCloseProfit=>' || '''' || trim(IncludeCloseProfit) || '''' --可提是否包含平仓盈利
      || ',AllWithoutTrade=>' || '''' || trim(AllWithoutTrade) || '''' --本日无仓且无成交客户是否受可提比例限制
      || ',AvailIncludeCloseProfit=>' || '''' || trim(AvailIncludeCloseProfit) || '''' --可用是否包含平仓盈利
      || ',IsBrokerUserEvent=>' || '''' || trim(IsBrokerUserEvent) || '''' --是否启用用户事件
      || ',CurrencyID=>' || '''' || trim(CurrencyID) || '''' --币种
      || ',FundMortgageRatio=>' || NVL(to_char(FundMortgageRatio),'NULL')--货币质押比率
      || ',BalanceAlgorithm=>' || '''' || trim(BalanceAlgorithm) || '''' --权益算法
      || ')';


    RETURN l_string;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN NULL;
  END;



END;
/

