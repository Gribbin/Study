create TYPE Ty_AMLSSReportHis AS OBJECT
(
    TradingDay CHAR(8),  --交易日
    BrokerID CHAR(10),  --经纪公司代码
    GenerateDay CHAR(8),  --生成日期
    GenSequenceID NUMBER(8),  --当日生成批次编号
    ReportTypeID CHAR(2),  --交易报告类型标识
    ReportType CHAR(1),  --报文类型
    InvestorID CHAR(12),  --投资者代码
    CharacterID CHAR(4),  --可疑特征代码
    TouchDay CHAR(8),  --可疑交易发生日期
    AMLGenStatus CHAR(1),  --数据来源
    DrawDay CHAR(8),  --检查日期
    InvestorType CHAR(2),  --投资者类型
    InvestorName VARCHAR2(80),  --投资者名称
    IdentifiedCardType CHAR(2),  --证件类型
    IdentifiedCardNo CHAR(50),  --证件号码
    Telephone CHAR(40),  --联系电话
    Address CHAR(100),  --通讯地址
    FutureAccount CHAR(14),  --期货账号
    FutureCurrency CHAR(3),  --期货账号币种
    AccountID CHAR(14),  --投资者账号
    CurrencyID CHAR(3),  --投资者账号币种
    BankAccount CHAR(40),  --银行账户
    OpenBank CHAR(100),  --银行账户的开户行
    Corporation VARCHAR2(80),  --法人代表
    CorporationIDCardType CHAR(2),  --法人证件类型
    CorporationIDCardNo CHAR(50),  --法人证件号码

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_AMLSSReportHis RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

