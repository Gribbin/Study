create PACKAGE BODY PKG_UNIFYACCOUNTINTERFACE AS

  /*---- 生成报送表
  PROCEDURE up_CrtSendInformation
  (
    o_ReturnNo      OUT     PKGS_DATATYPE.STY_RETCODE,                  ---- 返回码
    o_ReturnMsg     OUT     PKGS_DATATYPE.STY_RETMSG,                 ---- 返回信息
    i_OperatorID    IN      PKGS_DATATYPE.STY_OperatorID,                ---- 操作员代码
    i_BrokerID      IN      PKGS_DATATYPE.STY_BrokerID,                  ---- 经纪公司代码
    i_ProcessID     IN      t_InvestorExchangeApply.Processid%TYPE    ---- 业务流水号
  )
  AS
    l_TypeInvestorExchangeApply    TypeInvestorExchangeApply;         ---- 投资者交易所交易编码申请信息类型
  BEGIN

    l_TypeInvestorExchangeApply := typeinvestorexchangeapply(NULL, NULL, i_BrokerID, NULL, NULL, NULL, i_ProcessID, NULL);
    pkg_UnifyAccountManager.up_CrtSendInformation(o_ReturnNo, o_ReturnMsg, i_OperatorID, pkg_Define.UOASM_ByAPI, l_TypeInvestorExchangeApply);
  END up_CrtSendInformation;*/

  ---- 申请表报送状态切换
  PROCEDURE UP_SWITCHISSEND
  (
    I_OPERATORID IN PKGS_DATATYPE.STY_OPERATORID, ---- 操作员ID
    I_BROKERID   IN T_INVESTOREXCHANGEAPPLY.BROKERID%TYPE, ---- 开户审核信息类型
    I_PROCESSID  IN T_INVESTOREXCHANGEAPPLY.PROCESSID%TYPE, ---- 开户审核信息类型
    I_NEXTISSEND IN T_INVESTOREXCHANGEAPPLY.ISSEND%TYPE, ---- 开户审核信息类型
    O_RETURNNO   OUT PKGS_DATATYPE.STY_RETCODE, ---- 执行结果返回
    O_RETURNMSG  OUT PKGS_DATATYPE.STY_RETMSG ---- 返回信息
  ) AS
    L_TYPEINVESTOREXCHANGEAPPLY TY_INVESTOREXCHANGEAPPLY; ---- 投资者交易所交易编码申请信息类型
  BEGIN

    PKGS_LOG.UP_TRACE('up_SwitchIsSend',
                      I_OPERATORID);
    PKGS_LOG.UP_TRACE('up_SwitchIsSend',
                      I_BROKERID);
    PKGS_LOG.UP_TRACE('up_SwitchIsSend',
                      I_PROCESSID);
    PKGS_LOG.UP_TRACE('up_SwitchIsSend',
                      I_NEXTISSEND);

    L_TYPEINVESTOREXCHANGEAPPLY := TY_INVESTOREXCHANGEAPPLY(NULL,
                                                            NULL,
                                                            I_BROKERID,
                                                            NULL,
                                                            NULL,
                                                            NULL,
                                                            I_PROCESSID,
                                                            I_NEXTISSEND,
                                                            NULL,
                                                            NULL,
                                                            NULL,
                                                            NULL);
    PKGI_ACCOUNTMGRT.UP_CHGINVESTOREXCHANGEAPPLY(L_TYPEINVESTOREXCHANGEAPPLY,
                                                 '',
                                                 '',
                                                 I_OPERATORID,
                                                 O_RETURNNO,
                                                 O_RETURNMSG,
                                                 0);
    --pkgi_UnifyAccountManager.up_SwitchIsSend(o_ReturnNo, o_ReturnMsg, i_OperatorID, l_TypeInvestorExchangeApply);
  END UP_SWITCHISSEND;

  ---- 增加投资者行业编码通讯信息
  PROCEDURE UP_CRTSEQ_BUSINESSRANGE
  (
    O_RETURNNO   OUT PKGS_DATATYPE.STY_RETCODE, ---- 返回码
    O_RETURNMSG  OUT PKGS_DATATYPE.STY_RETMSG, ---- 返回信息
    I_BROKERID   IN CHAR, ---- 经纪公司代码
    I_PROCESSID  IN CHAR, ---- 业务流水号
    I_INDUSTRYID IN CHAR, ---- 行业编码
    I_OPERATORID IN PKGS_DATATYPE.STY_OPERATORID ---- 操作员代码
  ) AS
    L_TY_SEQ_BUSINESSRANGE TY_SEQ_BUSINESSRANGE;
  BEGIN
    L_TY_SEQ_BUSINESSRANGE := TY_SEQ_BUSINESSRANGE(I_BROKERID,
                                                   I_PROCESSID,
                                                   I_INDUSTRYID);
    PKGI_UNIFYOPENACCOUNTMGRT.UP_INSSEQ_BUSINESSRANGE(L_TY_SEQ_BUSINESSRANGE,
                                                      '',
                                                      '',
                                                      '',
                                                      O_RETURNNO,
                                                      O_RETURNMSG,
                                                      0);
    --pkg_UnifyAccountManager.up_Crtseq_BusinessRange(o_ReturnNo,o_ReturnMsg,i_OperatorID,l_ty_Seq_BusinessRange);
  END UP_CRTSEQ_BUSINESSRANGE;

  ---- 增加投资者交易所特殊问题通讯信息
  PROCEDURE UP_CRTSEQ_EXSPECOPTION
  (
    O_RETURNNO        OUT PKGS_DATATYPE.STY_RETCODE, ---- 返回码
    O_RETURNMSG       OUT PKGS_DATATYPE.STY_RETMSG, ---- 返回信息
    I_BROKERID        IN CHAR, ---- 经纪公司代码
    I_PROCESSID       IN CHAR, ---- 业务流水号
    I_QUESTIONID      IN CHAR, ---- 特有信息编号
    I_QUESTIONCONTENT IN CHAR, ---- 特有信息说明
    I_OPTIONID        IN CHAR, ---- 选项编号
    I_OPTIONCONTENT   IN CHAR, ---- 选项说明
    I_ISSELECTED      IN NUMBER, ---- 是否选中标志
    I_OPERATORID      IN PKGS_DATATYPE.STY_OPERATORID ---- 操作员代码
  ) AS
    L_TY_SEQ_EXSPECOPTION TY_SEQ_EXSPECOPTION;
  BEGIN
    L_TY_SEQ_EXSPECOPTION := TY_SEQ_EXSPECOPTION(I_BROKERID,
                                                 I_PROCESSID,
                                                 I_QUESTIONID,
                                                 I_QUESTIONCONTENT,
                                                 I_OPTIONID,
                                                 I_OPTIONCONTENT,
                                                 I_ISSELECTED);
    --pkg_UnifyAccountManager.up_Crtseq_ExSpecOption(o_ReturnNo,o_ReturnMsg,i_OperatorID,l_ty_Seq_ExSpecOption);
    PKGI_UNIFYOPENACCOUNTMGRT.UP_INSSEQ_EXSPECOPTION(L_TY_SEQ_EXSPECOPTION,
                                                     '',
                                                     '',
                                                     '',
                                                     O_RETURNNO,
                                                     O_RETURNMSG,
                                                     0);
  END UP_CRTSEQ_EXSPECOPTION;

  ---- 新增投资者银行账户通讯信息
  PROCEDURE UP_CRTSEQ_BANKACCOUNT
  (
    O_RETURNNO    OUT PKGS_DATATYPE.STY_RETCODE, ---- 返回码
    O_RETURNMSG   OUT PKGS_DATATYPE.STY_RETMSG, ---- 返回信息
    I_BROKERID    IN CHAR, ---- 经纪公司代码
    I_PROCESSID   IN CHAR, ---- 业务流水号
    I_ACCOUNTSEQ  IN NUMBER, ---- 银行帐号序列号
    I_BANKID      IN CHAR, ---- 开户银行代码
    I_ACCOUNTNO   IN CHAR, ---- 银行帐号
    I_ACCOUNTNAME IN CHAR, ---- 账户户名
    I_BRANCHNAME  IN CHAR, ---- 开户行网点
    I_CURRENCY    IN CHAR, ---- 币种代码
    I_OPERATORID  IN PKGS_DATATYPE.STY_OPERATORID ---- 操作员代码
  ) AS
    L_TY_SEQ_BANKACCOUNT TY_SEQ_BANKACCOUNT;
  BEGIN
    L_TY_SEQ_BANKACCOUNT := TY_SEQ_BANKACCOUNT(I_BROKERID,
                                               I_PROCESSID,
                                               I_ACCOUNTSEQ,
                                               I_BANKID,
                                               I_ACCOUNTNO,
                                               I_ACCOUNTNAME,
                                               I_BRANCHNAME);
    --pkg_UnifyAccountManager.up_Crtseq_bankaccount(o_ReturnNo,o_ReturnMsg,i_OperatorID,l_ty_Seq_bankaccount);
    PKGI_UNIFYOPENACCOUNTMGRT.UP_INSSEQ_BANKACCOUNT(L_TY_SEQ_BANKACCOUNT,
                                                    '',
                                                    '',
                                                    '',
                                                    O_RETURNNO,
                                                    O_RETURNMSG,
                                                    0);
  END UP_CRTSEQ_BANKACCOUNT;

  ---- 新增投资者银行账户通讯信息
  PROCEDURE UP_CRTSEQ_LEDREFBANKACC
  (
    O_RETURNNO    OUT PKGS_DATATYPE.STY_RETCODE, ---- 返回码
    O_RETURNMSG   OUT PKGS_DATATYPE.STY_RETMSG, ---- 返回信息
    I_BROKERID    IN CHAR, ---- 经纪公司代码
    I_PROCESSID   IN CHAR, ---- 业务流水号
    I_ACCOUNTSEQ  IN NUMBER, ---- 银行帐号序列号
    I_ACCOUNTTYPE IN CHAR, ---- 开户银行代码
    I_BANKACCOUNT IN CHAR, ---- 银行帐号
    I_OPERATORID  IN PKGS_DATATYPE.STY_OPERATORID ---- 操作员代码
  ) AS
    L_TY_SEQ_LEDREFBANKACC TY_SEQ_LEDREFBANKACC;
  BEGIN
    L_TY_SEQ_LEDREFBANKACC := TY_SEQ_LEDREFBANKACC(I_BROKERID,
                                                   I_PROCESSID,
                                                   I_ACCOUNTSEQ,
                                                   I_ACCOUNTTYPE,
                                                   I_BANKACCOUNT);
    --pkg_UnifyAccountManager.up_CrtSeq_LedRefBankAcc(o_ReturnNo,o_ReturnMsg,i_OperatorID,l_ty_Seq_LedRefBankAcc);
    PKGI_UNIFYOPENACCOUNTMGRT.UP_INSSEQ_LEDREFBANKACC(L_TY_SEQ_LEDREFBANKACC,
                                                      '',
                                                      '',
                                                      '',
                                                      O_RETURNNO,
                                                      O_RETURNMSG,
                                                      0);
  END UP_CRTSEQ_LEDREFBANKACC;

  ---- 新增期货资管托管账户通讯信息
  PROCEDURE UP_CRTSEQ_AMTRUSTEEACCOUNT
  (
    O_RETURNNO    OUT PKGS_DATATYPE.STY_RETCODE, ---- 返回码
    O_RETURNMSG   OUT PKGS_DATATYPE.STY_RETMSG, ---- 返回信息
    I_BROKERID    IN CHAR, ---- 经纪公司代码
    I_PROCESSID   IN CHAR, ---- 业务流水号
    I_ACCOUNTSEQ  IN NUMBER, ---- 银行帐号序列号
    I_BANKID      IN CHAR, ---- 开户银行代码
    I_ACCOUNTNO   IN CHAR, ---- 银行帐号
    I_ACCOUNTNAME IN CHAR, ---- 银行帐号
    I_BRANCHNAME  IN CHAR, ---- 银行帐号
    I_OPERATORID  IN PKGS_DATATYPE.STY_OPERATORID ---- 操作员代码
  ) AS
    L_TY_SEQ_AMTRUSTEEACCOUNT TY_SEQ_AMTRUSTEEACCOUNT;
  BEGIN
    L_TY_SEQ_AMTRUSTEEACCOUNT := TY_SEQ_AMTRUSTEEACCOUNT(I_BROKERID,
                                                         I_PROCESSID,
                                                         I_ACCOUNTSEQ,
                                                         I_BANKID,
                                                         I_ACCOUNTNO,
                                                         I_ACCOUNTNAME,
                                                         I_BRANCHNAME);
    --pkg_UnifyAccountManager.up_CrtSeq_AmTrusteeAccount(o_ReturnNo,o_ReturnMsg,i_OperatorID,l_ty_Seq_AmTrusteeAccount);
    PKGI_UNIFYOPENACCOUNTMGRT.UP_INSSEQ_AMTRUSTEEACCOUNT(L_TY_SEQ_AMTRUSTEEACCOUNT,
                                                         '',
                                                         '',
                                                         '',
                                                         O_RETURNNO,
                                                         O_RETURNMSG,
                                                         0);
  END UP_CRTSEQ_AMTRUSTEEACCOUNT;

  ---- 新增期货中转账户通讯信息
  PROCEDURE UP_CRTSEQ_AMTRANSFERACCOUNT
  (
    O_RETURNNO    OUT PKGS_DATATYPE.STY_RETCODE, ---- 返回码
    O_RETURNMSG   OUT PKGS_DATATYPE.STY_RETMSG, ---- 返回信息
    I_BROKERID    IN CHAR, ---- 经纪公司代码
    I_PROCESSID   IN CHAR, ---- 业务流水号
    I_ACCOUNTSEQ  IN NUMBER, ---- 银行帐号序列号
    I_BANKID      IN CHAR, ---- 开户银行代码
    I_ACCOUNTNO   IN CHAR, ---- 银行帐号
    I_ACCOUNTNAME IN CHAR, ---- 银行帐号
    I_BRANCHNAME  IN CHAR, ---- 银行帐号
    I_OPERATORID  IN PKGS_DATATYPE.STY_OPERATORID ---- 操作员代码
  ) AS
    L_TY_SEQ_AMTRANSFERACCOUNT TY_SEQ_AMTRANSFERACCOUNT;
  BEGIN
    L_TY_SEQ_AMTRANSFERACCOUNT := TY_SEQ_AMTRANSFERACCOUNT(I_BROKERID,
                                                           I_PROCESSID,
                                                           I_ACCOUNTSEQ,
                                                           I_BANKID,
                                                           I_ACCOUNTNO,
                                                           I_ACCOUNTNAME,
                                                           I_BRANCHNAME);
    --pkg_UnifyAccountManager.up_CrtSeq_AmTransferAccount(o_ReturnNo,o_ReturnMsg,i_OperatorID,l_ty_Seq_AmTransferAccount);
    PKGI_UNIFYOPENACCOUNTMGRT.UP_INSSEQ_AMTRANSFERACCOUNT(L_TY_SEQ_AMTRANSFERACCOUNT,
                                                          '',
                                                          '',
                                                          '',
                                                          O_RETURNNO,
                                                          O_RETURNMSG,
                                                          0);
  END UP_CRTSEQ_AMTRANSFERACCOUNT;

  ---- 新增参考证件信息通讯信息
  PROCEDURE UP_CRTSEQ_REFERENCEDOC
  (
    O_RETURNNO   OUT PKGS_DATATYPE.STY_RETCODE, ---- 返回码
    O_RETURNMSG  OUT PKGS_DATATYPE.STY_RETMSG, ---- 返回信息
    I_BROKERID   IN CHAR, ---- 经纪公司代码
    I_PROCESSID  IN CHAR, ---- 业务流水号
    I_IDTYPE     IN CHAR, ---- 参考证件类型
    I_DOCID      IN CHAR, ---- 参考证件号码
    I_OPERATORID IN PKGS_DATATYPE.STY_OPERATORID ---- 操作员代码
  ) AS
    L_TY_SEQ_REFERENCEDOC TY_SEQ_REFERENCEDOC;
  BEGIN
    L_TY_SEQ_REFERENCEDOC := TY_SEQ_REFERENCEDOC(I_BROKERID,
                                                 I_PROCESSID,
                                                 I_IDTYPE,
                                                 I_DOCID);
    --pkg_UnifyAccountManager.up_CrtSeq_ReferenceDoc(o_ReturnNo,o_ReturnMsg,i_OperatorID,l_ty_Seq_ReferenceDoc);
    PKGI_UNIFYOPENACCOUNTMGRT.UP_INSSEQ_REFERENCEDOC(L_TY_SEQ_REFERENCEDOC,
                                                     '',
                                                     '',
                                                     '',
                                                     O_RETURNNO,
                                                     O_RETURNMSG,
                                                     0);
  END UP_CRTSEQ_REFERENCEDOC;

  ---- 新增参考证件信息通讯信息
  PROCEDURE UP_CRTSEQ_LEGALREFERENCEDOC
  (
    O_RETURNNO   OUT PKGS_DATATYPE.STY_RETCODE, ---- 返回码
    O_RETURNMSG  OUT PKGS_DATATYPE.STY_RETMSG, ---- 返回信息
    I_BROKERID   IN CHAR, ---- 经纪公司代码
    I_PROCESSID  IN CHAR, ---- 业务流水号
    I_IDTYPE     IN CHAR, ---- 参考证件类型
    I_DOCID      IN CHAR, ---- 参考证件号码
    I_OPERATORID IN PKGS_DATATYPE.STY_OPERATORID ---- 操作员代码
  ) AS
    L_TY_SEQ_LEGALREFERENCEDOC TY_SEQ_LEGALREFERENCEDOC;
  BEGIN
    L_TY_SEQ_LEGALREFERENCEDOC := TY_SEQ_LEGALREFERENCEDOC(I_BROKERID,
                                                           I_PROCESSID,
                                                           I_IDTYPE,
                                                           I_DOCID);
    --pkg_UnifyAccountManager.up_CrtSeq_LegalReferenceDoc(o_ReturnNo,o_ReturnMsg,i_OperatorID,l_ty_Seq_LegalReferenceDoc);
    PKGI_UNIFYOPENACCOUNTMGRT.UP_INSSEQ_LEGALREFERENCEDOC(L_TY_SEQ_LEGALREFERENCEDOC,
                                                          '',
                                                          '',
                                                          '',
                                                          O_RETURNNO,
                                                          O_RETURNMSG,
                                                          0);
  END UP_CRTSEQ_LEGALREFERENCEDOC;

  --zhao.jl 20170503 CTP00431
  ---- 新增份额持有人信息
  PROCEDURE UP_CRTSEQ_SHARE_HOLDERS
  (
    O_RETURNNO               OUT PKGS_DATATYPE.STY_RETCODE, ---- 返回码
    O_RETURNMSG              OUT PKGS_DATATYPE.STY_RETMSG, ---- 返回信息
    I_BROKERID               IN CHAR, ---- 经纪公司代码
    I_PROCESSID              IN CHAR, ---- 业务流水号
    I_SHID                   IN CHAR,
    I_SHPID                  IN CHAR,
    I_SHARE_HOLDER_TYPE      IN CHAR,
    I_SHARE_HOLDER_NAME      IN CHAR,
    I_SHARE_HOLDER_IDTYPE    IN CHAR,
    I_SHARE_HOLDER_ID        IN CHAR,
    I_SHARE_HOLDING_RATIO    IN CHAR,
    I_SHARE_HOLDING_AMOUNT   IN CHAR,
    I_PRODUCT_MGR_NAME       IN CHAR,
    I_PRODUCT_CODE           IN CHAR,
    I_PRODUCT_SCALE          IN CHAR,
    I_OPERATORID             IN PKGS_DATATYPE.STY_OPERATORID, ---- 操作员代码
    I_SHARE_HOLDING_CURRENCY IN CHAR,
    I_PRODUCT_CURRENCY       IN CHAR
  ) AS
    L_TY_SEQ_SHAREHOLDERS TY_SEQ_SHAREHOLDERS;
  BEGIN
    L_TY_SEQ_SHAREHOLDERS := TY_SEQ_SHAREHOLDERS(I_BROKERID,
                                                 I_PROCESSID,
                                                 I_SHID,
                                                 I_SHPID,
                                                 I_SHARE_HOLDER_TYPE,
                                                 I_SHARE_HOLDER_NAME,
                                                 I_SHARE_HOLDER_IDTYPE,
                                                 I_SHARE_HOLDER_ID,
                                                 I_SHARE_HOLDING_RATIO,
                                                 I_SHARE_HOLDING_AMOUNT,
                                                 I_PRODUCT_MGR_NAME,
                                                 I_PRODUCT_CODE,
                                                 I_PRODUCT_SCALE,
                                                 I_SHARE_HOLDING_CURRENCY,
                                                 I_PRODUCT_CURRENCY);
    PKGI_UNIFYOPENACCOUNTMGRT.UP_INSSEQ_SHAREHOLDERS(L_TY_SEQ_SHAREHOLDERS,
                                                     '',
                                                     '',
                                                     '',
                                                     O_RETURNNO,
                                                     O_RETURNMSG,
                                                     0);
  END UP_CRTSEQ_SHARE_HOLDERS;
  --CTP00431

  ---- 修改统一开户通讯信息  （mainapi不调用，mainapi调用UP_CRTSEQ_PROCESSCO）
  PROCEDURE UP_CRTSEQ_PROCESS
  (
    O_RETURNNO                 OUT PKGS_DATATYPE.STY_RETCODE, ---- 返回码
    O_RETURNMSG                OUT PKGS_DATATYPE.STY_RETMSG, ---- 返回信息
    IO_BROKERID                IN CHAR, ---- 经纪公司代码
    IO_PROCESSID               IN CHAR, ---- 业务流水号
    IO_SERIAL                  IN NUMBER, ---- 流水序列号
    IO_SEQNO                   IN NUMBER, ---- 流水号
    IO_SENDDATE                IN CHAR, ---- 发送日期
    IO_SENDTIME                IN CHAR, ---- 发送时间
    IO_RESPONSEDATE            IN CHAR, ---- 响应日期
    IO_PROCESSSTATUS           IN CHAR, ---- 流程状态
    IO_PROCESSDATE             IN CHAR, ---- 流程日期
    IO_PROCESSTIME             IN CHAR, ---- 流程时间
    IO_PROCESSTYPE             IN CHAR, ---- 流程功能类型
    IO_BUSINESSTYPE            IN CHAR, ---- 业务类型
    IO_CFMMCRETURNCODE         IN CHAR, ---- 监控中心返回码
    IO_CFMMCRETURNMSG          IN CHAR, ---- 监控中心返回提示信息
    IO_EXRETURNCODE            IN CHAR, ---- 交易所返回码
    IO_EXRETURNMSG             IN CHAR, ---- 交易所返回提示信息
    IO_CLIENTTYPE              IN CHAR, ---- 客户类型
    IO_FUTURESID               IN CHAR, ---- 监控中心为客户分配的代码
    IO_EXCHANGEID              IN CHAR, ---- 交易所代码
    IO_COMPANYID               IN CHAR, ---- 期货公司统一编码
    IO_EXCOMPANYID             IN CHAR, ---- 期货公司在交易所的会员号
    IO_EXCLIENTIDTYPE          IN CHAR, ---- 交易编码类型
    IO_EXCLIENTID              IN CHAR, ---- 交易编码
    IO_CLIENTNAME              IN CHAR, ---- 姓名
    IO_NOCID                   IN CHAR, ---- 组织机构代码
    IO_IDTYPE                  IN CHAR, ---- 证件类型
    IO_ID_ORIGINAL             IN CHAR, ---- 原始输入的证件号码
    IO_ID_TRANSFORMED          IN CHAR, ---- 转换后的证件号码
    IO_BIRTHDAY                IN CHAR, ---- 出生日期
    IO_GENDER                  IN CHAR, ---- 性别
    IO_CLASSIFY                IN CHAR, ---- 客户分类码
    IO_COMPCLIENTID            IN CHAR, ---- 客户内部资金账户
    IO_ORGANTYPE               IN CHAR, ---- 单位性质
    IO_TAXNO                   IN CHAR, ---- 税务登记号
    IO_LICENSENO               IN CHAR, ---- 营业执照号
    IO_REGISTRYCAPITAL         IN NUMBER, ---- 注册资本
    IO_LEGALPERSON             IN CHAR, ---- 法人代表
    IO_CONTACTPERSON           IN CHAR, ---- 联系人姓名
    IO_PHONE_COUNTRYCODE       IN CHAR, ---- 联系电话中的国家代码
    IO_PHONE_AREACODE          IN CHAR, ---- 联系电话中的区号
    IO_PHONE_NUMBER            IN CHAR, ---- 联系电话中的电话号码
    IO_ADDR_ZIPCODE            IN CHAR, ---- 邮政编码
    IO_ADDR_COUNTRY            IN CHAR, ---- 联系地址中的国家
    IO_ADDR_PROVINCE           IN CHAR, ---- 联系地址中的省/自治区/直辖市
    IO_ADDR_CITY               IN CHAR, ---- 联系地址中的市/县/区
    IO_ADDR_ADDRESS            IN CHAR, ---- 联系地址中的地址
    IO_AUTH_NAME               IN CHAR, ---- 开户授权人姓名
    IO_AUTH_IDTYPE             IN CHAR, ---- 开户授权人的证件类型
    IO_AUTH_ID                 IN CHAR, ---- 开户授权人证件号码
    IO_AUTH_PHONE_COUNTRYCODE  IN CHAR, ---- 开户授权人联系电话中的国家代码
    IO_AUTH_PHONE_AREACODE     IN CHAR, ---- 开户授权人联系电话中的区号
    IO_AUTH_PHONE_NUMBER       IN CHAR, ---- 开户授权人联系电话中的电话号码
    IO_AUTH_ADDR_ZIPCODE       IN CHAR, ---- 开户授权人邮政编码
    IO_AUTH_ADDR_COUNTRY       IN CHAR, ---- 开户授权人联系地址中的国家
    IO_AUTH_ADDR_PROVINCE      IN CHAR, ---- 开户授权人联系地址中的省/自治区/直辖市
    IO_AUTH_ADDR_CITY          IN CHAR, ---- 开户授权人联系地址中的市/县/区
    IO_AUTH_ADDR_ADDRESS       IN CHAR, ---- 开户授权人联系地址中的地址
    IO_ORDER_NAME              IN CHAR, ---- 指定下单人姓名
    IO_ORDER_IDTYPE            IN CHAR, ---- 指定下单人的证件类型
    IO_ORDER_ID                IN CHAR, ---- 指定下单人证件号码
    IO_ORDER_PHONE_COUNTRYCODE IN CHAR, ---- 指定下单人联系电话中的国家代码
    IO_ORDER_PHONE_AREACODE    IN CHAR, ---- 指定下单人联系电话中的区号
    IO_ORDER_PHONE_NUMBER      IN CHAR, ---- 指定下单人联系电话中的电话号码
    IO_ORDER_ADDR_ZIPCODE      IN CHAR, ---- 指定下单人邮政编码
    IO_ORDER_ADDR_COUNTRY      IN CHAR, ---- 指定下单人联系地址中的国家
    IO_ORDER_ADDR_PROVINCE     IN CHAR, ---- 指定下单人联系地址中的省/自治区/直辖市
    IO_ORDER_ADDR_CITY         IN CHAR, ---- 指定下单人联系地址中的市/县/区
    IO_ORDER_ADDR_ADDRESS      IN CHAR, ---- 指定下单人联系地址中的地址
    IO_FUND_NAME               IN CHAR, ---- 资金调拨人姓名
    IO_FUND_IDTYPE             IN CHAR, ---- 资金调拨人的证件类型
    IO_FUND_ID                 IN CHAR, ---- 资金调拨人证件号码
    IO_FUND_PHONE_COUNTRYCODE  IN CHAR, ---- 资金调拨人联系电话中的国家代码
    IO_FUND_PHONE_AREACODE     IN CHAR, ---- 资金调拨人联系电话中的区号
    IO_FUND_PHONE_NUMBER       IN CHAR, ---- 资金调拨人联系电话中的电话号码
    IO_FUND_ADDR_ZIPCODE       IN CHAR, ---- 资金调拨人邮政编码
    IO_FUND_ADDR_COUNTRY       IN CHAR, ---- 资金调拨人联系地址中的国家
    IO_FUND_ADDR_PROVINCE      IN CHAR, ---- 资金调拨人联系地址中的省/自治区/直辖市
    IO_FUND_ADDR_CITY          IN CHAR, ---- 资金调拨人联系地址中的市/县/区
    IO_FUND_ADDR_ADDRESS       IN CHAR, ---- 资金调拨人联系地址中的地址
    IO_BILL_NAME               IN CHAR, ---- 结算单确认人姓名
    IO_BILL_IDTYPE             IN CHAR, ---- 结算单确认人的证件类型
    IO_BILL_ID                 IN CHAR, ---- 结算单确认人证件号码
    IO_BILL_PHONE_COUNTRYCODE  IN CHAR, ---- 结算单确认人联系电话中的国家代码
    IO_BILL_PHONE_AREACODE     IN CHAR, ---- 结算单确认人联系电话中的区号
    IO_BILL_PHONE_NUMBER       IN CHAR, ---- 结算单确认人联系电话中的电话号码
    IO_BILL_ADDR_ZIPCODE       IN CHAR, ---- 结算单确认人邮政编码
    IO_BILL_ADDR_COUNTRY       IN CHAR, ---- 结算单确认人联系地址中的国家
    IO_BILL_ADDR_PROVINCE      IN CHAR, ---- 结算单确认人联系地址中的省/自治区/直辖市
    IO_BILL_ADDR_CITY          IN CHAR, ---- 结算单确认人联系地址中的市/县/区
    IO_BILL_ADDR_ADDRESS       IN CHAR, ---- 结算单确认人联系地址中的地址
    IO_UPDATEFLAG              IN CHAR, ---- 更新状态
    IO_OPERATORID              IN CHAR, ---- 录入员代码
    IO_OPERATEDATE             IN CHAR, ---- 录入日期
    IO_OPERATETIME             IN CHAR, ---- 录入时间
    I_OPERATORID               IN PKGS_DATATYPE.STY_OPERATORID, ---- 操作员代码
    --zhao.jl 20170503 CTP00431
    IO_HAS_FUND_MGR             IN CHAR,
    IO_FUND_MGR_NAME            IN CHAR,
    IO_FUND_MGR_IDTYPE          IN CHAR,
    IO_FUND_MGR_ID              IN CHAR,
    IO_FUND_MGR_COUNTRYCODE     IN CHAR,
    IO_FUND_MGR_AREACODE        IN CHAR,
    IO_FUND_MGR_PHONE           IN CHAR,
    IO_FUND_MGR_ADDR_COUNTRY    IN CHAR,
    IO_FUND_MGR_ADDR_PROVINCE   IN CHAR,
    IO_FUND_MGR_ADDR_CITY       IN CHAR,
    IO_FUND_MGR_ADDR            IN CHAR,
    IO_HAS_INVEST_ADV           IN CHAR,
    IO_INVEST_ADV_NAME          IN CHAR,
    IO_INVEST_ADV_IDTYPE        IN CHAR,
    IO_INVEST_ADV_ID            IN CHAR,
    IO_INVEST_ADV_COUNTRYCODE   IN CHAR,
    IO_INVEST_ADV_AREACODE      IN CHAR,
    IO_INVEST_ADV_PHONE         IN CHAR,
    IO_INVEST_ADV_ADDR_COUNTRY  IN CHAR,
    IO_INVEST_ADV_ADDR_PROVINCE IN CHAR,
    IO_INVEST_ADV_ADDR_CITY     IN CHAR,
    IO_INVEST_ADV_ADDR          IN CHAR,
    IO_HAS_SHARE_HOLDERS        IN CHAR,
    --CTP00431
    IO_AppropriaType            IN CHAR,
    IO_RiskBearingCapacity      IN CHAR
  ) AS
    L_TY_SEQ_PROCESS     TY_SEQ_PROCESS;
    L_ADDR_ZIPCODE       CHAR(10);
    L_AUTH_ADDR_ZIPCODE  CHAR(10);
    L_ORDER_ADDR_ZIPCODE CHAR(10);
    L_FUND_ADDR_ZIPCODE  CHAR(10);
    L_BILL_ADDR_ZIPCODE  CHAR(10);
  BEGIN
    L_ADDR_ZIPCODE       := TRIM(IO_ADDR_ZIPCODE);
    L_AUTH_ADDR_ZIPCODE  := TRIM(IO_AUTH_ADDR_ZIPCODE);
    L_ORDER_ADDR_ZIPCODE := TRIM(IO_ORDER_ADDR_ZIPCODE);
    L_FUND_ADDR_ZIPCODE  := TRIM(IO_FUND_ADDR_ZIPCODE);
    L_BILL_ADDR_ZIPCODE  := TRIM(IO_BILL_ADDR_ZIPCODE);
    ----co
    L_TY_SEQ_PROCESS := TY_SEQ_PROCESS(IO_BROKERID,
                                       IO_PROCESSID,
                                       IO_SERIAL,
                                       IO_SEQNO,
                                       IO_SENDDATE,
                                       IO_SENDTIME,
                                       IO_RESPONSEDATE,
                                       IO_PROCESSSTATUS,
                                       IO_PROCESSDATE,
                                       IO_PROCESSTIME,
                                       IO_PROCESSTYPE,
                                       IO_BUSINESSTYPE,
                                       IO_CFMMCRETURNCODE,
                                       IO_CFMMCRETURNMSG,
                                       IO_EXRETURNCODE,
                                       IO_EXRETURNMSG,
                                       IO_CLIENTTYPE,
                                       IO_FUTURESID,
                                       IO_EXCHANGEID,
                                       IO_COMPANYID,
                                       IO_EXCOMPANYID,
                                       IO_EXCLIENTIDTYPE,
                                       IO_EXCLIENTID,
                                       IO_CLIENTNAME,
                                       IO_NOCID,
                                       IO_IDTYPE,
                                       IO_ID_ORIGINAL,
                                       IO_ID_TRANSFORMED,
                                       IO_BIRTHDAY,
                                       IO_GENDER,
                                       IO_CLASSIFY,
                                       IO_COMPCLIENTID,
                                       IO_ORGANTYPE,
                                       IO_TAXNO,
                                       IO_LICENSENO,
                                       IO_REGISTRYCAPITAL,
                                       IO_LEGALPERSON,
                                       IO_CONTACTPERSON,
                                       IO_PHONE_COUNTRYCODE,
                                       IO_PHONE_AREACODE,
                                       IO_PHONE_NUMBER,
                                       L_ADDR_ZIPCODE,
                                       IO_ADDR_COUNTRY,
                                       IO_ADDR_PROVINCE,
                                       IO_ADDR_CITY,
                                       IO_ADDR_ADDRESS,
                                       IO_AUTH_NAME,
                                       IO_AUTH_IDTYPE,
                                       IO_AUTH_ID,
                                       IO_AUTH_PHONE_COUNTRYCODE,
                                       IO_AUTH_PHONE_AREACODE,
                                       IO_AUTH_PHONE_NUMBER,
                                       L_AUTH_ADDR_ZIPCODE,
                                       IO_AUTH_ADDR_COUNTRY,
                                       IO_AUTH_ADDR_PROVINCE,
                                       IO_AUTH_ADDR_CITY,
                                       IO_AUTH_ADDR_ADDRESS,
                                       IO_ORDER_NAME,
                                       IO_ORDER_IDTYPE,
                                       IO_ORDER_ID,
                                       IO_ORDER_PHONE_COUNTRYCODE,
                                       IO_ORDER_PHONE_AREACODE,
                                       IO_ORDER_PHONE_NUMBER,
                                       L_ORDER_ADDR_ZIPCODE,
                                       IO_ORDER_ADDR_COUNTRY,
                                       IO_ORDER_ADDR_PROVINCE,
                                       IO_ORDER_ADDR_CITY,
                                       IO_ORDER_ADDR_ADDRESS,
                                       IO_FUND_NAME,
                                       IO_FUND_IDTYPE,
                                       IO_FUND_ID,
                                       IO_FUND_PHONE_COUNTRYCODE,
                                       IO_FUND_PHONE_AREACODE,
                                       IO_FUND_PHONE_NUMBER,
                                       L_FUND_ADDR_ZIPCODE,
                                       IO_FUND_ADDR_COUNTRY,
                                       IO_FUND_ADDR_PROVINCE,
                                       IO_FUND_ADDR_CITY,
                                       IO_FUND_ADDR_ADDRESS,
                                       IO_BILL_NAME,
                                       IO_BILL_IDTYPE,
                                       IO_BILL_ID,
                                       IO_BILL_PHONE_COUNTRYCODE,
                                       IO_BILL_PHONE_AREACODE,
                                       IO_BILL_PHONE_NUMBER,
                                       L_BILL_ADDR_ZIPCODE,
                                       IO_BILL_ADDR_COUNTRY,
                                       IO_BILL_ADDR_PROVINCE,
                                       IO_BILL_ADDR_CITY,
                                       IO_BILL_ADDR_ADDRESS,
                                       IO_UPDATEFLAG,
                                       IO_OPERATORID,
                                       IO_OPERATEDATE,
                                       IO_OPERATETIME,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       ----特殊法人
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       ----原油
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       IO_HAS_FUND_MGR,
                                       IO_FUND_MGR_NAME,
                                       IO_FUND_MGR_IDTYPE,
                                       IO_FUND_MGR_ID,
                                       IO_FUND_MGR_COUNTRYCODE,
                                       IO_FUND_MGR_AREACODE,
                                       IO_FUND_MGR_PHONE,
                                       IO_FUND_MGR_ADDR_COUNTRY,
                                       IO_FUND_MGR_ADDR_PROVINCE,
                                       IO_FUND_MGR_ADDR_CITY,
                                       IO_FUND_MGR_ADDR,
                                       IO_HAS_INVEST_ADV,
                                       IO_INVEST_ADV_NAME,
                                       IO_INVEST_ADV_IDTYPE,
                                       IO_INVEST_ADV_ID,
                                       IO_INVEST_ADV_COUNTRYCODE,
                                       IO_INVEST_ADV_AREACODE,
                                       IO_INVEST_ADV_PHONE,
                                       IO_INVEST_ADV_ADDR_COUNTRY,
                                       IO_INVEST_ADV_ADDR_PROVINCE,
                                       IO_INVEST_ADV_ADDR_CITY,
                                       IO_INVEST_ADV_ADDR,
                                       IO_HAS_SHARE_HOLDERS,
                                       IO_AppropriaType,
                                       IO_RiskBearingCapacity,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL);
    --pkg_UnifyAccountManager.up_Crtseq_process(o_ReturnNo,o_ReturnMsg,i_OperatorID,l_ty_Seq_process);
    PKGI_UNIFYOPENACCOUNTMGRT.UP_INSSEQ_PROCESS(L_TY_SEQ_PROCESS,
                                                '',
                                                '',
                                                '',
                                                O_RETURNNO,
                                                O_RETURNMSG,
                                                0);
  END UP_CRTSEQ_PROCESS;

  /*20101222 休眠户 begin */
  ---- 修改统一开户通讯信息 （mainapi不调用，mainapi调用UP_CRTSEQ_PROCESSCO）
  PROCEDURE UP_CREATESEQ_PROCESS
  (
    O_RETURNNO                     OUT PKGS_DATATYPE.STY_RETCODE, ---- 返回码
    O_RETURNMSG                    OUT PKGS_DATATYPE.STY_RETMSG, ---- 返回信息
    IO_BROKERID                    IN CHAR, ---- 经纪公司代码
    IO_PROCESSID                   IN CHAR, ---- 业务流水号
    IO_SERIAL                      IN NUMBER, ---- 流水序列号
    IO_SEQNO                       IN NUMBER, ---- 流水号
    IO_SENDDATE                    IN CHAR, ---- 发送日期
    IO_SENDTIME                    IN CHAR, ---- 发送时间
    IO_RESPONSEDATE                IN CHAR, ---- 响应日期
    IO_PROCESSSTATUS               IN CHAR, ---- 流程状态
    IO_PROCESSDATE                 IN CHAR, ---- 流程日期
    IO_PROCESSTIME                 IN CHAR, ---- 流程时间
    IO_PROCESSTYPE                 IN CHAR, ---- 流程功能类型
    IO_BUSINESSTYPE                IN CHAR, ---- 业务类型
    IO_CFMMCRETURNCODE             IN CHAR, ---- 监控中心返回码
    IO_CFMMCRETURNMSG              IN CHAR, ---- 监控中心返回提示信息
    IO_EXRETURNCODE                IN CHAR, ---- 交易所返回码
    IO_EXRETURNMSG                 IN CHAR, ---- 交易所返回提示信息
    IO_CLIENTTYPE                  IN CHAR, ---- 客户类型
    IO_FUTURESID                   IN CHAR, ---- 监控中心为客户分配的代码
    IO_EXCHANGEID                  IN CHAR, ---- 交易所代码
    IO_COMPANYID                   IN CHAR, ---- 期货公司统一编码
    IO_EXCOMPANYID                 IN CHAR, ---- 期货公司在交易所的会员号
    IO_EXCLIENTIDTYPE              IN CHAR, ---- 交易编码类型
    IO_EXCLIENTID                  IN CHAR, ---- 交易编码
    IO_CLIENTNAME                  IN CHAR, ---- 姓名
    IO_NOCID                       IN CHAR, ---- 组织机构代码
    IO_IDTYPE                      IN CHAR, ---- 证件类型
    IO_ID_ORIGINAL                 IN CHAR, ---- 原始输入的证件号码
    IO_ID_TRANSFORMED              IN CHAR, ---- 转换后的证件号码
    IO_BIRTHDAY                    IN CHAR, ---- 出生日期
    IO_GENDER                      IN CHAR, ---- 性别
    IO_CLASSIFY                    IN CHAR, ---- 客户分类码
    IO_COMPCLIENTID                IN CHAR, ---- 客户内部资金账户
    IO_ORGANTYPE                   IN CHAR, ---- 单位性质
    IO_TAXNO                       IN CHAR, ---- 税务登记号
    IO_LICENSENO                   IN CHAR, ---- 营业执照号
    IO_REGISTRYCAPITAL             IN NUMBER, ---- 注册资本
    IO_LEGALPERSON                 IN CHAR, ---- 法人代表
    IO_CONTACTPERSON               IN CHAR, ---- 联系人姓名
    IO_PHONE_COUNTRYCODE           IN CHAR, ---- 联系电话中的国家代码
    IO_PHONE_AREACODE              IN CHAR, ---- 联系电话中的区号
    IO_PHONE_NUMBER                IN CHAR, ---- 联系电话中的电话号码
    IO_ADDR_ZIPCODE                IN CHAR, ---- 邮政编码
    IO_ADDR_COUNTRY                IN CHAR, ---- 联系地址中的国家
    IO_ADDR_PROVINCE               IN CHAR, ---- 联系地址中的省/自治区/直辖市
    IO_ADDR_CITY                   IN CHAR, ---- 联系地址中的市/县/区
    IO_ADDR_ADDRESS                IN CHAR, ---- 联系地址中的地址
    IO_AUTH_NAME                   IN CHAR, ---- 开户授权人姓名
    IO_AUTH_IDTYPE                 IN CHAR, ---- 开户授权人的证件类型
    IO_AUTH_ID                     IN CHAR, ---- 开户授权人证件号码
    IO_AUTH_PHONE_COUNTRYCODE      IN CHAR, ---- 开户授权人联系电话中的国家代码
    IO_AUTH_PHONE_AREACODE         IN CHAR, ---- 开户授权人联系电话中的区号
    IO_AUTH_PHONE_NUMBER           IN CHAR, ---- 开户授权人联系电话中的电话号码
    IO_AUTH_ADDR_ZIPCODE           IN CHAR, ---- 开户授权人邮政编码
    IO_AUTH_ADDR_COUNTRY           IN CHAR, ---- 开户授权人联系地址中的国家
    IO_AUTH_ADDR_PROVINCE          IN CHAR, ---- 开户授权人联系地址中的省/自治区/直辖市
    IO_AUTH_ADDR_CITY              IN CHAR, ---- 开户授权人联系地址中的市/县/区
    IO_AUTH_ADDR_ADDRESS           IN CHAR, ---- 开户授权人联系地址中的地址
    IO_ORDER_NAME                  IN CHAR, ---- 指定下单人姓名
    IO_ORDER_IDTYPE                IN CHAR, ---- 指定下单人的证件类型
    IO_ORDER_ID                    IN CHAR, ---- 指定下单人证件号码
    IO_ORDER_PHONE_COUNTRYCODE     IN CHAR, ---- 指定下单人联系电话中的国家代码
    IO_ORDER_PHONE_AREACODE        IN CHAR, ---- 指定下单人联系电话中的区号
    IO_ORDER_PHONE_NUMBER          IN CHAR, ---- 指定下单人联系电话中的电话号码
    IO_ORDER_ADDR_ZIPCODE          IN CHAR, ---- 指定下单人邮政编码
    IO_ORDER_ADDR_COUNTRY          IN CHAR, ---- 指定下单人联系地址中的国家
    IO_ORDER_ADDR_PROVINCE         IN CHAR, ---- 指定下单人联系地址中的省/自治区/直辖市
    IO_ORDER_ADDR_CITY             IN CHAR, ---- 指定下单人联系地址中的市/县/区
    IO_ORDER_ADDR_ADDRESS          IN CHAR, ---- 指定下单人联系地址中的地址
    IO_FUND_NAME                   IN CHAR, ---- 资金调拨人姓名
    IO_FUND_IDTYPE                 IN CHAR, ---- 资金调拨人的证件类型
    IO_FUND_ID                     IN CHAR, ---- 资金调拨人证件号码
    IO_FUND_PHONE_COUNTRYCODE      IN CHAR, ---- 资金调拨人联系电话中的国家代码
    IO_FUND_PHONE_AREACODE         IN CHAR, ---- 资金调拨人联系电话中的区号
    IO_FUND_PHONE_NUMBER           IN CHAR, ---- 资金调拨人联系电话中的电话号码
    IO_FUND_ADDR_ZIPCODE           IN CHAR, ---- 资金调拨人邮政编码
    IO_FUND_ADDR_COUNTRY           IN CHAR, ---- 资金调拨人联系地址中的国家
    IO_FUND_ADDR_PROVINCE          IN CHAR, ---- 资金调拨人联系地址中的省/自治区/直辖市
    IO_FUND_ADDR_CITY              IN CHAR, ---- 资金调拨人联系地址中的市/县/区
    IO_FUND_ADDR_ADDRESS           IN CHAR, ---- 资金调拨人联系地址中的地址
    IO_BILL_NAME                   IN CHAR, ---- 结算单确认人姓名
    IO_BILL_IDTYPE                 IN CHAR, ---- 结算单确认人的证件类型
    IO_BILL_ID                     IN CHAR, ---- 结算单确认人证件号码
    IO_BILL_PHONE_COUNTRYCODE      IN CHAR, ---- 结算单确认人联系电话中的国家代码
    IO_BILL_PHONE_AREACODE         IN CHAR, ---- 结算单确认人联系电话中的区号
    IO_BILL_PHONE_NUMBER           IN CHAR, ---- 结算单确认人联系电话中的电话号码
    IO_BILL_ADDR_ZIPCODE           IN CHAR, ---- 结算单确认人邮政编码
    IO_BILL_ADDR_COUNTRY           IN CHAR, ---- 结算单确认人联系地址中的国家
    IO_BILL_ADDR_PROVINCE          IN CHAR, ---- 结算单确认人联系地址中的省/自治区/直辖市
    IO_BILL_ADDR_CITY              IN CHAR, ---- 结算单确认人联系地址中的市/县/区
    IO_BILL_ADDR_ADDRESS           IN CHAR, ---- 结算单确认人联系地址中的地址
    IO_UPDATEFLAG                  IN CHAR, ---- 更新状态
    IO_OPERATORID                  IN CHAR, ---- 录入员代码
    IO_OPERATEDATE                 IN CHAR, ---- 录入日期
    IO_OPERATETIME                 IN CHAR, ---- 录入时间
    IO_OPENDATE                    IN CHAR, ---- 开户日期
    IO_CLIENTNAME_ENG              IN CHAR := NULL,
    IO_LEGAL_IDTYPE                IN CHAR := NULL,
    IO_LEGAL_ID                    IN CHAR := NULL,
    IO_LEGAL_PHONE_COUNTRYCODE     IN CHAR := NULL,
    IO_LEGAL_PHONE_AREACODE        IN CHAR := NULL,
    IO_LEGAL_PHONE_NUMBER          IN CHAR := NULL,
    IO_NOCID_EXTRACODE             IN CHAR := NULL,
    IO_REGISTRY_CURRENCY           IN CHAR := NULL,
    IO_EMAIL                       IN CHAR := NULL,
    IO_REGISTRY_ADDR_COUNTRY       IN CHAR := NULL,
    IO_REGISTRY_ADDR_PROVINCE      IN CHAR := NULL,
    IO_REGISTRY_ADDR_CITY          IN CHAR := NULL,
    IO_REGISTRY_ADDR_ADDRESS       IN CHAR := NULL,
    IO_LEDGER_MANAGE_NAME          IN CHAR := NULL,
    IO_EXCLIENTIDREFNAME           IN CHAR := NULL,
    IO_LEDGER_MANAGE_ID            IN CHAR := NULL,
    IO_DIRECTIONAL_ASSET_CLIENTTYP IN CHAR := NULL,
    IO_LEDGER_MANAGE_BANK          IN CHAR := NULL,
    IO_LEDGER_MANAGE_BANKACC       IN CHAR := NULL,
    IO_INVEST_VARIETY              IN CHAR := NULL,
    IO_INVEST_SCALE                IN CHAR := NULL,
    IO_DURATION_STARTDATE          IN CHAR := NULL,
    IO_DURATION_ENDDATE            IN CHAR := NULL,
    IO_LEDGER_CONTACT              IN CHAR := NULL,
    IO_LEG_IDTYPE                  IN CHAR := NULL,
    IO_LEG_ID                      IN CHAR := NULL,
    IO_LEG_PHONE_COUNTRYCODE       IN CHAR := NULL,
    IO_LEG_PHONE_AREACODE          IN CHAR := NULL,
    IO_LEG_PHONE_NUMBER            IN CHAR := NULL,
    IO_CAPITAL_SCALE               IN CHAR,
    IO_DEPARTMENT_NAME             IN CHAR := NULL,
    IO_DEPARTMENT_CODE             IN CHAR := NULL,
    IO_HAS_TRUSTEE                 IN NUMBER := NULL,
    IO_TRUSTEE_NAME                IN CHAR := NULL,
    IO_TRUSTEE_NOCID               IN CHAR := NULL,
    IO_TRUSTEE_REGCURRENCY         IN CHAR := NULL,
    IO_TRUSTEE_REGCAPITAL          IN NUMBER := NULL,
    IO_TRUSTEE_LICENSENO           IN CHAR := NULL,
    IO_TRUSTEE_TAXNO               IN CHAR := NULL,
    IO_TRUSTEE_BANK                IN CHAR := NULL,
    IO_TRUSTEE_BANKACC             IN CHAR := NULL,
    IO_TRUSTEE_COUNTRY             IN CHAR := NULL,
    IO_TRUSTEE_PROVINCE            IN CHAR := NULL,
    IO_TRUSTEE_CITY                IN CHAR := NULL,
    IO_TRUSTEE_ADDRESS             IN CHAR := NULL,
    IO_TRUSTEE_ZIPCODE             IN CHAR := NULL,
    IO_TRUSTEE_LEGALPERSON         IN CHAR := NULL,
    IO_TRUSTEE_LEGAL_IDTYPE        IN CHAR := NULL,
    IO_TRUSTEE_LEGAL_ID            IN CHAR := NULL,
    IO_TRUSTEE_LEGAL_PHONE_COUNTRY IN CHAR := NULL,
    IO_TRUSTEE_LEGAL_PHONE_AREACOD IN CHAR := NULL,
    IO_TRUSTEE_LEGAL_PHONE_NUMBER  IN CHAR := NULL,
    IO_TRUSTEE_AUTH_NAME           IN CHAR := NULL,
    IO_TRUSTEE_AUTH_IDTYPE         IN CHAR := NULL,
    IO_TRUSTEE_AUTH_ID             IN CHAR := NULL,
    IO_TRUSTEE_AUTH_PHONE_COUNTRYC IN CHAR := NULL,
    IO_TRUSTEE_AUTH_PHONE_AREACODE IN CHAR := NULL,
    IO_TRUSTEE_AUTH_PHONE_NUMBER   IN CHAR := NULL,
    IO_TRUSTEE_CONTACT_NAME        IN CHAR := NULL,
    IO_TRUSTEE_CONTACT_IDTYPE      IN CHAR := NULL,
    IO_TRUSTEE_CONTACT_ID          IN CHAR := NULL,
    IO_TRUSTEE_CONTACT_PHONE_COUNT IN CHAR := NULL,
    IO_TRUSTEE_CONTACT_PHONE_AREAC IN CHAR := NULL,
    IO_TRUSTEE_CONTACT_PHONE_NUMBE IN CHAR := NULL,
    ----资管户开始
    IO_ASSETMGR_CLIENTTYPE         IN CHAR := NULL,
    IO_ASSETMGR_TYPE               IN CHAR := NULL,
    IO_ASSETMGR_FUND               IN NUMBER := NULL,
    IO_ASSETMGR_STARTTIME          IN CHAR := NULL,
    IO_ASSETMGR_EXPIRYTIME         IN CHAR := NULL,
    IO_ASSETMGR_MGR_NAME           IN CHAR := NULL,
    IO_ASSETMGR_MGR_PHONE_COUNTRYC IN CHAR := NULL,
    IO_ASSETMGR_MGR_PHONE_AREACODE IN CHAR := NULL,
    --io_Assetmgr_Mgr_Telephone           IN CHAR  := NULL  ,
    IO_ASSETMGR_MGR_PHONE_NUMBER IN CHAR := NULL,
    IO_ASSETMGR_IDTYPE           IN CHAR := NULL,
    IO_ASSETMGR_ID               IN CHAR := NULL,
		-- 00240 资管新规统一开户接口变更 增加3个字段 ASSETMGR_PLAN_NAME、SUBSCRIBER_EXTRACOD、其中TRUSTEE_NAME是和特发开户托保管人共用的
		IO_ASSETMGR_PLAN_NAME        IN CHAR := NULL,
		IO_SUBSCRIBER_EXTRACOD       IN CHAR := NULL,
    ----资管户结束
    I_OPERATORID                IN PKGS_DATATYPE.STY_OPERATORID, ---- 操作员代码
    IO_HAS_FUND_MGR             IN CHAR,
    IO_FUND_MGR_NAME            IN CHAR,
    IO_FUND_MGR_IDTYPE          IN CHAR,
    IO_FUND_MGR_ID              IN CHAR,
    IO_FUND_MGR_COUNTRYCODE     IN CHAR,
    IO_FUND_MGR_AREACODE        IN CHAR,
    IO_FUND_MGR_PHONE           IN CHAR,
    IO_FUND_MGR_ADDR_COUNTRY    IN CHAR,
    IO_FUND_MGR_ADDR_PROVINCE   IN CHAR,
    IO_FUND_MGR_ADDR_CITY       IN CHAR,
    IO_FUND_MGR_ADDR            IN CHAR,
    IO_HAS_INVEST_ADV           IN CHAR,
    IO_INVEST_ADV_NAME          IN CHAR,
    IO_INVEST_ADV_IDTYPE        IN CHAR,
    IO_INVEST_ADV_ID            IN CHAR,
    IO_INVEST_ADV_COUNTRYCODE   IN CHAR,
    IO_INVEST_ADV_AREACODE      IN CHAR,
    IO_INVEST_ADV_PHONE         IN CHAR,
    IO_INVEST_ADV_ADDR_COUNTRY  IN CHAR,
    IO_INVEST_ADV_ADDR_PROVINCE IN CHAR,
    IO_INVEST_ADV_ADDR_CITY     IN CHAR,
    IO_INVEST_ADV_ADDR          IN CHAR,
    IO_HAS_SHARE_HOLDERS        IN CHAR,
    IO_AppropriaType            IN CHAR,
    IO_RiskBearingCapacity      IN CHAR
  ) AS
    L_TY_SEQ_PROCESS         TY_SEQ_PROCESS;
    L_TY_SEQ_INVESTOREXUNIFY TY_SEQ_INVESTOREXUNIFY;
    L_ADDR_ZIPCODE           CHAR(10);
    L_AUTH_ADDR_ZIPCODE      CHAR(10);
    L_ORDER_ADDR_ZIPCODE     CHAR(10);
    L_FUND_ADDR_ZIPCODE      CHAR(10);
    L_BILL_ADDR_ZIPCODE      CHAR(10);
  BEGIN
    L_ADDR_ZIPCODE       := TRIM(IO_ADDR_ZIPCODE);
    L_AUTH_ADDR_ZIPCODE  := TRIM(IO_AUTH_ADDR_ZIPCODE);
    L_ORDER_ADDR_ZIPCODE := TRIM(IO_ORDER_ADDR_ZIPCODE);
    L_FUND_ADDR_ZIPCODE  := TRIM(IO_FUND_ADDR_ZIPCODE);
    L_BILL_ADDR_ZIPCODE  := TRIM(IO_BILL_ADDR_ZIPCODE);
    ----co
    L_TY_SEQ_PROCESS := TY_SEQ_PROCESS(IO_BROKERID,
                                       IO_PROCESSID,
                                       IO_SERIAL,
                                       IO_SEQNO,
                                       IO_SENDDATE,
                                       IO_SENDTIME,
                                       IO_RESPONSEDATE,
                                       IO_PROCESSSTATUS,
                                       IO_PROCESSDATE,
                                       IO_PROCESSTIME,
                                       IO_PROCESSTYPE,
                                       IO_BUSINESSTYPE,
                                       IO_CFMMCRETURNCODE,
                                       IO_CFMMCRETURNMSG,
                                       IO_EXRETURNCODE,
                                       IO_EXRETURNMSG,
                                       IO_CLIENTTYPE,
                                       IO_FUTURESID,
                                       IO_EXCHANGEID,
                                       IO_COMPANYID,
                                       IO_EXCOMPANYID,
                                       IO_EXCLIENTIDTYPE,
                                       IO_EXCLIENTID,
                                       IO_CLIENTNAME,
                                       IO_NOCID,
                                       IO_IDTYPE,
                                       IO_ID_ORIGINAL,
                                       IO_ID_TRANSFORMED,
                                       IO_BIRTHDAY,
                                       IO_GENDER,
                                       IO_CLASSIFY,
                                       IO_COMPCLIENTID,
                                       IO_ORGANTYPE,
                                       IO_TAXNO,
                                       IO_LICENSENO,
                                       IO_REGISTRYCAPITAL,
                                       IO_LEGALPERSON,
                                       IO_CONTACTPERSON,
                                       IO_PHONE_COUNTRYCODE,
                                       IO_PHONE_AREACODE,
                                       IO_PHONE_NUMBER,
                                       L_ADDR_ZIPCODE,
                                       IO_ADDR_COUNTRY,
                                       IO_ADDR_PROVINCE,
                                       IO_ADDR_CITY,
                                       IO_ADDR_ADDRESS,
                                       IO_AUTH_NAME,
                                       IO_AUTH_IDTYPE,
                                       IO_AUTH_ID,
                                       IO_AUTH_PHONE_COUNTRYCODE,
                                       IO_AUTH_PHONE_AREACODE,
                                       IO_AUTH_PHONE_NUMBER,
                                       L_AUTH_ADDR_ZIPCODE,
                                       IO_AUTH_ADDR_COUNTRY,
                                       IO_AUTH_ADDR_PROVINCE,
                                       IO_AUTH_ADDR_CITY,
                                       IO_AUTH_ADDR_ADDRESS,
                                       IO_ORDER_NAME,
                                       IO_ORDER_IDTYPE,
                                       IO_ORDER_ID,
                                       IO_ORDER_PHONE_COUNTRYCODE,
                                       IO_ORDER_PHONE_AREACODE,
                                       IO_ORDER_PHONE_NUMBER,
                                       L_ORDER_ADDR_ZIPCODE,
                                       IO_ORDER_ADDR_COUNTRY,
                                       IO_ORDER_ADDR_PROVINCE,
                                       IO_ORDER_ADDR_CITY,
                                       IO_ORDER_ADDR_ADDRESS,
                                       IO_FUND_NAME,
                                       IO_FUND_IDTYPE,
                                       IO_FUND_ID,
                                       IO_FUND_PHONE_COUNTRYCODE,
                                       IO_FUND_PHONE_AREACODE,
                                       IO_FUND_PHONE_NUMBER,
                                       L_FUND_ADDR_ZIPCODE,
                                       IO_FUND_ADDR_COUNTRY,
                                       IO_FUND_ADDR_PROVINCE,
                                       IO_FUND_ADDR_CITY,
                                       IO_FUND_ADDR_ADDRESS,
                                       IO_BILL_NAME,
                                       IO_BILL_IDTYPE,
                                       IO_BILL_ID,
                                       IO_BILL_PHONE_COUNTRYCODE,
                                       IO_BILL_PHONE_AREACODE,
                                       IO_BILL_PHONE_NUMBER,
                                       L_BILL_ADDR_ZIPCODE,
                                       IO_BILL_ADDR_COUNTRY,
                                       IO_BILL_ADDR_PROVINCE,
                                       IO_BILL_ADDR_CITY,
                                       IO_BILL_ADDR_ADDRESS,
                                       IO_UPDATEFLAG,
                                       IO_OPERATORID,
                                       IO_OPERATEDATE,
                                       IO_OPERATETIME,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       IO_OPENDATE,
                                       IO_CLIENTNAME_ENG,
                                       IO_LEGAL_IDTYPE,
                                       IO_LEGAL_ID,
                                       IO_LEGAL_PHONE_COUNTRYCODE,
                                       IO_LEGAL_PHONE_AREACODE,
                                       IO_LEGAL_PHONE_NUMBER,
                                       IO_NOCID_EXTRACODE,
                                       IO_REGISTRY_CURRENCY,
                                       IO_EMAIL,
                                       IO_REGISTRY_ADDR_COUNTRY,
                                       IO_REGISTRY_ADDR_PROVINCE,
                                       IO_REGISTRY_ADDR_CITY,
                                       IO_REGISTRY_ADDR_ADDRESS,
                                       IO_LEDGER_MANAGE_NAME,
                                       IO_EXCLIENTIDREFNAME,
                                       IO_LEDGER_MANAGE_ID,
                                       IO_DIRECTIONAL_ASSET_CLIENTTYP,
                                       IO_LEDGER_MANAGE_BANK,
                                       IO_LEDGER_MANAGE_BANKACC,
                                       IO_INVEST_VARIETY,
                                       IO_INVEST_SCALE,
                                       IO_DURATION_STARTDATE,
                                       IO_DURATION_ENDDATE,
                                       IO_LEDGER_CONTACT,
                                       IO_LEG_IDTYPE,
                                       IO_LEG_ID,
                                       IO_LEG_PHONE_COUNTRYCODE,
                                       IO_LEG_PHONE_AREACODE,
                                       IO_LEG_PHONE_NUMBER,
                                       IO_CAPITAL_SCALE,
                                       IO_DEPARTMENT_NAME,
                                       IO_DEPARTMENT_CODE,
                                       IO_HAS_TRUSTEE,
                                       IO_TRUSTEE_NAME,
                                       IO_TRUSTEE_NOCID,
                                       IO_TRUSTEE_REGCURRENCY,
                                       IO_TRUSTEE_REGCAPITAL,
                                       IO_TRUSTEE_LICENSENO,
                                       IO_TRUSTEE_TAXNO,
                                       IO_TRUSTEE_BANK,
                                       IO_TRUSTEE_BANKACC,
                                       IO_TRUSTEE_COUNTRY,
                                       IO_TRUSTEE_PROVINCE,
                                       IO_TRUSTEE_CITY,
                                       IO_TRUSTEE_ADDRESS,
                                       IO_TRUSTEE_ZIPCODE,
                                       IO_TRUSTEE_LEGALPERSON,
                                       IO_TRUSTEE_LEGAL_IDTYPE,
                                       IO_TRUSTEE_LEGAL_ID,
                                       IO_TRUSTEE_LEGAL_PHONE_COUNTRY,
                                       IO_TRUSTEE_LEGAL_PHONE_AREACOD,
                                       IO_TRUSTEE_LEGAL_PHONE_NUMBER,
                                       IO_TRUSTEE_AUTH_NAME,
                                       IO_TRUSTEE_AUTH_IDTYPE,
                                       IO_TRUSTEE_AUTH_ID,
                                       IO_TRUSTEE_AUTH_PHONE_COUNTRYC,
                                       IO_TRUSTEE_AUTH_PHONE_AREACODE,
                                       IO_TRUSTEE_AUTH_PHONE_NUMBER,
                                       IO_TRUSTEE_CONTACT_NAME,
                                       IO_TRUSTEE_CONTACT_IDTYPE,
                                       IO_TRUSTEE_CONTACT_ID,
                                       IO_TRUSTEE_CONTACT_PHONE_COUNT,
                                       IO_TRUSTEE_CONTACT_PHONE_AREAC,
                                       IO_TRUSTEE_CONTACT_PHONE_NUMBE,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       IO_HAS_FUND_MGR,
                                       IO_FUND_MGR_NAME,
                                       IO_FUND_MGR_IDTYPE,
                                       IO_FUND_MGR_ID,
                                       IO_FUND_MGR_COUNTRYCODE,
                                       IO_FUND_MGR_AREACODE,
                                       IO_FUND_MGR_PHONE,
                                       IO_FUND_MGR_ADDR_COUNTRY,
                                       IO_FUND_MGR_ADDR_PROVINCE,
                                       IO_FUND_MGR_ADDR_CITY,
                                       IO_FUND_MGR_ADDR,
                                       IO_HAS_INVEST_ADV,
                                       IO_INVEST_ADV_NAME,
                                       IO_INVEST_ADV_IDTYPE,
                                       IO_INVEST_ADV_ID,
                                       IO_INVEST_ADV_COUNTRYCODE,
                                       IO_INVEST_ADV_AREACODE,
                                       IO_INVEST_ADV_PHONE,
                                       IO_INVEST_ADV_ADDR_COUNTRY,
                                       IO_INVEST_ADV_ADDR_PROVINCE,
                                       IO_INVEST_ADV_ADDR_CITY,
                                       IO_INVEST_ADV_ADDR,
                                       IO_HAS_SHARE_HOLDERS,
                                       IO_AppropriaType,
                                       IO_RiskBearingCapacity,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL);
    --pkg_UnifyAccountManager.up_Crtseq_process(o_ReturnNo,o_ReturnMsg,i_OperatorID,l_ty_Seq_process);
    PKGI_UNIFYOPENACCOUNTMGRT.UP_INSSEQ_PROCESS(L_TY_SEQ_PROCESS,
                                                '',
                                                '',
                                                '',
                                                O_RETURNNO,
                                                O_RETURNMSG,
                                                0);
    L_TY_SEQ_INVESTOREXUNIFY := TY_SEQ_INVESTOREXUNIFY(
                                                      IO_BROKERID,
                                                      IO_PROCESSID,
                                                      NULL,
                                                      NULL,
                                                      NULL,
                                                      NULL,
                                                      NULL,
                                                      NULL,
                                                      NULL,
                                                      NULL,
                                                      NULL,
                                                      NULL,
                                                      NULL,
                                                      NULL,
                                                      NULL,
                                                      NULL,
                                                      NULL,
                                                      NULL,
                                                      NULL,
                                                      NULL,
                                                      NULL,
                                                      NULL,
                                                      NULL,
                                                      NULL,
                                                      NULL,
                                                      NULL,
                                                      NULL,
                                                      NULL,
                                                      NULL,
                                                      NULL,
                                                      NULL,
                                                      NULL,
                                                      NULL,
                                                      NULL,
                                                      NULL,
                                                      NULL,
                                                      NULL,
                                                      NULL,
                                                      NULL,
                                                      NULL,
                                                      NULL);
    ---- asset start
    L_TY_SEQ_INVESTOREXUNIFY.ASSETMGR_CLIENTTYPE            := IO_ASSETMGR_CLIENTTYPE;
    L_TY_SEQ_INVESTOREXUNIFY.ASSETMGR_TYPE                  := IO_ASSETMGR_TYPE;
    L_TY_SEQ_INVESTOREXUNIFY.ASSETMGR_FUND                  := IO_ASSETMGR_FUND;
    L_TY_SEQ_INVESTOREXUNIFY.ASSETMGR_STARTTIME             := IO_ASSETMGR_STARTTIME;
    L_TY_SEQ_INVESTOREXUNIFY.ASSETMGR_EXPIRYTIME            := IO_ASSETMGR_EXPIRYTIME;
    L_TY_SEQ_INVESTOREXUNIFY.ASSETMGR_MGR_NAME              := IO_ASSETMGR_MGR_NAME;
    L_TY_SEQ_INVESTOREXUNIFY.ASSETMGR_MGR_PHONE_COUNTRYCODE := IO_ASSETMGR_MGR_PHONE_COUNTRYC;
    L_TY_SEQ_INVESTOREXUNIFY.ASSETMGR_MGR_PHONE_AREACODE    := IO_ASSETMGR_MGR_PHONE_AREACODE;
    L_TY_SEQ_INVESTOREXUNIFY.ASSETMGR_MGR_PHONE_NUMBER      := IO_ASSETMGR_MGR_PHONE_NUMBER;
    L_TY_SEQ_INVESTOREXUNIFY.ASSETMGR_IDTYPE                := IO_ASSETMGR_IDTYPE;
    L_TY_SEQ_INVESTOREXUNIFY.ASSETMGR_ID                    := IO_ASSETMGR_ID;
		-- 00240 资管新规统一开户接口变更 增加3个字段 ASSETMGR_PLAN_NAME、SUBSCRIBER_EXTRACOD、TRUSTEE_NAME
		L_TY_SEQ_INVESTOREXUNIFY.ASSETMGR_PLAN_NAME             := IO_ASSETMGR_PLAN_NAME;
		L_TY_SEQ_INVESTOREXUNIFY.SUBSCRIBER_EXTRACODE            := IO_SUBSCRIBER_EXTRACOD;
		L_TY_SEQ_INVESTOREXUNIFY.TRUSTEE_NAME                   := IO_TRUSTEE_NAME;

    --pkg_UnifyAccountManager.up_Crtseq_investorexunify(o_ReturnNo,o_ReturnMsg,i_OperatorID,l_ty_Seq_investorexunify);
    PKGI_UNIFYOPENACCOUNTMGRT.UP_INSSEQ_INVESTOREXUNIFY(L_TY_SEQ_INVESTOREXUNIFY,
                                                        '',
                                                        '',
                                                        '',
                                                        O_RETURNNO,
                                                        O_RETURNMSG,
                                                        0);

  END UP_CREATESEQ_PROCESS;

  ---- 修改统一开户通讯信息_原油 (mainAPI调用)
  PROCEDURE UP_CRTSEQ_PROCESSCO
  (
    O_RETURNNO                     OUT PKGS_DATATYPE.STY_RETCODE, ---- 返回码
    O_RETURNMSG                    OUT PKGS_DATATYPE.STY_RETMSG, ---- 返回信息
    IO_BROKERID                    IN CHAR, ---- 经纪公司代码
    IO_PROCESSID                   IN CHAR, ---- 业务流水号
    IO_SERIAL                      IN NUMBER, ---- 流水序列号
    IO_SEQNO                       IN NUMBER, ---- 流水号
    IO_SENDDATE                    IN CHAR, ---- 发送日期
    IO_SENDTIME                    IN CHAR, ---- 发送时间
    IO_RESPONSEDATE                IN CHAR, ---- 响应日期
    IO_PROCESSSTATUS               IN CHAR, ---- 流程状态
    IO_PROCESSDATE                 IN CHAR, ---- 流程日期
    IO_PROCESSTIME                 IN CHAR, ---- 流程时间
    IO_PROCESSTYPE                 IN CHAR, ---- 流程功能类型
    IO_BUSINESSTYPE                IN CHAR, ---- 业务类型
    IO_CFMMCRETURNCODE             IN CHAR, ---- 监控中心返回码
    IO_CFMMCRETURNMSG              IN CHAR, ---- 监控中心返回提示信息
    IO_EXRETURNCODE                IN CHAR, ---- 交易所返回码
    IO_EXRETURNMSG                 IN CHAR, ---- 交易所返回提示信息
    IO_CLIENTTYPE                  IN CHAR, ---- 客户类型
    IO_FUTURESID                   IN CHAR, ---- 监控中心为客户分配的代码
    IO_EXCHANGEID                  IN CHAR, ---- 交易所代码
    IO_COMPANYID                   IN CHAR, ---- 期货公司统一编码
    IO_EXCOMPANYID                 IN CHAR, ---- 期货公司在交易所的会员号
    IO_EXCLIENTIDTYPE              IN CHAR, ---- 交易编码类型
    IO_EXCLIENTID                  IN CHAR, ---- 交易编码
    IO_CLIENTNAME                  IN CHAR, ---- 姓名
    IO_NOCID                       IN CHAR, ---- 组织机构代码
    IO_IDTYPE                      IN CHAR, ---- 证件类型
    IO_ID_ORIGINAL                 IN CHAR, ---- 原始输入的证件号码
    IO_ID_TRANSFORMED              IN CHAR, ---- 转换后的证件号码
    IO_BIRTHDAY                    IN CHAR, ---- 出生日期
    IO_GENDER                      IN CHAR, ---- 性别
    IO_CLASSIFY                    IN CHAR, ---- 客户分类码
    IO_COMPCLIENTID                IN CHAR, ---- 客户内部资金账户
    IO_ORGANTYPE                   IN CHAR, ---- 单位性质
    IO_TAXNO                       IN CHAR, ---- 税务登记号
    IO_LICENSENO                   IN CHAR, ---- 营业执照号
    IO_REGISTRYCAPITAL             IN NUMBER, ---- 注册资本
    IO_LEGALPERSON                 IN CHAR, ---- 法人代表
    IO_CONTACTPERSON               IN CHAR, ---- 联系人姓名
    IO_PHONE_COUNTRYCODE           IN CHAR, ---- 联系电话中的国家代码
    IO_PHONE_AREACODE              IN CHAR, ---- 联系电话中的区号
    IO_PHONE_NUMBER                IN CHAR, ---- 联系电话中的电话号码
    IO_ADDR_ZIPCODE                IN CHAR, ---- 邮政编码
    IO_ADDR_COUNTRY                IN CHAR, ---- 联系地址中的国家
    IO_ADDR_PROVINCE               IN CHAR, ---- 联系地址中的省/自治区/直辖市
    IO_ADDR_CITY                   IN CHAR, ---- 联系地址中的市/县/区
    IO_ADDR_ADDRESS                IN CHAR, ---- 联系地址中的地址
    IO_AUTH_NAME                   IN CHAR, ---- 开户授权人姓名
    IO_AUTH_IDTYPE                 IN CHAR, ---- 开户授权人的证件类型
    IO_AUTH_ID                     IN CHAR, ---- 开户授权人证件号码
    IO_AUTH_PHONE_COUNTRYCODE      IN CHAR, ---- 开户授权人联系电话中的国家代码
    IO_AUTH_PHONE_AREACODE         IN CHAR, ---- 开户授权人联系电话中的区号
    IO_AUTH_PHONE_NUMBER           IN CHAR, ---- 开户授权人联系电话中的电话号码
    IO_AUTH_ADDR_ZIPCODE           IN CHAR, ---- 开户授权人邮政编码
    IO_AUTH_ADDR_COUNTRY           IN CHAR, ---- 开户授权人联系地址中的国家
    IO_AUTH_ADDR_PROVINCE          IN CHAR, ---- 开户授权人联系地址中的省/自治区/直辖市
    IO_AUTH_ADDR_CITY              IN CHAR, ---- 开户授权人联系地址中的市/县/区
    IO_AUTH_ADDR_ADDRESS           IN CHAR, ---- 开户授权人联系地址中的地址
    IO_ORDER_NAME                  IN CHAR, ---- 指定下单人姓名
    IO_ORDER_IDTYPE                IN CHAR, ---- 指定下单人的证件类型
    IO_ORDER_ID                    IN CHAR, ---- 指定下单人证件号码
    IO_ORDER_PHONE_COUNTRYCODE     IN CHAR, ---- 指定下单人联系电话中的国家代码
    IO_ORDER_PHONE_AREACODE        IN CHAR, ---- 指定下单人联系电话中的区号
    IO_ORDER_PHONE_NUMBER          IN CHAR, ---- 指定下单人联系电话中的电话号码
    IO_ORDER_ADDR_ZIPCODE          IN CHAR, ---- 指定下单人邮政编码
    IO_ORDER_ADDR_COUNTRY          IN CHAR, ---- 指定下单人联系地址中的国家
    IO_ORDER_ADDR_PROVINCE         IN CHAR, ---- 指定下单人联系地址中的省/自治区/直辖市
    IO_ORDER_ADDR_CITY             IN CHAR, ---- 指定下单人联系地址中的市/县/区
    IO_ORDER_ADDR_ADDRESS          IN CHAR, ---- 指定下单人联系地址中的地址
    IO_FUND_NAME                   IN CHAR, ---- 资金调拨人姓名
    IO_FUND_IDTYPE                 IN CHAR, ---- 资金调拨人的证件类型
    IO_FUND_ID                     IN CHAR, ---- 资金调拨人证件号码
    IO_FUND_PHONE_COUNTRYCODE      IN CHAR, ---- 资金调拨人联系电话中的国家代码
    IO_FUND_PHONE_AREACODE         IN CHAR, ---- 资金调拨人联系电话中的区号
    IO_FUND_PHONE_NUMBER           IN CHAR, ---- 资金调拨人联系电话中的电话号码
    IO_FUND_ADDR_ZIPCODE           IN CHAR, ---- 资金调拨人邮政编码
    IO_FUND_ADDR_COUNTRY           IN CHAR, ---- 资金调拨人联系地址中的国家
    IO_FUND_ADDR_PROVINCE          IN CHAR, ---- 资金调拨人联系地址中的省/自治区/直辖市
    IO_FUND_ADDR_CITY              IN CHAR, ---- 资金调拨人联系地址中的市/县/区
    IO_FUND_ADDR_ADDRESS           IN CHAR, ---- 资金调拨人联系地址中的地址
    IO_BILL_NAME                   IN CHAR, ---- 结算单确认人姓名
    IO_BILL_IDTYPE                 IN CHAR, ---- 结算单确认人的证件类型
    IO_BILL_ID                     IN CHAR, ---- 结算单确认人证件号码
    IO_BILL_PHONE_COUNTRYCODE      IN CHAR, ---- 结算单确认人联系电话中的国家代码
    IO_BILL_PHONE_AREACODE         IN CHAR, ---- 结算单确认人联系电话中的区号
    IO_BILL_PHONE_NUMBER           IN CHAR, ---- 结算单确认人联系电话中的电话号码
    IO_BILL_ADDR_ZIPCODE           IN CHAR, ---- 结算单确认人邮政编码
    IO_BILL_ADDR_COUNTRY           IN CHAR, ---- 结算单确认人联系地址中的国家
    IO_BILL_ADDR_PROVINCE          IN CHAR, ---- 结算单确认人联系地址中的省/自治区/直辖市
    IO_BILL_ADDR_CITY              IN CHAR, ---- 结算单确认人联系地址中的市/县/区
    IO_BILL_ADDR_ADDRESS           IN CHAR, ---- 结算单确认人联系地址中的地址
    IO_UPDATEFLAG                  IN CHAR, ---- 更新状态
    IO_OPERATORID                  IN CHAR, ---- 录入员代码
    IO_OPERATEDATE                 IN CHAR, ---- 录入日期
    IO_OPERATETIME                 IN CHAR, ---- 录入时间
    IO_OPENDATE                    IN CHAR, ---- 开户日期
    IO_CLIENTNAME_ENG              IN CHAR := NULL,
    IO_LEGAL_IDTYPE                IN CHAR := NULL,
    IO_LEGAL_ID                    IN CHAR := NULL,
    IO_LEGAL_PHONE_COUNTRYCODE     IN CHAR := NULL,
    IO_LEGAL_PHONE_AREACODE        IN CHAR := NULL,
    IO_LEGAL_PHONE_NUMBER          IN CHAR := NULL,
    IO_NOCID_EXTRACODE             IN CHAR := NULL,
    IO_REGISTRY_CURRENCY           IN CHAR := NULL,
    IO_EMAIL                       IN CHAR := NULL,
    IO_REGISTRY_ADDR_COUNTRY       IN CHAR := NULL,
    IO_REGISTRY_ADDR_PROVINCE      IN CHAR := NULL,
    IO_REGISTRY_ADDR_CITY          IN CHAR := NULL,
    IO_REGISTRY_ADDR_ADDRESS       IN CHAR := NULL,
    IO_LEDGER_MANAGE_NAME          IN CHAR := NULL,
    IO_EXCLIENTIDREFNAME           IN CHAR := NULL,
    IO_LEDGER_MANAGE_ID            IN CHAR := NULL,
    IO_DIRECTIONAL_ASSET_CLIENTTYP IN CHAR := NULL,
    IO_LEDGER_MANAGE_BANK          IN CHAR := NULL,
    IO_LEDGER_MANAGE_BANKACC       IN CHAR := NULL,
    IO_INVEST_VARIETY              IN CHAR := NULL,
    IO_INVEST_SCALE                IN CHAR := NULL,
    IO_DURATION_STARTDATE          IN CHAR := NULL,
    IO_DURATION_ENDDATE            IN CHAR := NULL,
    IO_LEDGER_CONTACT              IN CHAR := NULL,
    IO_LEG_IDTYPE                  IN CHAR := NULL,
    IO_LEG_ID                      IN CHAR := NULL,
    IO_LEG_PHONE_COUNTRYCODE       IN CHAR := NULL,
    IO_LEG_PHONE_AREACODE          IN CHAR := NULL,
    IO_LEG_PHONE_NUMBER            IN CHAR := NULL,
    IO_CAPITAL_SCALE               IN CHAR,
    IO_DEPARTMENT_NAME             IN CHAR := NULL,
    IO_DEPARTMENT_CODE             IN CHAR := NULL,
    IO_HAS_TRUSTEE                 IN NUMBER := NULL,
    IO_TRUSTEE_NAME                IN CHAR := NULL,
    IO_TRUSTEE_NOCID               IN CHAR := NULL,
    IO_TRUSTEE_REGCURRENCY         IN CHAR := NULL,
    IO_TRUSTEE_REGCAPITAL          IN NUMBER := NULL,
    IO_TRUSTEE_LICENSENO           IN CHAR := NULL,
    IO_TRUSTEE_TAXNO               IN CHAR := NULL,
    IO_TRUSTEE_BANK                IN CHAR := NULL,
    IO_TRUSTEE_BANKACC             IN CHAR := NULL,
    IO_TRUSTEE_COUNTRY             IN CHAR := NULL,
    IO_TRUSTEE_PROVINCE            IN CHAR := NULL,
    IO_TRUSTEE_CITY                IN CHAR := NULL,
    IO_TRUSTEE_ADDRESS             IN CHAR := NULL,
    IO_TRUSTEE_ZIPCODE             IN CHAR := NULL,
    IO_TRUSTEE_LEGALPERSON         IN CHAR := NULL,
    IO_TRUSTEE_LEGAL_IDTYPE        IN CHAR := NULL,
    IO_TRUSTEE_LEGAL_ID            IN CHAR := NULL,
    IO_TRUSTEE_LEGAL_PHONE_COUNTRY IN CHAR := NULL,
    IO_TRUSTEE_LEGAL_PHONE_AREACOD IN CHAR := NULL,
    IO_TRUSTEE_LEGAL_PHONE_NUMBER  IN CHAR := NULL,
    IO_TRUSTEE_AUTH_NAME           IN CHAR := NULL,
    IO_TRUSTEE_AUTH_IDTYPE         IN CHAR := NULL,
    IO_TRUSTEE_AUTH_ID             IN CHAR := NULL,
    IO_TRUSTEE_AUTH_PHONE_COUNTRYC IN CHAR := NULL,
    IO_TRUSTEE_AUTH_PHONE_AREACODE IN CHAR := NULL,
    IO_TRUSTEE_AUTH_PHONE_NUMBER   IN CHAR := NULL,
    IO_TRUSTEE_CONTACT_NAME        IN CHAR := NULL,
    IO_TRUSTEE_CONTACT_IDTYPE      IN CHAR := NULL,
    IO_TRUSTEE_CONTACT_ID          IN CHAR := NULL,
    IO_TRUSTEE_CONTACT_PHONE_COUNT IN CHAR := NULL,
    IO_TRUSTEE_CONTACT_PHONE_AREAC IN CHAR := NULL,
    IO_TRUSTEE_CONTACT_PHONE_NUMBE IN CHAR := NULL,
    ----资管户开始
    IO_ASSETMGR_CLIENTTYPE         IN CHAR := NULL,
    IO_ASSETMGR_TYPE               IN CHAR := NULL,
    IO_ASSETMGR_FUND               IN NUMBER := NULL,
    IO_ASSETMGR_STARTTIME          IN CHAR := NULL,
    IO_ASSETMGR_EXPIRYTIME         IN CHAR := NULL,
    IO_ASSETMGR_MGR_NAME           IN CHAR := NULL,
    IO_ASSETMGR_MGR_PHONE_COUNTRYC IN CHAR := NULL,
    IO_ASSETMGR_MGR_PHONE_AREACODE IN CHAR := NULL,
    IO_ASSETMGR_MGR_PHONE_NUMBER   IN CHAR := NULL,
    IO_ASSETMGR_IDTYPE             IN CHAR := NULL,
    IO_ASSETMGR_ID                 IN CHAR := NULL,
		-- 00240 资管新规统一开户接口变更 增加3个字段 ASSETMGR_PLAN_NAME、SUBSCRIBER_EXTRACOD、其中TRUSTEE_NAME是和特发开户托保管人共用的
		IO_ASSETMGR_PLAN_NAME          IN CHAR := NULL,
		io_subscriber_extracode         IN CHAR := NULL,
    ----资管户结束
    ----原油开始
    IO_CLIENTREGION       IN CHAR := NULL,
    IO_FOREIGNCLIENTMODE  IN CHAR := NULL,
    IO_AGENCYREGID        IN CHAR := NULL,
    IO_EXAGENCYREGID      IN CHAR := NULL,
    IO_NATIONALITY        IN CHAR := NULL,
    IO_PROVINCE           IN CHAR := NULL,
    IO_CITY               IN CHAR := NULL,
    IO_WORKUNIT           IN CHAR := NULL,
    IO_POSITION           IN CHAR := NULL,
    IO_WORKPROPERTY       IN CHAR := NULL,
    IO_ORDER_NATIONALITY  IN CHAR := NULL,
    IO_ORDER_PROVINCE     IN CHAR := NULL,
    IO_ORDER_CITY         IN CHAR := NULL,
    IO_ORDER_EMAIL        IN CHAR := NULL,
    IO_FUND_NATIONALITY   IN CHAR := NULL,
    IO_FUND_PROVINCE      IN CHAR := NULL,
    IO_FUND_CITY          IN CHAR := NULL,
    IO_FUND_EMAIL         IN CHAR := NULL,
    IO_BILL_NATIONALITY   IN CHAR := NULL,
    IO_BILL_PROVINCE      IN CHAR := NULL,
    IO_BILL_CITY          IN CHAR := NULL,
    IO_BILL_EMAIL         IN CHAR := NULL,
    IO_BUSINESSPERIOD     IN CHAR := NULL,
    IO_FAX_COUNTRYCODE    IN CHAR := NULL,
    IO_FAX_AREACODE       IN CHAR := NULL,
    IO_FAX_NUMBER         IN CHAR := NULL,
    IO_WEBSITE            IN CHAR := NULL,
    IO_HASBOARD           IN CHAR := NULL,
    IO_LEGAL_BIRTHDAY     IN CHAR := NULL,
    IO_LEGAL_NATIONALITY  IN CHAR := NULL,
    IO_LEGAL_PROVINCE     IN CHAR := NULL,
    IO_LEGAL_CITY         IN CHAR := NULL,
    IO_LEGAL_ADDR_ZIPCODE IN CHAR := NULL,
    IO_AUTH_NATIONALITY   IN CHAR := NULL,
    IO_AUTH_PROVINCE      IN CHAR := NULL,
    IO_AUTH_CITY          IN CHAR := NULL,
    IO_AUTH_EMAIL         IN CHAR := NULL,
    ----原油结束
    I_OPERATORID                IN PKGS_DATATYPE.STY_OPERATORID ---- 操作员代码
   ,
    IO_HAS_FUND_MGR             IN CHAR,
    IO_FUND_MGR_NAME            IN CHAR,
    IO_FUND_MGR_IDTYPE          IN CHAR,
    IO_FUND_MGR_ID              IN CHAR,
    IO_FUND_MGR_COUNTRYCODE     IN CHAR,
    IO_FUND_MGR_AREACODE        IN CHAR,
    IO_FUND_MGR_PHONE           IN CHAR,
    IO_FUND_MGR_ADDR_COUNTRY    IN CHAR,
    IO_FUND_MGR_ADDR_PROVINCE   IN CHAR,
    IO_FUND_MGR_ADDR_CITY       IN CHAR,
    IO_FUND_MGR_ADDR            IN CHAR,
    IO_HAS_INVEST_ADV           IN CHAR,
    IO_INVEST_ADV_NAME          IN CHAR,
    IO_INVEST_ADV_IDTYPE        IN CHAR,
    IO_INVEST_ADV_ID            IN CHAR,
    IO_INVEST_ADV_COUNTRYCODE   IN CHAR,
    IO_INVEST_ADV_AREACODE      IN CHAR,
    IO_INVEST_ADV_PHONE         IN CHAR,
    IO_INVEST_ADV_ADDR_COUNTRY  IN CHAR,
    IO_INVEST_ADV_ADDR_PROVINCE IN CHAR,
    IO_INVEST_ADV_ADDR_CITY     IN CHAR,
    IO_INVEST_ADV_ADDR          IN CHAR,
    IO_HAS_SHARE_HOLDERS        IN CHAR,
    IO_AppropriaType            IN CHAR,
    io_risk_bearing_capacity      IN CHAR,
    --CTPII00271 start
    IO_Ledger_taxno	            IN CHAR,
    IO_Ledger_capital_currency	IN CHAR,
    IO_Ledger_registry_country	IN CHAR,
    IO_Ledger_registry_province	IN CHAR,
    IO_Ledger_registry_city	    IN CHAR,
    IO_Ledger_registry_address	IN CHAR,
    IO_Classify_detail	        IN CHAR
    --CTPII00271 end
  ) AS
    L_TY_SEQ_PROCESS         TY_SEQ_PROCESS;
    L_TY_SEQ_INVESTOREXUNIFY TY_SEQ_INVESTOREXUNIFY;
    L_ADDR_ZIPCODE           CHAR(10);
    L_AUTH_ADDR_ZIPCODE      CHAR(10);
    L_ORDER_ADDR_ZIPCODE     CHAR(10);
    L_FUND_ADDR_ZIPCODE      CHAR(10);
    L_BILL_ADDR_ZIPCODE      CHAR(10);
    L_VARSPNAME              T_OPERATIONLOG.PROCESSNAME%TYPE := 'PKG_UnifyOpenAccountInterface.UP_CRTSEQ_PROCESSCO';
    L_VARLOGIC               PKGS_DATATYPE.STY_LOGIC := 'mainAPI应用统一开户信息到本平台';
  BEGIN
    PKGS_LOG.UP_SETENV(I_OPERATORID,'mainAPI调用','修改/创建统一开户通讯信息');
    PKGS_LOG.UP_INFO(L_VARSPNAME, '开始。' || L_VARLOGIC);
    L_ADDR_ZIPCODE       := TRIM(IO_ADDR_ZIPCODE);
    L_AUTH_ADDR_ZIPCODE  := TRIM(IO_AUTH_ADDR_ZIPCODE);
    L_ORDER_ADDR_ZIPCODE := TRIM(IO_ORDER_ADDR_ZIPCODE);
    L_FUND_ADDR_ZIPCODE  := TRIM(IO_FUND_ADDR_ZIPCODE);
    L_BILL_ADDR_ZIPCODE  := TRIM(IO_BILL_ADDR_ZIPCODE);
    ----co
    L_TY_SEQ_PROCESS := TY_SEQ_PROCESS(IO_BROKERID,
                                       IO_PROCESSID,
                                       IO_SERIAL,
                                       IO_SEQNO,
                                       IO_SENDDATE,
                                       IO_SENDTIME,
                                       IO_RESPONSEDATE,
                                       IO_PROCESSSTATUS,
                                       IO_PROCESSDATE,
                                       IO_PROCESSTIME,
                                       IO_PROCESSTYPE,
                                       IO_BUSINESSTYPE,
                                       IO_CFMMCRETURNCODE,
                                       IO_CFMMCRETURNMSG,
                                       IO_EXRETURNCODE,
                                       IO_EXRETURNMSG,
                                       IO_CLIENTTYPE,
                                       IO_FUTURESID,
                                       IO_EXCHANGEID,
                                       IO_COMPANYID,
                                       IO_EXCOMPANYID,
                                       IO_EXCLIENTIDTYPE,
                                       IO_EXCLIENTID,
                                       IO_CLIENTNAME,
                                       IO_NOCID,
                                       IO_IDTYPE,
                                       IO_ID_ORIGINAL,
                                       IO_ID_TRANSFORMED,
                                       IO_BIRTHDAY,
                                       IO_GENDER,
                                       IO_CLASSIFY,
                                       IO_COMPCLIENTID,
                                       IO_ORGANTYPE,
                                       IO_TAXNO,
                                       IO_LICENSENO,
                                       IO_REGISTRYCAPITAL,
                                       IO_LEGALPERSON,
                                       IO_CONTACTPERSON,
                                       IO_PHONE_COUNTRYCODE,
                                       IO_PHONE_AREACODE,
                                       IO_PHONE_NUMBER,
                                       L_ADDR_ZIPCODE,
                                       IO_ADDR_COUNTRY,
                                       IO_ADDR_PROVINCE,
                                       IO_ADDR_CITY,
                                       IO_ADDR_ADDRESS,
                                       IO_AUTH_NAME,
                                       IO_AUTH_IDTYPE,
                                       IO_AUTH_ID,
                                       IO_AUTH_PHONE_COUNTRYCODE,
                                       IO_AUTH_PHONE_AREACODE,
                                       IO_AUTH_PHONE_NUMBER,
                                       L_AUTH_ADDR_ZIPCODE,
                                       IO_AUTH_ADDR_COUNTRY,
                                       IO_AUTH_ADDR_PROVINCE,
                                       IO_AUTH_ADDR_CITY,
                                       IO_AUTH_ADDR_ADDRESS,
                                       IO_ORDER_NAME,
                                       IO_ORDER_IDTYPE,
                                       IO_ORDER_ID,
                                       IO_ORDER_PHONE_COUNTRYCODE,
                                       IO_ORDER_PHONE_AREACODE,
                                       IO_ORDER_PHONE_NUMBER,
                                       L_ORDER_ADDR_ZIPCODE,
                                       IO_ORDER_ADDR_COUNTRY,
                                       IO_ORDER_ADDR_PROVINCE,
                                       IO_ORDER_ADDR_CITY,
                                       IO_ORDER_ADDR_ADDRESS,
                                       IO_FUND_NAME,
                                       IO_FUND_IDTYPE,
                                       IO_FUND_ID,
                                       IO_FUND_PHONE_COUNTRYCODE,
                                       IO_FUND_PHONE_AREACODE,
                                       IO_FUND_PHONE_NUMBER,
                                       L_FUND_ADDR_ZIPCODE,
                                       IO_FUND_ADDR_COUNTRY,
                                       IO_FUND_ADDR_PROVINCE,
                                       IO_FUND_ADDR_CITY,
                                       IO_FUND_ADDR_ADDRESS,
                                       IO_BILL_NAME,
                                       IO_BILL_IDTYPE,
                                       IO_BILL_ID,
                                       IO_BILL_PHONE_COUNTRYCODE,
                                       IO_BILL_PHONE_AREACODE,
                                       IO_BILL_PHONE_NUMBER,
                                       L_BILL_ADDR_ZIPCODE,
                                       IO_BILL_ADDR_COUNTRY,
                                       IO_BILL_ADDR_PROVINCE,
                                       IO_BILL_ADDR_CITY,
                                       IO_BILL_ADDR_ADDRESS,
                                       IO_UPDATEFLAG,
                                       IO_OPERATORID,
                                       IO_OPERATEDATE,
                                       IO_OPERATETIME,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       IO_OPENDATE,
                                       IO_CLIENTNAME_ENG,
                                       IO_LEGAL_IDTYPE,
                                       IO_LEGAL_ID,
                                       IO_LEGAL_PHONE_COUNTRYCODE,
                                       IO_LEGAL_PHONE_AREACODE,
                                       IO_LEGAL_PHONE_NUMBER,
                                       IO_NOCID_EXTRACODE,
                                       IO_REGISTRY_CURRENCY,
                                       IO_EMAIL,
                                       IO_REGISTRY_ADDR_COUNTRY,
                                       IO_REGISTRY_ADDR_PROVINCE,
                                       IO_REGISTRY_ADDR_CITY,
                                       IO_REGISTRY_ADDR_ADDRESS,
                                       IO_LEDGER_MANAGE_NAME,
                                       IO_EXCLIENTIDREFNAME,
                                       IO_LEDGER_MANAGE_ID,
                                       IO_DIRECTIONAL_ASSET_CLIENTTYP,
                                       IO_LEDGER_MANAGE_BANK,
                                       IO_LEDGER_MANAGE_BANKACC,
                                       IO_INVEST_VARIETY,
                                       IO_INVEST_SCALE,
                                       IO_DURATION_STARTDATE,
                                       IO_DURATION_ENDDATE,
                                       IO_LEDGER_CONTACT,
                                       IO_LEG_IDTYPE,
                                       IO_LEG_ID,
                                       IO_LEG_PHONE_COUNTRYCODE,
                                       IO_LEG_PHONE_AREACODE,
                                       IO_LEG_PHONE_NUMBER,
                                       IO_CAPITAL_SCALE,
                                       IO_DEPARTMENT_NAME,
                                       IO_DEPARTMENT_CODE,
                                       IO_HAS_TRUSTEE,
                                       IO_TRUSTEE_NAME,
                                       IO_TRUSTEE_NOCID,
                                       IO_TRUSTEE_REGCURRENCY,
                                       IO_TRUSTEE_REGCAPITAL,
                                       IO_TRUSTEE_LICENSENO,
                                       IO_TRUSTEE_TAXNO,
                                       IO_TRUSTEE_BANK,
                                       IO_TRUSTEE_BANKACC,
                                       IO_TRUSTEE_COUNTRY,
                                       IO_TRUSTEE_PROVINCE,
                                       IO_TRUSTEE_CITY,
                                       IO_TRUSTEE_ADDRESS,
                                       IO_TRUSTEE_ZIPCODE,
                                       IO_TRUSTEE_LEGALPERSON,
                                       IO_TRUSTEE_LEGAL_IDTYPE,
                                       IO_TRUSTEE_LEGAL_ID,
                                       IO_TRUSTEE_LEGAL_PHONE_COUNTRY,
                                       IO_TRUSTEE_LEGAL_PHONE_AREACOD,
                                       IO_TRUSTEE_LEGAL_PHONE_NUMBER,
                                       IO_TRUSTEE_AUTH_NAME,
                                       IO_TRUSTEE_AUTH_IDTYPE,
                                       IO_TRUSTEE_AUTH_ID,
                                       IO_TRUSTEE_AUTH_PHONE_COUNTRYC,
                                       IO_TRUSTEE_AUTH_PHONE_AREACODE,
                                       IO_TRUSTEE_AUTH_PHONE_NUMBER,
                                       IO_TRUSTEE_CONTACT_NAME,
                                       IO_TRUSTEE_CONTACT_IDTYPE,
                                       IO_TRUSTEE_CONTACT_ID,
                                       IO_TRUSTEE_CONTACT_PHONE_COUNT,
                                       IO_TRUSTEE_CONTACT_PHONE_AREAC,
                                       IO_TRUSTEE_CONTACT_PHONE_NUMBE,
                                       ---- co start
                                       IO_CLIENTREGION,
                                       IO_FOREIGNCLIENTMODE,
                                       IO_NATIONALITY,
                                       IO_PROVINCE,
                                       IO_CITY,
                                       IO_FAX_NUMBER,
                                       IO_POSITION,
                                       IO_WORKPROPERTY,
                                       IO_AUTH_NATIONALITY,
                                       IO_ORDER_NATIONALITY,
                                       IO_FUND_NATIONALITY,
                                       IO_BILL_NATIONALITY,
                                       ---- co end
                                       IO_HAS_FUND_MGR,
                                       IO_FUND_MGR_NAME,
                                       IO_FUND_MGR_IDTYPE,
                                       IO_FUND_MGR_ID,
                                       IO_FUND_MGR_COUNTRYCODE,
                                       IO_FUND_MGR_AREACODE,
                                       IO_FUND_MGR_PHONE,
                                       IO_FUND_MGR_ADDR_COUNTRY,
                                       IO_FUND_MGR_ADDR_PROVINCE,
                                       IO_FUND_MGR_ADDR_CITY,
                                       IO_FUND_MGR_ADDR,
                                       IO_HAS_INVEST_ADV,
                                       IO_INVEST_ADV_NAME,
                                       IO_INVEST_ADV_IDTYPE,
                                       IO_INVEST_ADV_ID,
                                       IO_INVEST_ADV_COUNTRYCODE,
                                       IO_INVEST_ADV_AREACODE,
                                       IO_INVEST_ADV_PHONE,
                                       IO_INVEST_ADV_ADDR_COUNTRY,
                                       IO_INVEST_ADV_ADDR_PROVINCE,
                                       IO_INVEST_ADV_ADDR_CITY,
                                       IO_INVEST_ADV_ADDR,
                                       IO_HAS_SHARE_HOLDERS,
                                       IO_AppropriaType,
                                       io_risk_bearing_capacity,
                                       IO_Ledger_taxno,
                                       IO_Ledger_capital_currency,
                                       IO_Ledger_registry_country,
                                       IO_Ledger_registry_province,
                                       IO_Ledger_registry_city,
                                       IO_Ledger_registry_address,
                                       IO_Classify_detail);
    --pkg_UnifyAccountManager.up_Crtseq_process(o_ReturnNo,o_ReturnMsg,i_OperatorID,l_ty_Seq_process);
    PKGI_UNIFYOPENACCOUNTMGRT.UP_INSSEQ_PROCESS(L_TY_SEQ_PROCESS,
                                                '',
                                                '',
                                                '',
                                                O_RETURNNO,
                                                O_RETURNMSG,
                                                0);
    L_TY_SEQ_INVESTOREXUNIFY := TY_SEQ_INVESTOREXUNIFY(IO_BROKERID,
                                                       IO_PROCESSID,
                                                       NULL,
                                                       NULL,
                                                       NULL,
                                                       NULL,
                                                       NULL,
                                                       NULL,
                                                       NULL,
                                                       NULL,
                                                       NULL,
                                                       NULL,
                                                       NULL,
                                                       NULL,
                                                       NULL,
                                                       NULL,
                                                       NULL,
                                                       NULL,
                                                       NULL,
                                                       NULL,
                                                       NULL,
                                                       NULL,
                                                       NULL,
                                                       NULL,
                                                       NULL,
                                                       NULL,
                                                       NULL,
                                                       NULL,
                                                       NULL,
                                                       NULL,
                                                       NULL,
                                                       NULL,
                                                       NULL,
                                                       NULL,
                                                       NULL,
                                                       NULL,
                                                       NULL,
                                                       NULL,
                                                       NULL,
                                                       NULL,
                                                       NULL);
    ---- asset start
    L_TY_SEQ_INVESTOREXUNIFY.ASSETMGR_CLIENTTYPE            := IO_ASSETMGR_CLIENTTYPE;
    L_TY_SEQ_INVESTOREXUNIFY.ASSETMGR_TYPE                  := IO_ASSETMGR_TYPE;
    L_TY_SEQ_INVESTOREXUNIFY.ASSETMGR_FUND                  := IO_ASSETMGR_FUND;
    L_TY_SEQ_INVESTOREXUNIFY.ASSETMGR_STARTTIME             := IO_ASSETMGR_STARTTIME;
    L_TY_SEQ_INVESTOREXUNIFY.ASSETMGR_EXPIRYTIME            := IO_ASSETMGR_EXPIRYTIME;
    L_TY_SEQ_INVESTOREXUNIFY.ASSETMGR_MGR_NAME              := IO_ASSETMGR_MGR_NAME;
    L_TY_SEQ_INVESTOREXUNIFY.ASSETMGR_MGR_PHONE_COUNTRYCODE := IO_ASSETMGR_MGR_PHONE_COUNTRYC;
    L_TY_SEQ_INVESTOREXUNIFY.ASSETMGR_MGR_PHONE_AREACODE    := IO_ASSETMGR_MGR_PHONE_AREACODE;
    L_TY_SEQ_INVESTOREXUNIFY.ASSETMGR_MGR_PHONE_NUMBER      := IO_ASSETMGR_MGR_PHONE_NUMBER;
    L_TY_SEQ_INVESTOREXUNIFY.ASSETMGR_IDTYPE                := IO_ASSETMGR_IDTYPE;
    L_TY_SEQ_INVESTOREXUNIFY.ASSETMGR_ID                    := IO_ASSETMGR_ID;
		-- 00240 资管新规统一开户接口变更 增加3个字段 ASSETMGR_PLAN_NAME、SUBSCRIBER_EXTRACOD、TRUSTEE_NAME
		L_TY_SEQ_INVESTOREXUNIFY.ASSETMGR_PLAN_NAME             := IO_ASSETMGR_PLAN_NAME;
		L_TY_SEQ_INVESTOREXUNIFY.SUBSCRIBER_EXTRACODE            := io_subscriber_extracode;
		L_TY_SEQ_INVESTOREXUNIFY.TRUSTEE_NAME                   := IO_TRUSTEE_NAME;
    ---- asset end
    ----co start
    L_TY_SEQ_INVESTOREXUNIFY.AGENCYREGID        := IO_AGENCYREGID;
    L_TY_SEQ_INVESTOREXUNIFY.EXAGENCYREGID      := IO_EXAGENCYREGID;
    L_TY_SEQ_INVESTOREXUNIFY.WORKUNIT           := IO_WORKUNIT;
    L_TY_SEQ_INVESTOREXUNIFY.FAX_COUNTRYCODE    := IO_FAX_COUNTRYCODE;
    L_TY_SEQ_INVESTOREXUNIFY.FAX_AREACODE       := IO_FAX_AREACODE;
    L_TY_SEQ_INVESTOREXUNIFY.WEBSITE            := IO_WEBSITE;
    L_TY_SEQ_INVESTOREXUNIFY.HASBOARD           := IO_HASBOARD;
    L_TY_SEQ_INVESTOREXUNIFY.BUSINESSPERIOD     := IO_BUSINESSPERIOD;
    L_TY_SEQ_INVESTOREXUNIFY.LEGAL_NATIONALITY  := IO_LEGAL_NATIONALITY;
    L_TY_SEQ_INVESTOREXUNIFY.LEGAL_PROVINCE     := IO_LEGAL_PROVINCE;
    L_TY_SEQ_INVESTOREXUNIFY.LEGAL_CITY         := IO_LEGAL_CITY;
    L_TY_SEQ_INVESTOREXUNIFY.LEGAL_BIRTHDAY     := IO_LEGAL_BIRTHDAY;
    L_TY_SEQ_INVESTOREXUNIFY.LEGAL_ADDR_ZIPCODE := IO_LEGAL_ADDR_ZIPCODE;
    L_TY_SEQ_INVESTOREXUNIFY.AUTH_PROVINCE      := IO_AUTH_PROVINCE;
    L_TY_SEQ_INVESTOREXUNIFY.AUTH_CITY          := IO_AUTH_CITY;
    L_TY_SEQ_INVESTOREXUNIFY.AUTH_EMAIL         := IO_AUTH_EMAIL;
    L_TY_SEQ_INVESTOREXUNIFY.ORDER_PROVINCE     := IO_ORDER_PROVINCE;
    L_TY_SEQ_INVESTOREXUNIFY.ORDER_CITY         := IO_ORDER_CITY;
    L_TY_SEQ_INVESTOREXUNIFY.ORDER_EMAIL        := IO_ORDER_EMAIL;
    L_TY_SEQ_INVESTOREXUNIFY.FUND_PROVINCE      := IO_FUND_PROVINCE;
    L_TY_SEQ_INVESTOREXUNIFY.FUND_CITY          := IO_FUND_CITY;
    L_TY_SEQ_INVESTOREXUNIFY.FUND_EMAIL         := IO_FUND_EMAIL;
    L_TY_SEQ_INVESTOREXUNIFY.BILL_PROVINCE      := IO_BILL_PROVINCE;
    L_TY_SEQ_INVESTOREXUNIFY.BILL_CITY          := IO_BILL_CITY;
    L_TY_SEQ_INVESTOREXUNIFY.BILL_EMAIL         := IO_BILL_EMAIL;
    ----co end
    --pkg_UnifyAccountManager.up_Crtseq_investorexunify(o_ReturnNo,o_ReturnMsg,i_OperatorID,l_ty_Seq_investorexunify);
    PKGI_UNIFYOPENACCOUNTMGRT.UP_INSSEQ_INVESTOREXUNIFY(L_TY_SEQ_INVESTOREXUNIFY,
                                                        '',
                                                        '',
                                                        '',
                                                        O_RETURNNO,
                                                        O_RETURNMSG,
                                                        0);
    PKGS_LOG.UP_INFO(L_VARSPNAME, '结束。' || L_VARLOGIC);

  END UP_CRTSEQ_PROCESSCO;

  ---- 应用统一开户信息到本平台
  PROCEDURE UP_APPLYUNIFYACCOUNTMSG
  (
    O_RETURNNO   OUT PKGS_DATATYPE.STY_RETCODE, ---- 返回码
    O_RETURNMSG  OUT PKGS_DATATYPE.STY_RETMSG, ---- 返回信息
    IO_BROKERID  IN PKGS_DATATYPE.STY_BROKERID, ---- 经纪公司代码
    IO_PROCESSID IN CHAR, ---- 业务流水号
    I_OPERATORID IN PKGS_DATATYPE.STY_OPERATORID ---- 操作员代码
  ) AS
    L_VARSPNAME      T_OPERATIONLOG.PROCESSNAME%TYPE := 'PKG_UnifyOpenAccountInterface.up_ApplyUnifyAccountMsg';
    L_VARLOGIC       PKGS_DATATYPE.STY_LOGIC := '应用统一开户信息到本平台';
    L_TY_SEQ_PROCESS TY_SEQ_PROCESS;
    L_COUNT          INT;
    L_PROCESSNAME    PKGS_DATATYPE.STY_PROCESSNAME; ---- 存储过程名称
  BEGIN
    /*SELECT COUNT(*)
    INTO l_count
    FROM t_SysSettleParam t
    WHERE t.brokerid = io_BrokerID
    AND t.systemparamid = pkg_Define.SPI_TradingCode
    AND t.systemparamvalue = Pkg_Define.BOOL_True;
    IF l_count > 0 THEN*/
    PKGS_LOG.UP_SETENV(I_OPERATORID,
                       '统一开户管理',
                       '应用统一开户信息到本平台');
    PKGS_LOG.UP_INFO(L_VARSPNAME,
                     '开始。' || L_VARLOGIC);

    L_TY_SEQ_PROCESS := TY_SEQ_PROCESS(IO_BROKERID,
                                       IO_PROCESSID,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL,
                                       NULL);
    --pkg_UnifyAccountManager.up_ApplyUnifyAccountMsg(o_ReturnNo,o_ReturnMsg,i_OperatorID,l_ty_Seq_process);
    PKGI_UNIFYOPENACCOUNTMGRT.UP_APPLYUNIFYACCOUNTMSG(L_TY_SEQ_PROCESS,
                                                      '',
                                                      '',
                                                      I_OPERATORID,
                                                      O_RETURNNO,
                                                      O_RETURNMSG,
                                                      0);
    IF O_RETURNNO <> PKGS_CONSTANTS.C_RET_SUCCESS
    THEN
      PKGS_LOG.UP_ERROR(L_VARSPNAME,
                        O_RETURNMSG);
      RETURN;
    END IF;

    PKGS_LOG.UP_INFO(L_VARSPNAME,
                     '结束。' || L_VARLOGIC);

  END UP_APPLYUNIFYACCOUNTMSG;
  /*20101222 休眠户 end */
END PKG_UNIFYACCOUNTINTERFACE;
/

