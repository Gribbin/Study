create TYPE BODY Ty_CAPInvstDepartment IS

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_CAPInvstDepartment RETURN SELF AS RESULT IS
  BEGIN
    RETURN;
  END;

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2 IS
    l_string VARCHAR2(4000);
  BEGIN
    l_string:='ty_CAPInvstDepartment('
      || 'BrokerID=>' || '''' || trim(BrokerID) || '''' --经纪公司代码
      || ',InvestorID=>' || '''' || trim(InvestorID) || '''' --投资者代码
      || ',InvestUnitID=>' || '''' || trim(InvestUnitID) || '''' --投资单元代码
      || ',DepartmentID=>' || '''' || trim(DepartmentID) || '''' --组织架构代码
      || ')';


    RETURN l_string;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN NULL;
  END;



END;
/

