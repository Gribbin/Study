create TYPE Ty_AccountGroupMap AS OBJECT
(
    BrokerID CHAR(10),  --经纪公司代码
    AccountID CHAR(14),  --资金账号代码
    CurrencyID CHAR(3),  --资金账号币种代码
    AccountGroupID CHAR(12),  --资金账号分组代码

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_AccountGroupMap RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

