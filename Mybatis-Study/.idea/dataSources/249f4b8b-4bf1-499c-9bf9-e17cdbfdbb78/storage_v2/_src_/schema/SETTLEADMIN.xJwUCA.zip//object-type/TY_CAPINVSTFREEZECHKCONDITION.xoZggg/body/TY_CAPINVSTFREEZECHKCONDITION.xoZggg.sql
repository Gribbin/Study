create TYPE BODY Ty_CAPInvstFreezeChkCondition IS

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_CAPInvstFreezeChkCondition RETURN SELF AS RESULT IS
  BEGIN
    RETURN;
  END;

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2 IS
    l_string VARCHAR2(4000);
  BEGIN
    l_string:='ty_CAPInvstFreezeChkCondition('
      || 'BrokerID=>' || '''' || trim(BrokerID) || '''' --经纪公司代码
      || ',InvestorID=>' || '''' || trim(InvestorID) || '''' --投资者代码
      || ',FreezeMaxReMain=>' || NVL(to_char(FreezeMaxReMain),'NULL')--休眠户认定权益
      || ')';


    RETURN l_string;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN NULL;
  END;



END;
/

