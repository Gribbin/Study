create TYPE BODY Ty_AMInvestorSpecInfo IS

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_AMInvestorSpecInfo RETURN SELF AS RESULT IS
  BEGIN
    RETURN;
  END;

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2 IS
    l_string VARCHAR2(4000);
  BEGIN
    l_string:='ty_AMInvestorSpecInfo('
      || 'BrokerID=>' || '''' || trim(BrokerID) || '''' --经纪公司代码
      || ',InvestorID=>' || '''' || trim(InvestorID) || '''' --投资者代码
      || ',AssetmgrClientType=>' || '''' || trim(AssetmgrClientType) || '''' --资产管理客户类型
      || ',AssetmgrType=>' || '''' || trim(AssetmgrType) || '''' --投资类型
      || ',AssetmgrCFullName=>' || '''' || trim(AssetmgrCFullName) || '''' --代理资产管理业务的期货公司全称
      || ',AssetmgrFund=>' || NVL(to_char(AssetmgrFund),'NULL')--委托资金
      || ',AssetmgrApprovalNO=>' || '''' || trim(AssetmgrApprovalNO) || '''' --资产管理业务批文号
      || ',AssetmgrStartDate=>' || '''' || trim(AssetmgrStartDate) || '''' --起始委托时间
      || ',AssetmgrFinishDate=>' || '''' || trim(AssetmgrFinishDate) || '''' --终止委托时间
      || ',AssetmgrName=>' || '''' || trim(AssetmgrName) || '''' --资产管理业务负责人姓名
      || ',AssetmgrPhoneCountryCode=>' || '''' || trim(AssetmgrPhoneCountryCode) || '''' --资产管理业务负责人联系电话国家代码
      || ',AssetmgrPhoneAreaCode=>' || '''' || trim(AssetmgrPhoneAreaCode) || '''' --资产管理业务负责人联系电话区号
      || ',AssetmgrTelephone=>' || '''' || trim(AssetmgrTelephone) || '''' --资产管理业务负责人联系电话电话号码
      || ',AssetmgrIdentifiedCardType=>' || '''' || trim(AssetmgrIdentifiedCardType) || '''' --资产管理业务负责人证件类型
      || ',AssetmgrIdentifiedCardNo=>' || '''' || trim(AssetmgrIdentifiedCardNo) || '''' --资产管理业务负责人证件号码
      || ',AssetmgrInstitution=>' || '''' || trim(AssetmgrInstitution) || '''' --资产管理业务的经营机构
      || ',AssetmgrPlanName=>' || '''' || trim(AssetmgrPlanName) || '''' --资产管理计划名称
      || ',SubscriberExtracode=>' || '''' || trim(SubscriberExtracode) || '''' --委托人附加码
      || ',TrusteeName=>' || '''' || trim(TrusteeName) || '''' --托（保）管人名称
      || ')';


    RETURN l_string;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN NULL;
  END;



END;
/

