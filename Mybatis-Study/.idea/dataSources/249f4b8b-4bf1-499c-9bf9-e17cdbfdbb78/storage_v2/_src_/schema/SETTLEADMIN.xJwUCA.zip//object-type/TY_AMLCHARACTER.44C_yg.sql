create TYPE Ty_AMLCharacter AS OBJECT
(
    ReportTypeID CHAR(2),  --报告类型
    CharacterID CHAR(4),  --特征代码
    CharacterDesc VARCHAR2(400),  --特征描述
    AMLGenStatus CHAR(1),  --数据来源

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_AMLCharacter RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

