create TYPE Ty_Broker AS OBJECT
(
    BrokerID CHAR(10),  --经纪公司代码
    BrokerAbbr CHAR(8),  --经纪公司简称
    BrokerName CHAR(80),  --经纪公司名称
    BrokerType CHAR(1),  --经纪公司类型
    IsActive NUMBER(1),  --是否活跃
    IsNeedSettle NUMBER(1),  --是否需要结算

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_Broker RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

