create TYPE Ty_CSRC_HoldDetails AS OBJECT
(
    TradingDay CHAR(10),  --交易日
    ParticipantID CHAR(10),  --会员代码
    InvestorID CHAR(12),  --客户内部资金账户
    ExchangeInstID CHAR(30),  --品种合约
    TradeID CHAR(20),  --成交流水号
    Direction CHAR(1),  --买卖标志
    HedgeFlag CHAR(1),  --投机套保标志
    Volume NUMBER(20),  --持仓量
    OpenPrice NUMBER(15,3),  --开仓价
    PreSettlementPrice NUMBER(15,3),  --昨结算价
    SettlementPrice NUMBER(15,3),  --今结算价
    PositionProfitByDate NUMBER(15,3),  --持仓盈亏(逐日盯市)
    PositionProfitByTrade NUMBER(15,3),  --持仓盈亏(逐笔对冲)
    TradingCode CHAR(10),  --交易编码
    Margin NUMBER(15,3),  --交易保证金
    CurrencyID CHAR(3),  --币种
    TradeDate CHAR(10),  --成交日期
    CoverFlag CHAR(1),  --是否备对组合

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_CSRC_HoldDetails RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

