create TYPE BODY Ty_CFFEXCapitalChangeDetail IS

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_CFFEXCapitalChangeDetail RETURN SELF AS RESULT IS
  BEGIN
    RETURN;
  END;

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2 IS
    l_string VARCHAR2(4000);
  BEGIN
    l_string:='ty_CFFEXCapitalChangeDetail('
      || 'TradingDay=>' || '''' || trim(TradingDay) || '''' --交易日
      || ',ExchangeID=>' || '''' || trim(ExchangeID) || '''' --交易所代码
      || ',ParticipantID=>' || '''' || trim(ParticipantID) || '''' --会员代码
      || ',BillNo=>' || '''' || trim(BillNo) || '''' --票据号
      || ',BillName=>' || '''' || trim(BillName) || '''' --票据名称
      || ',Deposit=>' || NVL(to_char(Deposit),'NULL')--金额
      || ')';


    RETURN l_string;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN NULL;
  END;



END;
/

