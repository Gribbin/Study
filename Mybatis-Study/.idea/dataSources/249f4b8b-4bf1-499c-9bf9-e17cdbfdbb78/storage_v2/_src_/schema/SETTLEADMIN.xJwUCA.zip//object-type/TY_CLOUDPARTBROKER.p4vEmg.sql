create TYPE Ty_CloudPartBroker AS OBJECT
(
    BrokerID CHAR(10),  --经纪公司代码
    ParticipantID CHAR(10),  --会员代码
    CloudPassword CHAR(40),  --云开户密码
    CtpPassword CHAR(40),  --CTP柜台密码

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_CloudPartBroker RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

