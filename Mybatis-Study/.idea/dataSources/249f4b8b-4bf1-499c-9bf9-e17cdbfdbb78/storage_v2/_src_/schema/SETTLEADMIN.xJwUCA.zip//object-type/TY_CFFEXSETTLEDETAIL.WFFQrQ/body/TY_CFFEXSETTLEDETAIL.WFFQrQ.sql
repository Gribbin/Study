create TYPE BODY Ty_CFFEXSettleDetail IS

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_CFFEXSettleDetail RETURN SELF AS RESULT IS
  BEGIN
    RETURN;
  END;

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2 IS
    l_string VARCHAR2(4000);
  BEGIN
    l_string:='ty_CFFEXSettleDetail('
      || 'TradingDay=>' || '''' || trim(TradingDay) || '''' --交易日
      || ',ExchangeID=>' || '''' || trim(ExchangeID) || '''' --交易所代码
      || ',ParticipantID=>' || '''' || trim(ParticipantID) || '''' --会员代码
      || ',NoSettlePartID=>' || '''' || trim(NoSettlePartID) || '''' --非结算会员号
      || ',ClientID=>' || '''' || trim(ClientID) || '''' --客户编码
      || ',ExchangeInstID=>' || '''' || trim(ExchangeInstID) || '''' --合约代码
      || ',SettlementPrice=>' || NVL(to_char(SettlementPrice),'NULL')--结算价
      || ',BuyOpenAmt=>' || NVL(to_char(BuyOpenAmt),'NULL')--买开成交量
      || ',BuyCloseAmt=>' || NVL(to_char(BuyCloseAmt),'NULL')--买平成交量
      || ',BuyAmtTotal=>' || NVL(to_char(BuyAmtTotal),'NULL')--买成交量合计
      || ',SellOpenAmt=>' || NVL(to_char(SellOpenAmt),'NULL')--卖开成交量
      || ',SellCloseAmt=>' || NVL(to_char(SellCloseAmt),'NULL')--卖平成交量
      || ',SellAmtTotal=>' || NVL(to_char(SellAmtTotal),'NULL')--卖成交量合计
      || ',BuySum=>' || NVL(to_char(BuySum),'NULL')--买入成交额
      || ',SellSum=>' || NVL(to_char(SellSum),'NULL')--卖出成交额
      || ',BTotalAmt=>' || NVL(to_char(BTotalAmt),'NULL')--买持仓额合计
      || ',STotalAmt=>' || NVL(to_char(STotalAmt),'NULL')--卖持仓额合计
      || ',Margin=>' || NVL(to_char(Margin),'NULL')--交易保证金
      || ',Actual=>' || NVL(to_char(Actual),'NULL')--当日盈亏
      || ',TransFee=>' || NVL(to_char(TransFee),'NULL')--交易手续费
      || ',OPTPremiumMoney=>' || NVL(to_char(OPTPremiumMoney),'NULL')--权利金
      || ')';


    RETURN l_string;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN NULL;
  END;



END;
/

