create TYPE BODY Ty_CRAInvestorRisk IS

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_CRAInvestorRisk RETURN SELF AS RESULT IS
  BEGIN
    RETURN;
  END;

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2 IS
    l_string VARCHAR2(4000);
  BEGIN
    l_string:='ty_CRAInvestorRisk('
      || 'BrokerID=>' || '''' || trim(BrokerID) || '''' --经纪商代码
      || ',InvestorID=>' || '''' || trim(InvestorID) || '''' --投资者代码
      || ',RiskScore=>' || NVL(to_char(RiskScore),'NULL')--评级系统得分
      || ',RiskLevel=>' || NVL(to_char(RiskLevel),'NULL')--风险等级
      || ',RatingType=>' || '''' || trim(RatingType) || '''' --评级方式
      || ',RatingDate=>' || '''' || trim(RatingDate) || '''' --评级时间
      || ')';


    RETURN l_string;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN NULL;
  END;



END;
/

