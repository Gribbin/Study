create TYPE Ty_ClearInterest AS OBJECT
(
    BrokerID CHAR(10),  --经纪公司代码
    ClearIntNo NUMBER(14),  --结息操作编号
    AccountID CHAR(14),  --资金账号
    CurrencyID CHAR(3),  --资金账号币种
    EndDate CHAR(8),  --结息结束日期
    ClearIntScope CHAR(1),  --计息范围
    EliminateType CHAR(1),  --剔除方式
    Interest NUMBER(22,6),  --利息金额
    OperatorID CHAR(64),  --操作员代码
    OpDate CHAR(8),  --操作日期
    OpTime CHAR(8),  --操作时间

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_ClearInterest RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

