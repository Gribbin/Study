create TYPE BODY Ty_CSRCAssets IS

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_CSRCAssets RETURN SELF AS RESULT IS
  BEGIN
    RETURN;
  END;

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2 IS
    l_string VARCHAR2(4000);
  BEGIN
    l_string:='ty_CSRCAssets('
      || 'TradingDay=>' || '''' || trim(TradingDay) || '''' --交易日
      || ',BrokerID=>' || '''' || trim(BrokerID) || '''' --经纪公司代码
      || ',InvestorID=>' || '''' || trim(InvestorID) || '''' --客户内部资金账户
      || ',Actual=>' || NVL(to_char(Actual),'NULL')--当日盈亏
      || ',Deposit=>' || NVL(to_char(Deposit),'NULL')--净值总额
      || ',CurrencyID=>' || '''' || trim(CurrencyID) || '''' --币种
      || ',Memo=>' || '''' || trim(Memo) || '''' --说明
      || ',InvTargetType=>' || '''' || trim(InvTargetType) || '''' --投资标的类型
      || ',ProductCode=>' || '''' || trim(ProductCode) || '''' --产品编码
      || ')';


    RETURN l_string;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN NULL;
  END;



END;
/

