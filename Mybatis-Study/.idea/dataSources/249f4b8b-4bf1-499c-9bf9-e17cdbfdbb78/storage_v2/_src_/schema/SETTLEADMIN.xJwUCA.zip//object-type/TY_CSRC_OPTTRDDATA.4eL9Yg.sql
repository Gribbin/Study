create TYPE Ty_CSRC_OptTrdData AS OBJECT
(
    TradingDay CHAR(10),  --交易日
    ParticipantID CHAR(10),  --会员代码
    InvestorID CHAR(12),  --客户内部资金账户
    TradeID CHAR(20),  --成交流水号
    ExchangeInstID CHAR(30),  --品种合约
    Direction CHAR(1),  --买卖标志
    Volume NUMBER(20),  --成交量
    Price NUMBER(15,3),  --权利金单价
    OptPremiumMoney NUMBER(15,3),  --权利金
    TradeTime CHAR(10),  --成交时间
    OffsetFlag CHAR(1),  --开平仓标志
    HedgeFlag CHAR(1),  --投机套保标志
    Transfee NUMBER(15,3),  --手续费
    OptionsType CHAR(1),  --期权类型
    ExerPrice NUMBER(20,7),  --执行价格
    UnderlyingProductID CHAR(6),  --标的品种
    UnderlyingInstrID CHAR(30),  --标的合约
    ClientID CHAR(10),  --交易编码
    ExchangeFlag CHAR(1),  --交易所统一标识
    IsSettlement CHAR(1),  --是否为交易会员
    OrderID CHAR(20),  --报单号
    TraderID CHAR(20),  --席位号
    CurrencyID CHAR(3),  --币种
    TradeDate CHAR(10),  --成交日期
    CoverFlag CHAR(1),  --是否备对组合
    InstrumentCode CHAR(8),  --合约编码

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_CSRC_OptTrdData RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

