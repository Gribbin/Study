create TYPE BODY Ty_BrokerPositionOUT IS

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_BrokerPositionOUT RETURN SELF AS RESULT IS
  BEGIN
    RETURN;
  END;

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2 IS
    l_string VARCHAR2(4000);
  BEGIN
    l_string:='ty_BrokerPositionOUT('
      || 'SettleTaskID=>' || '''' || trim(SettleTaskID) || '''' --结算任务ID
      || ',BrokerID=>' || '''' || trim(BrokerID) || '''' --经纪公司代码
      || ',ExchangeID=>' || '''' || trim(ExchangeID) || '''' --交易所代码
      || ',InstrumentID=>' || '''' || trim(InstrumentID) || '''' --合约代码
      || ',HedgeFlag=>' || '''' || trim(HedgeFlag) || '''' --投机套保标志
      || ',BuyAmt=>' || NVL(to_char(BuyAmt),'NULL')--买入成交量
      || ',BuySum=>' || NVL(to_char(BuySum),'NULL')--买入成交额
      || ',BOpenAmt=>' || NVL(to_char(BOpenAmt),'NULL')--买入开仓量
      || ',BOpenSum=>' || NVL(to_char(BOpenSum),'NULL')--买入开仓额
      || ',BCloseAmt=>' || NVL(to_char(BCloseAmt),'NULL')--买入平仓量
      || ',BCloseSum=>' || NVL(to_char(BCloseSum),'NULL')--买入平仓额
      || ',BCloseTodayAmt=>' || NVL(to_char(BCloseTodayAmt),'NULL')--买入平今仓量
      || ',BCloseTodaySum=>' || NVL(to_char(BCloseTodaySum),'NULL')--买入平今仓额
      || ',SellAmt=>' || NVL(to_char(SellAmt),'NULL')--卖出成交量
      || ',SellSum=>' || NVL(to_char(SellSum),'NULL')--卖出成交额
      || ',SOpenAmt=>' || NVL(to_char(SOpenAmt),'NULL')--卖出开仓量
      || ',SOpenSum=>' || NVL(to_char(SOpenSum),'NULL')--卖出开仓额
      || ',SCloseAmt=>' || NVL(to_char(SCloseAmt),'NULL')--卖出平仓量
      || ',SCloseSum=>' || NVL(to_char(SCloseSum),'NULL')--卖出平仓额
      || ',SCloseTodayAmt=>' || NVL(to_char(SCloseTodayAmt),'NULL')--卖出平今仓量
      || ',SCloseTodaySum=>' || NVL(to_char(SCloseTodaySum),'NULL')--卖出平今仓额
      || ',BTotalAmt=>' || NVL(to_char(BTotalAmt),'NULL')--多头持仓量
      || ',BTotalSum=>' || NVL(to_char(BTotalSum),'NULL')--多头持仓额
      || ',STotalAmt=>' || NVL(to_char(STotalAmt),'NULL')--空头持仓量
      || ',STotalSum=>' || NVL(to_char(STotalSum),'NULL')--空头持仓额
      || ',BCloseProfitByDate=>' || NVL(to_char(BCloseProfitByDate),'NULL')--多头平仓盈亏
      || ',SCloseProfitByDate=>' || NVL(to_char(SCloseProfitByDate),'NULL')--空头平仓盈亏
      || ',BCloseProfitByTrade=>' || NVL(to_char(BCloseProfitByTrade),'NULL')--多头平仓盈亏
      || ',SCloseProfitByTrade=>' || NVL(to_char(SCloseProfitByTrade),'NULL')--空头平仓盈亏
      || ',BPositionProfitByDate=>' || NVL(to_char(BPositionProfitByDate),'NULL')--多头持仓盈亏
      || ',SPositionProfitByDate=>' || NVL(to_char(SPositionProfitByDate),'NULL')--空头持仓盈亏
      || ',BPositionProfitByTrade=>' || NVL(to_char(BPositionProfitByTrade),'NULL')--多头持仓盈亏
      || ',SPositionProfitByTrade=>' || NVL(to_char(SPositionProfitByTrade),'NULL')--空头持仓盈亏
      || ',BActual=>' || NVL(to_char(BActual),'NULL')--多头当日盈亏
      || ',SActual=>' || NVL(to_char(SActual),'NULL')--空头当日盈亏
      || ',TransFee=>' || NVL(to_char(TransFee),'NULL')--投资者交易手续费
      || ',SettlementFee=>' || NVL(to_char(SettlementFee),'NULL')--投资者结算手续费
      || ',DelivFee=>' || NVL(to_char(DelivFee),'NULL')--投资者交割手续费
      || ',TransferPosFee=>' || NVL(to_char(TransferPosFee),'NULL')--投资者移仓手续费
      || ',StrikeFee=>' || NVL(to_char(StrikeFee),'NULL')--投资者执行手续费
      || ',PerformFee=>' || NVL(to_char(PerformFee),'NULL')--投资者履约手续费
      || ',ExchTransFee=>' || NVL(to_char(ExchTransFee),'NULL')--交易所交易手续费
      || ',ExchSettlementFee=>' || NVL(to_char(ExchSettlementFee),'NULL')--交易所结算手续费
      || ',ExchDelivFee=>' || NVL(to_char(ExchDelivFee),'NULL')--交易所交割手续费
      || ',ExchTransferPosFee=>' || NVL(to_char(ExchTransferPosFee),'NULL')--交易所移仓手续费
      || ',ExchStrikeFee=>' || NVL(to_char(ExchStrikeFee),'NULL')--交易所执行手续费
      || ',ExchPerformFee=>' || NVL(to_char(ExchPerformFee),'NULL')--交易所履约手续费
      || ',BMargin=>' || NVL(to_char(BMargin),'NULL')--投资者多头保证金
      || ',SMargin=>' || NVL(to_char(SMargin),'NULL')--投资者空头保证金
      || ',ExchBMargin=>' || NVL(to_char(ExchBMargin),'NULL')--交易所多头保证金
      || ',ExchSMargin=>' || NVL(to_char(ExchSMargin),'NULL')--交易所空头保证金
      || ',SettlementPrice=>' || NVL(to_char(SettlementPrice),'NULL')--本次结算价
      || ',BAvgCost=>' || NVL(to_char(BAvgCost),'NULL')--买入成本
      || ',SAvgCost=>' || NVL(to_char(SAvgCost),'NULL')--卖出成本
      || ',LastBTotalAmt=>' || NVL(to_char(LastBTotalAmt),'NULL')--昨多头持仓量
      || ',LastSTotalAmt=>' || NVL(to_char(LastSTotalAmt),'NULL')--昨空头持仓量
      || ',VolumeMultiple=>' || NVL(to_char(VolumeMultiple),'NULL')--合约数量乘数
      || ')';


    RETURN l_string;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN NULL;
  END;



END;
/

