create TYPE BODY Ty_CAPAppTradCodeCondition IS

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_CAPAppTradCodeCondition RETURN SELF AS RESULT IS
  BEGIN
    RETURN;
  END;

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2 IS
    l_string VARCHAR2(4000);
  BEGIN
    l_string:='ty_CAPAppTradCodeCondition('
      || 'BrokerID=>' || '''' || trim(BrokerID) || '''' --经纪公司代码
      || ',InvestorID=>' || '''' || trim(InvestorID) || '''' --投资者代码
      || ',ExchangeID=>' || '''' || trim(ExchangeID) || '''' --交易所代码
      || ',DateNum=>' || NVL(to_char(DateNum),'NULL')--连续交易日天数
      || ',MinPrepa=>' || '''' || trim(MinPrepa) || '''' --开户最低金额限制
      || ')';


    RETURN l_string;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN NULL;
  END;



END;
/

