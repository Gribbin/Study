create TYPE Ty_BrokerWithdrawAlm AS OBJECT
(
    BrokerID CHAR(10),  --经纪公司代码
    WithdrawAlgorithm CHAR(1),  --可提资金算法
    UsingRatio NUMBER(19,8),  --资金使用率
    IncludeCloseProfit CHAR(1),  --可提是否包含平仓盈利
    AllWithoutTrade CHAR(1),  --本日无仓且无成交客户是否受可提比例限制
    AvailIncludeCloseProfit CHAR(1),  --可用是否包含平仓盈利
    IsBrokerUserEvent NUMBER(1),  --是否启用用户事件
    CurrencyID CHAR(3),  --币种
    FundMortgageRatio NUMBER(19,8),  --货币质押比率
    BalanceAlgorithm CHAR(1),  --权益算法

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_BrokerWithdrawAlm RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

