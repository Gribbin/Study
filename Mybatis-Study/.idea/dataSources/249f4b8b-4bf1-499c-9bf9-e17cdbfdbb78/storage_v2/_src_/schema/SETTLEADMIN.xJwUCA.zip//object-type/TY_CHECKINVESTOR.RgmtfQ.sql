create TYPE Ty_CheckInvestor AS OBJECT
(
    BrokerID CHAR(10),  --经纪公司代码
    Systype CHAR(1),  --业务账户类型
    InvestorID CHAR(12),  --投资者代码
    IdentifiedCardType CHAR(2),  --证件类型
    IdentifiedCardNo CHAR(50),  --证件号码
    Mobile CHAR(40),  --手机

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_CheckInvestor RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

