create TYPE Ty_CAPInvstBasicInfo AS OBJECT
(
    BrokerID CHAR(10),  --经纪公司代码
    InvestorID CHAR(12),  --投资者代码
    InvestorName VARCHAR2(80),  --投资者名称
    InvestorType CHAR(1),  --投资者类型
    DepartmentID CHAR(12),  --组织架构代码
    IsEmail NUMBER(1),  --是否接收电子邮件
    IsSMS NUMBER(1),  --是否接收短信
    IsUsingOTP NUMBER(1),  --是否使用令牌
    ClientRegion CHAR(1),  --开户客户地域
    ClientMode CHAR(2),  --开户模式
    RiskLevel CHAR(1),  --风险等级
    ContractCode CHAR(40),  --合同编号
    InvestorFullName VARCHAR2(80),  --投资者全称
    BrokerSecAgentID CHAR(12),  --境外中介机构资金账号
    AgencyRegId CHAR(10),  --监控中心分配的境外中介机构代码
    Telephone CHAR(40),  --联系电话
    PhoneCountryCode CHAR(10),  --国家代码
    PhoneAreaCode CHAR(10),  --区号
    Fax CHAR(40),  --传真
    Mobile CHAR(40),  --移动电话
    ZipCode CHAR(10),  --邮政编码
    EMail CHAR(100),  --电子邮件
    IdentifiedCardType CHAR(1),  --证件类型
    IdentifiedCardNo CHAR(50),  --证件号码
    Classify CHAR(10),  --客户分类码
    Nationality CHAR(15),  --国籍国家
    Country CHAR(15),  --联系地址中的国家
    Province CHAR(50),  --联系地址中的省州
    City CHAR(50),  --联系地址中的城市
    Region CHAR(15),  --区
    Address CHAR(100),  --联系地址
    OriginalCardNO CHAR(50),  --原始证件号码
    Memo CHAR(160),  --备注
    BirthDay CHAR(8),  --出生日期
    Sex CHAR(1),  --性别
    Position CHAR(100),  --职务
    OrganType CHAR(10),  --单位性质
    TaxNo VARCHAR2(30),  --税务登记号
    Corporation VARCHAR2(100),  --法人代表
    Linkman VARCHAR2(100),  --联系人
    LicenseNo CHAR(32),  --统一社会信用代码
    CompanyType CHAR(15),  --企业性质
    Capital NUMBER(21,6),  --注册资本
    CapitalCurrency CHAR(3),  --注册资本货币
    RegistryCountry CHAR(15),  --注册国家
    LedgerManageName VARCHAR2(100),  --产品名称
    AssetmgrClientType CHAR(1),  --资产管理客户类型
    AssetmgrType CHAR(1),  --投资类型
    AssetmgrInstitution CHAR(1),  --资产管理业务的经营机构
    AssetmgrPlanName CHAR(100),  --资产管理计划名称
    SubscriberExtracode CHAR(50),  --委托人附加码
    TrusteeName CHAR(100),  --托（保）管人名称
    BusinessScope CHAR(1000),  --经营范围
    OpenDate CHAR(8),  --开户日期

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_CAPInvstBasicInfo RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

