create TYPE Ty_CFMMCPartBroker AS OBJECT
(
    BrokerID CHAR(10),  --经纪公司代码
    ParticipantID CHAR(10),  --经纪公司统一编码
    Password CHAR(40),  --密码
    IsActive NUMBER(1),  --是否活跃
    UserID CHAR(15),  --用户代码,登录监控中心使用
    DRIdentityID NUMBER(4),  --交易中心代码

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_CFMMCPartBroker RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

