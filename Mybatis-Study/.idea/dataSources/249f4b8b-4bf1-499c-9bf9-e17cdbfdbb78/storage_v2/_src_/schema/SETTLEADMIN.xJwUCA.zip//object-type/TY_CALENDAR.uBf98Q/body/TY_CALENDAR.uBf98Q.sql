create TYPE BODY Ty_Calendar IS

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_Calendar RETURN SELF AS RESULT IS
  BEGIN
    RETURN;
  END;

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2 IS
    l_string VARCHAR2(4000);
  BEGIN
    l_string:='ty_Calendar('
      || 'ExchangeID=>' || '''' || trim(ExchangeID) || '''' --交易所代码
      || ',Day=>' || '''' || trim(Day) || '''' --（自然）日期
      || ',Dat=>' || '''' || trim(Dat) || '''' --公历日
      || ',Wrk=>' || '''' || trim(Wrk) || '''' --工作日
      || ',Tra=>' || '''' || trim(Tra) || '''' --交易日
      || ',Sun=>' || '''' || trim(Sun) || '''' --周日
      || ',Mon=>' || '''' || trim(Mon) || '''' --周一
      || ',Tue=>' || '''' || trim(Tue) || '''' --周二
      || ',Wed=>' || '''' || trim(Wed) || '''' --周三
      || ',Thu=>' || '''' || trim(Thu) || '''' --周四
      || ',Fri=>' || '''' || trim(Fri) || '''' --周五
      || ',Sat=>' || '''' || trim(Sat) || '''' --周六
      || ',Str=>' || '''' || trim(Str) || '''' --月初
      || ',Tal=>' || '''' || trim(Tal) || '''' --月末
      || ',Spr=>' || '''' || trim(Spr) || '''' --春节
      || ')';


    RETURN l_string;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN NULL;
  END;



END;
/

