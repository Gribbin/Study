create TYPE Ty_Credit AS OBJECT
(
    TradingDay CHAR(8),  --交易日
    BrokerID CHAR(10),  --经纪公司代码
    InvestorRange CHAR(1),  --投资者范围
    InvestorID CHAR(12),  --投资者代码
    IsAudit NUMBER(1),  --是否审核
    Credit NUMBER(22,6),  --资金冻结
    EndDate CHAR(8),  --截止日期
    OperatorID CHAR(64),  --录入员代码
    OperateDate CHAR(8),  --录入日期
    OperateTime CHAR(8),  --录入时间
    CheckerID CHAR(64),  --复核员代码
    CheckDate CHAR(8),  --复核日期
    CheckTime CHAR(8),  --复核时间
    CurrencyID CHAR(3),  --币种
    AccountID CHAR(14),  --投资者账号

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_Credit RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

