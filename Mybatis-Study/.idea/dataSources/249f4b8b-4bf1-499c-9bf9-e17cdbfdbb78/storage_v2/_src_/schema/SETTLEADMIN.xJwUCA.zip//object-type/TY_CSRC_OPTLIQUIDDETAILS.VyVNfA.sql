create TYPE Ty_CSRC_OptLiquidDetails AS OBJECT
(
    TradingDay CHAR(10),  --交易日
    ParticipantID CHAR(10),  --会员代码
    InvestorID CHAR(12),  --客户内部资金账户
    ExchangeInstID CHAR(30),  --品种合约
    TradeID CHAR(20),  --成交流水号
    Direction CHAR(1),  --买卖标志
    Price NUMBER(15,3),  --成交价
    OpenPrice NUMBER(15,3),  --开仓价
    Volume NUMBER(20),  --成交量
    PreSettlementPrice NUMBER(15,3),  --昨结算价
    SettlementPrice NUMBER(15,3),  --今结算价
    OptPremiumMoney NUMBER(15,3),  --权利金
    OpenOptPremiumMoney NUMBER(15,3),  --开仓权利金
    OrgTradeID CHAR(20),  --原成交流水号
    ClientID CHAR(10),  --交易编码
    CurrencyID CHAR(3),  --币种
    TradeDate CHAR(10),  --成交日期
    CoverFlag CHAR(1),  --是否备对组合
    InstrumentCode CHAR(8),  --合约编码

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_CSRC_OptLiquidDetails RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

