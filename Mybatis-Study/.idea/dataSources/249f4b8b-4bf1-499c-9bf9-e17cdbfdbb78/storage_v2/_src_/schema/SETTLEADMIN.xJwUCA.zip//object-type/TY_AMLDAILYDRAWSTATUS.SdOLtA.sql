create TYPE Ty_AmlDailyDrawStatus AS OBJECT
(
    BrokerID CHAR(10),  --经纪公司代码
    DrawDay CHAR(8),  --检查日期
    Status CHAR(1),  --抽取状态
    OperatorId CHAR(64),  --操作员代码
    OperateDate CHAR(8),  --日期
    OperateTime CHAR(8),  --时间

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_AmlDailyDrawStatus RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

