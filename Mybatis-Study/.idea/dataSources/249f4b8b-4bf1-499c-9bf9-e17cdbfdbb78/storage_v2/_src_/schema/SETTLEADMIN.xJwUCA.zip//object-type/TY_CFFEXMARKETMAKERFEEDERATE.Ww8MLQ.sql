create TYPE Ty_CFFEXMarketmakerFeeDerate AS OBJECT
(
    Tradingday CHAR(8),  --交易日期
    clrPartid CHAR(10),  --结算会员号
    clrParAbbr CHAR(8),  --结算会员简称
    AccountID CHAR(14),  --资金账户
    partid CHAR(12),  --交易会员号
    partidAbbr CHAR(8),  --交易会员简称
    feeDerate NUMBER(22,6),  --做市商手续费减免额

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_CFFEXMarketmakerFeeDerate RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

