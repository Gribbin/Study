create TYPE BODY Ty_AMCustomer IS

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_AMCustomer RETURN SELF AS RESULT IS
  BEGIN
    RETURN;
  END;

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2 IS
    l_string VARCHAR2(4000);
  BEGIN
    l_string:='ty_AMCustomer('
      || 'TradingDay=>' || '''' || trim(TradingDay) || '''' --交易日
      || ',ParticipantID=>' || '''' || trim(ParticipantID) || '''' --会员代码
      || ',InvestorName=>' || '''' || trim(InvestorName) || '''' --客户名称
      || ',IdentifiedCardNo=>' || '''' || trim(IdentifiedCardNo) || '''' --证件号码
      || ',InvestorID=>' || '''' || trim(InvestorID) || '''' --客户内部资金账户
      || ',City=>' || '''' || trim(City) || '''' --联系地址市
      || ',Address=>' || '''' || trim(Address) || '''' --联系地址
      || ',ZipCode=>' || '''' || trim(ZipCode) || '''' --邮政编码
      || ',TelePhone=>' || '''' || trim(TelePhone) || '''' --联系电话
      || ',CancelFlag=>' || '''' || trim(CancelFlag) || '''' --开户和销户标志
      || ',IsSettlement=>' || '''' || trim(IsSettlement) || '''' --是否为结算会员
      || ',InvestorType=>' || '''' || trim(InvestorType) || '''' --客户类型
      || ',ActiveDate=>' || '''' || trim(ActiveDate) || '''' --开户日期
      || ',EID=>' || '''' || trim(EID) || '''' --组织机构代码
      || ',LicenseNo=>' || '''' || trim(LicenseNo) || '''' --营业执照
      || ',OpenInvestorName=>' || '''' || trim(OpenInvestorName) || '''' --开户授权人名称
      || ',OpenIdentifiedCardNO=>' || '''' || trim(OpenIdentifiedCardNO) || '''' --开户授权人证件号
      || ',FreezeStatus=>' || '''' || trim(FreezeStatus) || '''' --休眠状态
      || ',ClientRegion=>' || '''' || trim(ClientRegion) || '''' --开户客户地域
      || ',National=>' || '''' || trim(National) || '''' --国籍
      || ',Passport=>' || '''' || trim(Passport) || '''' --港澳台及境外自然人有效证件号
      || ',BusinessRegistration=>' || '''' || trim(BusinessRegistration) || '''' --商业登记证
      || ',IsSeconderyAgent=>' || '''' || trim(IsSeconderyAgent) || '''' --是否为二级代理商
      || ',CSRCSecAgentID=>' || '''' || trim(CSRCSecAgentID) || '''' --二级代理编号
      || ',IsAssetmgrIns=>' || '''' || trim(IsAssetmgrIns) || '''' --是否为期货公司子公司
      || ',STKAccountID=>' || '''' || trim(STKAccountID) || '''' --客户证券现货内部资金账户
      || ',STKOpenDate=>' || '''' || trim(STKOpenDate) || '''' --客户证券现货内部资金账户开户日期
      || ',IsMarketMaker=>' || '''' || trim(IsMarketMaker) || '''' --是否为做市商
      || ',OverseasInstitutionType=>' || '''' || trim(OverseasInstitutionType) || '''' --境外特殊参与者与境外中介机构标识
      || ')';


    RETURN l_string;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN NULL;
  END;



END;
/

