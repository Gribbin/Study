create TYPE BODY Ty_CFFEXMarketmakerFeeDerate IS

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_CFFEXMarketmakerFeeDerate RETURN SELF AS RESULT IS
  BEGIN
    RETURN;
  END;

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2 IS
    l_string VARCHAR2(4000);
  BEGIN
    l_string:='ty_CFFEXMarketmakerFeeDerate('
      || 'Tradingday=>' || '''' || trim(Tradingday) || '''' --交易日期
      || ',clrPartid=>' || '''' || trim(clrPartid) || '''' --结算会员号
      || ',clrParAbbr=>' || '''' || trim(clrParAbbr) || '''' --结算会员简称
      || ',AccountID=>' || '''' || trim(AccountID) || '''' --资金账户
      || ',partid=>' || '''' || trim(partid) || '''' --交易会员号
      || ',partidAbbr=>' || '''' || trim(partidAbbr) || '''' --交易会员简称
      || ',feeDerate=>' || NVL(to_char(feeDerate),'NULL')--做市商手续费减免额
      || ')';


    RETURN l_string;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN NULL;
  END;



END;
/

