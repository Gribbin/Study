create TYPE Ty_AmlReportHis AS OBJECT
(
    BrokerID CHAR(10),  --经纪公司代码
    GenerateDay CHAR(8),  --生成日期
    GenSequenceID NUMBER(8),  --当日生成批次编号
    ReportTypeID CHAR(2),  --交易报告类型标识
    ReportType CHAR(1),  --报文类型

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_AmlReportHis RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

