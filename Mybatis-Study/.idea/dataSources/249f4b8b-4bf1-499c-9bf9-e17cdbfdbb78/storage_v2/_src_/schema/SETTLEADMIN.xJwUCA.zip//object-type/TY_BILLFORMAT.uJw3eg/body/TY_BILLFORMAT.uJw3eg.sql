create TYPE BODY Ty_BillFormat IS

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_BillFormat RETURN SELF AS RESULT IS
  BEGIN
    RETURN;
  END;

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2 IS
    l_string VARCHAR2(4000);
  BEGIN
    l_string:='ty_BillFormat('
      || 'BrokerID=>' || '''' || trim(BrokerID) || '''' --经纪公司代码
      || ',NoteType=>' || '''' || trim(NoteType) || '''' --通知类型
      || ',BeginSentence=>' || '''' || trim(BeginSentence) || '''' --开始语句
      || ',EndSentence=>' || '''' || trim(EndSentence) || '''' --结束语句
      || ',LanguageType=>' || '''' || trim(LanguageType) || '''' --通知语言类型
      || ')';


    RETURN l_string;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN NULL;
  END;



END;
/

