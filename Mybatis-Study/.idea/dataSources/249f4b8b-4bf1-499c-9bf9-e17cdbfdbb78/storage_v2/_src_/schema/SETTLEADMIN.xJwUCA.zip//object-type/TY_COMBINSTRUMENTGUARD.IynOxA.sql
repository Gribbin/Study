create TYPE Ty_CombInstrumentGuard AS OBJECT
(
    TradingDay CHAR(8),  --交易日
    BrokerID CHAR(10),  --经纪公司代码
    InstrumentID CHAR(30),  --合约代码
    GuarantRatio NUMBER(19,8),  --安全系数

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_CombInstrumentGuard RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

