create TYPE BODY Ty_BatchExecOrder IS

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_BatchExecOrder RETURN SELF AS RESULT IS
  BEGIN
    RETURN;
  END;

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2 IS
    l_string VARCHAR2(4000);
  BEGIN
    l_string:='ty_BatchExecOrder('
      || 'BrokerID=>' || '''' || trim(BrokerID) || '''' --经纪公司代码
      || ',InvestorID=>' || '''' || trim(InvestorID) || '''' --投资者代码
      || ',InstrumentID=>' || '''' || trim(InstrumentID) || '''' --合约代码
      || ',ExecOrderRef=>' || '''' || trim(ExecOrderRef) || '''' --执行宣告引用
      || ',UserID=>' || '''' || trim(UserID) || '''' --用户代码
      || ',Volume=>' || NVL(to_char(Volume),'NULL')--数量
      || ',RequestID=>' || NVL(to_char(RequestID),'NULL')--请求编号
      || ',BusinessUnit=>' || '''' || trim(BusinessUnit) || '''' --业务单元
      || ',OffsetFlag=>' || '''' || trim(OffsetFlag) || '''' --开平标志
      || ',HedgeFlag=>' || '''' || trim(HedgeFlag) || '''' --投机套保标志
      || ',ActionType=>' || '''' || trim(ActionType) || '''' --执行类型
      || ',PosiDirection=>' || '''' || trim(PosiDirection) || '''' --保留头寸申请的持仓方向
      || ',ReservePositionFlag=>' || '''' || trim(ReservePositionFlag) || '''' --期权行权后是否保留期货头寸的标记
      || ',CloseFlag=>' || '''' || trim(CloseFlag) || '''' --期权行权后生成的头寸是否自动平仓
      || ',ExecOrderLocalID=>' || '''' || trim(ExecOrderLocalID) || '''' --本地执行宣告编号
      || ',ExchangeID=>' || '''' || trim(ExchangeID) || '''' --交易所代码
      || ',ParticipantID=>' || '''' || trim(ParticipantID) || '''' --会员代码
      || ',ClientID=>' || '''' || trim(ClientID) || '''' --客户代码
      || ',ExchangeInstID=>' || '''' || trim(ExchangeInstID) || '''' --合约在交易所的代码
      || ',TraderID=>' || '''' || trim(TraderID) || '''' --交易所交易员代码
      || ',InstallID=>' || NVL(to_char(InstallID),'NULL')--安装编号
      || ',OrderSubmitStatus=>' || '''' || trim(OrderSubmitStatus) || '''' --执行宣告提交状态
      || ',NotifySequence=>' || NVL(to_char(NotifySequence),'NULL')--报单提示序号
      || ',TradingDay=>' || '''' || trim(TradingDay) || '''' --交易日
      || ',SettlementID=>' || NVL(to_char(SettlementID),'NULL')--结算编号
      || ',ExecOrderSysID=>' || '''' || trim(ExecOrderSysID) || '''' --执行宣告编号
      || ',InsertDate=>' || '''' || trim(InsertDate) || '''' --报单日期
      || ',InsertTime=>' || '''' || trim(InsertTime) || '''' --插入时间
      || ',CancelTime=>' || '''' || trim(CancelTime) || '''' --撤销时间
      || ',ExecResult=>' || '''' || trim(ExecResult) || '''' --执行结果
      || ',ClearingPartID=>' || '''' || trim(ClearingPartID) || '''' --结算会员编号
      || ',SequenceNo=>' || NVL(to_char(SequenceNo),'NULL')--序号
      || ',FrontID=>' || NVL(to_char(FrontID),'NULL')--前置编号
      || ',SessionID=>' || NVL(to_char(SessionID),'NULL')--会话编号
      || ',UserProductInfo=>' || '''' || trim(UserProductInfo) || '''' --用户端产品信息
      || ',StatusMsg=>' || '''' || trim(StatusMsg) || '''' --状态信息
      || ',ActiveUserID=>' || '''' || trim(ActiveUserID) || '''' --操作用户代码
      || ',BrokerExecOrderSeq=>' || NVL(to_char(BrokerExecOrderSeq),'NULL')--经纪公司报单编号
      || ')';


    RETURN l_string;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN NULL;
  END;



END;
/

