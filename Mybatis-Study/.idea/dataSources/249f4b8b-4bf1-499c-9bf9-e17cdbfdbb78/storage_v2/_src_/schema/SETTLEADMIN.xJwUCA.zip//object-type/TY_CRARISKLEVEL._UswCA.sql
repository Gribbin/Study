create TYPE Ty_CRARiskLevel AS OBJECT
(
    BrokerID CHAR(10),  --经纪商代码
    RiskLevel NUMBER(8),  --等级编号
    ScoreLower NUMBER(8),  --分值下限
    ScoreUpper NUMBER(8),  --分值上限
    LevelDesc VARCHAR2(120),  --等级名称
    Validity CHAR(8),  --复评有效期

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_CRARiskLevel RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

