create TYPE Ty_BankExchangeRate AS OBJECT
(
    TradingDay CHAR(8),  --交易日
    BrokerID CHAR(10),  --经纪公司代码
    BankID CHAR(3),  --银行编码
    FromCurrencyID CHAR(3),  --原始货币
    FromCurrencyUnit NUMBER(16,8),  --原始货币单位数量
    ToCurrencyID CHAR(3),  --目标货币
    ExchangeRate NUMBER(16,8),  --汇率
    curexchangerate NUMBER(16,8),  --实时汇率
    updatedate CHAR(8),  --最后更新日期
    updatetime CHAR(8),  --最后更新时间

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_BankExchangeRate RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

