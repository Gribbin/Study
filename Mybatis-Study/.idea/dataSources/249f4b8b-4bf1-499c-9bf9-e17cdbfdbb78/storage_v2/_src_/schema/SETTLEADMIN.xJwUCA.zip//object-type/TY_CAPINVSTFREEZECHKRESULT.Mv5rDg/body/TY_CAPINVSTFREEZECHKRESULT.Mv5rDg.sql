create TYPE BODY Ty_CAPInvstFreezeChkResult IS

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_CAPInvstFreezeChkResult RETURN SELF AS RESULT IS
  BEGIN
    RETURN;
  END;

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2 IS
    l_string VARCHAR2(4000);
  BEGIN
    l_string:='ty_CAPInvstFreezeChkResult('
      || 'BrokerID=>' || '''' || trim(BrokerID) || '''' --经纪公司代码
      || ',InvestorID=>' || '''' || trim(InvestorID) || '''' --投资者代码
      || ',ErrorNo=>' || NVL(to_char(ErrorNo),'NULL')--校验状态
      || ',ErrorInfo=>' || '''' || trim(ErrorInfo) || '''' --校验结果
      || ')';


    RETURN l_string;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN NULL;
  END;



END;
/

