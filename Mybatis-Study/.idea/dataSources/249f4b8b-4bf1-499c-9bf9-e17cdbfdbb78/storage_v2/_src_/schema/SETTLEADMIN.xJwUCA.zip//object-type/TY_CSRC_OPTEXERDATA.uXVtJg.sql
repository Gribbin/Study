create TYPE Ty_CSRC_OptExerData AS OBJECT
(
    TradingDay CHAR(10),  --交易日
    ParticipantID CHAR(10),  --会员代码
    InvestorID CHAR(12),  --客户内部资金账户
    ExchangeInstID CHAR(30),  --品种合约
    ExerDate CHAR(10),  --执行日期
    ExerTime CHAR(10),  --执行时间
    TradeID CHAR(20),  --流水号
    Direction CHAR(1),  --买卖标志
    HedgeFlag CHAR(1),  --投机套保标志
    ExerVolume NUMBER(20),  --执行手数
    ExerPrice NUMBER(20,7),  --执行价格
    ExerProfit NUMBER(15,3),  --行权盈亏
    Transfee NUMBER(15,3),  --手续费
    OptionsType CHAR(1),  --期权类型
    UnderlyingProductID CHAR(6),  --标的品种
    UnderlyingInstrID CHAR(30),  --标的合约
    ClientID CHAR(10),  --交易编码
    ExchangeFlag CHAR(1),  --交易所统一标识
    IsSettlement CHAR(1),  --是否为非结算会员
    CurrencyID CHAR(3),  --币种
    StrikeLockMargin NUMBER(15,3),  --行权锁定保证金
    FreezEMoney NUMBER(15,3),  --冻结资金
    InstrumentCode CHAR(8),  --合约编码

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_CSRC_OptExerData RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

