create TYPE BODY Ty_CffexPositionComDtl IS

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_CffexPositionComDtl RETURN SELF AS RESULT IS
  BEGIN
    RETURN;
  END;

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2 IS
    l_string VARCHAR2(4000);
  BEGIN
    l_string:='ty_CffexPositionComDtl('
      || 'TradingDay=>' || '''' || trim(TradingDay) || '''' --交易日
      || ',OpenDate=>' || '''' || trim(OpenDate) || '''' --开仓日期
      || ',ExchangeID=>' || '''' || trim(ExchangeID) || '''' --交易所代码
      || ',SettlementID=>' || NVL(to_char(SettlementID),'NULL')--结算编号
      || ',BrokerID=>' || '''' || trim(BrokerID) || '''' --经纪公司代码
      || ',InvestorID=>' || '''' || trim(InvestorID) || '''' --投资者代码
      || ',InvestUnitID=>' || '''' || trim(InvestUnitID) || '''' --投资单元代码
      || ',TradeID=>' || '''' || trim(TradeID) || '''' --撮合编号
      || ',InstrumentID=>' || '''' || trim(InstrumentID) || '''' --合约代码
      || ',HedgeFlag=>' || '''' || trim(HedgeFlag) || '''' --投机套保标志
      || ',Direction=>' || '''' || trim(Direction) || '''' --买卖
      || ',TotalAmt=>' || NVL(to_char(TotalAmt),'NULL')--持仓量
      || ',Margin=>' || NVL(to_char(Margin),'NULL')--保证金
      || ',ExchMargin=>' || NVL(to_char(ExchMargin),'NULL')--交易所保证金
      || ',MarginRateByMoney=>' || NVL(to_char(MarginRateByMoney),'NULL')--保证金率按金额
      || ',MarginRateByVolume=>' || NVL(to_char(MarginRateByVolume),'NULL')--保证金率按手数
      || ',ComType=>' || NVL(to_char(ComType),'NULL')--组合成交类型
      || ',LegID=>' || '''' || trim(LegID) || '''' --单腿编号
      || ',VolumeMultiple=>' || NVL(to_char(VolumeMultiple),'NULL')--合约数量乘数
      || ',CombInstrID=>' || '''' || trim(CombInstrID) || '''' --组合合约代码
      || ',TradeGroupID=>' || '''' || trim(TradeGroupID) || '''' --合约组号
      || ',CombineType=>' || '''' || trim(CombineType) || '''' --组合类型
      || ')';


    RETURN l_string;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN NULL;
  END;



END;
/

