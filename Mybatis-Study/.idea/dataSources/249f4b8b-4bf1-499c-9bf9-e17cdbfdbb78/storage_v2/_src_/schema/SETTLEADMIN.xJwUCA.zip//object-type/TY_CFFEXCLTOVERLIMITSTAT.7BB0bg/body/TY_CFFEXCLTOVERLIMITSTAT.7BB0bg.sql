create TYPE BODY Ty_CFFEXCltOverLimitStat IS

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_CFFEXCltOverLimitStat RETURN SELF AS RESULT IS
  BEGIN
    RETURN;
  END;

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2 IS
    l_string VARCHAR2(4000);
  BEGIN
    l_string:='ty_CFFEXCltOverLimitStat('
      || 'TradingDay=>' || '''' || trim(TradingDay) || '''' --交易日
      || ',ExchangeID=>' || '''' || trim(ExchangeID) || '''' --交易所代码
      || ',ParticipantID=>' || '''' || trim(ParticipantID) || '''' --会员代码
      || ',TradePartID=>' || '''' || trim(TradePartID) || '''' --交易会员代码
      || ',ClientID=>' || '''' || trim(ClientID) || '''' --客户编码
      || ',ExchangeInstID=>' || '''' || trim(ExchangeInstID) || '''' --合约代码
      || ',StatStyle=>' || '''' || trim(StatStyle) || '''' --强平统计类型
      || ',TotalAmt=>' || NVL(to_char(TotalAmt),'NULL')--合约总持仓量
      || ',ForceCloseReason=>' || '''' || trim(ForceCloseReason) || '''' --强平原因
      || ',BTotalAmt=>' || NVL(to_char(BTotalAmt),'NULL')--多头持仓量
      || ',BForceCloseAmt=>' || NVL(to_char(BForceCloseAmt),'NULL')--多头强平量
      || ',BForceClosedAmt=>' || NVL(to_char(BForceClosedAmt),'NULL')--多头已强平量
      || ',STotalAmt=>' || NVL(to_char(STotalAmt),'NULL')--空头持仓量
      || ',SForceCloseAmt=>' || NVL(to_char(SForceCloseAmt),'NULL')--空头强平量
      || ',SForceClosedAmt=>' || NVL(to_char(SForceClosedAmt),'NULL')--空头已强平量
      || ',ForceCloseSum=>' || NVL(to_char(ForceCloseSum),'NULL')--强平金额
      || ',ForceClosedSum=>' || NVL(to_char(ForceClosedSum),'NULL')--已强平金额
      || ',TransferFlag=>' || '''' || trim(TransferFlag) || '''' --处理标志
      || ',OperatorID=>' || '''' || trim(OperatorID) || '''' --操作员
      || ',OperationDate=>' || '''' || trim(OperationDate) || '''' --操作日期
      || ',OperationTime=>' || '''' || trim(OperationTime) || '''' --操作时间
      || ')';


    RETURN l_string;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN NULL;
  END;



END;
/

