create TYPE BODY Ty_CopyInstrFutMarginRate IS

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_CopyInstrFutMarginRate RETURN SELF AS RESULT IS
  BEGIN
    RETURN;
  END;

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2 IS
    l_string VARCHAR2(4000);
  BEGIN
    l_string:='ty_CopyInstrFutMarginRate('
      || 'TradingDay=>' || '''' || trim(TradingDay) || '''' --交易日
      || ',BrokerID=>' || '''' || trim(BrokerID) || '''' --经纪公司代码
      || ',InvestorRange=>' || '''' || trim(InvestorRange) || '''' --投资者范围
      || ',InvestorID=>' || '''' || trim(InvestorID) || '''' --投资者代码
      || ',InvestUnitID=>' || '''' || trim(InvestUnitID) || '''' --投资单元代码
      || ',SourceExchangeID=>' || '''' || trim(SourceExchangeID) || '''' --源交易所代码
      || ',SourceInstrumentID=>' || '''' || trim(SourceInstrumentID) || '''' --源合约代码
      || ',TargetExchangeID=>' || '''' || trim(TargetExchangeID) || '''' --目标交易所代码
      || ',TargetInstrumentID=>' || '''' || trim(TargetInstrumentID) || '''' --目标合约代码
      || ',RatioAttr=>' || '''' || trim(RatioAttr) || '''' --费率属性
      || ')';


    RETURN l_string;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN NULL;
  END;



END;
/

