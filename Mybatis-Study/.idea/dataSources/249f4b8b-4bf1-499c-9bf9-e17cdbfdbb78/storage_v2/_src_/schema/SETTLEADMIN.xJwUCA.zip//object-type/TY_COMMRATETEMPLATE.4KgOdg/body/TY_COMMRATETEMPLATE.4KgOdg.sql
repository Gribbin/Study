create TYPE BODY Ty_CommRateTemplate IS

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_CommRateTemplate RETURN SELF AS RESULT IS
  BEGIN
    RETURN;
  END;

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2 IS
    l_string VARCHAR2(4000);
  BEGIN
    l_string:='ty_CommRateTemplate('
      || 'BrokerID=>' || '''' || trim(BrokerID) || '''' --经纪公司代码
      || ',RateTemplateID=>' || '''' || trim(RateTemplateID) || '''' --模型代码
      || ',RateTemplateName=>' || '''' || trim(RateTemplateName) || '''' --模型名称
      || ',ExchangeID=>' || '''' || trim(ExchangeID) || '''' --交易所代码
      || ',ProductID=>' || '''' || trim(ProductID) || '''' --产品代码
      || ',RateTemplateMemo=>' || '''' || trim(RateTemplateMemo) || '''' --模型说明
      || ',IsActive=>' || '''' || trim(IsActive) || '''' --是否启用
      || ',OperatorID=>' || '''' || trim(OperatorID) || '''' --录入员代码
      || ',OperateDate=>' || '''' || trim(OperateDate) || '''' --录入日期
      || ',OperateTime=>' || '''' || trim(OperateTime) || '''' --录入时间
      || ',TemplateType=>' || '''' || trim(TemplateType) || '''' --模型类型
      || ',VersionNo=>' || NVL(to_char(VersionNo),'NULL')--版本号
      || ')';


    RETURN l_string;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN NULL;
  END;



END;
/

