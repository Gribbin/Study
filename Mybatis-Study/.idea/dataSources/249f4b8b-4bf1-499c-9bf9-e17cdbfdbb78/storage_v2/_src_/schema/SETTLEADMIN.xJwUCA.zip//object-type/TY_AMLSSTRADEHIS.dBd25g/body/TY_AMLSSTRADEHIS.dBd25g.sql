create TYPE BODY Ty_AMLSSTradeHis IS

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_AMLSSTradeHis RETURN SELF AS RESULT IS
  BEGIN
    RETURN;
  END;

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2 IS
    l_string VARCHAR2(4000);
  BEGIN
    l_string:='ty_AMLSSTradeHis('
      || 'TradingDay=>' || '''' || trim(TradingDay) || '''' --交易日
      || ',BrokerID=>' || '''' || trim(BrokerID) || '''' --经纪公司代码
      || ',GenerateDay=>' || '''' || trim(GenerateDay) || '''' --生成日期
      || ',GenSequenceID=>' || NVL(to_char(GenSequenceID),'NULL')--当日生成批次编号
      || ',ReportTypeID=>' || '''' || trim(ReportTypeID) || '''' --交易报告类型标识
      || ',ReportType=>' || '''' || trim(ReportType) || '''' --报文类型
      || ',AMLSSTradeID=>' || NVL(to_char(AMLSSTradeID),'NULL')--反洗钱可疑交易序列号
      || ',CharacterID=>' || '''' || trim(CharacterID) || '''' --可疑特征代码
      || ',TouchDay=>' || '''' || trim(TouchDay) || '''' --可疑交易发生日期
      || ',InvestorID=>' || '''' || trim(InvestorID) || '''' --投资者代码
      || ',DepositSeqNo=>' || '''' || trim(DepositSeqNo) || '''' --业务标示号
      || ',AMLGenStatus=>' || '''' || trim(AMLGenStatus) || '''' --数据来源
      || ',DrawDay=>' || '''' || trim(DrawDay) || '''' --检查日期
      || ',InvestorType=>' || '''' || trim(InvestorType) || '''' --投资者类型
      || ',InvestorName=>' || '''' || trim(InvestorName) || '''' --投资者名称
      || ',IdentifiedCardType=>' || '''' || trim(IdentifiedCardType) || '''' --证件类型
      || ',IdentifiedCardNo=>' || '''' || trim(IdentifiedCardNo) || '''' --证件号码
      || ',FutureAccount=>' || '''' || trim(FutureAccount) || '''' --期货账号
      || ',FutureCurrency=>' || '''' || trim(FutureCurrency) || '''' --期货账号币种
      || ',AccountID=>' || '''' || trim(AccountID) || '''' --资金账户
      || ',CurrencyID=>' || '''' || trim(CurrencyID) || '''' --资金账户币种
      || ',BankAccount=>' || '''' || trim(BankAccount) || '''' --结算账号
      || ',FundInvestorName=>' || '''' || trim(FundInvestorName) || '''' --交易代办人
      || ',FundIdentifiedCardType=>' || '''' || trim(FundIdentifiedCardType) || '''' --交易代办人证件类型
      || ',FundIdentifiedCardNo=>' || '''' || trim(FundIdentifiedCardNo) || '''' --交易代办人证件号码
      || ',OrderInvestorName=>' || '''' || trim(OrderInvestorName) || '''' --经办人名称
      || ',OrderIdentifiedCardType=>' || '''' || trim(OrderIdentifiedCardType) || '''' --经办人证件类型
      || ',OrderIdentifiedCardNo=>' || '''' || trim(OrderIdentifiedCardNo) || '''' --经办人证件号码
      || ',TradingTime=>' || '''' || trim(TradingTime) || '''' --交易时间
      || ',TradingType=>' || '''' || trim(TradingType) || '''' --交易种类
      || ',TransactClass=>' || '''' || trim(TransactClass) || '''' --涉外收支交易分类与代码
      || ',TradeTaget=>' || '''' || trim(TradeTaget) || '''' --交易品种代码
      || ',CapitalCurrency=>' || '''' || trim(CapitalCurrency) || '''' --币种
      || ',TradeVolume=>' || NVL(to_char(TradeVolume),'NULL')--交易金额
      || ',TradeDirect=>' || '''' || trim(TradeDirect) || '''' --资金进出方向
      || ',TradeModel=>' || '''' || trim(TradeModel) || '''' --资金进出方式
      || ')';


    RETURN l_string;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN NULL;
  END;



END;
/

