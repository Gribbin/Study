create TYPE Ty_BankFlagMaping AS OBJECT
(
    BankId CHAR(3),  --银行代码
    BankFlag CHAR(3),  --银行统一标识类型
    BankName CHAR(100),  --银行名称
    BankMapType CHAR(1),  --类型

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_BankFlagMaping RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

