create TYPE Ty_CSRC_OptHoldData AS OBJECT
(
    TradingDay CHAR(10),  --交易日
    ParticipantID CHAR(10),  --会员代码
    InvestorID CHAR(12),  --客户内部资金账户
    ExchangeInstID CHAR(30),  --品种合约
    Direction CHAR(1),  --买卖标志
    HedgeFlag CHAR(1),  --投机套保标志
    TotalAmt NUMBER(20),  --持仓量
    Margin NUMBER(15,3),  --交易保证金
    PositionProfitByDate NUMBER(15,3),  --持仓盈亏(逐日盯市)
    PositionProfitByTrade NUMBER(15,3),  --持仓盈亏(逐笔对冲)
    AvgPrice NUMBER(15,3),  --持仓均价
    LastSettlementPrice NUMBER(15,3),  --昨结算价
    SettlementPrice NUMBER(15,3),  --今结算价
    ClientID CHAR(10),  --交易编码
    ExchangeFlag CHAR(1),  --交易所统一标识
    IsSettlement CHAR(1),  --是否为非结算会员
    CurrencyID CHAR(3),  --币种
    OptionsType CHAR(1),  --期权类型
    ExerPrice NUMBER(20,7),  --执行价格
    UnderlyingProductID CHAR(6),  --标的品种
    UnderlyingInstrID CHAR(30),  --标的合约
    CoverFlag CHAR(1),  --是否备对组合
    InstrumentCode CHAR(8),  --合约编码

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_CSRC_OptHoldData RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

