create PACKAGE BODY PKGS_Enums IS
    --CommRateType:浮动手续费类型 -->>
    Function FLOATCR_Open
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --开仓
	  end;

    Function FLOATCR_Close
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --平仓
	  end;

    Function FLOATCR_CloseToday
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --平今
	  end;

    Function FLOATCR_Delivery
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '4'; --交割
	  end;

    Function FLOATCR_Strike
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '5'; --执行
	  end;

    Function FLOATCR_Perform
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '6'; --履约
	  end;

    Function FLOATCR_OpenClose
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '7'; --短线开平
	  end;

    --CommRateType:浮动手续费类型 --<<

    --AccountType:账户状态 -->>
    Function CLOUD_None
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'N'; --无账户
	  end;

    Function CLOUD_Active
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'A'; --活跃
	  end;

    Function CLOUD_Sleep
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'S'; --休眠
	  end;

    Function CLOUD_Canceled
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'C'; --注销
	  end;

    Function CLOUD_Frozen
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'D'; --冻结
	  end;

    --AccountType:账户状态 --<<

    --TaxType:税收类型 -->>
    Function TAX_Local
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'A'; --仅为中国税收居民
	  end;

    Function TAX_NLocal
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'B'; --仅为非居民
	  end;

    Function TAX_Both
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'C'; --既是中国税收居民又是其他国家（地区）税收居民
	  end;

    --TaxType:税收类型 --<<

    --PlatformType:政要关系 -->>
    Function PF_Self
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'A'; --外国政要
	  end;

    Function PF_Member
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'B'; --外国政要家庭成员
	  end;

    Function PF_Friend
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'C'; --与外国政要关系密切
	  end;

    Function PF_Manager
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'E'; --国际组织的高级管理人员
	  end;

    Function PF_None
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'D'; --无关系
	  end;

    --PlatformType:政要关系 --<<

    --CreditRecord:诚信记录 -->>
    Function CREDIT_PBCC
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'A'; --中国人民银行征信中心
	  end;

    Function CREDIT_SPCP
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'B'; --最高人民法院失信被执行人名单
	  end;

    Function CREDIT_AMIC
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'C'; --工商行政管理机构
	  end;

    Function CREDIT_TA
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'D'; --税务管理机构
	  end;

    Function CREDIT_RG
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'E'; --监管机构、自律组织
	  end;

    Function CREDIT_RB
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'F'; --投资者在期货经营机构从事投资活动时产生的违约行为记录
	  end;

    Function CREDIT_ERP
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'G'; --过度维权等不当行为信息
	  end;

    Function CREDIT_Other
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'H'; --其他组织
	  end;

    Function CREDIT_None
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'I'; --无
	  end;

    --CreditRecord:诚信记录 --<<

    --TradingYears:投资期限 -->>
    Function YEARS_One
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'A'; --0年-1年
	  end;

    Function YEARS_Five
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'B'; --1年-5年
	  end;

    Function YEARS_Beyond
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'C'; --5年以上
	  end;

    --TradingYears:投资期限 --<<

    --TradingProducts:投资品种 -->>
    Function PRODUCTS_Futures
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'A'; --期货、期权
	  end;

    Function PRODUCTS_Asset
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'B'; --资管产品
	  end;

    Function PRODUCTS_Other
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'C'; --其他
	  end;

    --TradingProducts:投资品种 --<<

    --ProfitType:收益类型 -->>
    Function PROFIT_safe
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'A'; --稳健
	  end;

    Function PROFIT_grow
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'B'; --成长
	  end;

    Function PROFIT_Radical
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'C'; --激进
	  end;

    --ProfitType:收益类型 --<<

    --ControlRelation:控制关系 -->>
    Function CR_None
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'A'; --不存在
	  end;

    Function CR_Exist
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'B'; --存在
	  end;

    --ControlRelation:控制关系 --<<

    --Beneficiary:收益人 -->>
    Function BENEFIT_Self
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'A'; --本人
	  end;

    Function BENEFIT_Other
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'B'; --其他
	  end;

    --Beneficiary:收益人 --<<

    --Education:学历 -->>
    Function EDUCATION_Master
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --硕士及以上
	  end;

    Function EDUCATION_Bachelor
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --大学本科
	  end;

    Function EDUCATION_Junior
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '4'; --大学专科
	  end;

    Function EDUCATION_Senior
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '5'; --高中及以下
	  end;

    --Education:学历 --<<

    --OpenStatus:开通状态 -->>
    Function OPENSTATUS_Handleing
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --处理中
	  end;

    Function OPENSTATUS_HandleSuccess
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --处理成功
	  end;

    Function OPENSTATUS_HandleFailed
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --处理失败
	  end;

    --OpenStatus:开通状态 --<<

    --IfFlag:是否过期 -->>
    Function CLOUD_NO
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --不过期
	  end;

    Function CLOUD_Yes
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --过期
	  end;

    --IfFlag:是否过期 --<<

    --SpecialFlag:踩雷题0分标识 -->>
    Function CLOUD_NoZero
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --不是0分
	  end;

    Function CLOUD_YesZero
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --是0分
	  end;

    --SpecialFlag:踩雷题0分标识 --<<

    --AmlSYRInvestorType:投资者类型 -->>
    Function AMLIT_NP
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --自然人
	  end;

    Function AMLIT_NNP
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --非自然人
	  end;

    --AmlSYRInvestorType:投资者类型 --<<

    --NPSubtype:自然人细分类型 -->>
    Function AMLITNP_Z
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --Z
	  end;

    Function AMLITNP_O
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --O
	  end;

    --NPSubtype:自然人细分类型 --<<

    --NNPSubtype:非自然人细分类型 -->>
    Function AMLITNNP_0
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --公司
	  end;

    Function AMLITNNP_1
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --合伙企业
	  end;

    Function AMLITNNP_2
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --信托
	  end;

    Function AMLITNNP_3
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --基金
	  end;

    Function AMLITNNP_4
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '4'; --个体工商户
	  end;

    Function AMLITNNP_5
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '5'; --个人独资企业
	  end;

    Function AMLITNNP_6
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '6'; --不具备法人资格的专业服务机构
	  end;

    Function AMLITNNP_7
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '7'; --经营农林渔牧产业的非公司制农民专业合作组织
	  end;

    Function AMLITNNP_8
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '8'; --受政府控制的企事业单位
	  end;

    Function AMLITNNP_9
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '9'; --其他
	  end;

    --NNPSubtype:非自然人细分类型 --<<

    --BeneficiaryRole:受益人角色 -->>
    Function AMLBR_0
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --股东
	  end;

    Function AMLBR_1
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --高管
	  end;

    Function AMLBR_2
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --通过人事对公司控制
	  end;

    Function AMLBR_3
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --通过财务对公司控制
	  end;

    --BeneficiaryRole:受益人角色 --<<

    --Action:报文类型 -->>
    Function AMLNIACTION_N
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'N'; --新增
	  end;

    Function AMLNIACTION_C
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'C'; --修改
	  end;

    Function AMLNIACTION_D
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'D'; --删除
	  end;

    --Action:报文类型 --<<

    --TradingRightSource:权限来源 -->>
    Function TRS_General
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --普通交易权限
	  end;

    Function TRS_Special
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --特殊交易权限
	  end;

    --TradingRightSource:权限来源 --<<

    --BankRela:银期关系是否存在 -->>
    Function BR_No
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --不存在
	  end;

    Function BR_Yes
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --存在
	  end;

    --BankRela:银期关系是否存在 --<<

    --StrategyBatchOpType:批量操作类型 -->>
    Function SBOT_Apply
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --批量应用
	  end;

    Function SBOT_Cancel
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --批量取消应用
	  end;

    --StrategyBatchOpType:批量操作类型 --<<

    --STKMarketID:市场代码 -->>
    Function STKMK_ShSpot
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --上海A股市场
	  end;

    Function STKMK_ShOpt
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'a'; --上海期权市场
	  end;

    Function STKMK_SzOpt
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --深圳期权市场
	  end;

    Function STKMK_SzSpot
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'b'; --深圳A股市场
	  end;

    --STKMarketID:市场代码 --<<

    --ExchangeProperty:交易所属性 -->>
    Function EXP_Normal
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --正常
	  end;

    Function EXP_GenOrderByTrade
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --根据成交生成报单
	  end;

    --ExchangeProperty:交易所属性 --<<

    --IdCardType:证件类型 -->>
    Function ICT_EID
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --组织机构代码
	  end;

    Function ICT_IDCard
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --中国公民身份证
	  end;

    Function ICT_OfficerIDCard
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --军官证
	  end;

    Function ICT_PoliceIDCard
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --警官证
	  end;

    Function ICT_SoldierIDCard
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '4'; --士兵证
	  end;

    Function ICT_HouseholdRegister
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '5'; --户口簿
	  end;

    Function ICT_Passport
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '6'; --护照
	  end;

    Function ICT_TaiwanCompatriotIDCard
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '7'; --台胞证
	  end;

    Function ICT_HomeComingCard
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '8'; --回乡证
	  end;

    Function ICT_LicenseNo
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '9'; --统一社会信用代码
	  end;

    Function ICT_TaxNo
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'A'; --税务登记号/当地纳税ID
	  end;

    Function ICT_HMMainlandTravelPermit
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'B'; --港澳居民来往内地通行证
	  end;

    Function ICT_TwMainlandTravelPermit
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'C'; --台湾居民来往大陆通行证
	  end;

    Function ICT_DrivingLicense
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'D'; --驾照
	  end;

    Function ICT_SocialID
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'F'; --当地社保ID
	  end;

    Function ICT_LocalID
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'G'; --当地身份证
	  end;

    Function ICT_BusinessRegistration
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'H'; --商业登记证
	  end;

    Function ICT_HKMCIDCard
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'I'; --港澳永久性居民身份证
	  end;

    Function ICT_AccountsPermits
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'J'; --人行开户许可证
	  end;

    Function ICT_PermanantResidence
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'K'; --外国人永久居留证
	  end;

    Function ICT_AssetProductRecord
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'L'; --资管产品备案函
	  end;

    Function ICT_HKMCTWResisdencePermit
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'M'; --港澳台居民居住证
	  end;

    Function ICT_CompanyFoundCertifyNo
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'N'; --机构成立证明文件
	  end;

    Function ICT_OtherCard
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'x'; --其他证件
	  end;

    --IdCardType:证件类型 --<<

    --InvestorRange:投资者范围 -->>
    Function IR_All
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --所有
	  end;

    Function IR_Group
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --投资者组
	  end;

    Function IR_Single
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --单一投资者
	  end;

    --InvestorRange:投资者范围 --<<

    --RateInvestorRange:投资者范围(专为手续费率和保证金率) -->>
    Function RIR_All
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --公司标准
	  end;

    Function RIR_Model
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --模板
	  end;

    Function RIR_Single
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --单一投资者
	  end;

    --RateInvestorRange:投资者范围(专为手续费率和保证金率) --<<

    --DepartmentRange:组织架构或投资者范围 -->>
    Function DR_All
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --所有
	  end;

    Function DR_Group
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --组织架构
	  end;

    Function DR_Single
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --单一投资者
	  end;

    --DepartmentRange:组织架构或投资者范围 --<<

    --DataSyncStatus:数据同步状态 -->>
    Function DS_Asynchronous
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --未同步
	  end;

    Function DS_Synchronizing
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --同步中
	  end;

    Function DS_Synchronized
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --已同步
	  end;

    --DataSyncStatus:数据同步状态 --<<

    --BrokerDataSyncStatus:经纪公司数据同步状态 -->>
    Function BDS_Synchronized
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --已同步
	  end;

    Function BDS_Synchronizing
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --同步中
	  end;

    --BrokerDataSyncStatus:经纪公司数据同步状态 --<<

    --ExchangeConnectStatus:交易所连接状态 -->>
    Function ECS_NoConnection
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --没有任何连接
	  end;

    Function ECS_QryInstrumentSent
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --已经发出合约查询请求
	  end;

    Function ECS_GotInformation
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '9'; --已经获取信息
	  end;

    --ExchangeConnectStatus:交易所连接状态 --<<

    --TraderConnectStatus:交易所交易员连接状态 -->>
    Function TCS_NotConnected
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --没有任何连接
	  end;

    Function TCS_Connected
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --已经连接
	  end;

    Function TCS_QryInstrumentSent
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --已经发出合约查询请求
	  end;

    Function TCS_SubPrivateFlow
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '4'; --订阅私有流
	  end;

    --TraderConnectStatus:交易所交易员连接状态 --<<

    --FunctionCode:功能代码 -->>
    Function FC_DataAsync
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --数据异步化
	  end;

    Function FC_ForceUserLogout
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --强制用户登出
	  end;

    Function FC_UserPasswordUpdate
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --变更管理用户口令
	  end;

    Function FC_BrokerPasswordUpdate
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '4'; --变更经纪公司口令
	  end;

    Function FC_InvestorPasswordUpdate
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '5'; --变更投资者口令
	  end;

    Function FC_OrderInsert
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '6'; --报单插入
	  end;

    Function FC_OrderAction
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '7'; --报单操作
	  end;

    Function FC_SyncSystemData
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '8'; --同步系统数据
	  end;

    Function FC_SyncBrokerData
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '9'; --同步经纪公司数据
	  end;

    Function FC_BachSyncBrokerData
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'A'; --批量同步经纪公司数据
	  end;

    Function FC_SuperQuery
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'B'; --超级查询
	  end;

    Function FC_ParkedOrderInsert
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'C'; --预埋报单插入
	  end;

    Function FC_ParkedOrderAction
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'D'; --预埋报单操作
	  end;

    Function FC_SyncOTP
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'E'; --同步动态令牌
	  end;

    Function FC_DeleteOrder
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'F'; --删除未知单
	  end;

    --FunctionCode:功能代码 --<<

    --BrokerFunctionCode:经纪公司功能代码 -->>
    Function BFC_ForceUserLogout
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --强制用户登出
	  end;

    Function BFC_UserPasswordUpdate
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --变更用户口令
	  end;

    Function BFC_SyncBrokerData
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --同步经纪公司数据
	  end;

    Function BFC_BachSyncBrokerData
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '4'; --批量同步经纪公司数据
	  end;

    Function BFC_OrderInsert
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '5'; --报单插入
	  end;

    Function BFC_OrderAction
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '6'; --报单操作
	  end;

    Function BFC_AllQuery
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '7'; --全部查询
	  end;

    Function BFC_log
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'a'; --系统功能：登入/登出/修改密码等
	  end;

    Function BFC_BaseQry
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'b'; --基本查询：查询基础数据，如合约，交易所等常量
	  end;

    Function BFC_TradeQry
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'c'; --交易查询：如查成交，委托
	  end;

    Function BFC_Trade
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'd'; --交易功能：报单，撤单
	  end;

    Function BFC_Virement
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'e'; --银期转账
	  end;

    Function BFC_Risk
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'f'; --风险监控
	  end;

    Function BFC_Session
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'g'; --查询/管理：查询会话，踢人等
	  end;

    Function BFC_RiskNoticeCtl
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'h'; --风控通知控制
	  end;

    Function BFC_RiskNotice
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'i'; --风控通知发送
	  end;

    Function BFC_BrokerDeposit
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'j'; --察看经纪公司资金权限
	  end;

    Function BFC_QueryFund
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'k'; --资金查询
	  end;

    Function BFC_QueryOrder
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'l'; --报单查询
	  end;

    Function BFC_QueryTrade
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'm'; --成交查询
	  end;

    Function BFC_QueryPosition
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'n'; --持仓查询
	  end;

    Function BFC_QueryMarketData
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'o'; --行情查询
	  end;

    Function BFC_QueryUserEvent
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'p'; --用户事件查询
	  end;

    Function BFC_QueryRiskNotify
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'q'; --风险通知查询
	  end;

    Function BFC_QueryFundChange
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'r'; --出入金查询
	  end;

    Function BFC_QueryInvestor
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 's'; --投资者信息查询
	  end;

    Function BFC_QueryTradingCode
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 't'; --交易编码查询
	  end;

    Function BFC_ForceClose
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'u'; --强平
	  end;

    Function BFC_PressTest
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'v'; --压力测试
	  end;

    Function BFC_RemainCalc
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'w'; --权益反算
	  end;

    Function BFC_NetPositionInd
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'x'; --净持仓保证金指标
	  end;

    Function BFC_RiskPredict
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'y'; --风险预算
	  end;

    Function BFC_DataExport
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'z'; --数据导出
	  end;

    Function BFC_RiskTargetSetup
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'A'; --风控指标设置
	  end;

    Function BFC_MarketDataWarn
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'B'; --行情预警
	  end;

    Function BFC_QryBizNotice
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'C'; --业务通知查询
	  end;

    Function BFC_CfgBizNotice
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'D'; --业务通知模板设置
	  end;

    Function BFC_SyncOTP
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'E'; --同步动态令牌
	  end;

    Function BFC_SendBizNotice
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'F'; --发送业务通知
	  end;

    Function BFC_CfgRiskLevelStd
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'G'; --风险级别标准设置
	  end;

    Function BFC_TbCommand
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'H'; --交易终端应急功能
	  end;

    Function BFC_DeleteOrder
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'J'; --删除未知单
	  end;

    Function BFC_ParkedOrderInsert
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'K'; --预埋报单插入
	  end;

    Function BFC_ParkedOrderAction
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'L'; --预埋报单操作
	  end;

    Function BFC_ExecOrderNoCheck
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'M'; --资金不够仍允许行权-批量行权
	  end;

    Function BFC_Designate
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'N'; --指定
	  end;

    Function BFC_StockDisposal
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'O'; --证券处置
	  end;

    Function BFC_BrokerDepositWarn
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'Q'; --席位资金预警
	  end;

    Function BFC_CoverWarn
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'S'; --备兑不足预警
	  end;

    Function BFC_PreExecOrder
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'T'; --行权试算
	  end;

    Function BFC_ExecOrderRisk
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'P'; --行权交收风险
	  end;

    Function BFC_PosiLimitWarn
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'U'; --持仓限额预警
	  end;

    Function BFC_QryPosiLimit
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'V'; --持仓限额查询
	  end;

    Function BFC_FBSign
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'W'; --银期签到签退
	  end;

    Function BFC_FBAccount
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'X'; --银期签约解约
	  end;

    --BrokerFunctionCode:经纪公司功能代码 --<<

    --OrderActionStatus:报单操作状态 -->>
    Function OAS_Submitted
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'a'; --已经提交
	  end;

    Function OAS_Accepted
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'b'; --已经接受
	  end;

    Function OAS_Rejected
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'c'; --已经被拒绝
	  end;

    --OrderActionStatus:报单操作状态 --<<

    --OrderStatus:报单状态 -->>
    Function OST_AllTraded
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --全部成交
	  end;

    Function OST_PartTradedQueueing
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --部分成交还在队列中
	  end;

    Function OST_PartTradedNotQueueing
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --部分成交不在队列中
	  end;

    Function OST_NoTradeQueueing
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --未成交还在队列中
	  end;

    Function OST_NoTradeNotQueueing
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '4'; --未成交不在队列中
	  end;

    Function OST_Canceled
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '5'; --撤单
	  end;

    Function OST_Unknown
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'a'; --未知
	  end;

    Function OST_NotTouched
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'b'; --尚未触发
	  end;

    Function OST_Touched
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'c'; --已触发
	  end;

    --OrderStatus:报单状态 --<<

    --OrderSubmitStatus:报单提交状态 -->>
    Function OSS_InsertSubmitted
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --已经提交
	  end;

    Function OSS_CancelSubmitted
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --撤单已经提交
	  end;

    Function OSS_ModifySubmitted
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --修改已经提交
	  end;

    Function OSS_Accepted
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --已经接受
	  end;

    Function OSS_InsertRejected
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '4'; --报单已经被拒绝
	  end;

    Function OSS_CancelRejected
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '5'; --撤单已经被拒绝
	  end;

    Function OSS_ModifyRejected
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '6'; --改单已经被拒绝
	  end;

    --OrderSubmitStatus:报单提交状态 --<<

    --PositionDate:持仓日期 -->>
    Function PSD_Today
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --今日持仓
	  end;

    Function PSD_History
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --历史持仓
	  end;

    --PositionDate:持仓日期 --<<

    --TradingRole:交易角色 -->>
    Function ER_Broker
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --代理
	  end;

    Function ER_Host
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --自营
	  end;

    Function ER_Maker
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --做市商
	  end;

    --TradingRole:交易角色 --<<

    --ProductClass:产品类型 -->>
    Function PC_Futures
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --期货
	  end;

    Function PC_Options
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --期货期权
	  end;

    Function PC_Combination
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --组合
	  end;

    Function PC_Spot
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '4'; --即期
	  end;

    Function PC_EFP
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '5'; --期转现
	  end;

    Function PC_SpotOption
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '6'; --现货期权
	  end;

    --ProductClass:产品类型 --<<

    --ComProductType:组合产品类型 -->>
    --ComProductType:组合产品类型 --<<

    --ReportProductClass:产品类型 -->>
    Function RPC_Futures
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --商品期货
	  end;

    Function RPC_Options
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --期货期权
	  end;

    Function RPC_SpotOption
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '6'; --现货期权
	  end;

    Function RPC_FinancialFutures
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '7'; --金融期货
	  end;

    --ReportProductClass:产品类型 --<<

    --InstLifePhase:合约生命周期状态 -->>
    Function IP_NotStart
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --未上市
	  end;

    Function IP_Started
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --上市
	  end;

    Function IP_Pause
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --停牌
	  end;

    Function IP_Expired
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --到期
	  end;

    --InstLifePhase:合约生命周期状态 --<<

    --Direction:买卖方向 -->>
    Function D_Buy
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --买
	  end;

    Function D_Sell
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --卖
	  end;

    --Direction:买卖方向 --<<

    --PositionMode:持仓类型 -->>
    Function PM_Net
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --净持仓
	  end;

    Function PM_Gross
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --综合持仓
	  end;

    --PositionMode:持仓类型 --<<

    --PosiDirection:持仓多空方向 -->>
    Function PD_Net
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --净
	  end;

    Function PD_Long
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --多头
	  end;

    Function PD_Short
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --空头
	  end;

    --PosiDirection:持仓多空方向 --<<

    --SysSettlementStatus:系统结算状态 -->>
    Function SS_NonActive
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --不活跃
	  end;

    Function SS_Startup
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --启动
	  end;

    Function SS_Operating
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --操作
	  end;

    Function SS_Settlement
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '4'; --结算
	  end;

    Function SS_SettlementFinished
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '5'; --结算完成
	  end;

    --SysSettlementStatus:系统结算状态 --<<

    --RatioAttr:费率属性 -->>
    Function RA_Trade
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --交易费率
	  end;

    Function RA_Settlement
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --结算费率
	  end;

    --RatioAttr:费率属性 --<<

    --HedgeFlag:投机套保标志 -->>
    Function HF_Speculation
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --投机
	  end;

    Function HF_Arbitrage
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --套利
	  end;

    Function HF_Hedge
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --套保
	  end;

    Function HF_Maker
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '4'; --做市商
	  end;

    --HedgeFlag:投机套保标志 --<<

    --BillHedgeFlag:投机套保标志 -->>
    Function BHF_Speculation
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --投机
	  end;

    Function BHF_Arbitrage
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --套利
	  end;

    Function BHF_Hedge
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --套保
	  end;

    Function BHF_Maker
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '4'; --做市商
	  end;

    --BillHedgeFlag:投机套保标志 --<<

    --ClientIDMode:交易编码类型 -->>
    Function CIDM_Speculation
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --投机
	  end;

    Function CIDM_Arbitrage
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --套利
	  end;

    Function CIDM_Hedge
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --套保
	  end;

    Function CIDM_Maker
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '4'; --做市商
	  end;

    --ClientIDMode:交易编码类型 --<<

    --OrderPriceType:报单价格条件 -->>
    Function OPT_AnyPrice
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --任意价
	  end;

    Function OPT_LimitPrice
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --限价
	  end;

    Function OPT_BestPrice
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --最优价
	  end;

    Function OPT_LastPrice
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '4'; --最新价
	  end;

    Function OPT_LastPricePlusOneTicks
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '5'; --最新价浮动上浮1个ticks
	  end;

    Function OPT_LastPricePlusTwoTicks
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '6'; --最新价浮动上浮2个ticks
	  end;

    Function OPT_LastPricePlusThreeTicks
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '7'; --最新价浮动上浮3个ticks
	  end;

    Function OPT_AskPrice1
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '8'; --卖一价
	  end;

    Function OPT_AskPrice1PlusOneTicks
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '9'; --卖一价浮动上浮1个ticks
	  end;

    Function OPT_AskPrice1PlusTwoTicks
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'A'; --卖一价浮动上浮2个ticks
	  end;

    Function OPT_AskPrice1PlusThreeTicks
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'B'; --卖一价浮动上浮3个ticks
	  end;

    Function OPT_BidPrice1
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'C'; --买一价
	  end;

    Function OPT_BidPrice1PlusOneTicks
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'D'; --买一价浮动上浮1个ticks
	  end;

    Function OPT_BidPrice1PlusTwoTicks
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'E'; --买一价浮动上浮2个ticks
	  end;

    Function OPT_BidPrice1PlusThreeTicks
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'F'; --买一价浮动上浮3个ticks
	  end;

    Function OPT_FiveLevelPrice
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'G'; --五档价
	  end;

    --OrderPriceType:报单价格条件 --<<

    --OffsetFlag:开平标志 -->>
    Function OF_Open
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --开仓
	  end;

    Function OF_Close
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --平仓
	  end;

    Function OF_ForceClose
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --强平
	  end;

    Function OF_CloseToday
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --平今
	  end;

    Function OF_CloseYesterday
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '4'; --平昨
	  end;

    Function OF_ForceOff
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '5'; --强减
	  end;

    Function OF_LocalForceClose
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '6'; --本地强平
	  end;

    --OffsetFlag:开平标志 --<<

    --ForceCloseReason:强平原因 -->>
    Function FCC_NotForceClose
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --非强平
	  end;

    Function FCC_LackDeposit
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --资金不足
	  end;

    Function FCC_ClientOverPositionLimit
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --客户超仓
	  end;

    Function FCC_MemberOverPositionLimit
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --会员超仓
	  end;

    Function FCC_NotMultiple
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '4'; --持仓非整数倍
	  end;

    Function FCC_Violation
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '5'; --违规
	  end;

    Function FCC_Other
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '6'; --其它
	  end;

    Function FCC_PersonDeliv
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '7'; --自然人临近交割
	  end;

    --ForceCloseReason:强平原因 --<<

    --OrderType:报单类型 -->>
    Function ORDT_Normal
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --正常
	  end;

    Function ORDT_DeriveFromQuote
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --报价衍生
	  end;

    Function ORDT_DeriveFromCombination
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --组合衍生
	  end;

    Function ORDT_Combination
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --组合报单
	  end;

    Function ORDT_ConditionalOrder
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '4'; --条件单
	  end;

    Function ORDT_Swap
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '5'; --互换单
	  end;

    Function ORDT_EFPDerived
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '7'; --期转现成交衍生
	  end;

    --OrderType:报单类型 --<<

    --TimeCondition:有效期类型 -->>
    Function TC_IOC
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --立即完成，否则撤销
	  end;

    Function TC_GFS
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --本节有效
	  end;

    Function TC_GFD
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --当日有效
	  end;

    Function TC_GTD
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '4'; --指定日期前有效
	  end;

    Function TC_GTC
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '5'; --撤销前有效
	  end;

    Function TC_GFA
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '6'; --集合竞价有效
	  end;

    --TimeCondition:有效期类型 --<<

    --VolumeCondition:成交量类型 -->>
    Function VC_AV
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --任何数量
	  end;

    Function VC_MV
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --最小数量
	  end;

    Function VC_CV
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --全部数量
	  end;

    --VolumeCondition:成交量类型 --<<

    --ContingentCondition:触发条件 -->>
    Function CC_Immediately
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --立即
	  end;

    Function CC_Touch
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --止损
	  end;

    Function CC_TouchProfit
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --止赢
	  end;

    Function CC_ParkedOrder
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '4'; --预埋单
	  end;

    Function CC_LastPriceGreaterThanStopPri
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '5'; --最新价大于条件价
	  end;

    Function CC_LastPriceGreaterEqualStopPr
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '6'; --最新价大于等于条件价
	  end;

    Function CC_LastPriceLesserThanStopPric
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '7'; --最新价小于条件价
	  end;

    Function CC_LastPriceLesserEqualStopPri
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '8'; --最新价小于等于条件价
	  end;

    Function CC_AskPriceGreaterThanStopPric
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '9'; --卖一价大于条件价
	  end;

    Function CC_AskPriceGreaterEqualStopPri
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'A'; --卖一价大于等于条件价
	  end;

    Function CC_AskPriceLesserThanStopPrice
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'B'; --卖一价小于条件价
	  end;

    Function CC_AskPriceLesserEqualStopPric
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'C'; --卖一价小于等于条件价
	  end;

    Function CC_BidPriceGreaterThanStopPric
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'D'; --买一价大于条件价
	  end;

    Function CC_BidPriceGreaterEqualStopPri
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'E'; --买一价大于等于条件价
	  end;

    Function CC_BidPriceLesserThanStopPrice
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'F'; --买一价小于条件价
	  end;

    Function CC_BidPriceLesserEqualStopPric
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'H'; --买一价小于等于条件价
	  end;

    --ContingentCondition:触发条件 --<<

    --ActionFlag:操作标志 -->>
    Function AF_Delete
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --删除
	  end;

    Function AF_Modify
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --修改
	  end;

    --ActionFlag:操作标志 --<<

    --TradingRight:交易权限 -->>
    Function TR_Allow
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --可以交易
	  end;

    Function TR_CloseOnly
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --只能平仓
	  end;

    Function TR_Forbidden
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --不能交易
	  end;

    --TradingRight:交易权限 --<<

    --OrderSource:报单来源 -->>
    Function OSRC_Participant
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --来自参与者
	  end;

    Function OSRC_Administrator
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --来自管理员
	  end;

    --OrderSource:报单来源 --<<

    --TradeType:成交类型 -->>
    Function TRDT_SplitCombination
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '#'; --组合持仓拆分为单一持仓,初始化不应包含该类型的持仓
	  end;

    Function TRDT_Common
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --普通成交
	  end;

    Function TRDT_OptionsExecution
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --期权执行
	  end;

    Function TRDT_OTC
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --OTC成交
	  end;

    Function TRDT_EFPDerived
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --期转现衍生成交
	  end;

    Function TRDT_CombinationDerived
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '4'; --组合衍生成交
	  end;

    Function TRDT_TAS
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '5'; --TAS成交
	  end;

    --TradeType:成交类型 --<<

    --PriceSource:成交价来源 -->>
    Function PSRC_LastPrice
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --前成交价
	  end;

    Function PSRC_Buy
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --买委托价
	  end;

    Function PSRC_Sell
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --卖委托价
	  end;

    --PriceSource:成交价来源 --<<

    --InstrumentStatus:合约交易状态 -->>
    Function IS_BeforeTrading
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --开盘前
	  end;

    Function IS_NoTrading
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --非交易
	  end;

    Function IS_Continous
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --连续交易
	  end;

    Function IS_AuctionOrdering
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --集合竞价报单
	  end;

    Function IS_AuctionBalance
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '4'; --集合竞价价格平衡
	  end;

    Function IS_AuctionMatch
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '5'; --集合竞价撮合
	  end;

    Function IS_Closed
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '6'; --收盘
	  end;

    --InstrumentStatus:合约交易状态 --<<

    --InstStatusEnterReason:品种进入交易状态原因 -->>
    Function IER_Automatic
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --自动切换
	  end;

    Function IER_Manual
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --手动切换
	  end;

    Function IER_Fuse
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --熔断
	  end;

    --InstStatusEnterReason:品种进入交易状态原因 --<<

    --BatchStatus:处理状态 -->>
    Function BS_NoUpload
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --未上传
	  end;

    Function BS_Uploaded
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --已上传
	  end;

    Function BS_Failed
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --审核失败
	  end;

    --BatchStatus:处理状态 --<<

    --ReturnStyle:按品种返还方式 -->>
    Function RS_All
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --按所有品种
	  end;

    Function RS_ByProduct
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --按品种
	  end;

    --ReturnStyle:按品种返还方式 --<<

    --ReturnPattern:返还模式 -->>
    Function RP_ByVolume
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --按成交手数
	  end;

    Function RP_ByFeeOnHand
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --按留存手续费
	  end;

    --ReturnPattern:返还模式 --<<

    --ReturnLevel:返还级别 -->>
    Function RL_Level1
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --级别1
	  end;

    Function RL_Level2
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --级别2
	  end;

    Function RL_Level3
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --级别3
	  end;

    Function RL_Level4
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '4'; --级别4
	  end;

    Function RL_Level5
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '5'; --级别5
	  end;

    Function RL_Level6
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '6'; --级别6
	  end;

    Function RL_Level7
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '7'; --级别7
	  end;

    Function RL_Level8
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '8'; --级别8
	  end;

    Function RL_Level9
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '9'; --级别9
	  end;

    --ReturnLevel:返还级别 --<<

    --ReturnStandard:返还标准 -->>
    Function RSD_ByPeriod
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --分阶段返还
	  end;

    Function RSD_ByStandard
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --按某一标准
	  end;

    --ReturnStandard:返还标准 --<<

    --MortgageType:质押类型 -->>
    Function MT_Out
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --质出
	  end;

    Function MT_In
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --质入
	  end;

    Function MT_Update
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --质押更新
	  end;

    --MortgageType:质押类型 --<<

    --InvestorSettlementParamID:投资者结算参数代码 -->>
    Function ISPI_MortgageRatio
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '4'; --质押比例
	  end;

    Function ISPI_MarginWay
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '5'; --保证金算法
	  end;

    Function ISPI_BillDeposit
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '9'; --结算单结存是否包含质押
	  end;

    --InvestorSettlementParamID:投资者结算参数代码 --<<

    --ExchangeSettlementParamID:交易所结算参数代码 -->>
    Function ESPI_MortgageRatio
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --质押比例
	  end;

    Function ESPI_OtherFundItem
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --分项资金导入项
	  end;

    Function ESPI_OtherFundImport
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --分项资金入交易所出入金
	  end;

    Function ESPI_CFFEXMinPrepa
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '6'; --开户最低可用金额
	  end;

    Function ESPI_CZCESettlementType
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '7'; --郑商所结算方式
	  end;

    Function ESPI_ExchDelivFeeMode
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '9'; --交易所交割手续费收取方式
	  end;

    Function ESPI_DelivFeeMode
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --投资者交割手续费收取方式
	  end;

    Function ESPI_CZCEComMarginType
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'A'; --郑商所组合持仓保证金收取方式
	  end;

    Function ESPI_DceComMarginType
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'B'; --大商所套利保证金是否优惠
	  end;

    Function ESPI_OptOutDisCountRate
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'a'; --虚值期权保证金优惠比率
	  end;

    Function ESPI_OptMiniGuarantee
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'b'; --最低保障系数
	  end;

    Function ESPI_CZCEOptExerFeeType
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'c'; --郑商所行权手续费收取方式
	  end;

    Function ESPI_SseOptStrikeMargin
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'd'; --上证所期权执行保证金收取方式
	  end;

    Function ESPI_SzeOptStrikeMargin
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'e'; --深交所期权执行保证金收取方式
	  end;

    Function ESPI_OtherFundPremiumType
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'f'; --分项资金文件权利金、行权手续费是否导入
	  end;

    --ExchangeSettlementParamID:交易所结算参数代码 --<<

    --SystemParamID:系统参数代码 -->>
    Function SPI_InvestorIDMinLength
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --投资者代码最小长度
	  end;

    Function SPI_AccountIDMinLength
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --投资者账号代码最小长度
	  end;

    Function SPI_UserRightLogon
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --投资者开户默认登录权限
	  end;

    Function SPI_SettlementBillTrade
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '4'; --投资者交易结算单成交汇总方式
	  end;

    Function SPI_TradingCode
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '5'; --统一开户更新交易编码方式
	  end;

    Function SPI_CheckFund
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '6'; --结算是否判断存在未复核的出入金和分项资金
	  end;

    Function SPI_CommModelRight
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '7'; --是否启用手续费模板数据权限
	  end;

    Function SPI_MarginModelRight
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '9'; --是否启用保证金率模板数据权限
	  end;

    Function SPI_IsStandardActive
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '8'; --是否规范用户才能激活
	  end;

    Function SPI_UploadSettlementFile
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'U'; --上传的交易所结算文件路径
	  end;

    Function SPI_DownloadCSRCFile
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'D'; --上报保证金监控中心文件路径
	  end;

    Function SPI_SettlementBillFile
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'S'; --生成的结算单文件路径
	  end;

    Function SPI_CSRCOthersFile
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'C'; --证监会文件标识
	  end;

    Function SPI_InvestorPhoto
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'P'; --投资者照片路径
	  end;

    Function SPI_CSRCData
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'R'; --全结经纪公司上传文件路径
	  end;

    Function SPI_AMLUploadDir
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'E'; --反洗钱上传文件路径
	  end;

    Function SPI_InvestorPwdModel
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'I'; --开户密码录入方式
	  end;

    Function SPI_CFFEXInvestorSettleFile
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'F'; --投资者中金所结算文件下载路径
	  end;

    Function SPI_InvestorIDType
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'a'; --投资者代码编码方式
	  end;

    Function SPI_FreezeMaxReMain
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'r'; --休眠户最高权益
	  end;

    Function SPI_IsSync
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'A'; --手续费相关操作实时上场开关
	  end;

    Function SPI_RelieveOpenLimit
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'O'; --解除开仓权限限制
	  end;

    Function SPI_IsStandardFreeze
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'X'; --是否规范用户才能休眠
	  end;

    Function SPI_CZCENormalProductHedge
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'B'; --郑商所是否开放所有品种套保交易
	  end;

    Function SPI_DateRange
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'Z'; --结算用交易日期获取范围
	  end;

    Function SPI_CsdcKHJGDM
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'J'; --中登开户代理机构代码
	  end;

    Function SPI_CsdcKHWDDM
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'W'; --中登开户代理网点代码
	  end;

    Function SPI_UploadRatioFile
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'V'; --上传费率导入文件路径
	  end;

    Function SPI_CloudQryInterval
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'q'; --云开户：轮询保证监控中心是否返回结果的间隔毫秒数
	  end;

    Function SPI_CloudPostURL
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'u'; --云开户：推送回云开户平台的URL
	  end;

    Function SPI_CloudPassword
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'p'; --云开户：服务器数据证书密码
	  end;

    Function SPI_CloudKeyStorePath
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'k'; --云开户：服务器秘钥文件路径
	  end;

    Function SPI_CloudTrustStorePath
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 't'; --云开户：服务器受信任证书路径
	  end;

    Function SPI_CloudSmsCodeInterval
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'd'; --云开户：验证码删除间隔分钟数
	  end;

    Function SPI_SysUserType
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'b'; --系统用户是否为单经纪公司
	  end;

    Function SPI_UserRightConditionOrder
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'l'; --投资者开户默认条件单权限
	  end;

    Function SPI_IsConfigureePayment
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'K'; --是否设置银期
	  end;

    Function SPI_FBTAgentVersion
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'G'; --银期版本配置
	  end;

    Function SPI_AMLUploadFilePath
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'e'; --反洗钱审核上传文件路径
	  end;

    Function SPI_InvestorCloseDtl
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'c'; --投资者平仓明细汇总方式
	  end;

    Function SPI_IncBackupPath
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'T'; --增量备份数据路径
	  end;

    Function SPI_SettlementToolsPath
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'H'; --结算工具存放路径
	  end;

    Function SPI_MortgageFundUseRange
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'M'; --质押资金可用范围
	  end;

    Function SPI_CheckMutiTradingRight
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'N'; --是否启用多维交易权限审核
	  end;

    Function SPI_Isauthforce
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'L'; --投资者开户默认打开终端认证
	  end;

    Function SPI_FeeAlgorithmSwitch
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'v'; --结算手续费算法开关
	  end;

    Function SPI_TMSystemURL
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'Q'; --脱敏系统URL配置
	  end;

    Function SPI_MemSettleSwitch
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'm'; --内存结算开关
	  end;

    Function SPI_MemSettleURL
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'g'; --内存结算URL配置
	  end;

    Function SPI_Credential
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 's'; --服务器根证书下载路径
	  end;

    Function SPI_SecTradeToolURL
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'f'; --异构次席工具路径
	  end;

    --SystemParamID:系统参数代码 --<<

    --InvestorCloseDtl:平仓明细汇总方式 -->>
    Function ICD_ByTradingdayInst
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --同日同合约
	  end;

    Function ICD_ByTraInstPrice
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --同日同合约同价格
	  end;

    Function ICD_ByInstrument
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --同合约
	  end;

    --InvestorCloseDtl:平仓明细汇总方式 --<<

    --TradeParamID:交易系统参数代码 -->>
    Function TPID_EncryptionStandard
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'E'; --系统加密算法
	  end;

    Function TPID_RiskMode
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'R'; --系统风险算法
	  end;

    Function TPID_RiskModeGlobal
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'G'; --系统风险算法是否全局 0-否 1-是
	  end;

    Function TPID_modeEncode
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'P'; --密码加密算法
	  end;

    Function TPID_tickMode
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'T'; --价格小数位数参数
	  end;

    Function TPID_SingleUserSessionMaxNum
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'S'; --用户最大会话数
	  end;

    Function TPID_LoginFailMaxNum
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'L'; --最大连续登录失败数
	  end;

    Function TPID_IsAuthForce
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'A'; --是否强制认证
	  end;

    Function TPID_IsFuturePosiLimit
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'B'; --是否期货限仓
	  end;

    Function TPID_IsFutureOrderFreq
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'C'; --是否期货下单频率限制
	  end;

    Function TPID_IsExecOrderProfit
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'H'; --行权冻结是否计算盈利
	  end;

    Function TPID_IsStrongPassword
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'K'; --强密码校验
	  end;

    Function TPID_BalanceMorgage
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'a'; --质押配比乘数
	  end;

    Function TPID_MinPwdLen
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'O'; --最小密码长度
	  end;

    Function TPID_PasswordDeadLine
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'J'; --弱密码最后修改日期
	  end;

    Function TPID_LoginFailMaxNumForIP
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'U'; --IP当日最大登陆失败次数
	  end;

    Function TPID_StrongPasswordDeadLine
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'V'; --强密码有效期
	  end;

    Function TPID_InvstMinPwdLen
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'D'; --投资者交易密码最小长度
	  end;

    Function TPID_ManagerMinPwdLen
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'd'; --操作员交易密码最小长度
	  end;

    Function TPID_InvstChLimit
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'F'; --投资者密码字符限制
	  end;

    Function TPID_ManagerChLimit
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'f'; --操作员密码字符限制
	  end;

    Function TPID_IsInvstPwd
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'W'; --是否启用投资者弱密码有效期
	  end;

    Function TPID_IsManagerPwd
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'w'; --是否启用操作员弱密码有效期
	  end;

    Function TPID_InvstPsdValid
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'X'; --投资者弱密码有效期
	  end;

    Function TPID_ManagerPsdValid
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'x'; --操作员弱密码有效期
	  end;

    Function TPID_InvstPwdDays
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'Y'; --投资者密码有效天数
	  end;

    Function TPID_ManagerPwdDays
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'y'; --操作员密码有效天数
	  end;

    Function TPID_IsCheckBankAcc
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'I'; --银期开户是否验证开户银行卡号
	  end;

    Function TPID_MortgageFundUseRange
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'M'; --质押资金可用范围
	  end;

    Function TPID_IsSmsCode
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'N'; --是否启用短信验证
	  end;

    --TradeParamID:交易系统参数代码 --<<

    --FileID:文件标识 -->>
    Function FI_SettlementFund
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'F'; --资金数据
	  end;

    Function FI_Trade
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'T'; --成交数据
	  end;

    Function FI_InvestorPosition
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'P'; --投资者持仓数据
	  end;

    Function FI_SubEntryFund
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'O'; --投资者分项资金数据
	  end;

    Function FI_CZCECombinationPos
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'C'; --组合持仓数据
	  end;

    Function FI_CSRCData
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'R'; --上报保证金监控中心数据
	  end;

    Function FI_CZCEClose
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'L'; --郑商所平仓了结数据
	  end;

    Function FI_CZCENoClose
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'N'; --郑商所非平仓了结数据
	  end;

    Function FI_PositionDtl
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'D'; --持仓明细数据
	  end;

    Function FI_OptionStrike
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'S'; --期权执行文件
	  end;

    Function FI_SettlementPriceComparison
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'M'; --结算价比对文件
	  end;

    Function FI_NonTradePosChange
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'B'; --上期所非持仓变动明细
	  end;

    Function FI_INEZip
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'I'; --能源中心压缩包
	  end;

    Function FI_CFFEXCombPosition
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'X'; --中金所组合持仓数据
	  end;

    Function FI_CffexCombRule
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'U'; --中金所组合策略规则
	  end;

    Function FI_CffexExchangeRate
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'E'; --中金所汇率文件
	  end;

    Function FI_CffexSpcTransRatio
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'Y'; --中金所差异化手续费率
	  end;

    Function FI_CffexPartpostransfer
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'A'; --中金所交易会员移仓
	  end;

    Function FI_CffexExchangeRate2
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'G'; --中金所汇率文件(外汇冲抵业务)
	  end;

    Function FI_INEExchangeRate
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'I'; --能源中心汇率文件
	  end;

    Function FI_CSRCClientInfoData
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'W'; --异构次用系统终端信息采集数据
	  end;

    Function FI_DCEExchmarginFavparam
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'H'; --大商所保证金优惠参数数据
	  end;

    Function FI_TradeMemberData
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'V'; --交易会员文件包
	  end;

    --FileID:文件标识 --<<

    --FileType:文件上传类型 -->>
    Function FUT_Settlement
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --结算
	  end;

    Function FUT_Check
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --核对
	  end;

    --FileType:文件上传类型 --<<

    --FileFormat:文件格式 -->>
    Function FFT_Txt
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --文本文件(.txt)
	  end;

    Function FFT_Zip
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --压缩文件(.zip)
	  end;

    Function FFT_DBF
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --DBF文件(.dbf)
	  end;

    --FileFormat:文件格式 --<<

    --FileUploadStatus:文件状态 -->>
    Function FUS_SucceedUpload
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --上传成功
	  end;

    Function FUS_FailedUpload
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --上传失败
	  end;

    Function FUS_SucceedLoad
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --导入成功
	  end;

    Function FUS_PartSucceedLoad
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '4'; --导入部分成功
	  end;

    Function FUS_FailedLoad
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '5'; --导入失败
	  end;

    Function FUS_AfterUploadInProcess
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '6'; --导入处理中
	  end;

    --FileUploadStatus:文件状态 --<<

    --TransferDirection:移仓方向 -->>
    Function TD_Out
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --移出
	  end;

    Function TD_In
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --移入
	  end;

    --TransferDirection:移仓方向 --<<

    --SpecialCreateRule:特殊的创建规则 -->>
    Function SC_NoSpecialRule
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --没有特殊创建规则
	  end;

    Function SC_NoSpringFestival
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --不包含春节
	  end;

    --SpecialCreateRule:特殊的创建规则 --<<

    --BasisPriceType:挂牌基准价类型 -->>
    Function IPT_LastSettlement
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --上一合约结算价
	  end;

    Function IPT_LaseClose
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --上一合约收盘价
	  end;

    --BasisPriceType:挂牌基准价类型 --<<

    --ProductLifePhase:产品生命周期状态 -->>
    Function PLP_Active
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --活跃
	  end;

    Function PLP_NonActive
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --不活跃
	  end;

    Function PLP_Canceled
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --注销
	  end;

    --ProductLifePhase:产品生命周期状态 --<<

    --DeliveryMode:交割方式 -->>
    Function DM_CashDeliv
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --现金交割
	  end;

    Function DM_CommodityDeliv
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --实物交割
	  end;

    --DeliveryMode:交割方式 --<<

    --FundIOType:出入金类型 -->>
    Function FIOT_FundIO
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --出入金
	  end;

    Function FIOT_Transfer
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --银期转账
	  end;

    Function FIOT_SwapCurrency
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --银期换汇
	  end;

    --FundIOType:出入金类型 --<<

    --FundType:资金类型 -->>
    Function FT_Deposite
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --银行存款
	  end;

    Function FT_ItemFund
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --分项资金
	  end;

    Function FT_Company
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --公司调整
	  end;

    Function FT_InnerTransfer
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '4'; --资金内转
	  end;

    Function FT_Interest
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '5'; --结息
	  end;

    Function FT_DelivDeposit
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '6'; --交割货款
	  end;

    Function FT_Allocation
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '7'; --资金调拨
	  end;

    --FundType:资金类型 --<<

    --FundDirection:出入金方向 -->>
    Function FD_In
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --入金
	  end;

    Function FD_Out
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --出金
	  end;

    --FundDirection:出入金方向 --<<

    --FundStatus:资金状态 -->>
    Function FS_Record
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --已录入
	  end;

    Function FS_Check
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --已复核
	  end;

    Function FS_Charge
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --已冲销
	  end;

    Function FS_Refuse
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '4'; --已拒绝
	  end;

    --FundStatus:资金状态 --<<

    --PublishStatus:发布状态 -->>
    Function PS_None
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --未发布
	  end;

    Function PS_Publishing
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --正在发布
	  end;

    Function PS_Published
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --已发布
	  end;

    --PublishStatus:发布状态 --<<

    --SystemStatus:系统状态 -->>
    Function ES_NonActive
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --不活跃
	  end;

    Function ES_Startup
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --启动
	  end;

    Function ES_Initialize
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --交易开始初始化
	  end;

    Function ES_Initialized
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '4'; --交易完成初始化
	  end;

    Function ES_Close
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '5'; --收市开始
	  end;

    Function ES_Closed
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '6'; --收市完成
	  end;

    Function ES_Settlement
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '7'; --结算
	  end;

    --SystemStatus:系统状态 --<<

    --TradingCodeStatus:交易编码状态 -->>
    Function TCS_Cancel
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --注销
	  end;

    Function TCS_NoCancel
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --未注销
	  end;

    --TradingCodeStatus:交易编码状态 --<<

    --SettlementStatus:结算状态 -->>
    Function STS_Initialize
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --初始化
	  end;

    Function STS_Settlementing
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --结算中
	  end;

    Function STS_Settlemented
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --已结算
	  end;

    Function STS_Finished
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --结算完成
	  end;

    --SettlementStatus:结算状态 --<<

    --InvestorType:投资者类型 -->>
    Function CT_Person
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --自然人
	  end;

    Function CT_Company
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --法人
	  end;

    Function CT_Fund
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --投资基金
	  end;

    Function CT_SpecialOrgan
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --特殊法人
	  end;

    Function CT_Asset
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '4'; --资管户
	  end;

    --InvestorType:投资者类型 --<<

    --BrokerType:经纪公司类型 -->>
    Function BT_Trade
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --交易会员
	  end;

    Function BT_TradeSettle
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --交易结算会员
	  end;

    Function BT_Settle
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --全面结算会员
	  end;

    --BrokerType:经纪公司类型 --<<

    --RiskLevel:风险等级 -->>
    Function FAS_Low
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --低风险客户
	  end;

    Function FAS_Normal
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --普通客户
	  end;

    Function FAS_Focus
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --关注客户
	  end;

    Function FAS_Risk
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '4'; --风险客户
	  end;

    --RiskLevel:风险等级 --<<

    --FeeAcceptStyle:手续费收取方式 -->>
    Function FAS_ByTrade
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --按交易收取
	  end;

    Function FAS_ByDeliv
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --按交割收取
	  end;

    Function FAS_None
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --不收
	  end;

    Function FAS_FixFee
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '4'; --按指定手续费收取
	  end;

    --FeeAcceptStyle:手续费收取方式 --<<

    --PasswordType:密码类型 -->>
    Function PWDT_Trade
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --交易密码
	  end;

    Function PWDT_Account
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --资金密码
	  end;

    --PasswordType:密码类型 --<<

    --Algorithm:盈亏算法 -->>
    Function AG_All
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --浮盈浮亏都计算
	  end;

    Function AG_OnlyLost
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --浮盈不计，浮亏计
	  end;

    Function AG_OnlyGain
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --浮盈计，浮亏不计
	  end;

    Function AG_None
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '4'; --浮盈浮亏都不计算
	  end;

    --Algorithm:盈亏算法 --<<

    --IncludeCloseProfit:是否包含平仓盈利 -->>
    Function ICP_Include
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --包含平仓盈利
	  end;

    Function ICP_NotInclude
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --不包含平仓盈利
	  end;

    --IncludeCloseProfit:是否包含平仓盈利 --<<

    --AllWithoutTrade:是否受可提比例限制 -->>
    Function AWT_Enable
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --无仓无成交不受可提比例限制
	  end;

    Function AWT_Disable
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --受可提比例限制
	  end;

    Function AWT_NoHoldEnable
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --无仓不受可提比例限制
	  end;

    --AllWithoutTrade:是否受可提比例限制 --<<

    --FuturePwdFlag:资金密码核对标志 -->>
    Function FPWD_UnCheck
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --不核对
	  end;

    Function FPWD_Check
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --核对
	  end;

    --FuturePwdFlag:资金密码核对标志 --<<

    --TransferType:银期转账类型 -->>
    Function TT_BankToFuture
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --银行转期货
	  end;

    Function TT_FutureToBank
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --期货转银行
	  end;

    --TransferType:银期转账类型 --<<

    --TransferValidFlag:转账有效标志 -->>
    Function TVF_Invalid
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --无效或失败
	  end;

    Function TVF_Valid
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --有效
	  end;

    Function TVF_Reverse
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --冲正
	  end;

    --TransferValidFlag:转账有效标志 --<<

    --Reason:事由 -->>
    Function RN_CD
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --错单
	  end;

    Function RN_ZT
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --资金在途
	  end;

    Function RN_QT
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --其它
	  end;

    --Reason:事由 --<<

    --Sex:性别 -->>
    Function SEX_None
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --未知
	  end;

    Function SEX_Man
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --男
	  end;

    Function SEX_Woman
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --女
	  end;

    --Sex:性别 --<<

    --UserType:用户类型 -->>
    Function UT_Investor
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --投资者
	  end;

    Function UT_Operator
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --操作员
	  end;

    Function UT_SuperUser
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --管理员
	  end;

    --UserType:用户类型 --<<

    --RateType:费率类型 -->>
    Function RATETYPE_MarginRate
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --保证金率
	  end;

    --RateType:费率类型 --<<

    --NoteType:通知类型 -->>
    Function NOTETYPE_TradeSettleBill
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --交易结算单
	  end;

    Function NOTETYPE_TradeSettleMonth
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --交易结算月报
	  end;

    Function NOTETYPE_CallMarginNotes
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --追加保证金通知书
	  end;

    Function NOTETYPE_ForceCloseNotes
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '4'; --强行平仓通知书
	  end;

    Function NOTETYPE_TradeNotes
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '5'; --成交通知书
	  end;

    Function NOTETYPE_DelivNotes
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '6'; --交割通知书
	  end;

    Function NOTETYPE_OptStrikeNotes
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '7'; --期权到期行权履约通知书
	  end;

    Function NOTETYPE_CHUANCANG
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '8'; --穿仓通知书
	  end;

    --NoteType:通知类型 --<<

    --SettlementStyle:结算单方式 -->>
    Function SBS_Day
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --逐日盯市
	  end;

    Function SBS_Volume
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --逐笔对冲
	  end;

    --SettlementStyle:结算单方式 --<<

    --SettlementBillType:结算单类型 -->>
    Function ST_Day
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --日报
	  end;

    Function ST_Month
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --月报
	  end;

    --SettlementBillType:结算单类型 --<<

    --UserRightType:客户权限类型 -->>
    Function URT_Logon
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --登录
	  end;

    Function URT_Transfer
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --银期转账
	  end;

    Function URT_EMail
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --邮寄结算单
	  end;

    Function URT_Fax
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '4'; --传真结算单
	  end;

    Function URT_ConditionalOrder
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '5'; --条件单
	  end;

    --UserRightType:客户权限类型 --<<

    --MarginPriceType:保证金价格类型 -->>
    Function MPT_PreSettlementPrice
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --昨结算价
	  end;

    Function MPT_SettlementPrice
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --最新价
	  end;

    Function MPT_AveragePrice
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --成交均价
	  end;

    Function MPT_OpenPrice
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '4'; --开仓价
	  end;

    --MarginPriceType:保证金价格类型 --<<

    --BillGenStatus:结算单生成状态 -->>
    Function BGS_None
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --未生成
	  end;

    Function BGS_NoGenerated
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --生成中
	  end;

    Function BGS_Generated
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --已邮寄
	  end;

    --BillGenStatus:结算单生成状态 --<<

    --AlgoType:算法类型 -->>
    Function AT_HandlePositionAlgo
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --持仓处理算法
	  end;

    Function AT_FindMarginRateAlgo
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --寻找保证金率算法
	  end;

    --AlgoType:算法类型 --<<

    --HandlePositionAlgoID:持仓处理算法编号 -->>
    Function HPA_Base
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --基本
	  end;

    Function HPA_DCE
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --大连商品交易所
	  end;

    Function HPA_CZCE
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --郑州商品交易所
	  end;

    --HandlePositionAlgoID:持仓处理算法编号 --<<

    --FindMarginRateAlgoID:寻找保证金率算法编号 -->>
    Function FMRA_Base
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --基本
	  end;

    Function FMRA_DCE
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --大连商品交易所
	  end;

    Function FMRA_CZCE
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --郑州商品交易所
	  end;

    --FindMarginRateAlgoID:寻找保证金率算法编号 --<<

    --HandleTradingAccountAlgoID:资金处理算法编号 -->>
    Function HTAA_Base
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --基本
	  end;

    Function HTAA_DCE
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --大连商品交易所
	  end;

    Function HTAA_CZCE
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --郑州商品交易所
	  end;

    --HandleTradingAccountAlgoID:资金处理算法编号 --<<

    --PersonType:联系人类型 -->>
    Function PST_Order
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --指定下单人
	  end;

    Function PST_Open
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --开户授权人
	  end;

    Function PST_Fund
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --资金调拨人
	  end;

    Function PST_Settlement
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '4'; --结算单确认人
	  end;

    Function PST_Company
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '5'; --法人
	  end;

    Function PST_Corporation
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '6'; --法人代表
	  end;

    Function PST_LinkMan
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '7'; --投资者联系人
	  end;

    Function PST_Ledger
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '8'; --分户管理资产负责人
	  end;

    Function PST_Trustee
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '9'; --托（保）管人
	  end;

    Function PST_TrusteeCorporation
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'A'; --托（保）管机构法人代表
	  end;

    Function PST_TrusteeOpen
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'B'; --托（保）管机构开户授权人
	  end;

    Function PST_TrusteeContact
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'C'; --托（保）管机构联系人
	  end;

    Function PST_ForeignerRefer
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'D'; --境外自然人参考证件
	  end;

    Function PST_CorporationRefer
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'E'; --法人代表参考证件
	  end;

    --PersonType:联系人类型 --<<

    --QueryInvestorRange:查询范围 -->>
    Function QIR_All
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --所有
	  end;

    Function QIR_Group
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --查询分类
	  end;

    Function QIR_Single
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --单一投资者
	  end;

    --QueryInvestorRange:查询范围 --<<

    --InvestorRiskStatus:投资者风险状态 -->>
    Function IRS_Normal
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --正常
	  end;

    Function IRS_Warn
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --警告
	  end;

    Function IRS_Call
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --追保
	  end;

    Function IRS_Force
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '4'; --强平
	  end;

    Function IRS_Exception
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '5'; --异常
	  end;

    --InvestorRiskStatus:投资者风险状态 --<<

    --UserEventType:用户事件类型 -->>
    Function UET_Login
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --登录
	  end;

    Function UET_Logout
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --登出
	  end;

    Function UET_Trading
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --交易成功
	  end;

    Function UET_TradingError
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '4'; --交易失败
	  end;

    Function UET_UpdatePassword
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '5'; --修改密码
	  end;

    Function UET_Authenticate
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '6'; --客户端认证
	  end;

    Function UET_Other
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '9'; --其他
	  end;

    --UserEventType:用户事件类型 --<<

    --CloseStyle:平仓方式 -->>
    Function ICS_Close
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --先开先平
	  end;

    Function ICS_CloseToday
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --先平今再平昨
	  end;

    --CloseStyle:平仓方式 --<<

    --StatMode:统计方式 -->>
    Function SM_Non
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; ------
	  end;

    Function SM_Instrument
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --按合约统计
	  end;

    Function SM_Product
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --按产品统计
	  end;

    Function SM_Investor
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --按投资者统计
	  end;

    --StatMode:统计方式 --<<

    --ParkedOrderStatus:预埋单状态 -->>
    Function PAOS_NotSend
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --未发送
	  end;

    Function PAOS_Send
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --已发送
	  end;

    Function PAOS_Deleted
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --已删除
	  end;

    --ParkedOrderStatus:预埋单状态 --<<

    --VirDealStatus:处理状态 -->>
    Function VDS_Dealing
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --正在处理
	  end;

    Function VDS_DeaclSucceed
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --处理成功
	  end;

    --VirDealStatus:处理状态 --<<

    --OrgSystemID:原有系统代码 -->>
    Function ORGS_Standard
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --综合交易平台
	  end;

    Function ORGS_ESunny
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --易盛系统
	  end;

    Function ORGS_KingStarV6
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --金仕达V6系统
	  end;

    --OrgSystemID:原有系统代码 --<<

    --VirTradeStatus:交易状态 -->>
    Function VTS_NaturalDeal
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --正常处理中
	  end;

    Function VTS_SucceedEnd
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --成功结束
	  end;

    Function VTS_FailedEND
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --失败结束
	  end;

    Function VTS_Exception
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --异常中
	  end;

    Function VTS_ManualDeal
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '4'; --已人工异常处理
	  end;

    Function VTS_MesException
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '5'; --通讯异常 ，请人工处理
	  end;

    Function VTS_SysException
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '6'; --系统出错，请人工处理
	  end;

    --VirTradeStatus:交易状态 --<<

    --VirBankAccType:银行账户类型 -->>
    Function VBAT_BankBook
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --存折
	  end;

    Function VBAT_BankCard
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --储蓄卡
	  end;

    Function VBAT_CreditCard
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --信用卡
	  end;

    Function VBAT_NRA
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '9'; --NRA账户
	  end;

    --VirBankAccType:银行账户类型 --<<

    --VirementStatus:银行账户类型 -->>
    Function VMS_Natural
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --正常
	  end;

    Function VMS_Canceled
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '9'; --销户
	  end;

    --VirementStatus:银行账户类型 --<<

    --VirementAvailAbility:有效标志 -->>
    Function VAA_NoAvailAbility
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --未确认
	  end;

    Function VAA_AvailAbility
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --有效
	  end;

    Function VAA_Repeal
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --冲正
	  end;

    --VirementAvailAbility:有效标志 --<<

    --VirementTradeCode:交易代码 -->>
    Function VTC_BankBankToFuture
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '102001'; --银行发起银行资金转期货
	  end;

    Function VTC_BankFutureToBank
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '102002'; --银行发起期货资金转银行
	  end;

    Function VTC_FutureBankToFuture
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '202001'; --期货发起银行资金转期货
	  end;

    Function VTC_FutureFutureToBank
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '202002'; --期货发起期货资金转银行
	  end;

    --VirementTradeCode:交易代码 --<<

    --AMLGenStatus:Aml生成方式 -->>
    Function GEN_Program
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --程序生成
	  end;

    Function GEN_HandWork
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --人工生成
	  end;

    --AMLGenStatus:Aml生成方式 --<<

    --CFMMCKeyKind:动态密钥类别(保证金监管) -->>
    Function CFMMCKK_REQUEST
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'R'; --主动请求更新
	  end;

    Function CFMMCKK_AUTO
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'A'; --CFMMC自动更新
	  end;

    Function CFMMCKK_MANUAL
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'M'; --CFMMC手动更新
	  end;

    --CFMMCKeyKind:动态密钥类别(保证金监管) --<<

    --CertificationType:证件类型 -->>
    Function CFT_IDCard
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --身份证
	  end;

    Function CFT_Passport
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --护照
	  end;

    Function CFT_OfficerIDCard
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --军官证
	  end;

    Function CFT_SoldierIDCard
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --士兵证
	  end;

    Function CFT_HomeComingCard
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '4'; --回乡证
	  end;

    Function CFT_HouseholdRegister
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '5'; --户口簿
	  end;

    Function CFT_LicenseNo
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '6'; --营业执照号
	  end;

    Function CFT_InstitutionCodeCard
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '7'; --组织机构代码证
	  end;

    Function CFT_TempLicenseNo
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '8'; --临时营业执照号
	  end;

    Function CFT_NoEnterpriseLicenseNo
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '9'; --民办非企业登记证书
	  end;

    Function CFT_OtherCard
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'x'; --其他证件
	  end;

    Function CFT_SuperDepAgree
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'a'; --主管部门批文
	  end;

    --CertificationType:证件类型 --<<

    --FileBusinessCode:文件业务功能 -->>
    Function FBC_Others
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --其他
	  end;

    Function FBC_TransferDetails
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --转账交易明细对账
	  end;

    Function FBC_CustAccStatus
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --客户账户状态对账
	  end;

    Function FBC_AccountTradeDetails
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --账户类交易明细对账
	  end;

    Function FBC_FutureAccountChangeInfoDet
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '4'; --期货账户信息变更明细对账
	  end;

    Function FBC_CustMoneyDetail
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '5'; --客户资金台账余额明细对账
	  end;

    Function FBC_CustCancelAccountInfo
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '6'; --客户销户结息明细对账
	  end;

    Function FBC_CustMoneyResult
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '7'; --客户资金余额对账结果
	  end;

    Function FBC_OthersExceptionResult
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '8'; --其它对账异常结果文件
	  end;

    Function FBC_CustInterestNetMoneyDetail
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '9'; --客户结息净额明细
	  end;

    Function FBC_CustMoneySendAndReceiveDet
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'a'; --客户资金交收明细
	  end;

    Function FBC_CorporationMoneyTotal
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'b'; --法人存管银行资金交收汇总
	  end;

    Function FBC_MainbodyMoneyTotal
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'c'; --主体间资金交收汇总
	  end;

    Function FBC_MainPartMonitorData
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'd'; --总分平衡监管数据
	  end;

    Function FBC_PreparationMoney
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'e'; --存管银行备付金余额
	  end;

    Function FBC_BankMoneyMonitorData
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'f'; --协办存管银行资金监管数据
	  end;

    --FileBusinessCode:文件业务功能 --<<

    --CashExchangeCode:汇钞标志 -->>
    Function CEC_Exchange
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --汇
	  end;

    Function CEC_Cash
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --钞
	  end;

    --CashExchangeCode:汇钞标志 --<<

    --YesNoIndicator:是或否标识 -->>
    Function YNI_Yes
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --是
	  end;

    Function YNI_No
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --否
	  end;

    --YesNoIndicator:是或否标识 --<<

    --BanlanceType:余额类型 -->>
    Function BLT_CurrentMoney
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --当前余额
	  end;

    Function BLT_UsableMoney
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --可用余额
	  end;

    Function BLT_FetchableMoney
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --可取余额
	  end;

    Function BLT_FreezeMoney
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --冻结余额
	  end;

    --BanlanceType:余额类型 --<<

    --Gender:性别 -->>
    Function GD_Unknown
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --未知状态
	  end;

    Function GD_Male
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --男
	  end;

    Function GD_Female
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --女
	  end;

    --Gender:性别 --<<

    --FeePayFlag:费用支付标志 -->>
    Function FPF_BEN
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --由受益方支付费用
	  end;

    Function FPF_OUR
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --由发送方支付费用
	  end;

    Function FPF_SHA
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --由发送方支付发起的费用，受益方支付接受的费用
	  end;

    --FeePayFlag:费用支付标志 --<<

    --PassWordKeyType:密钥类型 -->>
    Function PWKT_ExchangeKey
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --交换密钥
	  end;

    Function PWKT_PassWordKey
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --密码密钥
	  end;

    Function PWKT_MACKey
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --MAC密钥
	  end;

    Function PWKT_MessageKey
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --报文密钥
	  end;

    --PassWordKeyType:密钥类型 --<<

    --FBTPassWordType:密码类型 -->>
    Function PWT_Query
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --查询
	  end;

    Function PWT_Fetch
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --取款
	  end;

    Function PWT_Transfer
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --转账
	  end;

    Function PWT_Trade
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --交易
	  end;

    --FBTPassWordType:密码类型 --<<

    --FBTEncryMode:加密方式 -->>
    Function EM_NoEncry
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --不加密
	  end;

    Function EM_DES
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --DES
	  end;

    Function EM_3DES
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --3DES
	  end;

    --FBTEncryMode:加密方式 --<<

    --BankRepealFlag:银行冲正标志 -->>
    Function BRF_BankNotNeedRepeal
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --银行无需自动冲正
	  end;

    Function BRF_BankWaitingRepeal
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --银行待自动冲正
	  end;

    Function BRF_BankBeenRepealed
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --银行已自动冲正
	  end;

    --BankRepealFlag:银行冲正标志 --<<

    --BrokerRepealFlag:期商冲正标志 -->>
    Function BRORF_BrokerNotNeedRepeal
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --期商无需自动冲正
	  end;

    Function BRORF_BrokerWaitingRepeal
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --期商待自动冲正
	  end;

    Function BRORF_BrokerBeenRepealed
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --期商已自动冲正
	  end;

    --BrokerRepealFlag:期商冲正标志 --<<

    --InstitutionType:机构类别 -->>
    Function TS_Bank
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --银行
	  end;

    Function TS_Future
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --期商
	  end;

    Function TS_Store
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --券商
	  end;

    --InstitutionType:机构类别 --<<

    --LastFragment:最后分片标志 -->>
    Function LF_Yes
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --是最后分片
	  end;

    Function LF_No
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --不是最后分片
	  end;

    --LastFragment:最后分片标志 --<<

    --BankAccStatus:银行账户状态 -->>
    Function BAS_Normal
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --正常
	  end;

    Function BAS_Freeze
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --冻结
	  end;

    Function BAS_ReportLoss
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --挂失
	  end;

    --BankAccStatus:银行账户状态 --<<

    --MoneyAccountStatus:资金账户状态 -->>
    Function MAS_Normal
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --正常
	  end;

    Function MAS_Cancel
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --销户
	  end;

    --MoneyAccountStatus:资金账户状态 --<<

    --ManageStatus:存管状态 -->>
    Function MSS_Point
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --指定存管
	  end;

    Function MSS_PrePoint
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --预指定
	  end;

    Function MSS_CancelPoint
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --撤销指定
	  end;

    --ManageStatus:存管状态 --<<

    --SystemType:应用系统类型 -->>
    Function SYT_FutureBankTransfer
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --银期转账
	  end;

    Function SYT_StockBankTransfer
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --银证转账
	  end;

    Function SYT_TheThirdPartStore
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --第三方存管
	  end;

    --SystemType:应用系统类型 --<<

    --TxnEndFlag:银期转账划转结果标志 -->>
    Function TEF_NormalProcessing
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --正常处理中
	  end;

    Function TEF_Success
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --成功结束
	  end;

    Function TEF_Failed
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --失败结束
	  end;

    Function TEF_Abnormal
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --异常中
	  end;

    Function TEF_ManualProcessedForExceptio
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '4'; --已人工异常处理
	  end;

    Function TEF_CommuFailedNeedManualProce
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '5'; --通讯异常 ，请人工处理
	  end;

    Function TEF_SysErrorNeedManualProcess
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '6'; --系统出错，请人工处理
	  end;

    --TxnEndFlag:银期转账划转结果标志 --<<

    --ProcessStatus:银期转账服务处理状态 -->>
    Function PSS_NotProcess
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --未处理
	  end;

    Function PSS_StartProcess
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --开始处理
	  end;

    Function PSS_Finished
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --处理完成
	  end;

    --ProcessStatus:银期转账服务处理状态 --<<

    --CustType:客户类型 -->>
    Function CUSTT_Person
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --自然人
	  end;

    Function CUSTT_Institution
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --机构户
	  end;

    --CustType:客户类型 --<<

    --FBTTransferDirection:银期转账方向 -->>
    Function FBTTD_FromBankToFuture
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --入金，银行转期货
	  end;

    Function FBTTD_FromFutureToBank
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --出金，期货转银行
	  end;

    --FBTTransferDirection:银期转账方向 --<<

    --OpenOrDestroy:开销户类别 -->>
    Function OOD_Open
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --开户
	  end;

    Function OOD_Destroy
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --销户
	  end;

    --OpenOrDestroy:开销户类别 --<<

    --AvailabilityFlag:有效标志 -->>
    Function AVAF_Invalid
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --未确认
	  end;

    Function AVAF_Valid
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --有效
	  end;

    Function AVAF_Repeal
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --冲正
	  end;

    --AvailabilityFlag:有效标志 --<<

    --OrganType:机构类型 -->>
    Function OT_Bank
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --银行代理
	  end;

    Function OT_Future
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --交易前置
	  end;

    Function OT_PlateForm
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '9'; --银期转账平台管理
	  end;

    --OrganType:机构类型 --<<

    --OrganLevel:机构级别 -->>
    Function OL_HeadQuarters
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --银行总行或期商总部
	  end;

    Function OL_Branch
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --银行分中心或期货公司营业部
	  end;

    --OrganLevel:机构级别 --<<

    --ProtocalID:协议类型 -->>
    Function PID_FutureProtocal
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --期商协议
	  end;

    Function PID_ICBCProtocal
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --工行协议
	  end;

    Function PID_ABCProtocal
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --农行协议
	  end;

    Function PID_CBCProtocal
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --中国银行协议
	  end;

    Function PID_CCBProtocal
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '4'; --建行协议
	  end;

    Function PID_BOCOMProtocal
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '5'; --交行协议
	  end;

    Function PID_FBTPlateFormProtocal
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'X'; --银期转账平台协议
	  end;

    --ProtocalID:协议类型 --<<

    --ConnectMode:套接字连接方式 -->>
    Function CM_ShortConnect
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --短连接
	  end;

    Function CM_LongConnect
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --长连接
	  end;

    --ConnectMode:套接字连接方式 --<<

    --SyncMode:套接字通信方式 -->>
    Function SRM_ASync
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --异步
	  end;

    Function SRM_Sync
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --同步
	  end;

    --SyncMode:套接字通信方式 --<<

    --BankAccType:银行账号类型 -->>
    Function BACT_Other
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --其他
	  end;

    Function BACT_BankBook
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --银行存折
	  end;

    Function BACT_SavingCard
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --储蓄卡
	  end;

    Function BACT_CreditCard
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --信用卡
	  end;

    Function BACT_NRA
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '9'; --NRA账户
	  end;

    --BankAccType:银行账号类型 --<<

    --FutureAccType:期货公司账号类型 -->>
    Function FAT_BankBook
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --银行存折
	  end;

    Function FAT_SavingCard
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --储蓄卡
	  end;

    Function FAT_CreditCard
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --信用卡
	  end;

    --FutureAccType:期货公司账号类型 --<<

    --OrganStatus:接入机构状态 -->>
    Function OS_Ready
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --启用
	  end;

    Function OS_CheckIn
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --签到
	  end;

    Function OS_CheckOut
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --签退
	  end;

    Function OS_CheckFileArrived
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --对账文件到达
	  end;

    Function OS_CheckDetail
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '4'; --对账
	  end;

    Function OS_DayEndClean
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '5'; --日终清理
	  end;

    Function OS_Invalid
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '9'; --注销
	  end;

    --OrganStatus:接入机构状态 --<<

    --CCBFeeMode:建行收费模式 -->>
    Function CCBFM_ByAmount
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --按金额扣收
	  end;

    Function CCBFM_ByMonth
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --按月扣收
	  end;

    --CCBFeeMode:建行收费模式 --<<

    --CommApiType:通讯API类型 -->>
    Function CAPIT_Client
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --客户端
	  end;

    Function CAPIT_Server
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --服务端
	  end;

    Function CAPIT_UserApi
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --交易系统的UserApi
	  end;

    --CommApiType:通讯API类型 --<<

    --LinkStatus:连接状态 -->>
    Function LS_Connected
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --已经连接
	  end;

    Function LS_Disconnected
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --没有连接
	  end;

    --LinkStatus:连接状态 --<<

    --PwdFlag:密码核对标志 -->>
    Function BPWDF_NoCheck
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --不核对
	  end;

    Function BPWDF_BlankCheck
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --明文核对
	  end;

    Function BPWDF_EncryptCheck
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --密文核对
	  end;

    --PwdFlag:密码核对标志 --<<

    --SecuAccType:期货账号类型 -->>
    Function SAT_AccountID
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --资金账号
	  end;

    Function SAT_CardID
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --资金卡号
	  end;

    Function SAT_SHStockholderID
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --上海股东账号
	  end;

    Function SAT_SZStockholderID
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '4'; --深圳股东账号
	  end;

    --SecuAccType:期货账号类型 --<<

    --SponsorType:发起方 -->>
    Function SPTYPE_Broker
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --期商
	  end;

    Function SPTYPE_Bank
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --银行
	  end;

    --SponsorType:发起方 --<<

    --ReqRspType:请求响应类别 -->>
    Function REQRSP_Request
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --请求
	  end;

    Function REQRSP_Response
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --响应
	  end;

    --ReqRspType:请求响应类别 --<<

    --FBTUserEventType:银期转账用户事件类型 -->>
    Function FBTUET_SignIn
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --签到
	  end;

    Function FBTUET_FromBankToFuture
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --银行转期货
	  end;

    Function FBTUET_FromFutureToBank
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --期货转银行
	  end;

    Function FBTUET_OpenAccount
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --开户
	  end;

    Function FBTUET_CancelAccount
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '4'; --销户
	  end;

    Function FBTUET_ChangeAccount
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '5'; --变更银行账户
	  end;

    Function FBTUET_RepealFromBankToFuture
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '6'; --冲正银行转期货
	  end;

    Function FBTUET_RepealFromFutureToBank
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '7'; --冲正期货转银行
	  end;

    Function FBTUET_QueryBankAccount
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '8'; --查询银行账户
	  end;

    Function FBTUET_QueryFutureAccount
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '9'; --查询期货账户
	  end;

    Function FBTUET_SignOut
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'A'; --签退
	  end;

    Function FBTUET_SyncKey
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'B'; --密钥同步
	  end;

    Function FBTUET_Other
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'Z'; --其他
	  end;

    --FBTUserEventType:银期转账用户事件类型 --<<

    --DBOperation:记录操作类型 -->>
    Function DBOP_Unknown
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --未知
	  end;

    Function DBOP_Insert
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --插入
	  end;

    Function DBOP_Update
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --更新
	  end;

    Function DBOP_Delete
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --删除
	  end;

    Function DBOP_Commit
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '4'; --提交
	  end;

    Function DBOP_Init
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '5'; --初始化
	  end;

    --DBOperation:记录操作类型 --<<

    --SyncFlag:同步标记 -->>
    Function SYNF_Yes
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --已同步
	  end;

    Function SYNF_No
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --未同步
	  end;

    --SyncFlag:同步标记 --<<

    --SyncType:同步类型 -->>
    Function SYNT_OneOffSync
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --一次同步
	  end;

    Function SYNT_TimerSync
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --定时同步
	  end;

    Function SYNT_TimerFullSync
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --定时完全同步
	  end;

    --SyncType:同步类型 --<<

    --ExDirection:换汇方向 -->>
    Function FBEDIR_Settlement
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --结汇
	  end;

    Function FBEDIR_Sale
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --购汇
	  end;

    --ExDirection:换汇方向 --<<

    --FBEResultFlag:换汇成功标志 -->>
    Function FBERES_Success
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --成功
	  end;

    Function FBERES_InsufficientBalance
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --账户余额不足
	  end;

    Function FBERES_UnknownTrading
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '8'; --交易结果未知
	  end;

    Function FBERES_Fail
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'x'; --失败
	  end;

    --FBEResultFlag:换汇成功标志 --<<

    --FBEExchStatus:换汇交易状态 -->>
    Function FBEES_Normal
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --正常
	  end;

    Function FBEES_ReExchange
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --交易重发
	  end;

    --FBEExchStatus:换汇交易状态 --<<

    --FBEFileFlag:换汇文件标志 -->>
    Function FBEFG_DataPackage
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --数据包
	  end;

    Function FBEFG_File
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --文件
	  end;

    --FBEFileFlag:换汇文件标志 --<<

    --FBEAlreadyTrade:换汇已交易标志 -->>
    Function FBEAT_NotTrade
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --未交易
	  end;

    Function FBEAT_Trade
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --已交易
	  end;

    --FBEAlreadyTrade:换汇已交易标志 --<<

    --FBEUserEventType:银期换汇用户事件类型 -->>
    Function FBEUET_SignIn
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --签到
	  end;

    Function FBEUET_Exchange
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --换汇
	  end;

    Function FBEUET_ReExchange
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --换汇重发
	  end;

    Function FBEUET_QueryBankAccount
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --银行账户查询
	  end;

    Function FBEUET_QueryExchDetial
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '4'; --换汇明细查询
	  end;

    Function FBEUET_QueryExchSummary
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '5'; --换汇汇总查询
	  end;

    Function FBEUET_QueryExchRate
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '6'; --换汇汇率查询
	  end;

    Function FBEUET_CheckBankAccount
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '7'; --对账文件通知
	  end;

    Function FBEUET_SignOut
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '8'; --签退
	  end;

    Function FBEUET_Other
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'Z'; --其他
	  end;

    --FBEUserEventType:银期换汇用户事件类型 --<<

    --FBEReqFlag:换汇发送标志 -->>
    Function FBERF_UnProcessed
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --未处理
	  end;

    Function FBERF_WaitSend
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --等待发送
	  end;

    Function FBERF_SendSuccess
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --发送成功
	  end;

    Function FBERF_SendFailed
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --发送失败
	  end;

    Function FBERF_WaitReSend
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '4'; --等待重发
	  end;

    --FBEReqFlag:换汇发送标志 --<<

    --NotifyClass:风险通知类型 -->>
    Function NC_NOERROR
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --正常
	  end;

    Function NC_Warn
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --警示
	  end;

    Function NC_Call
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --追保
	  end;

    Function NC_Force
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --强平
	  end;

    Function NC_CHUANCANG
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '4'; --穿仓
	  end;

    Function NC_Exception
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '5'; --异常
	  end;

    --NotifyClass:风险通知类型 --<<

    --ForceCloseType:强平单类型 -->>
    Function FCT_Manual
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --手工强平
	  end;

    Function FCT_Single
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --单一投资者辅助强平
	  end;

    Function FCT_Group
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --批量投资者辅助强平
	  end;

    --ForceCloseType:强平单类型 --<<

    --RiskNotifyMethod:风险通知途径 -->>
    Function RNM_System
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --系统通知
	  end;

    Function RNM_SMS
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --短信通知
	  end;

    Function RNM_EMail
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --邮件通知
	  end;

    Function RNM_Manual
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --人工通知
	  end;

    --RiskNotifyMethod:风险通知途径 --<<

    --RiskNotifyStatus:风险通知状态 -->>
    Function RNS_NotGen
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --未生成
	  end;

    Function RNS_Generated
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --已生成未发送
	  end;

    Function RNS_SendError
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --发送失败
	  end;

    Function RNS_SendOk
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --已发送未接收
	  end;

    Function RNS_Received
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '4'; --已接收未确认
	  end;

    Function RNS_Confirmed
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '5'; --已确认
	  end;

    --RiskNotifyStatus:风险通知状态 --<<

    --RiskUserEvent:风控用户操作事件 -->>
    Function RUE_ExportData
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --导出数据
	  end;

    --RiskUserEvent:风控用户操作事件 --<<

    --ConditionalOrderSortType:条件单索引条件 -->>
    Function COST_LastPriceAsc
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --使用最新价升序
	  end;

    Function COST_LastPriceDesc
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --使用最新价降序
	  end;

    Function COST_AskPriceAsc
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --使用卖价升序
	  end;

    Function COST_AskPriceDesc
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --使用卖价降序
	  end;

    Function COST_BidPriceAsc
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '4'; --使用买价升序
	  end;

    Function COST_BidPriceDesc
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '5'; --使用买价降序
	  end;

    --ConditionalOrderSortType:条件单索引条件 --<<

    --SendType:报送状态 -->>
    Function UOAST_NoSend
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --未发送
	  end;

    Function UOAST_Sended
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --已发送
	  end;

    Function UOAST_Generated
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --已生成
	  end;

    Function UOAST_SendFail
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --报送失败
	  end;

    Function UOAST_Success
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '4'; --接收成功
	  end;

    Function UOAST_Fail
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '5'; --接收失败
	  end;

    Function UOAST_Cancel
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '6'; --取消报送
	  end;

    --SendType:报送状态 --<<

    --ClientIDStatus:交易编码状态 -->>
    Function UOACS_NoApply
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --未申请
	  end;

    Function UOACS_Submited
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --已提交申请
	  end;

    Function UOACS_Sended
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --已发送申请
	  end;

    Function UOACS_Success
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '4'; --完成
	  end;

    Function UOACS_Refuse
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '5'; --拒绝
	  end;

    Function UOACS_Cancel
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '6'; --已撤销编码
	  end;

    --ClientIDStatus:交易编码状态 --<<

    --QuestionType:特有信息类型 -->>
    Function QT_Radio
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --单选
	  end;

    Function QT_Option
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --多选
	  end;

    Function QT_Blank
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --填空
	  end;

    --QuestionType:特有信息类型 --<<

    --BusinessType:业务类型 -->>
    Function BT_Request
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --请求
	  end;

    Function BT_Response
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --应答
	  end;

    Function BT_Notice
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --通知
	  end;

    --BusinessType:业务类型 --<<

    --CfmmcReturnCode:监控中心返回码 -->>
    Function CRC_Success
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --成功
	  end;

    Function CRC_Working
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --该客户已经有流程在处理中
	  end;

    Function CRC_InfoFail
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --监控中客户资料检查失败
	  end;

    Function CRC_IDCardFail
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --监控中实名制检查失败
	  end;

    Function CRC_OtherFail
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '4'; --其他错误
	  end;

    --CfmmcReturnCode:监控中心返回码 --<<

    --ClientType:客户类型 -->>
    Function CFMMCCT_All
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --所有
	  end;

    Function CFMMCCT_Person
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --个人
	  end;

    Function CFMMCCT_Company
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --单位
	  end;

    Function CFMMCCT_Other
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --其他
	  end;

    Function CFMMCCT_SpecialOrgan
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '4'; --特殊法人
	  end;

    Function CFMMCCT_Asset
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '5'; --资管户
	  end;

    --ClientType:客户类型 --<<

    --UpdateFlag:更新状态 -->>
    Function UF_NoUpdate
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --未更新
	  end;

    Function UF_Success
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --更新全部信息成功
	  end;

    Function UF_Fail
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --更新全部信息失败
	  end;

    Function UF_TCSuccess
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --更新交易编码成功
	  end;

    Function UF_TCFail
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '4'; --更新交易编码失败
	  end;

    Function UF_Cancel
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '5'; --已丢弃
	  end;

    --UpdateFlag:更新状态 --<<

    --ApplyAction:申请动作 -->>
    Function AA_OpenInvestor
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --开户
	  end;

    Function AA_ModifyIDCard
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --修改身份信息
	  end;

    Function AA_ModifyNoIDCard
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --修改一般信息
	  end;

    Function AA_ApplyTradingCode
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '4'; --申请交易编码
	  end;

    Function AA_CancelTradingCode
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '5'; --撤销交易编码
	  end;

    Function AA_CancelInvestor
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '6'; --销户
	  end;

    Function AA_FreezeAccount
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '8'; --账户休眠
	  end;

    Function AA_ActiveFreezeAccount
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '9'; --激活休眠账户
	  end;

    --ApplyAction:申请动作 --<<

    --ApplyStatus:申请状态 -->>
    Function AS_NoComplete
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --未补全
	  end;

    Function AS_Submited
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --已提交
	  end;

    Function AS_Checked
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --已审核
	  end;

    Function AS_Refused
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '4'; --已拒绝
	  end;

    Function AS_Deleted
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '5'; --已删除
	  end;

    --ApplyStatus:申请状态 --<<

    --SendMethod:发送方式 -->>
    Function UOASM_ByAPI
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --文件发送
	  end;

    Function UOASM_ByFile
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --电子发送
	  end;

    --SendMethod:发送方式 --<<

    --EventMode:操作方法 -->>
    Function EVM_ADD
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --增加
	  end;

    Function EVM_UPDATE
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --修改
	  end;

    Function EVM_DELETE
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --删除
	  end;

    Function EVM_CHECK
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '4'; --复核
	  end;

    Function EVM_COPY
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '5'; --复制
	  end;

    Function EVM_CANCEL
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '6'; --注销
	  end;

    Function EVM_Reverse
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '7'; --冲销
	  end;

    Function EVM_MORTUPDATE
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '8'; --质押更新
	  end;

    --EventMode:操作方法 --<<

    --UOAAutoSend:统一开户申请自动发送 -->>
    Function UOAA_ASR
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --自动发送并接收
	  end;

    Function UOAA_ASNR
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --自动发送，不自动接收
	  end;

    Function UOAA_NSAR
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --不自动发送，自动接收
	  end;

    Function UOAA_NSR
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '4'; --不自动发送，也不自动接收
	  end;

    --UOAAutoSend:统一开户申请自动发送 --<<

    --FlowID:流程ID -->>
    Function EVM_InvestorGroupFlow
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --投资者对应投资者组设置
	  end;

    Function EVM_InvestorRate
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --投资者手续费率设置
	  end;

    Function EVM_InvestorCommRateModel
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --投资者手续费率模板关系设置
	  end;

    Function EVM_InvestorOptRate
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '4'; --投资者期权手续费率设置
	  end;

    Function EVM_InvestorFutSettleRate
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '5'; --投资者期货手续费率设置
	  end;

    Function EVM_InvestorFutTransferRate
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '6'; --投资者期权移仓手续费率设置
	  end;

    Function EVM_InvestorOptSettleRate
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '7'; --投资者期权结算手续费率设置
	  end;

    Function EVM_InvestorOptTransferRate
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '8'; --投资者期权移仓手续费率设置
	  end;

    Function EVM_InvstFutGUARFundCommRate
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '9'; --投资者期货保障基金手续费率设置
	  end;

    Function EVM_FloatInvestorFutRate
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --投资者期货浮动手续费率设置
	  end;

    Function EVM_FloatInvestorOptRate
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'A'; --投资者期权浮动手续费率设置
	  end;

    --FlowID:流程ID --<<

    --CheckLevel:复核级别 -->>
    Function CL_Zero
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --零级复核
	  end;

    Function CL_One
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --一级复核
	  end;

    Function CL_Two
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --二级复核
	  end;

    --CheckLevel:复核级别 --<<

    --CheckStatus:复核级别 -->>
    Function CHS_Init
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --未复核
	  end;

    Function CHS_Checking
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --复核中
	  end;

    Function CHS_Checked
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --已复核
	  end;

    Function CHS_Refuse
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --拒绝
	  end;

    Function CHS_Cancel
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '4'; --作废
	  end;

    --CheckStatus:复核级别 --<<

    --UsedStatus:生效状态 -->>
    Function CHU_Unused
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --未生效
	  end;

    Function CHU_Used
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --已生效
	  end;

    Function CHU_Fail
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --生效失败
	  end;

    --UsedStatus:生效状态 --<<

    --BankAcountOrigin:账户来源 -->>
    Function BAO_ByAccProperty
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --手工录入
	  end;

    Function BAO_ByFBTransfer
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --银期转账
	  end;

    --BankAcountOrigin:账户来源 --<<

    --MonthBillTradeSum:结算单月报成交汇总方式 -->>
    Function MBTS_ByInstrument
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --同日同合约
	  end;

    Function MBTS_ByDayInsPrc
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --同日同合约同价格
	  end;

    Function MBTS_ByDayIns
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --同合约
	  end;

    --MonthBillTradeSum:结算单月报成交汇总方式 --<<

    --FBTTradeCodeEnum:银期交易代码枚举 -->>
    Function FTC_BankLaunchBankToBroker
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '102001'; --银行发起银行转期货
	  end;

    Function FTC_BrokerLaunchBankToBroker
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '202001'; --期货发起银行转期货
	  end;

    Function FTC_BankLaunchBrokerToBank
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '102002'; --银行发起期货转银行
	  end;

    Function FTC_BrokerLaunchBrokerToBank
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '202002'; --期货发起期货转银行
	  end;

    --FBTTradeCodeEnum:银期交易代码枚举 --<<

    --OTPType:动态令牌类型 -->>
    Function OTP_NONE
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --无动态令牌
	  end;

    Function OTP_TOTP
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --时间令牌
	  end;

    --OTPType:动态令牌类型 --<<

    --OTPStatus:动态令牌状态 -->>
    Function OTPS_Unused
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --未使用
	  end;

    Function OTPS_Used
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --已使用
	  end;

    Function OTPS_Disuse
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --注销
	  end;

    --OTPStatus:动态令牌状态 --<<

    --BrokerUserType:经纪公司用户类型 -->>
    Function BUT_Investor
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --投资者
	  end;

    Function BUT_BrokerUser
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --操作员
	  end;

    --BrokerUserType:经纪公司用户类型 --<<

    --FutureType:期货类型 -->>
    Function FUTT_Commodity
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --商品期货
	  end;

    Function FUTT_Financial
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --金融期货
	  end;

    --FutureType:期货类型 --<<

    --FundEventType:资金管理操作类型 -->>
    Function FET_Restriction
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --转账限额
	  end;

    Function FET_TodayRestriction
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --当日转账限额
	  end;

    Function FET_Transfer
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --期商流水
	  end;

    Function FET_Credit
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --资金冻结
	  end;

    Function FET_InvestorWithdrawAlm
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '4'; --投资者可提资金比例
	  end;

    Function FET_BankRestriction
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '5'; --单个银行账户转账限额
	  end;

    Function FET_Accountregister
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '6'; --银期签约账户
	  end;

    Function FET_ExchangeFundIO
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '7'; --交易所出入金
	  end;

    Function FET_InvestorFundIO
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '8'; --投资者出入金
	  end;

    Function FET_InvestorMortgage
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '9'; --投资者质押
	  end;

    Function FET_InvestorFundMortgage
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'a'; --投资者货币质押
	  end;

    Function FET_AutoSwapSetting
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'b'; --自动换汇设置
	  end;

    --FundEventType:资金管理操作类型 --<<

    --AccountSourceType:资金账户来源 -->>
    Function AST_FBTransfer
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --银期同步
	  end;

    Function AST_ManualEntry
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --手工录入
	  end;

    --AccountSourceType:资金账户来源 --<<

    --CodeSourceType:交易编码来源 -->>
    Function CST_UnifyAccount
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --统一开户(已规范)
	  end;

    Function CST_ManualEntry
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --手工录入(未规范)
	  end;

    --CodeSourceType:交易编码来源 --<<

    --UserRange:操作员范围 -->>
    Function UR_All
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --所有
	  end;

    Function UR_Single
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --单一操作员
	  end;

    --UserRange:操作员范围 --<<

    --ByGroup:交易统计表按客户统计方式 -->>
    Function BG_Investor
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --按投资者统计
	  end;

    Function BG_Group
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --按类统计
	  end;

    --ByGroup:交易统计表按客户统计方式 --<<

    --TradeSumStatMode:交易统计表按范围统计方式 -->>
    Function TSSM_Instrument
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --按合约统计
	  end;

    Function TSSM_Product
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --按产品统计
	  end;

    Function TSSM_Exchange
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --按交易所统计
	  end;

    --TradeSumStatMode:交易统计表按范围统计方式 --<<

    --ExprSetMode:日期表达式设置类型 -->>
    Function ESM_Relative
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --相对已有规则设置
	  end;

    Function ESM_Typical
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --典型设置
	  end;

    --ExprSetMode:日期表达式设置类型 --<<

    --SyncDataStatus:主次用系统数据同步状态 -->>
    Function SDS_Initialize
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --未同步
	  end;

    Function SDS_Settlementing
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --同步中
	  end;

    Function SDS_Settlemented
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --已同步
	  end;

    --SyncDataStatus:主次用系统数据同步状态 --<<

    --TradeSource:成交来源 -->>
    Function TSRC_NORMAL
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --来自交易所普通回报
	  end;

    Function TSRC_QUERY
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --来自查询
	  end;

    --TradeSource:成交来源 --<<

    --FlexStatMode:产品合约统计方式 -->>
    Function FSM_Product
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --产品统计
	  end;

    Function FSM_Exchange
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --交易所统计
	  end;

    Function FSM_All
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --统计所有
	  end;

    --FlexStatMode:产品合约统计方式 --<<

    --ByInvestorRange:投资者范围统计方式 -->>
    Function BIR_Property
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --属性统计
	  end;

    Function BIR_All
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --统计所有
	  end;

    --ByInvestorRange:投资者范围统计方式 --<<

    --PropertyInvestorRange:投资者范围 -->>
    Function PIR_All
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --所有
	  end;

    Function PIR_Property
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --投资者属性
	  end;

    Function PIR_Single
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --单一投资者
	  end;

    --PropertyInvestorRange:投资者范围 --<<

    --FileStatus:文件状态 -->>
    Function FIS_NoCreate
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --未生成
	  end;

    Function FIS_Created
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --已生成
	  end;

    Function FIS_Failed
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --生成失败
	  end;

    Function FIS_NoInvestor
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --未获取到符合条件的投资者
	  end;

    --FileStatus:文件状态 --<<

    --FileGenStyle:文件生成方式 -->>
    Function FGS_FileTransmit
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --下发
	  end;

    Function FGS_FileGen
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --生成
	  end;

    --FileGenStyle:文件生成方式 --<<

    --SysOperMode:系统日志操作方法 -->>
    Function SOM_Add
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --增加
	  end;

    Function SOM_Update
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --修改
	  end;

    Function SOM_Delete
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --删除
	  end;

    Function SOM_Copy
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '4'; --复制
	  end;

    Function SOM_AcTive
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '5'; --激活
	  end;

    Function SOM_CanCel
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '6'; --注销
	  end;

    Function SOM_ReSet
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '7'; --重置
	  end;

    Function SOM_Export
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '8'; --导出
	  end;

    Function SOM_Generate
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '9'; --生成
	  end;

    Function SOM_Mail
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'A'; --邮寄
	  end;

    --SysOperMode:系统日志操作方法 --<<

    --SysOperType:系统日志操作类型 -->>
    Function SOT_UpdatePassword
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --修改操作员密码
	  end;

    Function SOT_UserDepartment
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --操作员组织架构关系
	  end;

    Function SOT_RoleManager
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --角色管理
	  end;

    Function SOT_RoleFunction
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --角色功能设置
	  end;

    Function SOT_BaseParam
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '4'; --基础参数设置
	  end;

    Function SOT_SetUserID
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '5'; --设置操作员
	  end;

    Function SOT_SetUserRole
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '6'; --用户角色设置
	  end;

    Function SOT_UserIpRestriction
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '7'; --用户IP限制
	  end;

    Function SOT_DepartmentManager
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '8'; --组织架构管理
	  end;

    Function SOT_DepartmentCopy
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '9'; --组织架构向查询分类复制
	  end;

    Function SOT_Tradingcode
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'A'; --交易编码管理
	  end;

    Function SOT_InvestorStatus
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'B'; --投资者状态维护
	  end;

    Function SOT_InvestorAuthority
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'C'; --投资者权限管理
	  end;

    Function SOT_PropertySet
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'D'; --属性设置
	  end;

    Function SOT_ReSetInvestorPasswd
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'E'; --重置投资者密码
	  end;

    Function SOT_InvestorPersonalityInfo
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'F'; --投资者个性信息维护
	  end;

    Function SOT_DataExport
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'G'; --数据导出
	  end;

    Function SOT_FileGenAndDownLoad
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'H'; --文件生成与下载
	  end;

    Function SOT_SettleSystemParam
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'I'; --结算参数设置
	  end;

    Function SOT_TradeSystemParam
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'M'; --交易参数设置
	  end;

    Function SOT_FundPlatformParam
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'N'; --资金平台参数设置
	  end;

    Function SOT_ReSetInvestorLoginPasswd
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'J'; --投资者密码重置_重置终端登录密码
	  end;

    Function SOT_ReSetInvestorAccountPasswd
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'K'; --投资者密码重置_重置资金账户密码
	  end;

    Function SOT_ChangeBankAccount
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'O'; --变更存管银行
	  end;

    --SysOperType:系统日志操作类型 --<<

    --CSRCDataQueyType:上报数据查询类型 -->>
    Function CSRCQ_Current
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --查询当前交易日报送的数据
	  end;

    Function CSRCQ_History
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --查询历史报送的代理经纪公司的数据
	  end;

    --CSRCDataQueyType:上报数据查询类型 --<<

    --FreezeStatus:休眠状态 -->>
    Function FRS_Normal
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --活跃
	  end;

    Function FRS_Freeze
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --休眠
	  end;

    --FreezeStatus:休眠状态 --<<

    --StandardStatus:规范状态 -->>
    Function STST_Standard
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --已规范
	  end;

    Function STST_NonStandard
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --未规范
	  end;

    --StandardStatus:规范状态 --<<

    --RightParamType:配置类型 -->>
    Function RPT_Freeze
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --休眠户
	  end;

    Function RPT_FreezeActive
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --激活休眠户
	  end;

    Function RPT_OpenLimit
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --开仓权限限制
	  end;

    Function RPT_RelieveOpenLimit
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '4'; --解除开仓权限限制
	  end;

    --RightParamType:配置类型 --<<

    --DataStatus:反洗钱审核表数据状态 -->>
    Function AMLDS_Normal
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --正常
	  end;

    Function AMLDS_Deleted
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --已删除
	  end;

    --DataStatus:反洗钱审核表数据状态 --<<

    --AMLCheckStatus:审核状态 -->>
    Function AMLCHS_Init
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --未复核
	  end;

    Function AMLCHS_Checking
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --复核中
	  end;

    Function AMLCHS_Checked
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --已复核
	  end;

    Function AMLCHS_RefuseReport
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --拒绝上报
	  end;

    --AMLCheckStatus:审核状态 --<<

    --AmlDateType:日期类型 -->>
    Function AMLDT_DrawDay
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --检查日期
	  end;

    Function AMLDT_TouchDay
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --发生日期
	  end;

    --AmlDateType:日期类型 --<<

    --AmlCheckLevel:审核级别 -->>
    Function AMLCL_CheckLevel0
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --零级审核
	  end;

    Function AMLCL_CheckLevel1
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --一级审核
	  end;

    Function AMLCL_CheckLevel2
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --二级审核
	  end;

    Function AMLCL_CheckLevel3
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --三级审核
	  end;

    --AmlCheckLevel:审核级别 --<<

    --ExportFileType:导出文件类型 -->>
    Function EFT_CSV
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --CSV
	  end;

    Function EFT_EXCEL
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --Excel
	  end;

    Function EFT_DBF
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --DBF
	  end;

    --ExportFileType:导出文件类型 --<<

    --SettleManagerType:结算配置类型 -->>
    Function SMT_Before
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --结算前准备
	  end;

    Function SMT_Settlement
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --结算
	  end;

    Function SMT_After
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --结算后核对
	  end;

    Function SMT_Settlemented
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '4'; --结算后处理
	  end;

    --SettleManagerType:结算配置类型 --<<

    --SettleManagerLevel:结算配置等级 -->>
    Function SML_Must
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --必要
	  end;

    Function SML_Alarm
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --警告
	  end;

    Function SML_Prompt
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --提示
	  end;

    Function SML_Ignore
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '4'; --不检查
	  end;

    --SettleManagerLevel:结算配置等级 --<<

    --SettleManagerGroup:模块分组 -->>
    Function SMG_Exhcange
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --交易所核对
	  end;

    Function SMG_ASP
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --内部核对
	  end;

    Function SMG_CSRC
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --上报数据核对
	  end;

    --SettleManagerGroup:模块分组 --<<

    --LimitUseType:保值额度使用类型 -->>
    Function LUT_Repeatable
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --可重复使用
	  end;

    Function LUT_Unrepeatable
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --不可重复使用
	  end;

    --LimitUseType:保值额度使用类型 --<<

    --DataResource:数据来源 -->>
    Function DAR_Settle
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --本系统
	  end;

    Function DAR_Exchange
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --交易所
	  end;

    Function DAR_CSRC
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --报送数据
	  end;

    --DataResource:数据来源 --<<

    --MarginType:保证金类型 -->>
    Function MGT_ExchMarginRate
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --交易所保证金率
	  end;

    Function MGT_InstrMarginRate
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --投资者保证金率
	  end;

    Function MGT_InstrMarginRateTrade
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --投资者交易保证金率
	  end;

    --MarginType:保证金类型 --<<

    --ActiveType:生效类型 -->>
    Function ACT_Intraday
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --仅当日生效
	  end;

    Function ACT_Long
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --长期生效
	  end;

    --ActiveType:生效类型 --<<

    --MarginRateType:冲突保证金率类型 -->>
    Function MRT_Exchange
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --交易所保证金率
	  end;

    Function MRT_Investor
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --投资者保证金率
	  end;

    Function MRT_InvestorTrade
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --投资者交易保证金率
	  end;

    --MarginRateType:冲突保证金率类型 --<<

    --BackUpStatus:备份数据状态 -->>
    Function BUS_UnBak
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --未生成备份数据
	  end;

    Function BUS_BakUp
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --备份数据生成中
	  end;

    Function BUS_BakUped
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --已生成备份数据
	  end;

    Function BUS_BakFail
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --备份数据失败
	  end;

    --BackUpStatus:备份数据状态 --<<

    --InitSettlement:结算初始化状态 -->>
    Function SIS_UnInitialize
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --结算初始化未开始
	  end;

    Function SIS_Initialize
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --结算初始化中
	  end;

    Function SIS_Initialized
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --结算初始化完成
	  end;

    --InitSettlement:结算初始化状态 --<<

    --ReportStatus:报表数据生成状态 -->>
    Function SRS_NoCreate
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --未生成报表数据
	  end;

    Function SRS_Create
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --报表数据生成中
	  end;

    Function SRS_Created
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --已生成报表数据
	  end;

    Function SRS_CreateFail
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --生成报表数据失败
	  end;

    --ReportStatus:报表数据生成状态 --<<

    --SaveStatus:数据归档状态 -->>
    Function SSS_UnSaveData
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --归档未完成
	  end;

    Function SSS_SaveDatad
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --归档完成
	  end;

    --SaveStatus:数据归档状态 --<<

    --SettArchiveStatus:结算确认数据归档状态 -->>
    Function SAS_UnArchived
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --未归档数据
	  end;

    Function SAS_Archiving
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --数据归档中
	  end;

    Function SAS_Archived
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --已归档数据
	  end;

    Function SAS_ArchiveFail
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --归档数据失败
	  end;

    --SettArchiveStatus:结算确认数据归档状态 --<<

    --CTPType:CTP交易系统类型 -->>
    Function CTPT_Unkown
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --未知类型
	  end;

    Function CTPT_MainCenter
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --主中心
	  end;

    Function CTPT_BackUp
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --备中心
	  end;

    --CTPType:CTP交易系统类型 --<<

    --CloseDealType:平仓处理类型 -->>
    Function CDT_Normal
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --正常
	  end;

    Function CDT_SpecFirst
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --投机平仓优先
	  end;

    --CloseDealType:平仓处理类型 --<<

    --MortgageFundUseRange:货币质押资金可用范围 -->>
    Function MFUR_None
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --不能使用
	  end;

    Function MFUR_Margin
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --用于保证金
	  end;

    Function MFUR_All
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --用于手续费、盈亏、保证金
	  end;

    Function MFUR_CNY3
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --同人民币资金使用范围
	  end;

    --MortgageFundUseRange:货币质押资金可用范围 --<<

    --SpecProductType:特殊产品类型 -->>
    Function SPT_CzceHedge
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --郑商所套保产品
	  end;

    Function SPT_IneForeignCurrency
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --货币质押产品
	  end;

    Function SPT_DceOpenClose
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --大连短线开平仓产品
	  end;

    Function SPT_CffexRate
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '4'; --中金所交叉汇率产品
	  end;

    Function SPT_CffexMaxMargin
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '5'; --中金所组合单向大边产品
	  end;

    Function SPT_DceSpcOpenClose
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '6'; --交易时平今赋给开仓品种
	  end;

    Function SPT_MaxMargin
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '7'; --单向大边产品
	  end;

    Function SPT_TAS
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '8'; --TAS产品
	  end;

    --SpecProductType:特殊产品类型 --<<

    --FundMortgageType:货币质押类型 -->>
    Function FMT_Mortgage
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --质押
	  end;

    Function FMT_Redemption
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --解质
	  end;

    --FundMortgageType:货币质押类型 --<<

    --AccountSettlementParamID:投资者账户结算参数代码 -->>
    Function ASPI_BaseMargin
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --基础保证金
	  end;

    Function ASPI_LowestInterest
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --最低权益标准
	  end;

    --AccountSettlementParamID:投资者账户结算参数代码 --<<

    --FundMortDirection:货币质押方向 -->>
    Function FMD_In
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --货币质入
	  end;

    Function FMD_Out
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --货币质出
	  end;

    --FundMortDirection:货币质押方向 --<<

    --BusinessClass:换汇类别 -->>
    Function BT_Profit
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --盈利
	  end;

    Function BT_Loss
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --亏损
	  end;

    Function BT_Other
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'Z'; --其他
	  end;

    --BusinessClass:换汇类别 --<<

    --SwapSourceType:换汇数据来源 -->>
    Function SST_Manual
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --手工
	  end;

    Function SST_Automatic
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --自动生成
	  end;

    Function SST_DelivPayment
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --交割货款
	  end;

    --SwapSourceType:换汇数据来源 --<<

    --CurrExDirection:换汇类型 -->>
    Function CED_Settlement
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --结汇
	  end;

    Function CED_Sale
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --购汇
	  end;

    --CurrExDirection:换汇类型 --<<

    --IsManualSwap:是否手工换汇 -->>
    Function IMS_Yes
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --手工换汇
	  end;

    Function IMS_No
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --自动换汇或者其他
	  end;

    --IsManualSwap:是否手工换汇 --<<

    --IsAllRemainSetZero:是否将所有外币的剩余换汇额度设置为0 -->>
    Function IARSZ_Yes
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --更新为0
	  end;

    Function IARSZ_No
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --不更新
	  end;

    --IsAllRemainSetZero:是否将所有外币的剩余换汇额度设置为0 --<<

    --CurrencySwapStatus:申请状态 -->>
    Function CSS_Entry
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --已录入
	  end;

    Function CSS_Approve
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --已审核
	  end;

    Function CSS_Refuse
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --已拒绝
	  end;

    Function CSS_Revoke
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '4'; --已撤销
	  end;

    Function CSS_Send
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '5'; --已发送
	  end;

    Function CSS_Success
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '6'; --换汇成功
	  end;

    Function CSS_Failure
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '7'; --换汇失败
	  end;

    --CurrencySwapStatus:申请状态 --<<

    --ReqFlag:换汇发送标志 -->>
    Function REQF_NoSend
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --未发送
	  end;

    Function REQF_SendSuccess
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --发送成功
	  end;

    Function REQF_SendFailed
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --发送失败
	  end;

    Function REQF_WaitReSend
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --等待重发
	  end;

    --ReqFlag:换汇发送标志 --<<

    --ResFlag:换汇返回成功标志 -->>
    Function RESF_Success
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --成功
	  end;

    Function RESF_InsuffiCient
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --账户余额不足
	  end;

    Function RESF_UnKnown
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '8'; --交易结果未知
	  end;

    --ResFlag:换汇返回成功标志 --<<

    --ExStatus:修改状态 -->>
    Function EXS_Before
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --修改前
	  end;

    Function EXS_After
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --修改后
	  end;

    --ExStatus:修改状态 --<<

    --ClientRegion:开户客户地域 -->>
    Function CR_Domestic
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --国内客户
	  end;

    Function CR_GMT
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --港澳台地区客户
	  end;

    Function CR_Foreign
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --国外客户
	  end;

    Function CR_Residence
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '4'; --永久居留的境外客户
	  end;

    --ClientRegion:开户客户地域 --<<

    --HasBoard:是否有董事会 -->>
    Function HB_No
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --没有
	  end;

    Function HB_Yes
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --有
	  end;

    --HasBoard:是否有董事会 --<<

    --StartMode:启动模式 -->>
    Function SM_Normal
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --正常
	  end;

    Function SM_Emerge
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --应急
	  end;

    Function SM_Restore
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --恢复
	  end;

    --StartMode:启动模式 --<<

    --TemplateType:模型类型 -->>
    Function TPT_Full
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --全量
	  end;

    Function TPT_Increment
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --增量
	  end;

    Function TPT_BackUp
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --备份
	  end;

    --TemplateType:模型类型 --<<

    --LoginMode:登录模式 -->>
    Function LM_Trade
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --交易
	  end;

    Function LM_Transfer
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --转账
	  end;

    --LoginMode:登录模式 --<<

    --PromptType:日历提示类型 -->>
    Function CPT_Instrument
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --合约上下市
	  end;

    Function CPT_Margin
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --保证金分段生效
	  end;

    --PromptType:日历提示类型 --<<

    --AmType:机构类型 -->>
    Function AMT_Bank
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --银行
	  end;

    Function AMT_Securities
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --证券公司
	  end;

    Function AMT_Fund
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --基金公司
	  end;

    Function AMT_Insurance
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '4'; --保险公司
	  end;

    Function AMT_Trust
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '5'; --信托公司
	  end;

    Function AMT_Other
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '9'; --其他
	  end;

    --AmType:机构类型 --<<

    --CSRCFundIOType:出入金类型 -->>
    Function CFIOT_FundIO
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --银行出入金
	  end;

    Function CFIOT_SwapCurrency
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --换汇出入金
	  end;

    Function CFIOT_ManualCurrency
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --手工出入金
	  end;

    --CSRCFundIOType:出入金类型 --<<

    --CusAccountType:结算账户类型 -->>
    Function CAT_Futures
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --期货结算账户
	  end;

    Function CAT_AssetmgrFuture
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --纯期货资管业务下的资管结算账户
	  end;

    Function CAT_AssetmgrTrustee
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --综合类资管业务下的期货资管托管账户
	  end;

    Function CAT_AssetmgrTransfer
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '4'; --综合类资管业务下的资金中转账户
	  end;

    --CusAccountType:结算账户类型 --<<

    --LanguageType:通知语言类型 -->>
    Function LT_Chinese
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --中文
	  end;

    Function LT_English
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --英文
	  end;

    --LanguageType:通知语言类型 --<<

    --AssetmgrClientType:资产管理客户类型 -->>
    Function AMCT_Person
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --个人资管客户
	  end;

    Function AMCT_Organ
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --单位资管客户
	  end;

    Function AMCT_SpecialOrgan
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '4'; --特殊单位资管客户
	  end;

    Function AMCT_Multiple
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '5'; --一对多资管客户
	  end;

    --AssetmgrClientType:资产管理客户类型 --<<

    --AssetmgrType:投资类型 -->>
    Function ASST_Futures
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --期货类
	  end;

    Function ASST_SpecialOrgan
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '4'; --综合类
	  end;

    --AssetmgrType:投资类型 --<<

    --CheckInstrType:合约比较类型 -->>
    Function CIT_HasExch
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --合约交易所不存在
	  end;

    Function CIT_HasATP
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --合约本系统不存在
	  end;

    Function CIT_HasDiff
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --合约比较不一致
	  end;

    --CheckInstrType:合约比较类型 --<<

    --CheckInstrPriceType:结算价比较类型 -->>
    Function CIPT_HasExch
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --结算价交易所不存在
	  end;

    Function CIPT_HasATP
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --结算价本系统不存在
	  end;

    Function CIPT_HasDiff
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --结算价比较不一致
	  end;

    --CheckInstrPriceType:结算价比较类型 --<<

    --DeliveryType:交割类型 -->>
    Function DT_HandDeliv
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --手工交割
	  end;

    Function DT_PersonDeliv
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --到期交割
	  end;

    --DeliveryType:交割类型 --<<

    --MaxMarginSideAlgorithm:大额单边保证金算法 -->>
    Function MMSA_NO
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --不使用大额单边保证金算法
	  end;

    Function MMSA_YES
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --使用大额单边保证金算法
	  end;

    --MaxMarginSideAlgorithm:大额单边保证金算法 --<<

    --DAClientType:资产管理客户类型 -->>
    Function CACT_Person
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --自然人
	  end;

    Function CACT_Company
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --法人
	  end;

    Function CACT_Other
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --其他
	  end;

    --DAClientType:资产管理客户类型 --<<

    --UOAAssetmgrType:投资类型 -->>
    Function UOAAT_Futures
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --期货类
	  end;

    Function UOAAT_SpecialOrgan
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --综合类
	  end;

    --UOAAssetmgrType:投资类型 --<<

    --DirectionEn:买卖方向 -->>
    Function DEN_Buy
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --Buy
	  end;

    Function DEN_Sell
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --Sell
	  end;

    --DirectionEn:买卖方向 --<<

    --OffsetFlagEn:开平标志 -->>
    Function OFEN_Open
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --Position Opening
	  end;

    Function OFEN_Close
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --Position Close
	  end;

    Function OFEN_ForceClose
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --Forced Liquidation
	  end;

    Function OFEN_CloseToday
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --Close Today
	  end;

    Function OFEN_CloseYesterday
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '4'; --Close Prev.
	  end;

    Function OFEN_ForceOff
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '5'; --Forced Reduction
	  end;

    Function OFEN_LocalForceClose
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '6'; --Local Forced Liquidation
	  end;

    --OffsetFlagEn:开平标志 --<<

    --HedgeFlagEn:投机套保标志 -->>
    Function HFEN_Speculation
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --Speculation
	  end;

    Function HFEN_Arbitrage
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --Arbitrage
	  end;

    Function HFEN_Hedge
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --Hedge
	  end;

    --HedgeFlagEn:投机套保标志 --<<

    --FundIOTypeEn:出入金类型 -->>
    Function FIOTEN_FundIO
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --Deposit/Withdrawal
	  end;

    Function FIOTEN_Transfer
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --Bank-Futures Transfer
	  end;

    Function FIOTEN_SwapCurrency
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --Bank-Futures FX Exchange
	  end;

    --FundIOTypeEn:出入金类型 --<<

    --FundTypeEn:资金类型 -->>
    Function FTEN_Deposite
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --Bank Deposit
	  end;

    Function FTEN_ItemFund
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --Payment/Fee
	  end;

    Function FTEN_Company
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --Brokerage Adj
	  end;

    Function FTEN_InnerTransfer
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '4'; --Internal Transfer
	  end;

    Function FTEN_Interest
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '+'; --Interest Settlement
	  end;

    --FundTypeEn:资金类型 --<<

    --FundDirectionEn:出入金方向 -->>
    Function FDEN_In
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --Deposit
	  end;

    Function FDEN_Out
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --Withdrawal
	  end;

    --FundDirectionEn:出入金方向 --<<

    --FundMortDirectionEn:货币质押方向 -->>
    Function FMDEN_In
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --Pledge
	  end;

    Function FMDEN_Out
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --Redemption
	  end;

    --FundMortDirectionEn:货币质押方向 --<<

    --OptionsType:期权类型 -->>
    Function CP_CallOptions
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --看涨
	  end;

    Function CP_PutOptions
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --看跌
	  end;

    --OptionsType:期权类型 --<<

    --StrikeMode:执行方式 -->>
    Function STM_Continental
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --欧式
	  end;

    Function STM_American
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --美式
	  end;

    Function STM_Bermuda
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --百慕大
	  end;

    --StrikeMode:执行方式 --<<

    --StrikeType:行权类型 -->>
    Function STT_Strike
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --期权执行
	  end;

    Function STT_GiveUp
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --期权放弃
	  end;

    --StrikeType:行权类型 --<<

    --ApplyType:中金所期权放弃执行申请类型 -->>
    Function APPT_NotStrikeNum
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '4'; --不执行数量
	  end;

    --ApplyType:中金所期权放弃执行申请类型 --<<

    --GiveUpDataSource:放弃执行申请数据来源 -->>
    Function GUDS_Gen
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --系统生成
	  end;

    Function GUDS_Hand
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --手工添加
	  end;

    --GiveUpDataSource:放弃执行申请数据来源 --<<

    --ExecResult:执行结果 -->>
    Function OER_NoExec
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'n'; --没有执行
	  end;

    Function OER_Canceled
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'c'; --已经取消
	  end;

    Function OER_OK
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --执行成功
	  end;

    Function OER_NoPosition
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --期权持仓不够
	  end;

    Function OER_NoDeposit
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --资金不够
	  end;

    Function OER_NoParticipant
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --会员不存在
	  end;

    Function OER_NoClient
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '4'; --客户不存在
	  end;

    Function OER_NoInstrument
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '6'; --合约不存在
	  end;

    Function OER_NoRight
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '7'; --没有执行权限
	  end;

    Function OER_InvalidVolume
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '8'; --不合理的数量
	  end;

    Function OER_NoEnoughHistoryTrade
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '9'; --没有足够的历史成交
	  end;

    Function OER_Unknown
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'a'; --未知
	  end;

    --ExecResult:执行结果 --<<

    --PositionChangeType:持仓变动类型 -->>
    Function PCT_OptionStrike
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --期权执行
	  end;

    Function PCT_PositionHedge
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --持仓对冲
	  end;

    Function PCT_SwitchToDeliv
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --转入交割
	  end;

    Function PCT_TransferPos
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '4'; --移仓
	  end;

    --PositionChangeType:持仓变动类型 --<<

    --PctDelivType:交割类型 -->>
    Function PCTDT_FutureToSpot
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --期转现
	  end;

    Function PCTDT_ExpireToDeliv
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --到期交割
	  end;

    --PctDelivType:交割类型 --<<

    --CombinationType:组合类型 -->>
    Function COMBT_Future
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --期货组合
	  end;

    Function COMBT_BUL
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --垂直价差BUL
	  end;

    Function COMBT_BER
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --垂直价差BER
	  end;

    Function COMBT_STD
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --跨式组合
	  end;

    Function COMBT_STG
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '4'; --宽跨式组合
	  end;

    Function COMBT_PRT
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '5'; --备兑组合
	  end;

    Function COMBT_CLD
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '6'; --时间价差组合
	  end;

    Function COMBT_OPL
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '7'; --期权对锁组合
	  end;

    Function COMBT_BFO
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '8'; --买备兑组合
	  end;

    --CombinationType:组合类型 --<<

    --OptionRoyaltyPriceType:期权权利金价格类型 -->>
    Function ORPT_PreSettlementPrice
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --昨结算价
	  end;

    Function ORPT_OpenPrice
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '4'; --开仓价
	  end;

    Function ORPT_MaxPreSettlementPrice
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '5'; --max(昨结算价，最新价)
	  end;

    --OptionRoyaltyPriceType:期权权利金价格类型 --<<

    --BalanceAlgorithm:权益算法 -->>
    Function BLAG_Default
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --不计算期权市值盈亏
	  end;

    Function BLAG_IncludeOptValLost
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --计算期权市值亏损
	  end;

    --BalanceAlgorithm:权益算法 --<<

    --ActionType:执行类型 -->>
    Function ACTP_Exec
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --执行
	  end;

    Function ACTP_Abandon
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --放弃
	  end;

    --ActionType:执行类型 --<<

    --ForQuoteStatus:询价状态 -->>
    Function FQST_Submitted
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'a'; --已经提交
	  end;

    Function FQST_Accepted
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'b'; --已经接受
	  end;

    Function FQST_Rejected
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'c'; --已经被拒绝
	  end;

    --ForQuoteStatus:询价状态 --<<

    --QuotStatus:报价状态 -->>
    Function QTST_Unknown
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'a'; --未知
	  end;

    Function QTST_Accepted
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'b'; --已经接受
	  end;

    Function QTST_Canceled
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'c'; --已经撤销
	  end;

    --QuotStatus:报价状态 --<<

    --ValueMethod:取值方式 -->>
    Function VM_Absolute
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --按绝对值
	  end;

    Function VM_Ratio
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --按比率
	  end;

    --ValueMethod:取值方式 --<<

    --ExecOrderPositionFlag:期权行权后是否保留期货头寸的标记 -->>
    Function EOPF_Reserve
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --保留
	  end;

    Function EOPF_UnReserve
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --不保留
	  end;

    --ExecOrderPositionFlag:期权行权后是否保留期货头寸的标记 --<<

    --ExecOrderCloseFlag:期权行权后生成的头寸是否自动平仓 -->>
    Function EOCF_AutoClose
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --自动平仓
	  end;

    Function EOCF_NotToClose
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --免于自动平仓
	  end;

    --ExecOrderCloseFlag:期权行权后生成的头寸是否自动平仓 --<<

    --ProductType:产品类型 -->>
    Function PTE_Futures
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --期货
	  end;

    Function PTE_Options
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --期权
	  end;

    --ProductType:产品类型 --<<

    --CZCEUploadFileName:郑商所结算文件名 -->>
    Function CUFN_CUFN_O
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'O'; --^\d{8}_zz_\d{4}
	  end;

    Function CUFN_CUFN_T
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'T'; --^\d{8}成交表
	  end;

    Function CUFN_CUFN_P
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'P'; --^\d{8}单腿持仓表new
	  end;

    Function CUFN_CUFN_N
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'N'; --^\d{8}非平仓了结表
	  end;

    Function CUFN_CUFN_L
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'L'; --^\d{8}平仓表
	  end;

    Function CUFN_CUFN_F
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'F'; --^\d{8}资金表
	  end;

    Function CUFN_CUFN_C
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'C'; --^\d{8}组合持仓表
	  end;

    Function CUFN_CUFN_M
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'M'; --^\d{8}保证金参数表
	  end;

    --CZCEUploadFileName:郑商所结算文件名 --<<

    --DCEUploadFileName:大商所结算文件名 -->>
    Function DUFN_DUFN_O
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'O'; --^\d{8}_dl_\d{3}
	  end;

    Function DUFN_DUFN_T
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'T'; --^\d{8}_成交表
	  end;

    Function DUFN_DUFN_P
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'P'; --^\d{8}_持仓表
	  end;

    Function DUFN_DUFN_F
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'F'; --^\d{8}_资金结算表
	  end;

    Function DUFN_DUFN_C
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'C'; --^\d{8}_优惠组合持仓明细表
	  end;

    Function DUFN_DUFN_D
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'D'; --^\d{8}_持仓明细表
	  end;

    Function DUFN_DUFN_M
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'M'; --^\d{8}_保证金参数表
	  end;

    Function DUFN_DUFN_S
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'S'; --^\d{8}_期权执行表
	  end;

    Function DUFN_DUFN_H
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'H'; --^\d{8}_保证金优惠参数表
	  end;

    --DCEUploadFileName:大商所结算文件名 --<<

    --SHFEUploadFileName:上期所结算文件名 -->>
    Function SUFN_SUFN_O
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'O'; --^\d{4}_\d{8}_\d{8}_\d{8}_DailyFundChg_CNY
	  end;

    Function SUFN_SUFN_T
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'T'; --^\d{4}_\d{8}_\d{8}_\d{8}_Trade_CNY
	  end;

    Function SUFN_SUFN_P
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'P'; --^\d{4}_\d{8}_\d{8}_\d{8}_SettlementDetail_CNY
	  end;

    Function SUFN_SUFN_F
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'F'; --^\d{4}_\d{8}_\d{8}_\d{8}_Capital_CNY
	  end;

    Function SUFN_SUFN_B
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'B'; --^\d{4}_\d{8}_\d{8}_\d{8}_PositionChange_CNY
	  end;

    Function SUFN_SUFN_M
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'M'; --^\d{4}_\d{8}_\d{8}_\d{8}_InstrumentParam_CNY
	  end;

    --SHFEUploadFileName:上期所结算文件名 --<<

    --CFFEXUploadFileName:中金所结算文件名 -->>
    Function CFUFN_SUFN_T
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'T'; --^\d{4}_SG\d{2}_\d{8}_\d{1}_Trade
	  end;

    Function CFUFN_SUFN_P
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'P'; --^\d{4}_SG\d{2}_\d{8}_\d{1}_SettlementDetail
	  end;

    Function CFUFN_SUFN_F
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'F'; --^\d{4}_SG\d{2}_\d{8}_\d{1}_NewCapitalFX
	  end;

    Function CFUFN_SUFN_O
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'O'; --^\d{4}_SG\d{2}_\d{8}_\d{1}_ClientCapitalDetail
	  end;

    Function CFUFN_SUFN_S
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'S'; --^\d{4}_SG\d{2}_\d{8}_\d{1}_OptionExec
	  end;

    Function CFUFN_SUFN_X
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'X'; --^\d{4}_SG\d{2}_\d{8}_\d{1}_ClientCombPosition
	  end;

    Function CFUFN_SUFN_U
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'U'; --^\d{4}_SG\d{2}_\d{8}_\d{1}_CombRuleForSett
	  end;

    Function CFUFN_SUFN_E
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'E'; --^\d{4}_SG\d{2}_\d{8}_\d{1}_ExchangeRate
	  end;

    Function CFUFN_SUFN_Y
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'Y'; --^\d{4}_SG\d{2}_\d{8}_\d{1}_SpecialTransfeeRatio
	  end;

    Function CFUFN_SUFN_G
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'G'; --^\d{4}_SG\d{2}_\d{8}_\d{1}_ExchangeRate2
	  end;

    Function CFUFN_SUFN_D
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'D'; --^\d{4}_SG\d{2}_\d{8}_\d{1}_MarketmakerTransfeeDerate
	  end;

    --CFFEXUploadFileName:中金所结算文件名 --<<

    --INEUploadFileName:能源中心结算文件名 -->>
    Function IUFN_SUFN_O
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'O'; --^\d{4}_\d{8}_\d{8}_\d{8}_DailyFundChg_CNY
	  end;

    Function IUFN_SUFN_T
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'T'; --^\d{4}_\d{8}_\d{8}_\d{8}_Trade_CNY
	  end;

    Function IUFN_SUFN_P
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'P'; --^\d{4}_\d{8}_\d{8}_\d{8}_SettlementDetail_CNY
	  end;

    Function IUFN_SUFN_F
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'F'; --^\d{4}_\d{8}_\d{8}_\d{8}_Capital_CNY
	  end;

    Function IUFN_IUFN_I
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'I'; --^\d{4}_\d{8}_\d{8}_\d{8}_ExchangeRate_CNY
	  end;

    Function IUFN_IUFN_M
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'M'; --^\d{4}_\d{8}_\d{8}_\d{8}_InstrumentParam_CNY
	  end;

    --INEUploadFileName:能源中心结算文件名 --<<

    --InstrumentFlag:合约状态 -->>
    Function INF_Normal
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --正常
	  end;

    --InstrumentFlag:合约状态 --<<

    --InvestorFlag:投资者状态 -->>
    Function IVF_Normal
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --正常
	  end;

    --InvestorFlag:投资者状态 --<<

    --CorporateClassify:法人客户分类 -->>
    Function CC_Company
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --企业法人
	  end;

    --CorporateClassify:法人客户分类 --<<

    --SettleEntityType:结算实体类型 -->>
    Function SET_Investor
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'a'; --投资者
	  end;

    --SettleEntityType:结算实体类型 --<<

    --IsAllowed:是否允许 -->>
    Function IA_NotAllowed
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --不允许
	  end;

    Function IA_Allowed
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --允许
	  end;

    --IsAllowed:是否允许 --<<

    --Level:层次 -->>
    Function L_One
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --一级
	  end;

    Function L_Two
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --二级
	  end;

    --Level:层次 --<<

    --SecuritiesVarietyType:业务类型(结算用) -->>
    Function SVT_Warrant
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --标准仓单
	  end;

    Function SVT_OtherSVT
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '9'; --其他
	  end;

    --SecuritiesVarietyType:业务类型(结算用) --<<

    --SettleBusinessType:业务类型(结算用) -->>
    Function SBT_FundChange
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --出入金
	  end;

    Function SBT_Mortgage
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --质押
	  end;

    Function SBT_DeliveryConfirm
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --交割确认
	  end;

    --SettleBusinessType:业务类型(结算用) --<<

    --BusinessID:业务类型ID -->>
    Function BIZID_Product
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'Product'; --产品类
	  end;

    Function BIZID_Rate
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'Rate'; --费率类
	  end;

    Function BIZID_Fund
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'Fund'; --资金类
	  end;

    --BusinessID:业务类型ID --<<

    --ProductID:产品代码 -->>
    Function PRODUCTID_AllProduct
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '00000000'; --所有产品
	  end;

    --ProductID:产品代码 --<<

    --OperateType:业务操作类型 -->>
    Function OPTY_None
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --空操作
	  end;

    Function OPTY_Add
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --新增
	  end;

    Function OPTY_Update
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --修改
	  end;

    Function OPTY_Delete
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --删除
	  end;

    Function OPTY_Check
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '4'; --复核
	  end;

    --OperateType:业务操作类型 --<<

    --OperationStatus:操作状态字段 -->>
    Function OPS_UnChange
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --未改变
	  end;

    Function OPS_Add
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --新增
	  end;

    Function OPS_Modify
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --修改
	  end;

    Function OPS_Delete
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --删除
	  end;

    --OperationStatus:操作状态字段 --<<

    --OptProcessStatus:操作处理状态 -->>
    Function OPS_Apply
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --已提交
	  end;

    Function OPS_Pass
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --复核通过
	  end;

    Function OPS_Refuse
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --驳回
	  end;

    --OptProcessStatus:操作处理状态 --<<

    --PositionType:持仓类型 -->>
    Function PT_Net
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --净持仓
	  end;

    Function PT_Gross
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --综合持仓
	  end;

    --PositionType:持仓类型 --<<

    --PositionDateType:持仓日期类型 -->>
    Function PDT_UseHistory
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --使用历史持仓
	  end;

    Function PDT_NoUseHistory
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --不使用历史持仓
	  end;

    --PositionDateType:持仓日期类型 --<<

    --DelivFeeClass:交割手续费类型 -->>
    Function DFO_Exchange
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --交易所交割手续费
	  end;

    Function DFO_Investor
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --投资者交割手续费
	  end;

    --DelivFeeClass:交割手续费类型 --<<

    --AccountRange:资金账号范围 -->>
    Function AR_All
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --所有
	  end;

    Function AR_Group
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --账户组
	  end;

    Function AR_Single
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --单一资金账号
	  end;

    --AccountRange:资金账号范围 --<<

    --AccountOwnerMode:资金账号属主类型 -->>
    Function AOM_Investor
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --投资者
	  end;

    Function AOM_SecAgent
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --二级代理
	  end;

    Function AOM_TradeMember
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --交易会员
	  end;

    --AccountOwnerMode:资金账号属主类型 --<<

    --DeliveryFlag:交割是否完成标识 -->>
    Function DF_DF_UNFINISHED
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --交割未完成
	  end;

    Function DF_DF_FINISHED
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --交割已完成
	  end;

    --DeliveryFlag:交割是否完成标识 --<<

    --DeliveryFeeType:交割手续费收取方式 -->>
    Function DFT_ByAmount
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --按金额
	  end;

    Function DFT_ByRoundLot
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --按手数
	  end;

    --DeliveryFeeType:交割手续费收取方式 --<<

    --RegDicType:用于监管机构的字典类型 -->>
    Function RDT_Broker
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --经纪公司
	  end;

    Function RDT_Exchange
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --交易所
	  end;

    Function RDT_Bank
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --结算银行
	  end;

    --RegDicType:用于监管机构的字典类型 --<<

    --RegulatorID:监管机构代码 -->>
    Function RI_CFMMC
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --证监会期货保证金监控中心
	  end;

    --RegulatorID:监管机构代码 --<<

    --CheckFutMarginType:保证金率比较类型 -->>
    Function CFMT_CurrNO
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --当前系统不存在
	  end;

    Function CFMT_CurrDiff
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --当前系统存在但不相等
	  end;

    Function CFMT_CurrSame
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --当前系统存在且相等
	  end;

    --CheckFutMarginType:保证金率比较类型 --<<

    --RelativeAbsoluteType:相对绝对类型 -->>
    Function RAT_Relative
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --相对
	  end;

    Function RAT_Absolute
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --绝对
	  end;

    --RelativeAbsoluteType:相对绝对类型 --<<

    --RateEventOperatorMethod:费率业务操作方法 -->>
    Function REOM_Add
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --新增
	  end;

    Function REOM_Update
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --修改
	  end;

    Function REOM_BatUpdate
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --批量修改
	  end;

    Function REOM_Delete
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '4'; --删除
	  end;

    Function REOM_BatDelete
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '5'; --批量删除
	  end;

    Function REOM_Copy
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '6'; --复制
	  end;

    Function REOM_Apply
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '7'; --应用
	  end;

    --RateEventOperatorMethod:费率业务操作方法 --<<

    --MarginRateEventOperatorType:保证金业务操作类型 -->>
    Function MREOT_ExchFutMarginRate
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --交易所期货保证金率
	  end;

    Function MREOT_InvstFutMarginRate
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --投资者期货保证金率
	  end;

    --MarginRateEventOperatorType:保证金业务操作类型 --<<

    --CommRateEventOperatorType:手续费业务操作类型 -->>
    Function CREOT_ExchFutCommRate
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --交易所期货手续费率
	  end;

    Function CREOT_InvstFutCommRate
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --投资者期货手续费率
	  end;

    --CommRateEventOperatorType:手续费业务操作类型 --<<

    --TransferStatus:转账流水状态 -->>
    Function FBTS_Normal
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --正常
	  end;

    Function FBTS_Repealed
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --被冲正
	  end;

    --TransferStatus:转账流水状态 --<<

    --ClientIDCategory:交易编码类型 -->>
    Function TCT_Future
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --期货
	  end;

    Function TCT_Spot
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --现货
	  end;

    Function TCT_SpotDeriva
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --现货衍生品
	  end;

    --ClientIDCategory:交易编码类型 --<<

    --FutCommRateType:期货手续费类型 -->>
    Function FCRT_Open
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --开仓
	  end;

    Function FCRT_Close
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --平仓
	  end;

    Function FCRT_CloseToday
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --平今
	  end;

    Function FCRT_Delivery
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '4'; --交割
	  end;

    Function FCRT_Settlement
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '5'; --结算
	  end;

    Function FCRT_OpenClose
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '6'; --短线开平
	  end;

    --FutCommRateType:期货手续费类型 --<<

    --OptCommRateType:期权手续费类型 -->>
    Function OCRT_Open
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --开仓
	  end;

    Function OCRT_Close
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --平仓
	  end;

    Function OCRT_CloseToday
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --平今
	  end;

    Function OCRT_Strike
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '4'; --执行
	  end;

    Function OCRT_Settlement
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '5'; --结算
	  end;

    Function OCRT_Perform
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '6'; --履约
	  end;

    Function OCRT_OpenClose
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '7'; --短线开平
	  end;

    --OptCommRateType:期权手续费类型 --<<

    --DelivMarginAcceptStyle:交割保证金收取方式 -->>
    Function DMAS_ByVolume
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --按冻结量收取
	  end;

    Function DMAS_FixMargin
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --按指定保证金收取
	  end;

    --DelivMarginAcceptStyle:交割保证金收取方式 --<<

    --SseOptStrikeMargin:上证所期权执行保证金收取方式 -->>
    Function SSETSESP_Margin
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --只收取保证金
	  end;

    Function SSETSESP_Full
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --全额收取
	  end;

    --SseOptStrikeMargin:上证所期权执行保证金收取方式 --<<

    --InstructionRight:指令权限 -->>
    Function ISTR_Limit
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --限价单
	  end;

    Function ISTR_Limit_FOK
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --限价全额成交否则取消
	  end;

    Function ISTR_Market_RemainLimit
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --市价订单剩余转限价
	  end;

    Function ISTR_Market_FAK
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '4'; --市价订单剩余撤销
	  end;

    Function ISTR_Market_FOK
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '5'; --市价全额成交否则取消
	  end;

    Function ISTR_Lock
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '6'; --证券锁定
	  end;

    Function ISTR_Unlock
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '7'; --证券解锁
	  end;

    --InstructionRight:指令权限 --<<

    --AppType:应用程序类型 -->>
    Function APP_Offer
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --交易报盘
	  end;

    Function APP_Dbwriter
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --回写数据库
	  end;

    Function APP_Dbmt
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --实时上场
	  end;

    Function APP_MdOffer
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '4'; --行情报盘
	  end;

    Function APP_TInit
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '5'; --初始化上场
	  end;

    Function APP_CFMMCToken
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '6'; --保证金监控中心令牌查询
	  end;

    --AppType:应用程序类型 --<<

    --SYNCDBOperation:记录操作类型 -->>
    Function SYNCDBOP_Unknown
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --未知
	  end;

    Function SYNCDBOP_Insert
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --插入
	  end;

    Function SYNCDBOP_Update
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --更新
	  end;

    Function SYNCDBOP_Delete
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --删除
	  end;

    Function SYNCDBOP_Commit
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '4'; --提交
	  end;

    --SYNCDBOperation:记录操作类型 --<<

    --PrePayOrderStatus:预埋单状态 -->>
    Function PPOS_NotSend
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --未发送
	  end;

    Function PPOS_Send
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --已发送
	  end;

    Function PPOS_Deleted
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --已删除
	  end;

    --PrePayOrderStatus:预埋单状态 --<<

    --AppConnectStatus:报盘机连接状态 -->>
    Function ACS_NotConnected
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --没有任何连接
	  end;

    Function ACS_Logged
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --已经登录交易核心
	  end;

    Function ACS_ExgConnected
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --已经连接交易所
	  end;

    Function ACS_ExgLogged
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '4'; --已经登录交易所
	  end;

    --AppConnectStatus:报盘机连接状态 --<<

    --CombDirection:组合指令方向 -->>
    Function CMDR_Comb
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --申请组合
	  end;

    Function CMDR_UnComb
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --申请拆分
	  end;

    --CombDirection:组合指令方向 --<<

    --PositionDateMode:持仓日期类型 -->>
    Function PDM_UseHistory
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --使用历史持仓
	  end;

    Function PDM_NoUseHistory
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --不使用历史持仓
	  end;

    --PositionDateMode:持仓日期类型 --<<

    --SzeOptStrikeMargin:深交所期权执行保证金收取方式 -->>
    Function SZETSESP_Margin
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --只收取保证金
	  end;

    Function SZETSESP_Full
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --全额收取
	  end;

    --SzeOptStrikeMargin:深交所期权执行保证金收取方式 --<<

    --DCETradeType:大商所成交类型 -->>
    Function DTT_CJ
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --盘中成交
	  end;

    Function DTT_TT
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --投机转套保
	  end;

    Function DTT_EH
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --期权执行的期货建仓
	  end;

    Function DTT_JC
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --交割持仓对冲
	  end;

    Function DTT_FJ
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '4'; --强制减仓
	  end;

    Function DTT_QP
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '5'; --异常处理
	  end;

    Function DTT_LS
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '6'; --零碎持仓
	  end;

    Function DTT_QC
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '7'; --期权执行前对冲期权持仓
	  end;

    Function DTT_HC
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '8'; --期权执行后对冲期货持仓
	  end;

    Function DTT_LC
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '9'; --期权履约后对冲期货持仓
	  end;

    Function DTT_HS
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'A'; --套保转投机
	  end;

    --DCETradeType:大商所成交类型 --<<

    --RiskModeCalcID:风险算法 -->>
    Function RMCI_MARGIN
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --保证金/总权益
	  end;

    Function RMCI_EQUITY
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --总权益/保证金
	  end;

    Function RMCI_MARGIN10
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --保证金/总权益*100
	  end;

    Function RMCI_EQUITY10
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '4'; --总权益/保证金*100
	  end;

    --RiskModeCalcID:风险算法 --<<

    --StrikeOffsetType:行权偏移类型 -->>
    Function STOV_RealValue
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --实值额
	  end;

    Function STOV_ProfitValue
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --盈利额
	  end;

    Function STOV_RealRatio
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --实值比例
	  end;

    Function STOV_ProfitRatio
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '4'; --盈利比例
	  end;

    --StrikeOffsetType:行权偏移类型 --<<

    --CheckOperate:复核操作 -->>
    Function CHO_Init
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --复核初始化
	  end;

    Function CHO_Approve
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --复核同意
	  end;

    Function CHO_Refuse
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --复核拒绝
	  end;

    Function CHO_Cancel
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --复核作废
	  end;

    --CheckOperate:复核操作 --<<

    --PartType:会员类型 -->>
    Function PT_Trade
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --交易会员
	  end;

    Function PT_TradeSettle
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --交易结算会员
	  end;

    Function PT_Settle
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --全面结算会员
	  end;

    Function PT_SecSpecPart
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --境外特参
	  end;

    --PartType:会员类型 --<<

    --Share_Holder_Type:份额持有者类型 -->>
    Function SHT_Person
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --自然人
	  end;

    Function SHT_Company
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --一般单位
	  end;

    Function SHT_Product
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --产品
	  end;

    --Share_Holder_Type:份额持有者类型 --<<

    --AppropriaType:客户适当性分类 -->>
    Function AT_NormalInvestor
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --普通投资者
	  end;

    Function AT_ProfessionalInvestor
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --专业投资者
	  end;

    --AppropriaType:客户适当性分类 --<<

    --WeakPasswordSource:弱密码来源 -->>
    Function WPS_WeakPasswordLib
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --弱密码库
	  end;

    Function WPS_Manual
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --手工录入
	  end;

    --WeakPasswordSource:弱密码来源 --<<

    --IsWhite:是否白名单 -->>
    Function IW_IsBlack
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --黑名单
	  end;

    Function IW_IsWhite
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --白名单
	  end;

    --IsWhite:是否白名单 --<<

    --SettleFileType:结算数据类型 -->>
    Function SFT_CSRC
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --监控中心格式
	  end;

    Function SFT_CFFEX
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --中金所格式
	  end;

    --SettleFileType:结算数据类型 --<<

    --SettleFileVersion:结算数据版本 -->>
    Function SFV_V_431
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --V4.3.1
	  end;

    Function SFV_V_432
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --V4.3.2
	  end;

    --SettleFileVersion:结算数据版本 --<<

    --CFFEXSettleFileVersion:中金所结算数据版本 -->>
    Function CSFV_V_17
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --V1.7
	  end;

    Function CSFV_V_111
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --V1.11
	  end;

    --CFFEXSettleFileVersion:中金所结算数据版本 --<<

    --InterestStatus:结息状态 -->>
    Function ITS_Cleared
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --已结息
	  end;

    Function ITS_Canceled
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --已丢弃
	  end;

    --InterestStatus:结息状态 --<<

    --InterestMethod:结息算法 -->>
    Function ITM_Prepa
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --可用为利息基数
	  end;

    Function ITM_Deposit
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --结存为利息基数
	  end;

    --InterestMethod:结息算法 --<<

    --AmlChangeMethod:Aml变更识别方式 -->>
    Function ACM_Auto
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --自动识别
	  end;

    Function ACM_HandWork
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --人工识别
	  end;

    --AmlChangeMethod:Aml变更识别方式 --<<

    --IdentifiedCardExpireType:证件到期情况 -->>
    Function IET_Empty
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --证件到日期为空
	  end;

    Function IET_Expired
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --证件已到期
	  end;

    Function IET_ThreeMonth
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --3个月内即将到期
	  end;

    Function IET_SixMonth
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --6个月内即将到期
	  end;

    --IdentifiedCardExpireType:证件到期情况 --<<

    --ReserveOpenAccStas:预约开户状态 -->>
    Function ROAST_Processing
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --等待处理中
	  end;

    Function ROAST_Cancelled
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --已撤销
	  end;

    Function ROAST_Opened
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --已开户
	  end;

    Function ROAST_Invalid
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --无效请求
	  end;

    --ReserveOpenAccStas:预约开户状态 --<<

    --BizType:业务类型 -->>
    Function BZTP_Future
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --期货
	  end;

    Function BZTP_Stock
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --证券
	  end;

    --BizType:业务类型 --<<

    --MoreRows_Base:是否还有后续行 -->>
    Function MOREROWS_Yes
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --有后续行
	  end;

    Function MOREROWS_No
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --没有后续行
	  end;

    --MoreRows_Base:是否还有后续行 --<<

    --ClientIDType:交易编码类型 -->>
    Function CIDT_Speculation
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --投机
	  end;

    Function CIDT_Arbitrage
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --套利
	  end;

    Function CIDT_Hedge
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --套保
	  end;

    Function CIDT_Maker
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '4'; --做市商
	  end;

    --ClientIDType:交易编码类型 --<<

    --ApplyOperateID:申请动作 -->>
    Function AOID_OpenInvestor
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --开户
	  end;

    Function AOID_ModifyIDCard
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --修改身份信息
	  end;

    Function AOID_ModifyNoIDCard
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --修改一般信息
	  end;

    Function AOID_ApplyTradingCode
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '4'; --申请交易编码
	  end;

    Function AOID_CancelTradingCode
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '5'; --撤销交易编码
	  end;

    Function AOID_CancelInvestor
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '6'; --销户
	  end;

    Function AOID_FreezeAccount
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '8'; --账户休眠
	  end;

    Function AOID_ActiveFreezeAccount
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '9'; --激活休眠账户
	  end;

    --ApplyOperateID:申请动作 --<<

    --ApplyStatusID:申请状态 -->>
    Function ASID_NoComplete
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --未补全
	  end;

    Function ASID_Submited
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --已提交
	  end;

    Function ASID_Checked
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --已审核
	  end;

    Function ASID_Refused
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '4'; --已拒绝
	  end;

    Function ASID_Deleted
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '5'; --已删除
	  end;

    --ApplyStatusID:申请状态 --<<

    --PctDelivMode:交割方式 -->>
    Function PCTDM_Cash
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --现金交割
	  end;

    Function PCTDM_Physical
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --实物交割
	  end;

    --PctDelivMode:交割方式 --<<

    --BrokerFlag:经纪公司状态 -->>
    Function BF_InActive
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --不活跃
	  end;

    Function BF_Active
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --活跃
	  end;

    --BrokerFlag:经纪公司状态 --<<

    --OptSelfCloseFlag:期权行权的头寸是否自对冲 -->>
    Function OSCF_CloseSelfOptionPosition
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --自对冲期权仓位
	  end;

    Function OSCF_ReserveOptionPosition
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --保留期权仓位
	  end;

    Function OSCF_SellCloseSelfFuturePositi
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --自对冲卖方履约后的期货仓位
	  end;

    --OptSelfCloseFlag:期权行权的头寸是否自对冲 --<<

    --AdminOrderCommandFlag:管理报单指令 -->>
    Function AOCF_NotMultipleForceClose
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --交割月持仓非整数倍强平
	  end;

    Function AOCF_InitCreditLimit
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --初始化交易会员信用额度
	  end;

    Function AOCF_AlterCreditLimit
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --调整交易会员信用额度
	  end;

    Function AOCF_CancelCreditLimit
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '4'; --取消交易会员信用额度
	  end;

    --AdminOrderCommandFlag:管理报单指令 --<<

    --AdminOrderStatus:管理报单状态 -->>
    Function AOS_Tinit
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --初始化交易会员信用额度
	  end;

    Function AOS_Alter
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --调整交易会员信用额度
	  end;

    Function AOS_Cancel
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --取消交易会员信用额度
	  end;

    --AdminOrderStatus:管理报单状态 --<<

    --CurrencySwapFundCurrentStatus:换汇款项当前记录状态 -->>
    Function CSFCS_Record
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --已录入
	  end;

    Function CSFCS_Pass
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --已审核
	  end;

    Function CSFCS_Refuse
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --已驳回
	  end;

    --CurrencySwapFundCurrentStatus:换汇款项当前记录状态 --<<

    --SettleTaskStatus:结算任务状态 -->>
    Function STSS_ToBeSettled
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --待结算
	  end;

    Function STSS_Settling
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --结算中
	  end;

    Function STSS_Settled
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --已结算
	  end;

    Function STSS_ToBeInitiated
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '4'; --待初始化
	  end;

    Function STSS_Initiating
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '5'; --初始化中
	  end;

    Function STSS_Initiation
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '6'; --已初始化
	  end;

    Function STSS_Failed
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '7'; --处理失败
	  end;

    Function STSS_Returned
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '8'; --已回退
	  end;

    --SettleTaskStatus:结算任务状态 --<<

    --InHedgeFlag:投机套保标志 -->>
    Function IHF_Speculation
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --投机
	  end;

    Function IHF_Arbitrage
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --套利
	  end;

    Function IHF_Hedge
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --套保
	  end;

    Function IHF_Maker
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '4'; --做市商
	  end;

    --InHedgeFlag:投机套保标志 --<<

    --NoTradePosChgType:非交易持仓调整 -->>
    Function NTPCT_Add
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --增加
	  end;

    Function NTPCT_Reduce
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --减少
	  end;

    --NoTradePosChgType:非交易持仓调整 --<<

    --ClearIntScope:计息范围 -->>
    Function CI_All
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --所有
	  end;

    Function CI_Group
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --组
	  end;

    Function CI_Single
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --单一账户
	  end;

    --ClearIntScope:计息范围 --<<

    --EliminateType:剔除方式 -->>
    Function ET_Single
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --剔除某一用户
	  end;

    --EliminateType:剔除方式 --<<

    --ExClientIDType:交易编码类型 -->>
    Function ECIDT_Hedge
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --套保
	  end;

    Function ECIDT_Arbitrage
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --套利
	  end;

    Function ECIDT_Speculation
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --投机
	  end;

    Function ECIDT_Maker
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '4'; --做市商
	  end;

    --ExClientIDType:交易编码类型 --<<

    --SerialStatus:流水记录状态 -->>
    Function SEALS_Effective
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --新增
	  end;

    Function SEALS_Abandon
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --作废
	  end;

    Function SEALS_Charge
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --冲销
	  end;

    --SerialStatus:流水记录状态 --<<

    --RuleType:号段规则类型 -->>
    Function RTY_Default
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --默认
	  end;

    Function RTY_Custom
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --自定义
	  end;

    --RuleType:号段规则类型 --<<

    --AssetmgrInstitution:资产管理业务的经营机构 -->>
    Function ASSIS_SubCompany
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --期货公司子公司
	  end;

    Function ASSIS_UnSubCompany
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --非期货公司子公司
	  end;

    --AssetmgrInstitution:资产管理业务的经营机构 --<<

    --platformstatus:资金平台流水应用状态 -->>
    Function PFS_InterDay
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --日间操作
	  end;

    Function PFS_ChkSerFinished
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --对帐已确认
	  end;

    --platformstatus:资金平台流水应用状态 --<<

    --TerminalType:开户终端类型 -->>
    Function TMT_Online
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --PC网上开户
	  end;

    Function TMT_Mobile
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --移动端网上开户
	  end;

    Function TMT_Android
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '5'; --安卓SDK网上开户
	  end;

    Function TMT_IOS
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '6'; --IOS SDK网上开户
	  end;

    --TerminalType:开户终端类型 --<<

    --PersonBlackListTypeType:人员黑名单类型 -->>
    Function CRAPBL_list0
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --联合国发布的恐怖组织名单
	  end;

    Function CRAPBL_list1
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --联合国发布的恐怖分子名单
	  end;

    Function CRAPBL_list2
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --联合国发布的通缉罪犯名单
	  end;

    Function CRAPBL_list3
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --联合国发布的其他禁止性名单
	  end;

    Function CRAPBL_list4
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '4'; --国家有关部门发布的恐怖组织名单
	  end;

    Function CRAPBL_list5
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '5'; --国家有关部门发布的恐怖分子名单
	  end;

    Function CRAPBL_list6
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '6'; --代理人为黑名单人员
	  end;

    Function CRAPBL_list7
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '7'; --法人代表为黑名单人员
	  end;

    Function CRAPBL_list8
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '8'; --司法机关发布的恐怖组织名单
	  end;

    Function CRAPBL_list9
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '9'; --国家有关部门发布的通缉犯名单
	  end;

    Function CRAPBL_list10
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'A'; --外国政要人物的家庭成员
	  end;

    Function CRAPBL_list11
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'B'; --外国政要
	  end;

    Function CRAPBL_list12
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'C'; --公检法等机构协查
	  end;

    Function CRAPBL_list13
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'D'; --因涉嫌权威媒体重要负面报道
	  end;

    Function CRAPBL_list14
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'E'; --交易所通报或发函，客户涉嫌违规而被进入期货市场的，或被警示的
	  end;

    Function CRAPBL_list15
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'F'; --证监会通报或发函，客户涉嫌违规违法
	  end;

    Function CRAPBL_list16
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'G'; --因涉嫌其他犯罪被公检法部门要求协助冻结或划扣
	  end;

    Function CRAPBL_list17
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'H'; --因涉嫌毒品黑社会性质、恐怖活动、走私、贪污贿赂、破坏金融管理秩序、金融诈骗被公检部门要求协助冻结或划扣
	  end;

    --PersonBlackListTypeType:人员黑名单类型 --<<

    --AreaBlackListTypeType:国家与地区黑名单类型 -->>
    Function CRAABL_list0
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --客户关联地域为联合国发布的制裁、禁运的国家或地区
	  end;

    Function CRAABL_list1
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --客户关联地域为联合国发布的支持恐怖活动的国家或地区
	  end;

    Function CRAABL_list2
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --FATF组织、APG组织、EAG组织认定为缺乏反洗钱法律和反洗钱监管的国家或地区
	  end;

    Function CRAABL_list3
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --客户关联地域为贩毒犯罪、腐败犯罪、人口贩运、支持恐怖主义、或其他犯罪活动猖獗的地域
	  end;

    Function CRAABL_list4
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '4'; --离岸金融中心
	  end;

    Function CRAABL_list5
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '5'; --被称为“避税天堂”的国家或地区
	  end;

    Function CRAABL_list6
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '6'; --客户关联地域为国家发布的支持恐怖活动的国家或地区
	  end;

    --AreaBlackListTypeType:国家与地区黑名单类型 --<<

    --BlackListType:黑名单类型 -->>
    Function CRABLT_Person
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --人员黑名单
	  end;

    Function CRABLT_Area
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --地域黑名单
	  end;

    --BlackListType:黑名单类型 --<<

    --RatingType:评级方式 -->>
    Function CRART_Auto
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --自动定级
	  end;

    Function CRART_LowRisk
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --低风险直接定级
	  end;

    Function CRART_HighRisk
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --高风险直接定级
	  end;

    --RatingType:评级方式 --<<

    --AutoRatingType:自动评级判断 -->>
    Function CRAART_None
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --无
	  end;

    Function CRAART_LowRisk
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --低风险
	  end;

    Function CRAART_HighRisk
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --高风险
	  end;

    --AutoRatingType:自动评级判断 --<<

    --CRARiskIndexType:风险等级统计指标类型 -->>
    Function CRA_LowFrequency
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --低频
	  end;

    Function CRA_HighFrequency
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --高频
	  end;

    --CRARiskIndexType:风险等级统计指标类型 --<<

    --OverseasInstitutionType:境外特殊参与者与境外中介机构标识 -->>
    Function CSRCOIT_SpecialParticipants
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --境外特殊经纪参与者
	  end;

    Function CSRCOIT_SpecialNParticipants
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --境外特殊非经纪参与者
	  end;

    Function CSRCOIT_SecAgent
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --境外中介机构
	  end;

    --OverseasInstitutionType:境外特殊参与者与境外中介机构标识 --<<

    --FundOperateType:资金业务操作类型 -->>
    Function FOPTY_None
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --空操作
	  end;

    Function FOPTY_Add
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --新增
	  end;

    Function FOPTY_Update
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --修改
	  end;

    Function FOPTY_Delete
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --删除
	  end;

    Function FOPTY_Check
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '4'; --复核
	  end;

    Function FOPTY_MortgageUpdate
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '5'; --质押更新
	  end;

    Function FOPTY_FileMortgage
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '6'; --导入分项资金质押
	  end;

    --FundOperateType:资金业务操作类型 --<<

    --DataSource:数据来源 -->>
    Function DS_Local
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --柜台
	  end;

    Function DS_Cloud
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --云平台
	  end;

    Function DS_Interface
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --接口
	  end;

    --DataSource:数据来源 --<<

    --PaperType:试卷类型 -->>
    Function PT_Normal_Risk_Level
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --风险能力测试试卷
	  end;

    Function PT_Profession_Document
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --专业资料调查试卷
	  end;

    --PaperType:试卷类型 --<<

    --QuestionClass:问题分类 -->>
    Function QC_QuestionClass_1
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --基本情况
	  end;

    Function QC_QuestionClass_2
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --资产负债情况
	  end;

    Function QC_QuestionClass_3
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --投资知识和经验
	  end;

    Function QC_QuestionClass_4
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '4'; --风险偏好
	  end;

    --QuestionClass:问题分类 --<<

    --BlackListSource:黑名单数据来源 -->>
    Function BLS_RecognizeByPerson
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --人工识别
	  end;

    Function BLS_AutoRecognize
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --系统识别
	  end;

    --BlackListSource:黑名单数据来源 --<<

    --InvstFundChangeSource:出入金数据来源 -->>
    Function IFCS_RecordByHand
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --手工录入出入金
	  end;

    Function IFCS_SystemAutoInterest
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --系统自动结息
	  end;

    Function IFCS_ExchangeSubEntry
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --交易所分项资金导入
	  end;

    Function IFCS_OtherBatchImport
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '4'; --其他出入金批量导入
	  end;

    --InvstFundChangeSource:出入金数据来源 --<<

    --TradeMode:成交类型 -->>
    Function TM_CJ
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --盘中成交
	  end;

    Function TM_TT
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --投机转套保
	  end;

    Function TM_EH
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --期权执行的期货建仓
	  end;

    Function TM_JC
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --交割持仓对冲
	  end;

    Function TM_FJ
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '4'; --强制减仓
	  end;

    Function TM_QP
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '5'; --异常处理
	  end;

    Function TM_LS
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '6'; --零碎持仓
	  end;

    Function TM_QC
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '7'; --期权执行前对冲期权持仓
	  end;

    Function TM_HC
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '8'; --期权执行后对冲期货持仓
	  end;

    Function TM_LC
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '9'; --期权履约后对冲期货持仓
	  end;

    --TradeMode:成交类型 --<<

    --SyncStatus:数据同步状态 -->>
    Function ISS_Asynchronous
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --未同步
	  end;

    Function ISS_Synchronizing
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --同步中
	  end;

    Function ISS_Synchronized
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --已同步
	  end;

    --SyncStatus:数据同步状态 --<<

    --TransTargettype:转账目标系统类型 -->>
    Function TRTGT_CTPTrade
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --CTP交易系统
	  end;

    Function TRTGT_CTPSettlement
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --CTP结算系统
	  end;

    Function TRTGT_ThirdPartyTrade
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --第三方系统
	  end;

    Function TRTGT_UnKnow
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --未知系统
	  end;

    --TransTargettype:转账目标系统类型 --<<

    --TransSysStatus:转账系统状态 -->>
    Function TRSYST_ReadyForTransfer
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --不能转账
	  end;

    Function TRSYST_NotReadyForTransfer
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --可以转账
	  end;

    --TransSysStatus:转账系统状态 --<<

    --BankIntefaceType:银行转账接口类别 -->>
    Function FIT_Future
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --银期转账接口
	  end;

    Function FIT_Stock
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --银证转账接口
	  end;

    Function FIT_Derivative
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --银衍转账接口
	  end;

    --BankIntefaceType:银行转账接口类别 --<<

    --ECheckMode:资金平台当前真正对帐状态 -->>
    Function ECM_Maual
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --对帐未通过
	  end;

    Function ECM_Auto
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --对帐通过
	  end;

    --ECheckMode:资金平台当前真正对帐状态 --<<

    --EOperType:资金平台操作方式 -->>
    Function EOT_NextDay
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --日切
	  end;

    Function EOT_LastDay
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --回退
	  end;

    --EOperType:资金平台操作方式 --<<

    --DeliverWay:交收方式 -->>
    Function STKDW_NetSecurity
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --净额担保
	  end;

    Function STKDW_NonSecurityBytrade
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --逐笔非担保交收
	  end;

    Function STKDW_OutCourt
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --场外交收
	  end;

    --DeliverWay:交收方式 --<<

    --SOptRecordFormat:期权记录格式 -->>
    Function SORF_F01
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --期权交易结算
	  end;

    Function SORF_F02
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --期权行权指派明细
	  end;

    Function SORF_F03
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --期权账户开户费用
	  end;

    Function SORF_F04
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '4'; --期权行权过户费明细
	  end;

    Function SORF_F11
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'b'; --期权行权标的证券净额交收通知
	  end;

    Function SORF_F12
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'c'; --期权行权标的证券净额交收结果
	  end;

    Function SORF_F13
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'd'; --期权行权现金结算交收明细
	  end;

    Function SORF_F14
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'e'; --期权行权欠款扣券交收明细
	  end;

    Function SORF_F15
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'f'; --备兑期权标的证券锁定净额汇总
	  end;

    Function SORF_F16
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'g'; --期权行权申报处置扣券及返还
	  end;

    Function SORF_F21
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'l'; --期权行权资金净额交收通知
	  end;

    Function SORF_F22
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'm'; --期权行权资金按清算编号汇总明细
	  end;

    Function SORF_F23
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'n'; --期权行权资金交收结果
	  end;

    Function SORF_F31
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'v'; --期权合约账户开通注销业务回报
	  end;

    --SOptRecordFormat:期权记录格式 --<<

    --SOptRecordType:期权记录类型 -->>
    Function SORT_D01
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --衍生品清算数据
	  end;

    Function SORT_D02
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --衍生品业务交收通知
	  end;

    Function SORT_D03
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --衍生品业务交收结果
	  end;

    --SOptRecordType:期权记录类型 --<<

    --SpotTradeWay:证券交易方式 -->>
    Function SSTW_RegularTrade
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --普通交易
	  end;

    Function SSTW_BlockTrade
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --大宗交易
	  end;

    Function SSTW_NonTrade
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --非交易
	  end;

    Function SSTW_FrontDesk
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '4'; --前台业务
	  end;

    Function SSTW_Prop
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '5'; --Prop申报
	  end;

    Function SSTW_FixIncomeEPlatForm
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'a'; --固定收益证券综合电子平台交易商之间交易
	  end;

    Function SSTW_ComPlatForm
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'd'; --综合业务平台交易
	  end;

    Function SSTW_FixIncomeNonGuaran
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'e'; --固定收益证券综合电子平台实施非担保交收的交易
	  end;

    --SpotTradeWay:证券交易方式 --<<

    --CoverFlag:备兑标志 -->>
    Function CF_Uncover
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --非备兑
	  end;

    Function CF_Cover
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --备兑
	  end;

    --CoverFlag:备兑标志 --<<

    --StockType:证券类别 -->>
    Function STKT_GZ
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --固定收益类
	  end;

    Function STKT_JJ
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --基金
	  end;

    Function STKT_PT
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --无限售流通股
	  end;

    Function STKT_PG
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '4'; --配股
	  end;

    Function STKT_PS
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '5'; --配售股
	  end;

    Function STKT_PZ
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '6'; --权证
	  end;

    Function STKT_GJ
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '7'; --国家股
	  end;

    Function STKT_GF
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '8'; --国有法人股
	  end;

    Function STKT_JN
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '9'; --境内法人股
	  end;

    Function STKT_JW
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'a'; --境外法人股
	  end;

    Function STKT_SF
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'b'; --社会法人股
	  end;

    Function STKT_XL
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'c'; --限售流通股
	  end;

    Function STKT_YX
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'd'; --优先法人股
	  end;

    Function STKT_ZG
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'e'; --职工股
	  end;

    --StockType:证券类别 --<<

    --RemainType:权益类型 -->>
    Function SORT_Cash
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --兑付
	  end;

    Function SORT_Interest
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --兑息
	  end;

    Function SORT_Dividend
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --红利
	  end;

    Function SORT_Offering
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '4'; --配股
	  end;

    Function SORT_Bonus
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '5'; --送股
	  end;

    Function SORT_Assemble
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '6'; --转配
	  end;

    --RemainType:权益类型 --<<

    --SOptTransferType:期权过户类型 -->>
    Function SOTT_Trade
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --期权交易
	  end;

    Function SOTT_Strike
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --期权行权
	  end;

    Function SOTT_Expire
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '4'; --期权到期注销
	  end;

    Function SOTT_Cover
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '5'; --备兑标的不足调整
	  end;

    Function SOTT_Hedge
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '6'; --仓位对冲
	  end;

    --SOptTransferType:期权过户类型 --<<

    --SSpotTransferType:证券过户类型 -->>
    Function SPTT_Trade
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'A'; --交易过户
	  end;

    Function SPTT_NonTrade
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'B'; --非交易过户
	  end;

    Function SPTT_StockFrozen
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'C'; --证券冻结
	  end;

    Function SPTT_StockUnfreeze
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'D'; --证券解冻
	  end;

    Function SPTT_LossTransfer
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'E'; --挂失转户
	  end;

    Function SPTT_SharesTrust
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'F'; --股份托管
	  end;

    Function SPTT_ListedInCircul
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'G'; --上市流通
	  end;

    Function SPTT_ShortSell
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'H'; --卖空
	  end;

    Function SPTT_RestrSecurSold
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'I'; --受限证券卖出
	  end;

    Function SPTT_RegisterRights
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'J'; --权益登记
	  end;

    Function SPTT_EquityListing
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'K'; --权益挂牌/权益划付
	  end;

    Function SPTT_Delist
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'L'; --摘牌
	  end;

    Function SPTT_PledgedBondsStore
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'M'; --质押券出入库
	  end;

    Function SPTT_Deposit
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'N'; --托管/解托管
	  end;

    Function SPTT_DividendReplace
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'O'; --红利补领
	  end;

    Function SPTT_Backwash
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'P'; --回冲
	  end;

    Function SPTT_RatioAdjustment
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'Q'; --比率调整
	  end;

    Function SPTT_TransactionChange
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'R'; --交易联通变更
	  end;

    Function SPTT_TreasuryBondsIssue
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'S'; --国债发行
	  end;

    Function SPTT_Others
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'T'; --其它
	  end;

    Function SPTT_DesignatedTrading
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'U'; --指定交易/撤消指定交易
	  end;

    Function SPTT_RemainPaid
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'V'; --权益补划付
	  end;

    Function SPTT_RationedSharesApp
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'W'; --配股申领
	  end;

    Function SPTT_Transfer
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'X'; --账户转户
	  end;

    Function SPTT_Debt2eEuitySwap
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'Y'; --债转股
	  end;

    Function SPTT_HandAdjust
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'Z'; --手工调整
	  end;

    Function SPTT_DelayInDelivery
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --延迟交付/完成交付
	  end;

    Function SPTT_RestoreDelivery
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --恢复交收
	  end;

    Function SPTT_Handle
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --处置/返还
	  end;

    Function SPTT_AuthorityTravel
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --权证行权
	  end;

    Function SPTT_AuthorityCancel
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '4'; --权证注销
	  end;

    Function SPTT_BuyoutDeal
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '5'; --约定/买断交易
	  end;

    Function SPTT_BuyoutRepoTransfer
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '6'; --买断式回购过户
	  end;

    Function SPTT_ETFPurchaseRedemp
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '7'; --ETF/货币基金申购和赎回
	  end;

    Function SPTT_PledgeTransfer
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '8'; --质押转移
	  end;

    Function SPTT_warrantCreate
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '9'; --权证创设
	  end;

    Function SPTT_MoneyFundInctrans
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'a'; --货币基金收益结转
	  end;

    Function SPTT_RefinanceInTrans
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'b'; --转融通融入类过户
	  end;

    Function SPTT_RefinanceOutTrans
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'c'; --转融通融出类过户
	  end;

    Function SPTT_RefinInRetuTrans
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'd'; --转融通融出归还类过户
	  end;

    Function SPTT_RefinOutRetuTrans
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'e'; --转融通融入归还类过户
	  end;

    Function SPTT_RefinWrongTrans
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'f'; --转融通错误划调账申报
	  end;

    Function SPTT_RefinSourceTrans
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'g'; --转融通券源划转
	  end;

    Function SPTT_RefinGuaraSubmit
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'h'; --转融通担保证券提交
	  end;

    Function SPTT_RefinGuaraDraw
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'i'; --转融通担保证券提取
	  end;

    Function SPTT_RefinDisposalTrans
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'j'; --转融通处置担保证券划出
	  end;

    Function SPTT_RefinUseTrans
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'k'; --转融通临时使用担保证券划出
	  end;

    Function SPTT_RefinRemainIn
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'l'; --转融通临时使用担保证券划入
	  end;

    Function SPTT_RefineReaminOut
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'm'; --转融通临时使用担保证券权益补偿归还
	  end;

    Function SPTT_GoldETFAppRedemp
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'n'; --黄金ETF实物申赎
	  end;

    Function SPTT_LOFHeadInitChange
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'o'; --LOF 总部发起变动（认购、申购、赎回、转托管等）
	  end;

    Function SPTT_SplitMerge
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'p'; --LOF 拆分合并
	  end;

    Function SPTT_StockRatioChange
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'q'; --证券品种比例变更（用于LOF折算等业务）
	  end;

    Function SPTT_PreRelsCashSettle
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'r'; --预发行现金结算
	  end;

    Function SPTT_PreRelsStockDeliver
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 's'; --预发行证券交收
	  end;

    Function SPTT_PreRelsInitRegister
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 't'; --预发行初始额度注册
	  end;

    Function SPTT_PreRelsInitUnregis
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'u'; --预发行初始额度注销
	  end;

    Function SPTT_TreasBondFutDeliver
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'v'; --国债期货实物交割
	  end;

    Function SPTT_CapBondAppRedemp
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'w'; --资券通申购赎回
	  end;

    Function SPTT_SHSpecialApplica
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'x'; --上海特殊申购业务
	  end;

    Function SPTT_NonPubPreferShareTrans
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'y'; --非公开发行优先股转让
	  end;

    --SSpotTransferType:证券过户类型 --<<

    --SOptSettleLogo:期权清算标志 -->>
    Function SOSL_QB1
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --期权交易清算
	  end;

    Function SOSL_QB2
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --期权行权清算
	  end;

    Function SOSL_QB3
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --期权行权过户费
	  end;

    Function SOSL_QH1
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'a'; --期权个人账户开户费
	  end;

    Function SOSL_QH2
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'b'; --期权机构账户开户费
	  end;

    --SOptSettleLogo:期权清算标志 --<<

    --STKSpotCommRateType:证券费用类型 -->>
    Function SSCRT_TransferFee
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --过户费
	  end;

    Function SSCRT_Stamptax
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --印花税
	  end;

    Function SSCRT_Brokerage
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --经手费
	  end;

    Function SSCRT_Secfee
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '4'; --证管费
	  end;

    Function SSCRT_Commission
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '5'; --手续费
	  end;

    --STKSpotCommRateType:证券费用类型 --<<

    --STKOptCommRateType:个股期权费用类型 -->>
    Function SOCRT_OpenFee
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --经手费
	  end;

    Function SOCRT_CloseFee
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --过户费
	  end;

    Function SOCRT_CloseTodayFee
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --结算费
	  end;

    Function SOCRT_StrikeFee
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --行权结算费
	  end;

    --STKOptCommRateType:个股期权费用类型 --<<

    --InsUpdateType:合约版本 -->>
    Function IUT_NEW
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --新挂合约
	  end;

    --InsUpdateType:合约版本 --<<

    --CreationredemptionStatus:基金当天申购赎回状态 -->>
    Function CDS_Forbidden
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --不允许申购赎回
	  end;

    Function CDS_Allow
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --表示允许申购和赎回
	  end;

    Function CDS_OnlyPurchase
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --允许申购、不允许赎回
	  end;

    Function CDS_OnlyRedeem
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --不允许申购、允许赎回
	  end;

    --CreationredemptionStatus:基金当天申购赎回状态 --<<

    --ETFCurrenceReplaceStatus:ETF现金替代标志 -->>
    Function ETFCRS_Forbidden
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --禁止现金替代
	  end;

    Function ETFCRS_Allow
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --可以现金替代
	  end;

    Function ETFCRS_Force
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --必须现金替代
	  end;

    --ETFCurrenceReplaceStatus:ETF现金替代标志 --<<

    --STKClass:合约类型 -->>
    Function STKC_Opt
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --期权
	  end;

    Function STKC_Spot
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --现券
	  end;

    --STKClass:合约类型 --<<

    --SOptBusinessCategory:期权业务类型 -->>
    Function SOBC_Q01
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --期权交易
	  end;

    Function SOBC_Q02
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --期权行权
	  end;

    Function SOBC_Q07
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '7'; --备兑期权标的证券锁定
	  end;

    Function SOBC_Q10
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'a'; --期权账户开户
	  end;

    Function SOBC_Q91
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'b'; --期权行权处置申报
	  end;

    Function SOBC_Q92
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'c'; --期权处置申报返还
	  end;

    Function SOBC_QH1
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'A'; --期权合约账户开通注销
	  end;

    --SOptBusinessCategory:期权业务类型 --<<

    --StrikeDirection:执行方向 -->>
    Function SSD_Strik
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --行权方
	  end;

    Function SSD_Striked
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --被行权方
	  end;

    --StrikeDirection:执行方向 --<<

    --SecurityType:证券类型 -->>
    Function SCTT_EBS
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --ETF
	  end;

    Function SCTT_ASH
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --A股
	  end;

    --SecurityType:证券类型 --<<

    --CSRCInvestorType:投资者类型 -->>
    Function CSRCT_Person
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --自然人
	  end;

    Function CSRCT_Company
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --法人
	  end;

    Function CSRCT_SpecialOrgan
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --特殊法人
	  end;

    Function CSRCT_SingerFuAsset
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --单一客户纯期货资产管理计划
	  end;

    Function CSRCT_SingerSpAsset
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '4'; --单一客户综合类资产管理计划
	  end;

    Function CSRCT_MultipleFuAsset
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '5'; --特定多个客户纯期货资产管理计划
	  end;

    Function CSRCT_MultipleSpAsset
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '6'; --特定多个客户综合类资产管理计划
	  end;

    Function CSRCT_Other
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '9'; --其他
	  end;

    --CSRCInvestorType:投资者类型 --<<

    --CsdcApplyStatus:申请状态 -->>
    Function CAS_NotSend
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --未发送
	  end;

    Function CAS_Sent
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --已发送
	  end;

    Function CAS_Responsed
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --已应答
	  end;

    Function CAS_Cancelled
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '4'; --已撤销
	  end;

    --CsdcApplyStatus:申请状态 --<<

    --DailyNoticeType:每日通知类型 -->>
    Function DNT_NA
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --未定义
	  end;

    Function DNT_InstAdj
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --5日内合约调整
	  end;

    Function DNT_InstExpire
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --5日内合约到期
	  end;

    Function DNT_ExecAssigned
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --指派行权
	  end;

    Function DNT_CoveredComple
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '4'; --备兑持仓标的数量补足
	  end;

    --DailyNoticeType:每日通知类型 --<<

    --LevelType:投资者分级类型 -->>
    Function IVLV_FirstLevel
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --一级投资者
	  end;

    Function IVLV_SecondLevel
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --二级投资者
	  end;

    Function IVLV_ThirdLevel
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --三级投资者
	  end;

    --LevelType:投资者分级类型 --<<

    --STKOptCommDirection:个股期权费用方向 -->>
    Function SOCD_OpenFee
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --开仓
	  end;

    Function SOCD_CloseFee
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --平仓
	  end;

    Function SOCD_CloseTodayFee
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --平今仓
	  end;

    Function SOCD_StrikeFee
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --行权
	  end;

    Function SOCD_TransferFee
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '4'; --履约
	  end;

    --STKOptCommDirection:个股期权费用方向 --<<

    --ExchangeOpenParamID:交易所开户参数代码 -->>
    Function EOPI_MinPrepa
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '6'; --开户最低可用金额
	  end;

    --ExchangeOpenParamID:交易所开户参数代码 --<<

    --IsStrongPasswordEnum:强密码校验组合数 -->>
    Function ISPE_0
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --字符类型无限制
	  end;

    Function ISPE_1
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --字符类型至少1种
	  end;

    Function ISPE_2
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --字符类型至少2种
	  end;

    Function ISPE_3
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --字符类型至少3种
	  end;

    Function ISPE_4
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '4'; --字符类型至少4种
	  end;

    --IsStrongPasswordEnum:强密码校验组合数 --<<

    --currentStatus:申请状态 -->>
    Function CS_Entry
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --已录入
	  end;

    Function CS_Approve
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --已审核
	  end;

    Function CS_Refuse
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --已拒绝
	  end;

    --currentStatus:申请状态 --<<

    --SwapFundType:款项类型 -->>
    Function SFT_DeliveryDepositOut
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --交割定金支出
	  end;

    Function SFT_DeliveryProfit
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --交割盈亏
	  end;

    Function SFT_WareHousing
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --仓储费
	  end;

    --SwapFundType:款项类型 --<<

    --CffexComType:组合类型 -->>
    Function CCOMT_FuS
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --同合约对锁组合
	  end;

    Function CCOMT_FCS
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --跨期套利组合
	  end;

    Function CCOMT_BuC
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --牛市看涨组合
	  end;

    Function CCOMT_BeC
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --熊市看涨组合
	  end;

    Function CCOMT_BuP
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '4'; --牛市看跌组合
	  end;

    Function CCOMT_BeP
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '5'; --熊市看跌组合
	  end;

    Function CCOMT_StS
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '6'; --勒式及跨式组合
	  end;

    Function CCOMT_InS
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '7'; --同月份跨品种组合
	  end;

    Function CCOMT_ICS
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '8'; --不同月份跨品种组合
	  end;

    Function CCOMT_CoC
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '9'; --备兑组合
	  end;

    Function CCOMT_SSC
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'A'; --合成看涨期权组合
	  end;

    Function CCOMT_OCS
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'B'; --时间价差组合
	  end;

    --CffexComType:组合类型 --<<

    --QuestionType2:题目类型 -->>
    Function QT_Single_Choice
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --单选题
	  end;

    Function QT_Multiple_Choices
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --多选题
	  end;

    Function QT_Min_Risk_Level
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '4'; --最低风险测试题
	  end;

    --QuestionType2:题目类型 --<<

    --CurrStatus:当前状态 -->>
    Function CUS_IsActive
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --有效
	  end;

    Function CUS_NonActive
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --失效
	  end;

    --CurrStatus:当前状态 --<<

    --UserAppType:用户App类型 -->>
    Function APP_TYPE_Investor
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --直连的投资者
	  end;

    Function APP_TYPE_InvestorRelay
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --为每个投资者都创建连接的中继
	  end;

    Function APP_TYPE_OperatorRelay
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --所有投资者共享一个操作员连接的中继
	  end;

    Function APP_TYPE_UnKnown
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '4'; --豁免模式
	  end;

    --UserAppType:用户App类型 --<<

    --IsInstrumentID:是否是合约 -->>
    Function IITT_Product
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --产品
	  end;

    Function IITT_InstrumentID
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --合约
	  end;

    Function IITT_CombInstrumentID
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --组合合约
	  end;

    --IsInstrumentID:是否是合约 --<<

    --SpecTRStrategyType:策略类型 -->>
    Function STRST_AccountLimit
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --账户限制
	  end;

    Function STRST_ExchangeLimit
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --交易所限制
	  end;

    Function STRST_CommodityOptionLimit
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --期权权限策略
	  end;

    Function STRST_CommodityFutureLimit
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --商品期货限制
	  end;

    Function STRST_FinancialFutureLimit
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '4'; --金融期货限制
	  end;

    Function STRST_InternationalProductLimi
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '5'; --国际化品种权限策略
	  end;

    Function STRST_ForeignClientLimit
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '6'; --境外客户限制
	  end;

    --SpecTRStrategyType:策略类型 --<<

    --MultiTRApplyAction:申请动作 -->>
    Function MTRAA_AddGeneral
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --新增普通交易权限
	  end;

    Function MTRAA_UpdGeneral
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --修改普通交易权限
	  end;

    Function MTRAA_DelGeneral
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --删除普通交易权限
	  end;

    Function MTRAA_CopyGeneral
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '4'; --复制普通交易权限
	  end;

    Function MTRAA_AddStrategy
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '5'; --新增特殊权限策略
	  end;

    Function MTRAA_UpdStrategy
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '6'; --修改特殊权限策略
	  end;

    Function MTRAA_DelStrategy
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '7'; --删除特殊权限策略
	  end;

    Function MTRAA_ApplyStrategy
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '8'; --特殊权限策略应用
	  end;

    Function MTRAA_BatchApply
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '9'; --批量应用/取消
	  end;

    --MultiTRApplyAction:申请动作 --<<

    --MultiTRApplyStatus:申请状态 -->>
    Function MTRAS_Submited
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --待审核
	  end;

    Function MTRAS_Passed
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --已通过
	  end;

    Function MTRAS_Refused
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --已拒绝
	  end;

    --MultiTRApplyStatus:申请状态 --<<

    --Systype:业务账户类型 -->>
    Function CLOUD_Future
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --期货经纪
	  end;

    Function CLOUD_Asset
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --资管
	  end;

    Function CLOUD_Appropriate
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --适当性
	  end;

    --Systype:业务账户类型 --<<

    --HasTrustee:是否有托管人 -->>
    Function HT_Yes
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --有
	  end;

    Function HT_No
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --没有
	  end;

    --HasTrustee:是否有托管人 --<<

    --InvstInfoChgSource:修改一般/身份信息数据来源 -->>
    Function IICS_Local
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --柜台
	  end;

    Function IICS_Cloud
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --云开户
	  end;

    Function IICS_CFMMC
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --监控中心网站
	  end;

    --InvstInfoChgSource:修改一般/身份信息数据来源 --<<

    --CloseTodayCommModel:平今手续费率计算模式 -->>
    Function CTCM_Follow
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --浮动设置
	  end;

    Function CTCM_Single
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --平今免收
	  end;

    Function CTCM_Double
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --平今高收
	  end;

    Function CTCM_Retain
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --留存不变
	  end;

    --CloseTodayCommModel:平今手续费率计算模式 --<<

    --DistributionType:资金分配基准 -->>
    Function STDT_Available
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --可用
	  end;

    Function STDT_Remain
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --权益
	  end;

    --DistributionType:资金分配基准 --<<

    --PGSettleStatus:产品和产品组结算状态 -->>
    Function PGSS_UnSettled
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --未结算
	  end;

    Function PGSS_RiskSettling
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --风险计算中
	  end;

    Function PGSS_FormalSettling
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --正式结算中
	  end;

    Function PGSS_RiskSettled
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --风险计算完成
	  end;

    Function PGSS_FormalSettled
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '4'; --正式结算完成
	  end;

    Function PGSS_Finished
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '5'; --结算确认
	  end;

    --PGSettleStatus:产品和产品组结算状态 --<<

    --FrozenType:资金冻结类型 -->>
    Function FZT_Judicial
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --司法冻结
	  end;

    Function FZT_Delivery
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '2'; --交割货款冻结
	  end;

    Function FZT_Transfer
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '3'; --仓单转让冻结
	  end;

    Function FZT_Storage
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '4'; --仓储费冻结
	  end;

    Function FZT_MortgageFee
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '5'; --质押手续费冻结
	  end;

    Function FZT_MortgageOut
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '6'; --仓单质出冻结
	  end;

    Function FZT_Quality
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '7'; --质检费冻结
	  end;

    Function FZT_RiskSettle
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '8'; --风险计算冻结
	  end;

    Function FZT_Others
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return 'z'; --其他冻结
	  end;

    --FrozenType:资金冻结类型 --<<

    --PGSettleMode:结算模式 -->>
    Function PGSM_RiskSettle
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '0'; --风险计算
	  end;

    Function PGSM_FormalSettle
	  Return varchar2 DETERMINISTIC
	  is
	  begin
	     return '1'; --正式结算
	  end;

    --PGSettleMode:结算模式 --<<


END PKGS_Enums;
/

