create TYPE BODY Ty_CopyInvstFutMarginRate IS

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_CopyInvstFutMarginRate RETURN SELF AS RESULT IS
  BEGIN
    RETURN;
  END;

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2 IS
    l_string VARCHAR2(4000);
  BEGIN
    l_string:='ty_CopyInvstFutMarginRate('
      || 'TradingDay=>' || '''' || trim(TradingDay) || '''' --交易日
      || ',BrokerID=>' || '''' || trim(BrokerID) || '''' --经纪公司代码
      || ',ExchangeID=>' || '''' || trim(ExchangeID) || '''' --交易所代码
      || ',InstrumentID=>' || '''' || trim(InstrumentID) || '''' --合约代码
      || ',SourceInvestorRange=>' || '''' || trim(SourceInvestorRange) || '''' --源投资者范围
      || ',SourceInvestorID=>' || '''' || trim(SourceInvestorID) || '''' --源投资者代码
      || ',SourceInvestUnitID=>' || '''' || trim(SourceInvestUnitID) || '''' --源投资单元代码
      || ',TargetInvestorRange=>' || '''' || trim(TargetInvestorRange) || '''' --目标投资者范围
      || ',TargetInvestorID=>' || '''' || trim(TargetInvestorID) || '''' --目标投资者代码
      || ',TargetInvestUnitID=>' || '''' || trim(TargetInvestUnitID) || '''' --目标投资单元代码
      || ',RatioAttr=>' || '''' || trim(RatioAttr) || '''' --费率属性
      || ')';


    RETURN l_string;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN NULL;
  END;



END;
/

