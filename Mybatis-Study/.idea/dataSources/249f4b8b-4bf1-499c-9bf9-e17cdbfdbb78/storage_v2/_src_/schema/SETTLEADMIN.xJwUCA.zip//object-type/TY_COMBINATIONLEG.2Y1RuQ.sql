create TYPE Ty_CombinationLeg AS OBJECT
(
    ExchangeID CHAR(8),  --交易所代码
    CombInstrumentID CHAR(80),  --组合合约代码
    LegID NUMBER(1),  --单腿编号
    LegInstrumentID CHAR(30),  --单腿合约代码
    Direction CHAR(1),  --买卖方向
    LegMultiple NUMBER(2),  --单腿乘数
    ImplyLevel NUMBER(2),  --派生层数
    Ratio NUMBER(19,8),  --保证金比率

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_CombinationLeg RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

