create TYPE BODY Ty_Answer IS

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_Answer RETURN SELF AS RESULT IS
  BEGIN
    RETURN;
  END;

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2 IS
    l_string VARCHAR2(4000);
  BEGIN
    l_string:='ty_Answer('
      || 'BrokerID=>' || '''' || trim(BrokerID) || '''' --经纪公司代码
      || ',QuestionID=>' || NVL(to_char(QuestionID),'NULL')--题目编号
      || ',OptionID=>' || '''' || trim(OptionID) || '''' --选项编号
      || ',Answer=>' || '''' || trim(Answer) || '''' --答案内容
      || ',Score=>' || NVL(to_char(Score),'NULL')--分数
      || ',IsRefferenceAnswer=>' || '''' || trim(IsRefferenceAnswer) || '''' --答案内容
      || ',OperatorID=>' || '''' || trim(OperatorID) || '''' --操作员
      || ',OperateDate=>' || '''' || trim(OperateDate) || '''' --操作时间
      || ')';


    RETURN l_string;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN NULL;
  END;



END;
/

