create TYPE Ty_CSRC_ExchangeDetails AS OBJECT
(
    TradingDay CHAR(10),  --交易日
    ParticipantID CHAR(10),  --会员代码
    InvestorID CHAR(12),  --客户内部资金账户
    ExchangeDate CHAR(10),  --汇兑日期
    SourceCurrencyID CHAR(3),  --源币种
    SourceDeposit NUMBER(15,3),  --源币种兑换金额
    TargetCurrencyID CHAR(3),  --目标币种
    TargetDeposit NUMBER(15,3),  --目标币种兑换金额
    ExchangeRate NUMBER(16,8),  --汇率
    TradingTime CHAR(8),  --交易时间
    CurrExchCertNo CHAR(12),  --记账流水号
    CurrExDirection CHAR(1),  --换汇方向
    SourceAccount CHAR(32),  --外币账号
    SourceAccountName CHAR(60),  --外币账户名称
    TargetAccount CHAR(32),  --本币账号
    TargetAccountName CHAR(60),  --本币账户名称
    BusinessType CHAR(2),  --换汇业务种类
    Memo CHAR(40),  --备注
    CSRCBankID CHAR(2),  --银行统一标识

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_CSRC_ExchangeDetails RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

