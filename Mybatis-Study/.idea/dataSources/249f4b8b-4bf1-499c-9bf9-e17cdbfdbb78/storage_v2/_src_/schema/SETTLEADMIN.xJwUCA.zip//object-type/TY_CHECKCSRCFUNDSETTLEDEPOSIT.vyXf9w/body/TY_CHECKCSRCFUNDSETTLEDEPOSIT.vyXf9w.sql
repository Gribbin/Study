create TYPE BODY Ty_CheckCSRCFundSettleDeposit IS

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_CheckCSRCFundSettleDeposit RETURN SELF AS RESULT IS
  BEGIN
    RETURN;
  END;

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2 IS
    l_string VARCHAR2(4000);
  BEGIN
    l_string:='ty_CheckCSRCFundSettleDeposit('
      || 'IsSame=>' || '''' || trim(IsSame) || '''' --是否相同
      || ',TradingDay=>' || '''' || trim(TradingDay) || '''' --交易日
      || ',InvestorID=>' || '''' || trim(InvestorID) || '''' --投资者编码
      || ',InvestorName=>' || '''' || trim(InvestorName) || '''' --投资者名称
      || ',CurrencyID=>' || '''' || trim(CurrencyID) || '''' --币种
      || ',deposit1=>' || NVL(to_char(deposit1),'NULL')--上报本日结存（逐日盯市）
      || ',depositbyvolume1=>' || NVL(to_char(depositbyvolume1),'NULL')--上报本日结存（逐笔对冲）
      || ',deposit2=>' || NVL(to_char(deposit2),'NULL')--结算本日结存（逐日盯市）
      || ',depositbyvolume2=>' || NVL(to_char(depositbyvolume2),'NULL')--结算本日结存（逐笔对冲）
      || ')';


    RETURN l_string;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN NULL;
  END;



END;
/

