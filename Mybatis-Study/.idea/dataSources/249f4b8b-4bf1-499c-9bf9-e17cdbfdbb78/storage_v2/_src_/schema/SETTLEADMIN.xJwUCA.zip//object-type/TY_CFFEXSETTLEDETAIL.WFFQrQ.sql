create TYPE Ty_CFFEXSettleDetail AS OBJECT
(
    TradingDay CHAR(8),  --交易日
    ExchangeID CHAR(8),  --交易所代码
    ParticipantID CHAR(10),  --会员代码
    NoSettlePartID CHAR(10),  --非结算会员号
    ClientID CHAR(10),  --客户编码
    ExchangeInstID CHAR(30),  --合约代码
    SettlementPrice NUMBER(19,10),  --结算价
    BuyOpenAmt NUMBER(20),  --买开成交量
    BuyCloseAmt NUMBER(20),  --买平成交量
    BuyAmtTotal NUMBER(20),  --买成交量合计
    SellOpenAmt NUMBER(20),  --卖开成交量
    SellCloseAmt NUMBER(20),  --卖平成交量
    SellAmtTotal NUMBER(20),  --卖成交量合计
    BuySum NUMBER(22,6),  --买入成交额
    SellSum NUMBER(22,6),  --卖出成交额
    BTotalAmt NUMBER(20),  --买持仓额合计
    STotalAmt NUMBER(20),  --卖持仓额合计
    Margin NUMBER(22,6),  --交易保证金
    Actual NUMBER(22,6),  --当日盈亏
    TransFee NUMBER(22,6),  --交易手续费
    OPTPremiumMoney NUMBER(22,6),  --权利金

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_CFFEXSettleDetail RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

