create TYPE Ty_AmlCheckNiSsTrade AS OBJECT
(
    TradingDay CHAR(8),  --交易日期
    FlowID CHAR(1),  --流程ID
    ApplyOperate CHAR(1),  --触发流程操作
    DataStatus CHAR(1),  --数据状态
    BrokerID CHAR(10),  --经纪公司代码
    CharacterID CHAR(4),  --可疑特征代码
    TouchDay CHAR(8),  --可疑交易发生日期
    DrawDay CHAR(8),  --检查日期
    DataSource VARCHAR2(5),  --数据来源
    FINC VARCHAR2(20),  --金融机构网点代码
    InvestorID CHAR(12),  --投资者代码
    CTNM VARCHAR2(30),  --客户姓名名称
    CITP VARCHAR2(10),  --客户身份证件/证明文件类型
    CTID VARCHAR2(50),  --客户身份证件/证明文件号码
    SCAC VARCHAR2(100),  --可疑主体期货账号
    FDAC VARCHAR2(100),  --资金账户号码
    STAC VARCHAR2(500),  --结算账户号码
    TSTM VARCHAR2(30),  --交易时间
    TICD VARCHAR2(50),  --业务标识号
    OCTT VARCHAR2(10),  --非柜台交易方式
    OOCT VARCHAR2(10),  --其他非柜台交易方式
    OCEC VARCHAR2(50),  --非柜台交易方式的设备代码
    TOTS VARCHAR2(20),  --交易种类
    CTNO VARCHAR2(50),  --合同编号
    SRNO VARCHAR2(50),  --流水号
    TTCD VARCHAR2(20),  --交易品种代码
    TRPR VARCHAR2(20),  --成交价格
    TVOL VARCHAR2(20),  --成交数量
    CRDR VARCHAR2(20),  --资金进出方向
    CSTP VARCHAR2(20),  --资金进出方式
    CRTP VARCHAR2(3),  --交易币种
    CRAT VARCHAR2(100),  --交易金额

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_AmlCheckNiSsTrade RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

