create TYPE Ty_BackDataSpecialTable AS OBJECT
(
    SpecialTableName VARCHAR2(50),  --表名
    SchemaName VARCHAR2(50),  --Shcema
    Status NUMBER(2),  --特殊备份类型
    KeyColumn VARCHAR2(50),  --特殊字段名
    OperationType VARCHAR2(50),  --流水号表中对应操作类型

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_BackDataSpecialTable RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

