create TYPE Ty_CSRC_Customer AS OBJECT
(
    TradingDay CHAR(10),  --交易日
    ParticipantID CHAR(10),  --会员代码
    InvestorName CHAR(200),  --客户名称
    IdentifiedCardNo CHAR(50),  --证件号码
    InvestorID CHAR(12),  --客户内部资金账户
    City CHAR(50),  --联系地址市
    Address CHAR(100),  --联系地址
    ZipCode CHAR(10),  --邮政编码
    TelePhone CHAR(40),  --联系电话
    CancelFlag VARCHAR2(1),  --开户和销户标志
    IsSettlement CHAR(1),  --是否为结算会员
    InvestorType CHAR(1),  --客户类型
    ActiveDate VARCHAR2(10),  --开户日期
    EID VARCHAR2(100),  --组织机构代码
    LicenseNo CHAR(50),  --营业执照
    OpenInvestorName CHAR(100),  --开户授权人名称
    OpenIdentifiedCardNO VARCHAR2(50),  --开户授权人证件号
    FreezeStatus CHAR(1),  --休眠状态
    ClientRegion CHAR(1),  --开户客户地域
    National CHAR(30),  --国籍
    Passport CHAR(50),  --港澳台及境外自然人有效证件号
    BusinessRegistration CHAR(50),  --商业登记证
    IsSeconderyAgent CHAR(1),  --是否为二级代理商
    CSRCSecAgentID CHAR(10),  --二级代理编号
    IsAssetmgrIns CHAR(1),  --是否为期货公司子公司
    STKAccountID CHAR(18),  --客户证券现货内部资金账户
    STKOpenDate CHAR(10),  --客户证券现货内部资金账户开户日期
    IsMarketMaker CHAR(1),  --是否为做市商
    OverseasInstitutionType CHAR(1),  --境外特殊参与者与境外中介机构标识

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_CSRC_Customer RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

