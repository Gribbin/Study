create TYPE BODY Ty_CFFEXCapital IS

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_CFFEXCapital RETURN SELF AS RESULT IS
  BEGIN
    RETURN;
  END;

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2 IS
    l_string VARCHAR2(4000);
  BEGIN
    l_string:='ty_CFFEXCapital('
      || 'TradingDay=>' || '''' || trim(TradingDay) || '''' --交易日
      || ',ExchangeID=>' || '''' || trim(ExchangeID) || '''' --交易所代码
      || ',ParticipantID=>' || '''' || trim(ParticipantID) || '''' --会员代码
      || ',LastDeposit=>' || NVL(to_char(LastDeposit),'NULL')--上一交易日人民币实有货币资金余额
      || ',FundIn=>' || NVL(to_char(FundIn),'NULL')--当日收入资金
      || ',Actual=>' || NVL(to_char(Actual),'NULL')--当日盈亏
      || ',FundOut=>' || NVL(to_char(FundOut),'NULL')--当日付出资金
      || ',Fee=>' || NVL(to_char(Fee),'NULL')--手续费
      || ',TransFee=>' || NVL(to_char(TransFee),'NULL')--交易手续费
      || ',SettlementFee=>' || NVL(to_char(SettlementFee),'NULL')--结算手续费
      || ',DelivFee=>' || NVL(to_char(DelivFee),'NULL')--交割手续费
      || ',TransposFee=>' || NVL(to_char(TransposFee),'NULL')--移仓手续费
      || ',Deposit=>' || NVL(to_char(Deposit),'NULL')--当日人民币资金余额
      || ',ForeCurrMortgage=>' || NVL(to_char(ForeCurrMortgage),'NULL')--当日外汇实际可用金额
      || ',Margin=>' || NVL(to_char(Margin),'NULL')--交易保证金
      || ',Remain=>' || NVL(to_char(Remain),'NULL')--结算准备金
      || ',Margin1=>' || NVL(to_char(Margin1),'NULL')--交易保证金1
      || ',CurrreMain=>' || NVL(to_char(CurrreMain),'NULL')--当日结算准备金余额
      || ',DeclareFundIn=>' || NVL(to_char(DeclareFundIn),'NULL')--申报划入金额
      || ',DeclareFundOut=>' || NVL(to_char(DeclareFundOut),'NULL')--申报划出金额
      || ',Prepa=>' || NVL(to_char(Prepa),'NULL')--下一交易日开仓准备金
      || ',PayFee=>' || NVL(to_char(PayFee),'NULL')--支付手续费
      || ',ActualFundChange=>' || NVL(to_char(ActualFundChange),'NULL')--人民币资金变动
      || ',MarginChange=>' || NVL(to_char(MarginChange),'NULL')--交易保证金变动
      || ',RemainChange=>' || NVL(to_char(RemainChange),'NULL')--结算准备金变动
      || ',DelivMargin=>' || NVL(to_char(DelivMargin),'NULL')--交割保证金
      || ',OPTPremiumMoney=>' || NVL(to_char(OPTPremiumMoney),'NULL')--权利金
      || ',Mortgage=>' || NVL(to_char(Mortgage),'NULL')--当日有价证券实际可用金额
      || ')';


    RETURN l_string;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN NULL;
  END;



END;
/

