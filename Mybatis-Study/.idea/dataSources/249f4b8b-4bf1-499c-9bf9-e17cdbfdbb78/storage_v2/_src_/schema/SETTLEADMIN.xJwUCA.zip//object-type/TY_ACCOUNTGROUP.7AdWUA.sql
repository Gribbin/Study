create TYPE Ty_AccountGroup AS OBJECT
(
    BrokerID CHAR(10),  --经纪公司代码
    AccountGroupID CHAR(12),  --资金账号分组代码
    AccountGroupName CHAR(40),  --资金账号分组名称

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_AccountGroup RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

