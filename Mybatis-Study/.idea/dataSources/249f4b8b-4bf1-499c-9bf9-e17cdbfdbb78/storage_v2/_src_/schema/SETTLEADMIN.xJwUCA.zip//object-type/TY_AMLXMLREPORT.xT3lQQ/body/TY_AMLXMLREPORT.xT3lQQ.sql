create TYPE BODY Ty_AMLXMLReport IS

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_AMLXMLReport RETURN SELF AS RESULT IS
  BEGIN
    RETURN;
  END;

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2 IS
    l_string VARCHAR2(4000);
  BEGIN
    l_string:='ty_AMLXMLReport('
      || 'BrokerID=>' || '''' || trim(BrokerID) || '''' --经纪公司代码
      || ',AMLGenSeqID=>' || NVL(to_char(AMLGenSeqID),'NULL')--文件生成事件序列号
      || ',XMLNumber=>' || NVL(to_char(XMLNumber),'NULL')--XML编号
      || ',InvestorID=>' || '''' || trim(InvestorID) || '''' --投资者代码
      || ')';


    RETURN l_string;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN NULL;
  END;



END;
/

