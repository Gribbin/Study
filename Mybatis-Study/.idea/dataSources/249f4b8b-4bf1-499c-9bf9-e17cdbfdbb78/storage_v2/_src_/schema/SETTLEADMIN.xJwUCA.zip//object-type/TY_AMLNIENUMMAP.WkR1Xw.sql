create TYPE Ty_AmlNiEnumMap AS OBJECT
(
    ReportType CHAR(2),  --大额或可疑
    EnumGroup VARCHAR2(50),  --字典集名称
    CtpValue VARCHAR2(50),  --CTP值
    CtpValueMemo VARCHAR2(100),  --CTP值备注
    AmlNiValue VARCHAR2(50),  --反洗钱新接口值
    AmlNiValueMemo VARCHAR2(100),  --反洗钱新接口值备注

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_AmlNiEnumMap RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

