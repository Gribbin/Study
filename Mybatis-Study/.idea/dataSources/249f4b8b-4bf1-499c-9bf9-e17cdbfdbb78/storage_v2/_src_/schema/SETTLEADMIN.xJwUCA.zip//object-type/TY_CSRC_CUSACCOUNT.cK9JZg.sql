create TYPE Ty_CSRC_CusAccount AS OBJECT
(
    TradingDay CHAR(10),  --交易日
    ParticipantID CHAR(10),  --会员代码
    InvestorID CHAR(12),  --客户内部资金账户
    BankFlag CHAR(2),  --银行统一标识
    BankAccount CHAR(40),  --银行账户
    CancelFlag CHAR(1),  --新增或变更标志
    OpenName CHAR(400),  --银行账户的开户人名称
    OpenBank CHAR(100),  --银行账户的开户行
    CurrencyID CHAR(3),  --币种
    CusAccountType CHAR(1),  --结算账户类型

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_CSRC_CusAccount RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

