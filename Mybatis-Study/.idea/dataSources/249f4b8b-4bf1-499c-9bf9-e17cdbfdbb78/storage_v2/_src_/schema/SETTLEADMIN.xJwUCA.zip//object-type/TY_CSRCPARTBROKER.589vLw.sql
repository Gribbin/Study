create TYPE Ty_CSRCPartBroker AS OBJECT
(
    BrokerID CHAR(10),  --经纪公司代码
    ParticipantID CHAR(10),  --会员代码
    Password CHAR(40),  --密码
    OrgSystem CHAR(1),  --原有系统代码
    UAPassword CHAR(40),  --统一开户密码
    UOAAutoSend CHAR(1),  --统一开户申请自动发送
    UOAInterval CHAR(8),  --自动发送间隔（分钟）
    SETTParticipantID CHAR(10),  --结算会员代码

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_CSRCPartBroker RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

