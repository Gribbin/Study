create TYPE Ty_CSRC_MortgageDetails AS OBJECT
(
    TradingDay CHAR(10),  --交易日
    ParticipantID CHAR(10),  --会员代码
    InvestorID CHAR(12),  --客户内部资金账户
    MortgageName CHAR(10),  --质押品名称
    Volume NUMBER(20),  --质押手数
    Price NUMBER(15,3),  --质押价格
    Deposite NUMBER(15,3),  --质押金
    CurrencyID CHAR(3),  --币种

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_CSRC_MortgageDetails RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

