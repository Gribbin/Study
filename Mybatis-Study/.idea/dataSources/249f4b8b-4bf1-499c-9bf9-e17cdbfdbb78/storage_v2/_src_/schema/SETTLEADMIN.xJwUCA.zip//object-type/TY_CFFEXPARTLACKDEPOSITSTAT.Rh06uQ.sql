create TYPE Ty_CFFEXPartLackDepositStat AS OBJECT
(
    TradingDay CHAR(8),  --交易日
    ExchangeID CHAR(8),  --交易所代码
    ParticipantID CHAR(10),  --会员代码
    AccountID CHAR(14),  --资金账号
    CurrencyID CHAR(3),  --资金账号币种
    StatStyle CHAR(160),  --强平统计类型
    ForceCloseReason CHAR(160),  --强平原因
    Remain NUMBER(22,6),  --结算准备金余额
    ForceCloseSum NUMBER(22,6),  --强平金额
    ForceClosedSum NUMBER(22,6),  --已强平金额
    TransferFlag CHAR(160),  --处理标志
    OperatorID CHAR(64),  --操作员
    OperationDate CHAR(8),  --操作日期
    OperationTime CHAR(8),  --操作时间

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_CFFEXPartLackDepositStat RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

