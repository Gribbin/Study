create TYPE Ty_AMLSHReportHis AS OBJECT
(
    TradingDay CHAR(8),  --交易日
    BrokerID CHAR(10),  --经纪公司代码
    GenerateDay CHAR(8),  --生成日期
    GenSequenceID NUMBER(8),  --当日生成批次编号
    ReportTypeID CHAR(2),  --交易报告类型标识
    ReportType CHAR(1),  --报文类型
    InvestorID CHAR(12),  --投资者代码
    TouchDay CHAR(8),  --大额交易发生日期
    CharacterID CHAR(4),  --大额交易特征代码
    DrawDay CHAR(8),  --检查日期
    AMLGenStatus CHAR(1),  --数据来源
    InvestorType CHAR(2),  --投资者类型
    InvestorName VARCHAR2(80),  --投资者名称
    IdentifiedCardType CHAR(2),  --证件类型
    IdentifiedCardNo CHAR(50),  --证件号码
    National CHAR(30),  --身份归属国家/地区

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_AMLSHReportHis RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

