create TYPE Ty_CopyInstrFutMarginRate AS OBJECT
(
    TradingDay CHAR(8),  --交易日
    BrokerID CHAR(10),  --经纪公司代码
    InvestorRange CHAR(1),  --投资者范围
    InvestorID CHAR(12),  --投资者代码
    InvestUnitID CHAR(16),  --投资单元代码
    SourceExchangeID CHAR(8),  --源交易所代码
    SourceInstrumentID CHAR(30),  --源合约代码
    TargetExchangeID CHAR(8),  --目标交易所代码
    TargetInstrumentID CHAR(30),  --目标合约代码
    RatioAttr CHAR(1),  --费率属性

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_CopyInstrFutMarginRate RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

