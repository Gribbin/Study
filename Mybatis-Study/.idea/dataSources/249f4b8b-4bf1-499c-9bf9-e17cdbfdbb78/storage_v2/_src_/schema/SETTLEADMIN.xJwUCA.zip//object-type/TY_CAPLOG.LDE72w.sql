create TYPE Ty_CAPLog AS OBJECT
(
    SequenceNo NUMBER(12),  --序号
    ErrorNo CHAR(8),  --处理状态
    ErrorInfo VARCHAR2(4000),  --处理结果
    MQTopic CHAR(30),  --MQ业务对象
    MQTag CHAR(80),  --MQ业务类型
    MQKey CHAR(32),  --MQ索引
    MQMsgID CHAR(64),  --MQ消息ID
    MQTotal CHAR(12),  --每个原子操作的消息总数
    MQIndex CHAR(12),  --单条消息编号
    MQProcessID CHAR(32),  --每个原子操作的操作序号
    Sender CHAR(3),  --MQ发送方
    BrokerID CHAR(10),  --经纪公司代码
    OperatorID CHAR(64),  --操作人代码
    OperateDate CHAR(8),  --操作日期
    OperateTime CHAR(8),  --操作时间

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_CAPLog RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

