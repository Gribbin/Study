create TYPE Ty_CAPAppTradCodeCondition AS OBJECT
(
    BrokerID CHAR(10),  --经纪公司代码
    InvestorID CHAR(12),  --投资者代码
    ExchangeID CHAR(8),  --交易所代码
    DateNum NUMBER(8),  --连续交易日天数
    MinPrepa CHAR(255),  --开户最低金额限制

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_CAPAppTradCodeCondition RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

