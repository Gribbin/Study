create TYPE Ty_CffexOptionStrike AS OBJECT
(
    TradingDay CHAR(8),  --交易日
    ExchangeID CHAR(8),  --交易所代码
    ParticipantID CHAR(10),  --会员代码
    ClientID CHAR(10),  --客户编码
    ExchangeInstID CHAR(30),  --合约代码
    DeliveryPrice NUMBER(19,10),  --交割结算价
    BuyNotCloseNum NUMBER(20),  --买未平仓量
    BuyCanStrikeNum NUMBER(20),  --买可执行量
    GiveUpStrikeNum NUMBER(20),  --申请放弃执行量
    BuyStrikeNum NUMBER(20),  --买执行量
    SellNotCloseNum NUMBER(20),  --卖未平仓量
    SellStrikeNum NUMBER(20),  --卖执行量
    OptStrikeProfit NUMBER(22,6),  --期权执行盈亏
    OptStrikeFee NUMBER(22,6),  --期权执行手续费

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_CffexOptionStrike RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

