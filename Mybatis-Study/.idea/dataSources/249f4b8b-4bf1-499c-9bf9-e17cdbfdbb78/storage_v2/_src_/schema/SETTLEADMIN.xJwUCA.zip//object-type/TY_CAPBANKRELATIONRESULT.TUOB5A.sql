create TYPE Ty_CAPBankRelationResult AS OBJECT
(
    BankBranch CHAR(100),  --银行账户的开户行
    BankID CHAR(3),  --银行代码
    BankNO CHAR(40),  --银行行号
    BankRelation NUMBER(1),  --解绑状态

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_CAPBankRelationResult RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

