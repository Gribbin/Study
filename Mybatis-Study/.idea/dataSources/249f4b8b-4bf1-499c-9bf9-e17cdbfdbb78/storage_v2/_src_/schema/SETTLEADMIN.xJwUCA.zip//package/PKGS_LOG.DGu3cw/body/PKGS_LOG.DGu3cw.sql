create PACKAGE BODY PKGS_Log IS

  /*************************************************************************
  $spDesc  设置本Session日志的公共属性(接口的进入时间,本Session的标识,客户终端,操作者ID)，一般只在接口开始处调用
  $param   i_chOperatorID 操作者ID
  $param   i_varSystemName 系统名称(当传入的字符超过48个字符时，只截取48个，放弃后面的字符)
  $param   i_varSPDesc     功能描述(当传入的字符超过32个字符时，只截取32个，放弃后面的字符)
  $exception 不处理任何异常
  *************************************************************************/
  PROCEDURE up_SetEnv
  (
    i_chOperatorID  IN t_operationlog.operatorid%TYPE
   ,i_varSystemName IN VARCHAR2
   ,i_varSPDesc     IN VARCHAR2
  ) IS
  BEGIN
    --g_nStartTime        := dbms_utility.get_time;
    --g_varSessionID      := SYS_CONTEXT('USERENV', 'SESSIONID');
    --g_varInstanceName   := SYS_CONTEXT('USERENV', 'INSTANCE_NAME');
    --g_varClientIP       := SYS_CONTEXT('USERENV', 'IP_ADDRESS');
    g_chOperatorID      := i_chOperatorID;

    dbms_application_info.set_module(i_varSystemName, i_varSPDesc);
  EXCEPTION
    WHEN OTHERS THEN
      up_Error('PKGS_Log.SetEnv', '设置日志环境异常');
  END up_SetEnv;

  /*************************************************************************
  $spDesc  获取操作者ID
  $exception 不处理任何异常
  *************************************************************************/
  FUNCTION uf_GetOperatorID RETURN CHAR IS
  BEGIN
    RETURN g_chOperatorID;
  END uf_GetOperatorID;

  ---- 跟踪
  PROCEDURE Trace
  (
    i_OperatorID    IN PKGS_DataType.STY_OperatorID,                  ---- 操作员ID
    i_ProcessName   IN PKGS_DataType.STY_ProcessName,                 ---- 运行存储过程名称
    i_Memo          IN PKGS_DataType.STY_RETMSG                    ---- 记录信息
  )
  AS
  BEGIN
    IF S_Level = S_Trace THEN
      Log(S_Trace, i_OperatorID, i_ProcessName, i_Memo);
    END IF;
  END Trace;

  ---- 调试
  PROCEDURE Debug
  (
    i_OperatorID    IN PKGS_DataType.STY_OperatorID,                  ---- 操作员ID
    i_ProcessName   IN PKGS_DataType.STY_ProcessName,                 ---- 运行存储过程名称
    i_Memo          IN PKGS_DataType.STY_RETMSG                    ---- 记录信息
  )
  AS
  BEGIN
    IF S_Level = S_Trace OR
       S_Level = S_Debug THEN
      Log(S_Debug, i_OperatorID, i_ProcessName, i_Memo);
    END IF;
  END Debug;

  ---- 记录
  PROCEDURE Info
  (
    i_OperatorID    IN PKGS_DataType.STY_OperatorID,                  ---- 操作员ID
    i_ProcessName   IN PKGS_DataType.STY_ProcessName,                 ---- 运行存储过程名称
    i_Memo          IN PKGS_DataType.STY_RETMSG                    ---- 记录信息
  )
  AS
  BEGIN
    IF S_Level = S_Trace OR
       S_Level = S_Debug OR
       S_Level = S_Info THEN
      Log(S_Info, i_OperatorID, i_ProcessName, i_Memo);
    END IF;
  END Info;

  ---- 警告
  PROCEDURE Warn
  (
    i_OperatorID    IN PKGS_DataType.STY_OperatorID,                  ---- 操作员ID
    i_ProcessName   IN PKGS_DataType.STY_ProcessName,                 ---- 运行存储过程名称
    i_Memo          IN PKGS_DataType.STY_RETMSG                    ---- 记录信息
  )
  AS
  BEGIN
    IF S_Level = S_Trace OR
       S_Level = S_Debug OR
       S_Level = S_Info  OR
       S_Level = S_Warning THEN
      Log(S_Warning, i_OperatorID, i_ProcessName, i_Memo);
    END IF;
  END Warn;

  ---- 错误
  PROCEDURE Error
  (
    i_OperatorID    IN PKGS_DataType.STY_OperatorID,                  ---- 操作员ID
    i_ProcessName   IN PKGS_DataType.STY_ProcessName,                 ---- 运行存储过程名称
    i_Memo          IN PKGS_DataType.STY_RETMSG                    ---- 记录信息
  )
  AS
  	l_Memo	PKGS_DataType.STY_RETMSG;
  BEGIN
    IF S_Level = S_Trace   OR
       S_Level = S_Debug   OR
       S_Level = S_Info    OR
       S_Level = S_Warning OR
       S_Level = S_Error THEN
      IF SQLCODE<>0 THEN
      	l_Memo:=SUBSTR(i_Memo||'::'||SQLERRM||'::'||DBMS_Utility.FORMAT_ERROR_BACKTRACE(),1,4000);
      ELSE
      	l_Memo:=i_Memo;
      END IF
      ;
      Log(S_Error, i_OperatorID, i_ProcessName, l_Memo);
    END IF;
  END Error;

  ---- 致命
  PROCEDURE Fatal
  (
    i_OperatorID    IN PKGS_DataType.STY_OperatorID,                  ---- 操作员ID
    i_ProcessName   IN PKGS_DataType.STY_ProcessName,                 ---- 运行存储过程名称
    i_Memo          IN PKGS_DataType.STY_RETMSG                    ---- 记录信息
  )
  AS
  	l_Memo PKGS_DataType.STY_RETMSG;
  BEGIN
    IF SQLCODE<>0 THEN
    	l_Memo:=SUBSTR(i_Memo||'::'||SQLERRM||'::'||DBMS_Utility.FORMAT_ERROR_BACKTRACE(),1,4000);
    ELSE
    	l_Memo:=TRIM(SQLERRM) || TRIM(i_Memo);
    END IF
    ;
    Log(S_Fatal, i_OperatorID, i_ProcessName, l_Memo);
  END Fatal;

  ---- 跟踪
  PROCEDURE up_Trace(
                  i_ProcessName   IN PKGS_DataType.STY_ProcessName,   ---- 运行存储过程名称
                  i_Memo          IN PKGS_DataType.STY_RETMSG      ---- 记录信息
                 )
  AS
  BEGIN
    Trace(g_chOperatorID, i_ProcessName, i_Memo);
  END up_Trace;

  ---- 调试
  PROCEDURE up_Debug(
                  i_ProcessName   IN PKGS_DataType.STY_ProcessName,   ---- 运行存储过程名称
                  i_Memo          IN PKGS_DataType.STY_RETMSG      ---- 记录信息
                 )
  AS
  BEGIN
    Debug(g_chOperatorID, i_ProcessName, i_Memo);
  END up_Debug;

  ---- 记录
  PROCEDURE up_Info(
                  i_ProcessName   IN PKGS_DataType.STY_ProcessName,   ---- 运行存储过程名称
                  i_Memo          IN PKGS_DataType.STY_RETMSG      ---- 记录信息
                 )
  AS
  BEGIN
    Info(g_chOperatorID, i_ProcessName, i_Memo);
  END up_Info;

  ---- 警告
  PROCEDURE up_Warning(
                  i_ProcessName   IN PKGS_DataType.STY_ProcessName,   ---- 运行存储过程名称
                  i_Memo          IN PKGS_DataType.STY_RETMSG      ---- 记录信息
                 )
  AS
  BEGIN
    Warn(g_chOperatorID, i_ProcessName, i_Memo);
  END up_Warning;

  ---- 错误
  PROCEDURE up_Error(
                  i_ProcessName   IN PKGS_DataType.STY_ProcessName,   ---- 运行存储过程名称
                  i_Memo          IN PKGS_DataType.STY_RETMSG      ---- 记录信息
                 )
  AS
  BEGIN
    Error(g_chOperatorID, i_ProcessName, i_Memo);
  END up_Error;

  ---- 致命
  PROCEDURE up_Fatal(
                  i_ProcessName   IN PKGS_DataType.STY_ProcessName,   ---- 运行存储过程名称
                  i_Memo          IN PKGS_DataType.STY_RETMSG      ---- 记录信息
                 )
  AS
  BEGIN
    Fatal(g_chOperatorID, i_ProcessName, i_Memo);
  END up_Fatal;

  ---- 日志记录主存储过程
  PROCEDURE Log
  (
    i_LogLevel      IN PKGS_DataType.STY_LogLevel,                    ---- 日志级别
    i_OperatorID    IN PKGS_DataType.STY_OperatorID,                  ---- 操作员ID
    i_ProcessName   IN PKGS_DataType.STY_ProcessName,                 ---- 运行存储过程名称
    i_Memo          IN PKGS_DataType.STY_RETMSG                    ---- 记录信息
  )
  AS PRAGMA AUTONOMOUS_TRANSACTION;
  	l_TradingDay      PKGS_DataType.STY_Date;                             ---- 10位
    l_Memo            t_Operationlog.Operationmemo%TYPE;
  BEGIN
    ---- 设置日期
    --TODO:建议日志表去掉tradingday字段
    l_TradingDay:=TO_CHAR(SYSDATE, 'YYYYMMDD');


    INSERT INTO t_Operationlog
    (TradingDay,SequenceNo,BrokerID,LogLevel,ProcessName,OperationMemo,OperatorID,OperationDate,OperationTime)
    VALUES
    (
     l_TradingDay,--TO_CHAR(SYSDATE, 'YYYYMMDD'),
     seq_OpertionLog.NEXTVAL,
     SUBSTR(i_OperatorID, 1, INSTR(i_OperatorID, '.') - 1),
     i_LogLevel,
     i_ProcessName,
     i_Memo,
     SUBSTR(i_OperatorID, INSTR(i_OperatorID, '.') + 1),
     TO_CHAR(SYSDATE, 'YYYYMMDD'),
     TO_CHAR(SYSDATE, 'HH24:MI:SS')
    );
    COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
        --ROLLBACK;
    BEGIN
    l_Memo:=SUBSTR('发生异常:'||SUBSTR(SQLERRM,1,100)||
    							'.i_OperatorID['||trim(i_OperatorID)||
                  '],i_Memo['||trim(i_Memo)||
                  '],i_ProcessName['||trim(i_ProcessName)||
                   '].',1,4000);
    INSERT INTO t_Operationlog
    (TradingDay,SequenceNo,BrokerID,LogLevel,ProcessName,OperationMemo,OperatorID,OperationDate,OperationTime)
    VALUES
    (
     l_TradingDay,--TO_CHAR(SYSDATE, 'YYYYMMDD'),
     seq_OpertionLog.NEXTVAL,
     '0000',
     S_Fatal,
     'PKGS_Log.Log',
     l_Memo,
     'SYS',
     TO_CHAR(SYSDATE, 'YYYYMMDD'),
     TO_CHAR(SYSDATE, 'HH24:MI:SS')
    );
    COMMIT;
    EXCEPTION
     WHEN OTHERS THEN ROLLBACK;
    END
    ;
  END Log;

  /*************************************************************************
  $spDesc  向【业务操作日志表】表中插入指定的单条记录
  $param   i_tyEventLog  包含插入记录信息的对象
  $param   o_nRetCode   SP执行返回代码
  $param   o_varRetMsg  SP执行返回信息
  $exception 捕捉所有异常，以返回值(o_nRetCode, o_varRegMsg)方式返回给调用
  *************************************************************************/
  PROCEDURE up_InsEventLog(
                          i_tyEventLog  IN ty_EventLog
                         ,o_nRetCode    OUT PKGS_DataType.STY_RetCode
                         ,o_varRetMsg   OUT PKGS_DataType.STY_RetMsg
                          )
  AS
  	l_Tradingday     PKGS_DATATYPE.STY_DATE;
    l_varLogic  PKGS_DataType.STY_LOGIC;
  BEGIN
    o_nRetCode := PKGS_Constants.C_RET_SUCCESS;
    l_varLogic := '获取当前交易日期';

    ---- 获取当前交易日期
    pkgs_common.up_GetSysTradingDay(pkgs_constants.DEFAULT_EXCHANGE ,pkgs_log.g_chOperatorID ,l_TradingDay ,o_nRetCode ,o_varRetMsg);
    IF o_nRetCode <> PKGS_Constants.C_RET_SUCCESS THEN
      PKGS_Log.up_Error('PKGS_Log.up_InsEventLog', l_varLogic || '失败:' || o_varRetMsg );
    RETURN;
  	END IF;

    INSERT INTO T_EventLog (
       Tradingday
      ,Sequenceno
      ,Brokerid
      ,Eventtype
      ,Eventmode
      ,Investorrange
      ,Investorid
      ,InvestUnitID
      ,Operationmemo
      ,Operatorid
      ,OPERATEDATE
      ,OPERATETIME
    )
    VALUES (
       l_Tradingday
      ,seq_eventlog.nextval
      ,i_tyEventLog.BrokerID
      ,i_tyEventLog.EventType
      ,i_tyEventLog.EventMode
      ,i_tyEventLog.InvestorRange
      ,i_tyEventLog.InvestorID
      ,i_tyEventLog.InvestUnitID
      ,i_tyEventLog.OperationMemo
      ,PKGS_Log.g_chOperatorID
      ,TO_CHAR(SYSDATE, 'YYYYMMDD')
      ,TO_CHAR(SYSDATE, 'HH24:MI:SS')
    );
    o_varRetMsg := '增加【业务操作日志】记录成功';
  EXCEPTION
    WHEN OTHERS THEN
      o_nRetCode  := PKGS_Constants.C_RET_FAIL;
      o_varRetMsg := SUBSTR('增加【业务操作日志】记录失败'||SQLERRM||'::'||DBMS_Utility.FORMAT_ERROR_BACKTRACE(),1,4000);
      PKGS_Log.up_Error('PKGS_Log.up_InsEventLog',o_varRetMsg);
  END up_InsEventLog;

  /*************************************************************************
  $spDesc  将临时表数据落地
  --注：传入的临时表必须为会话型临时表，且本sp会隐式提交事务，仅用于被查询类sp调用
  *************************************************************************/
  PROCEDURE up_DumpTempTable(
                          i_chTableName  IN PKGS_DataType.STY_TableName
                          )
  AS
  BEGIN
    IF S_Level = S_Trace OR
       S_Level = S_Debug THEN
    	BEGIN
    	 EXECUTE IMMEDIATE 'DROP TABLE '||i_chTableName||'_';
    	EXCEPTION
    		WHEN OTHERS THEN NULL;--忽略异常
    	END;

    	BEGIN
    	  EXECUTE IMMEDIATE 'CREATE TABLE '||i_chTableName||'_ AS SELECT * FROM '||i_chTableName;
    	EXCEPTION
    		WHEN OTHERS THEN
    			up_Error('PKGS_Log.up_DumpTempTable','将临时表数据落地异常.'||dbms_utility.format_error_backtrace);
    	END;
    END IF;--IF S_Level = S_Trace OR S_Level = S_Debug

  END up_DumpTempTable;
   /*************************************************************************
  $spDesc  向【资金管理操作日志】表中插入指定的单条记录
  *************************************************************************/
  PROCEDURE up_InsFundEventLog(
                          i_tyFundEventLog  IN OUT ty_FundEventLog
                         ,o_nRetCode    OUT PKGS_DataType.STY_RetCode
                         ,o_varRetMsg   OUT PKGS_DataType.STY_RetMsg
                          )
   AS
      l_Tradingday     PKGS_DATATYPE.STY_DATE;
      l_varLogic       PKGS_DataType.STY_LOGIC;
      l_UserID         PKGS_DataType.STY_UserID;
      l_varSPName      t_Operationlog.ProcessName%TYPE := 'PKGS_Log.up_InsFundEventLog';

    BEGIN
      o_nRetCode := PKGS_Constants.C_RET_SUCCESS;
      l_varLogic := '获取当前交易日期';

      ---- 获取当前交易日期
      pkgs_common.up_GetSysTradingDay(pkgs_constants.DEFAULT_EXCHANGE ,pkgs_log.g_chOperatorID ,l_TradingDay ,o_nRetCode ,o_varRetMsg);
      IF o_nRetCode <> PKGS_Constants.C_RET_SUCCESS THEN
        PKGS_Log.up_Error(l_varSPName, l_varLogic || '失败:' || o_varRetMsg );
      RETURN;
      END IF;
      ---- 获取序列号
      SELECT SEQ_FUNDEVENTLOG.NEXTVAL
      INTO i_tyFundEventLog.SEQUENCENO
      FROM dual;
       ---- 获取userID
      pkgs_common.up_GetUserID(o_nRetCode,o_varRetMsg ,l_UserID, PKGS_log.g_chOperatorID);
      IF o_nRetCode <> PKGS_Constants.C_RET_SUCCESS THEN
          o_varRetMsg := '获取操作员代码失败';
          RETURN;
      END IF;
      i_tyFundEventLog.OperatorID   :=  l_UserID;
      i_tyFundEventLog.OPDATE  :=  TO_CHAR(SYSDATE, 'YYYYMMDD') ;
      i_tyFundEventLog.OPTIME  :=  TO_CHAR(SYSDATE, 'HH24:MI:SS');

      INSERT INTO t_FundEventLog (
        TRADINGDAY,
        SEQUENCENO,
        BROKERID,
        EVENTTYPE,
        EVENTMODE,
        INVESTORRANGE,
        INVESTORID,
        INVESTUNITID,
        ACCOUNTID,
        CURRENCYID,
        OPERATIONMEMO,
        OPERATORID,
        OPDATE,
        OPTIME
      )
      VALUES (
        l_TradingDay,
        i_tyFundEventLog.SEQUENCENO,
        i_tyFundEventLog.BROKERID,
        i_tyFundEventLog.EVENTTYPE,
        i_tyFundEventLog.EVENTMODE,
        i_tyFundEventLog.INVESTORRANGE,
        i_tyFundEventLog.INVESTORID,
        i_tyFundEventLog.INVESTUNITID,
        i_tyFundEventLog.ACCOUNTID,
        i_tyFundEventLog.CURRENCYID,
        i_tyFundEventLog.OPERATIONMEMO,
        i_tyFundEventLog.OPERATORID,
        i_tyFundEventLog.OPDATE,
        i_tyFundEventLog.OPTIME
      );
      o_varRetMsg := '增加【资金管理操作日志】记录成功';
      EXCEPTION
        WHEN DUP_VAL_ON_INDEX THEN -- 主键冲突
          o_nRetCode := PKGS_Constants.E_USER_ERROR;
          o_varRetMsg := '指定的【资金管理操作日志】记录已存在';
          PKGS_Log.up_Error(l_varSPName, o_varRetMsg || '::' || DBMS_Utility.FORMAT_ERROR_BACKTRACE());

        WHEN OTHERS THEN
          o_varRetMsg := '增加【资金管理操作日志】记录失败';
          PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);

    END up_InsFundEventLog;

END PKGS_Log;
/

