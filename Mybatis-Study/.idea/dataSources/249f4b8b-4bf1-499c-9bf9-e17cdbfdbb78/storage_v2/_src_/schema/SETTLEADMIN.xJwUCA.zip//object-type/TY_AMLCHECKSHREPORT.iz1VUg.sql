create TYPE Ty_AMLCheckSHReport AS OBJECT
(
    TradingDay CHAR(8),  --交易日
    BrokerID CHAR(10),  --经纪公司代码
    ApplyNo NUMBER(8),  --流水号
    FlowID CHAR(1),  --流程ID
    DrawDay CHAR(8),  --检查日期
    ApplyOperate CHAR(1),  --触发流程操作
    AMLCheckStatus CHAR(1),  --审核状态
    InvestorID CHAR(12),  --投资者代码
    TouchDay CHAR(8),  --大额交易发生日期
    CharacterID CHAR(4),  --交易特征代码
    AMLGenStatus CHAR(1),  --数据来源
    InvestorType CHAR(2),  --投资者类型
    InvestorName VARCHAR2(80),  --投资者名称
    IdentifiedCardType CHAR(2),  --证件类型
    IdentifiedCardNo CHAR(50),  --证件号码
    National CHAR(30),  --身份归属国家/地区

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_AMLCheckSHReport RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

