create TYPE Ty_BrokerUserFunction AS OBJECT
(
    BrokerID CHAR(10),  --经纪公司代码
    UserID CHAR(15),  --用户代码
    BrokerFunctionCode CHAR(256),  --经纪公司功能代码

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_BrokerUserFunction RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

