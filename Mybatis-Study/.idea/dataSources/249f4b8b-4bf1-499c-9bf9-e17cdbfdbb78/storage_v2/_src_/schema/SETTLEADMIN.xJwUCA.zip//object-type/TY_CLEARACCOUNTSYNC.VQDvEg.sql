create TYPE Ty_ClearAccountSync AS OBJECT
(
    BrokerID CHAR(10),  --经纪公司代码
    BankID CHAR(3),  --银行代码
    ClearAccount CHAR(40),  --结算账户
    OpenName CHAR(60),  --结算账户名称
    CurrencyCode CHAR(3),  --结算币别
    IsMainClearAccount NUMBER(1),  --是否主账户
    Memo CHAR(160),  --备注

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_ClearAccountSync RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

