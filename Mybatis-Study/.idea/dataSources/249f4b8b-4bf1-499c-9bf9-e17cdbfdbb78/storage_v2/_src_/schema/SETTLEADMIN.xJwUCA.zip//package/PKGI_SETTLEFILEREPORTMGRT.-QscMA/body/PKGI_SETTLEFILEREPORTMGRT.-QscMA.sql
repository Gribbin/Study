create PACKAGE BODY PKGI_SettleFileReportMgrt  IS
  /*************************************************************************
  $spDesc 查询投资者持仓数据
  *************************************************************************/
  PROCEDURE up_QuerySettleFileHoldata
  (
     i_tyQuerySettlementFile IN TY_QUERYSETTLEMENTFILE  --查询条件
    ,i_tyPage IN  TY_PAGE  --分页信息
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_curHoldata OUT NOCOPY PKGS_DATATYPE.TYPEREFCURSOR  --查询结果游标
    ,o_nCount OUT PKGS_DATATYPE.STY_COUNT  --记录数
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_SettleFileReportMgrt.up_QuerySettleFileHoldata';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '查询投资者持仓数据';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '基金公司结算单生成', '查询投资者持仓数据');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_SettleFileReportMgrt.up_QuerySettleFileHoldata(' ||
                           i_tyQuerySettlementFile.uf_toString()
                      || ',' ||
                           i_tyPage.uf_toString()
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_curHoldata'
                      || ',' ||
                        'o_nCount'
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_SettleFileReportMgrt.up_QuerySettleFileHoldata(
                               i_tyQuerySettlementFile
                              ,i_tyPage
                              ,i_chLanguage
                              ,o_curHoldata
                              ,o_nCount
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_QuerySettleFileHoldata;

  /*************************************************************************
  $spDesc 查询虚投资者成交数据
  *************************************************************************/
  PROCEDURE up_QuerySettleFileTrddata
  (
     i_tyQuerySettlementFile IN TY_QUERYSETTLEMENTFILE  --查询条件
    ,i_tyPage IN  TY_PAGE  --分页信息
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_curTrdData OUT NOCOPY PKGS_DATATYPE.TYPEREFCURSOR  --查询结果游标
    ,o_nCount OUT PKGS_DATATYPE.STY_COUNT  --记录数
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_SettleFileReportMgrt.up_QuerySettleFileTrddata';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '查询虚投资者成交数据';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '基金公司结算单生成', '查询虚投资者成交数据');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_SettleFileReportMgrt.up_QuerySettleFileTrddata(' ||
                           i_tyQuerySettlementFile.uf_toString()
                      || ',' ||
                           i_tyPage.uf_toString()
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_curTrdData'
                      || ',' ||
                        'o_nCount'
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_SettleFileReportMgrt.up_QuerySettleFileTrddata(
                               i_tyQuerySettlementFile
                              ,i_tyPage
                              ,i_chLanguage
                              ,o_curTrdData
                              ,o_nCount
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_QuerySettleFileTrddata;

  /*************************************************************************
  $spDesc 查询投资者平仓数据
  *************************************************************************/
  PROCEDURE up_QuerySettleFileLiquid
  (
     i_tyQuerySettlementFile IN TY_QUERYSETTLEMENTFILE  --查询条件
    ,i_tyPage IN  TY_PAGE  --分页信息
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_curLiquid OUT NOCOPY PKGS_DATATYPE.TYPEREFCURSOR  --查询结果游标
    ,o_nCount OUT PKGS_DATATYPE.STY_COUNT  --记录数
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_SettleFileReportMgrt.up_QuerySettleFileLiquid';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '查询投资者平仓数据';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '基金公司结算单生成', '查询投资者平仓数据');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_SettleFileReportMgrt.up_QuerySettleFileLiquid(' ||
                           i_tyQuerySettlementFile.uf_toString()
                      || ',' ||
                           i_tyPage.uf_toString()
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_curLiquid'
                      || ',' ||
                        'o_nCount'
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_SettleFileReportMgrt.up_QuerySettleFileLiquid(
                               i_tyQuerySettlementFile
                              ,i_tyPage
                              ,i_chLanguage
                              ,o_curLiquid
                              ,o_nCount
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_QuerySettleFileLiquid;

  /*************************************************************************
  $spDesc 查询投资者持仓明细
  *************************************************************************/
  PROCEDURE up_QuerySettleFileHoldDetail
  (
     i_tyQuerySettlementFile IN TY_QUERYSETTLEMENTFILE  --查询条件
    ,i_tyPage IN  TY_PAGE  --分页信息
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_curHoldDetail OUT NOCOPY PKGS_DATATYPE.TYPEREFCURSOR  --查询结果游标
    ,o_nCount OUT PKGS_DATATYPE.STY_COUNT  --记录数
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_SettleFileReportMgrt.up_QuerySettleFileHoldDetail';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '查询投资者持仓明细';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '基金公司结算单生成', '查询投资者持仓明细');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_SettleFileReportMgrt.up_QuerySettleFileHoldDetail(' ||
                           i_tyQuerySettlementFile.uf_toString()
                      || ',' ||
                           i_tyPage.uf_toString()
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_curHoldDetail'
                      || ',' ||
                        'o_nCount'
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_SettleFileReportMgrt.up_QuerySettleFileHoldDetail(
                               i_tyQuerySettlementFile
                              ,i_tyPage
                              ,i_chLanguage
                              ,o_curHoldDetail
                              ,o_nCount
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_QuerySettleFileHoldDetail;

  /*************************************************************************
  $spDesc 查询投资者基本资金数据文件
  *************************************************************************/
  PROCEDURE up_QuerySettleFileFund
  (
     i_tyQuerySettlementFile IN TY_QUERYSETTLEMENTFILE  --查询条件
    ,i_tyPage IN  TY_PAGE  --分页信息
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_curFund OUT NOCOPY PKGS_DATATYPE.TYPEREFCURSOR  --查询结果游标
    ,o_nCount OUT PKGS_DATATYPE.STY_COUNT  --记录数
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_SettleFileReportMgrt.up_QuerySettleFileFund';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '查询投资者基本资金数据文件';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '基金公司结算单生成', '查询投资者基本资金数据文件');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_SettleFileReportMgrt.up_QuerySettleFileFund(' ||
                           i_tyQuerySettlementFile.uf_toString()
                      || ',' ||
                           i_tyPage.uf_toString()
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_curFund'
                      || ',' ||
                        'o_nCount'
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_SettleFileReportMgrt.up_QuerySettleFileFund(
                               i_tyQuerySettlementFile
                              ,i_tyPage
                              ,i_chLanguage
                              ,o_curFund
                              ,o_nCount
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_QuerySettleFileFund;

  /*************************************************************************
  $spDesc 查询投资者出入金记录文件
  *************************************************************************/
  PROCEDURE up_QuerySettleFileFundChg
  (
     i_tyQuerySettlementFile IN TY_QUERYSETTLEMENTFILE  --查询条件
    ,i_tyPage IN  TY_PAGE  --分页信息
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_curFundChg OUT NOCOPY PKGS_DATATYPE.TYPEREFCURSOR  --查询结果游标
    ,o_nCount OUT PKGS_DATATYPE.STY_COUNT  --记录数
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_SettleFileReportMgrt.up_QuerySettleFileFundChg';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '查询投资者出入金记录文件';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '基金公司结算单生成', '查询投资者出入金记录文件');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_SettleFileReportMgrt.up_QuerySettleFileFundChg(' ||
                           i_tyQuerySettlementFile.uf_toString()
                      || ',' ||
                           i_tyPage.uf_toString()
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_curFundChg'
                      || ',' ||
                        'o_nCount'
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_SettleFileReportMgrt.up_QuerySettleFileFundChg(
                               i_tyQuerySettlementFile
                              ,i_tyPage
                              ,i_chLanguage
                              ,o_curFundChg
                              ,o_nCount
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_QuerySettleFileFundChg;

  /*************************************************************************
  $spDesc 查询投资者交割明细文件
  *************************************************************************/
  PROCEDURE up_QuerySettleFileDelivDetail
  (
     i_tyQuerySettlementFile IN TY_QUERYSETTLEMENTFILE  --查询条件
    ,i_tyPage IN  TY_PAGE  --分页信息
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作者ID
    ,o_curDelivDetail OUT NOCOPY PKGS_DATATYPE.TYPEREFCURSOR  --查询结果游标
    ,o_nCount OUT PKGS_DATATYPE.STY_COUNT  --记录数
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_SettleFileReportMgrt.up_QuerySettleFileDelivDetail';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '查询投资者交割明细文件';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '基金公司结算单生成', '查询投资者交割明细文件');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_SettleFileReportMgrt.up_QuerySettleFileDelivDetail(' ||
                           i_tyQuerySettlementFile.uf_toString()
                      || ',' ||
                           i_tyPage.uf_toString()
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_curDelivDetail'
                      || ',' ||
                        'o_nCount'
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_SettleFileReportMgrt.up_QuerySettleFileDelivDetail(
                               i_tyQuerySettlementFile
                              ,i_tyPage
                              ,i_chLanguage
                              ,o_curDelivDetail
                              ,o_nCount
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_QuerySettleFileDelivDetail;

  /*************************************************************************
  $spDesc 查询基金公司结算文件需要下发的投资者
  *************************************************************************/
  PROCEDURE up_QrySettleFileInvestor
  (
     i_tySettleFileInvestor IN TY_SETTLEFILEINVESTOR  --查询条件
    ,i_tyPage IN TY_PAGE  --分页查询输入
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作源代码
    ,o_Cursor OUT NOCOPY PKGS_DATATYPE.TYPEREFCURSOR  --返回游标
    ,o_nPageCount OUT NOCOPY INT  --返回页码
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回码
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_SettleFileReportMgrt.up_QrySettleFileInvestor';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '查询基金公司结算文件需要下发的投资者';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '基金公司结算单生成', '查询基金公司结算文件需要下发的投资者');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_SettleFileReportMgrt.up_QrySettleFileInvestor(' ||
                           i_tySettleFileInvestor.uf_toString()
                      || ',' ||
                           i_tyPage.uf_toString()
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_Cursor'
                      || ',' ||
                        'o_nPageCount'
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_SettleFileReportMgrt.up_QrySettleFileInvestor(
                               i_tySettleFileInvestor
                              ,i_tyPage
                              ,i_chLanguage
                              ,o_Cursor
                              ,o_nPageCount
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_QrySettleFileInvestor;

  /*************************************************************************
  $spDesc 查询基金公司结算文件需要下发的投资者
  *************************************************************************/
  PROCEDURE up_QuerySettleFileInvestor
  (
     i_tyQuerySettleFileInvestor IN TY_QUERYSETTLEFILEINVESTOR  --查询条件
    ,i_tyPage IN TY_PAGE  --分页查询输入
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作源代码
    ,o_Cursor OUT NOCOPY PKGS_DATATYPE.TYPEREFCURSOR  --返回游标
    ,o_nPageCount OUT NOCOPY INT  --返回页码
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回码
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_SettleFileReportMgrt.up_QuerySettleFileInvestor';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '查询基金公司结算文件需要下发的投资者';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '基金公司结算单生成', '查询基金公司结算文件需要下发的投资者');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_SettleFileReportMgrt.up_QuerySettleFileInvestor(' ||
                           i_tyQuerySettleFileInvestor.uf_toString()
                      || ',' ||
                           i_tyPage.uf_toString()
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_Cursor'
                      || ',' ||
                        'o_nPageCount'
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_SettleFileReportMgrt.up_QuerySettleFileInvestor(
                               i_tyQuerySettleFileInvestor
                              ,i_tyPage
                              ,i_chLanguage
                              ,o_Cursor
                              ,o_nPageCount
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_QuerySettleFileInvestor;

  /*************************************************************************
  $spDesc 批量更新结算文件需要下发的投资者
  *************************************************************************/
  PROCEDURE up_UpdateSettleFileInvestors
  (
     i_tytSettleFileInvestor IN OUT NOCOPY TYT_SETTLEFILEINVESTOR  --更新条件
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作源代码
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回码
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_SettleFileReportMgrt.up_UpdateSettleFileInvestors';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '批量更新结算文件需要下发的投资者';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '基金公司结算单生成', '批量更新结算文件需要下发的投资者');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_SettleFileReportMgrt.up_UpdateSettleFileInvestors(' ||
                           PKGS_Tyt2STRING.uf_Tyt2String(i_tytSettleFileInvestor)
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_SettleFileReportMgrt.up_UpdateSettleFileInvestors(
                               i_tytSettleFileInvestor
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_UpdateSettleFileInvestors;

  /*************************************************************************
  $spDesc 批量更新文件生成状态
  *************************************************************************/
  PROCEDURE up_UpdateSettleFilesStatus
  (
     i_tytSettleFile IN OUT NOCOPY TYT_SETTLEFILE  --待更新文件
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作源代码
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回码
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_SettleFileReportMgrt.up_UpdateSettleFilesStatus';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '批量更新文件生成状态';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '基金公司结算单生成', '批量更新文件生成状态');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_SettleFileReportMgrt.up_UpdateSettleFilesStatus(' ||
                           PKGS_Tyt2STRING.uf_Tyt2String(i_tytSettleFile)
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_SettleFileReportMgrt.up_UpdateSettleFilesStatus(
                               i_tytSettleFile
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_UpdateSettleFilesStatus;

  /*************************************************************************
  $spDesc 查询基金公司结算文件生成状态
  *************************************************************************/
  PROCEDURE up_QrySettleFile
  (
     i_tySettleFile IN TY_SETTLEFILE  --查询条件
    ,i_tyPage IN TY_PAGE  --分页查询输入
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作源代码
    ,o_Cursor OUT NOCOPY PKGS_DATATYPE.TYPEREFCURSOR  --返回游标
    ,o_nPageCount OUT NOCOPY INT  --返回页码
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回码
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_SettleFileReportMgrt.up_QrySettleFile';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '查询基金公司结算文件生成状态';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '基金公司结算单生成', '查询基金公司结算文件生成状态');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_SettleFileReportMgrt.up_QrySettleFile(' ||
                           i_tySettleFile.uf_toString()
                      || ',' ||
                           i_tyPage.uf_toString()
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_Cursor'
                      || ',' ||
                        'o_nPageCount'
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_SettleFileReportMgrt.up_QrySettleFile(
                               i_tySettleFile
                              ,i_tyPage
                              ,i_chLanguage
                              ,o_Cursor
                              ,o_nPageCount
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_QrySettleFile;

  /*************************************************************************
  $spDesc 批量增加文件生成状态
  *************************************************************************/
  PROCEDURE up_InsSettleFiles
  (
     i_tytSettleFile IN OUT NOCOPY TYT_SETTLEFILE  --待增加文件
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作源代码
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回码
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
    ,i_chCommit IN PKGS_DATATYPE.STY_COMMIT_FLAG DEFAULT '1'  --1:接口提交事务，0:接口不提交事务
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_SettleFileReportMgrt.up_InsSettleFiles';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '批量增加文件生成状态';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '基金公司结算单生成', '批量增加文件生成状态');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_SettleFileReportMgrt.up_InsSettleFiles(' ||
                           PKGS_Tyt2STRING.uf_Tyt2String(i_tytSettleFile)
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                      || ',' ||
                           '''' || trim(i_chCommit) || ''''
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_SettleFileReportMgrt.up_InsSettleFiles(
                               i_tytSettleFile
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_InsSettleFiles;

  /*************************************************************************
  $spDesc 结算前预计算行权手续费
  *************************************************************************/
  PROCEDURE up_PreCalStrikeFee
  (
     i_tytQryPreCalStrikeFee IN TYT_QRYPRECALSTRIKEFEE  --查询条件
    ,i_chFunctionCode IN  PKGS_DATATYPE.STY_FUNCTIONCODE  --功能编码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作员代码
    ,o_ResultCursor OUT NOCOPY PKGS_DATATYPE.TYPEREFCURSOR  --返回结果游标
    ,o_ErrCursor OUT NOCOPY PKGS_DATATYPE.TYPEREFCURSOR  --返回错误游标
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回码
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_SettleFileReportMgrt.up_PreCalStrikeFee';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '结算前预计算行权手续费';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '基金公司结算单生成', '结算前预计算行权手续费');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_SettleFileReportMgrt.up_PreCalStrikeFee(' ||
                           PKGS_Tyt2STRINGEx.uf_Tyt2String(i_tytQryPreCalStrikeFee)
                      || ',' ||
                           '''' || trim(i_chFunctionCode) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_ResultCursor'
                      || ',' ||
                        'o_ErrCursor'
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_SettleFileReportMgrt.up_PreCalStrikeFee(
                               i_tytQryPreCalStrikeFee
                              ,i_chFunctionCode
                              ,i_chLanguage
                              ,o_ResultCursor
                              ,o_ErrCursor
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_PreCalStrikeFee;

END PKGI_SettleFileReportMgrt;
/

