create TYPE Ty_AMLGenFileLog AS OBJECT
(
    BrokerID CHAR(10),  --经纪公司代码
    GenerateDay CHAR(8),  --生成日期
    GenSequenceID NUMBER(8),  --当日生成批次编号
    ReportTypeID CHAR(2),  --报告类型
    ReportType CHAR(1),  --报文类型
    AMLGenSeqID NUMBER(8),  --文件生成事件序列号
    ReportName CHAR(80),  --报文名称
    BeginDay CHAR(8),  --检查日期
    EndDay CHAR(8),  --结束检查日期
    ZipAmount NUMBER(4),  --压缩的数据包数量
    Description VARCHAR2(400),  --描述
    OperatorID CHAR(64),  --录入员代码
    OperateDate CHAR(8),  --录入日期
    OperateTime CHAR(8),  --录入时间

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_AMLGenFileLog RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

