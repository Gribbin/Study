create TYPE Ty_CSRC_DelivDetails AS OBJECT
(
    TradingDay CHAR(10),  --交易日
    ParticipantID CHAR(10),  --会员代码
    InvestorID CHAR(12),  --客户内部资金账户
    ExchangeInstID CHAR(30),  --品种合约
    Direction CHAR(1),  --买卖标志
    Price NUMBER(15,3),  --成交均价
    Turnover NUMBER(15,3),  --成交金额
    DelivSettlementPrice NUMBER(15,3),  --交割结算价
    DelivDeposit NUMBER(15,3),  --交割货款
    DelivVolume NUMBER(20),  --交割手数
    DelivFee NUMBER(15,3),  --交割手续费
    DelivProfit NUMBER(15,3),  --交割盈亏
    ClientID CHAR(10),  --交易编码
    CurrencyID CHAR(3),  --币种

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_CSRC_DelivDetails RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

