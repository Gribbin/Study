create TYPE Ty_CAPAmTransferAccount AS OBJECT
(
    BrokerID CHAR(10),  --经纪公司代码
    AccountID CHAR(14),  --投资者账号
    BankFlag CHAR(3),  --银行统一标识类型
    BankAccount CHAR(40),  --银行账户
    OpenName VARCHAR2(100),  --银行账户的开户人名称
    OpenBank CHAR(100),  --银行账户的开户行
    IsActive NUMBER(1),  --是否活跃
    CurrencyID CHAR(3),  --币种

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_CAPAmTransferAccount RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

