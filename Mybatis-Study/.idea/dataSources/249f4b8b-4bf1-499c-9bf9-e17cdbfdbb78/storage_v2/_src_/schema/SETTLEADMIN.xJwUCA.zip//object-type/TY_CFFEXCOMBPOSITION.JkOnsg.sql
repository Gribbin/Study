create TYPE Ty_CffexCombPosition AS OBJECT
(
    TradingDay CHAR(8),  --交易日
    BrokerID CHAR(10),  --经纪公司代码
    ExchangeID CHAR(8),  --交易所代码
    PartID CHAR(12),  --交易会员号
    ClientID CHAR(12),  --客户号
    ComInstrid CHAR(20),  --合约组号
    InstrID CHAR(30),  --合约
    Direction CHAR(10),  --合约买卖方向
    Position CHAR(20),  --合约持仓
    BfrCommarg CHAR(20),  --组合前保证金
    AftCommarg CHAR(20),  --组合后保证金

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_CffexCombPosition RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

