create TYPE Ty_BillFormat AS OBJECT
(
    BrokerID CHAR(10),  --经纪公司代码
    NoteType CHAR(1),  --通知类型
    BeginSentence VARCHAR2(4000),  --开始语句
    EndSentence VARCHAR2(4000),  --结束语句
    LanguageType CHAR(1),  --通知语言类型

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_BillFormat RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

