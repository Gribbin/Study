create TYPE Ty_CRALevelDistribute AS OBJECT
(
    RiskLevel NUMBER(8),  --风险等级
    LevelDesc VARCHAR2(120),  --等级名称
    LevelDisNumber NUMBER(20),  --风险等级客户人数

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_CRALevelDistribute RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

