create TYPE BODY Ty_AMLCheckSHTrade IS

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_AMLCheckSHTrade RETURN SELF AS RESULT IS
  BEGIN
    RETURN;
  END;

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2 IS
    l_string VARCHAR2(4000);
  BEGIN
    l_string:='ty_AMLCheckSHTrade('
      || 'TradingDay=>' || '''' || trim(TradingDay) || '''' --交易日
      || ',BrokerID=>' || '''' || trim(BrokerID) || '''' --经纪公司代码
      || ',FlowID=>' || '''' || trim(FlowID) || '''' --流程ID
      || ',AMLSHTradeID=>' || NVL(to_char(AMLSHTradeID),'NULL')--反洗钱大额交易序列号
      || ',DrawDay=>' || '''' || trim(DrawDay) || '''' --检查日期
      || ',DepositSeqNo=>' || '''' || trim(DepositSeqNo) || '''' --业务标示号
      || ',ApplyOperate=>' || '''' || trim(ApplyOperate) || '''' --触发流程操作
      || ',DataStatus=>' || '''' || trim(DataStatus) || '''' --数据状态
      || ',InvestorID=>' || '''' || trim(InvestorID) || '''' --投资者代码
      || ',TouchDay=>' || '''' || trim(TouchDay) || '''' --大额交易发生日期
      || ',CharacterID=>' || '''' || trim(CharacterID) || '''' --大额交易特征代码
      || ',AMLGenStatus=>' || '''' || trim(AMLGenStatus) || '''' --数据来源
      || ',DeputyName=>' || '''' || trim(DeputyName) || '''' --交易代办人姓名
      || ',DeputyCardType=>' || '''' || trim(DeputyCardType) || '''' --代办人身份证件类型
      || ',DeputyCardNo=>' || '''' || trim(DeputyCardNo) || '''' --交易代办人身份证件号码
      || ',DeputyNational=>' || '''' || trim(DeputyNational) || '''' --代办人身份归属国家/地区
      || ',TradingTime=>' || '''' || trim(TradingTime) || '''' --交易时间
      || ',TradingType=>' || '''' || trim(TradingType) || '''' --交易方式
      || ',TransactClass=>' || '''' || trim(TransactClass) || '''' --涉外收支交易分类与代码
      || ',CapitalIO=>' || '''' || trim(CapitalIO) || '''' --资金收付标识
      || ',TradingDestination=>' || '''' || trim(TradingDestination) || '''' --交易去向
      || ',TradingScene=>' || '''' || trim(TradingScene) || '''' --交易发生地
      || ',CapitalPurpose=>' || '''' || trim(CapitalPurpose) || '''' --资金用途
      || ',CapitalCurrency=>' || '''' || trim(CapitalCurrency) || '''' --币种
      || ',TradeVolume=>' || NVL(to_char(TradeVolume),'NULL')--交易金额
      || ',OtherInstitutionName=>' || '''' || trim(OtherInstitutionName) || '''' --对方金融机构网点名称
      || ',OtherInstitutionType=>' || '''' || trim(OtherInstitutionType) || '''' --对方金融机构代码类型
      || ',OtherInstitutionID=>' || '''' || trim(OtherInstitutionID) || '''' --对方金融机构网点代码
      || ',OtherUserName=>' || '''' || trim(OtherUserName) || '''' --交易对手姓名
      || ',OtherCustomerCardType=>' || '''' || trim(OtherCustomerCardType) || '''' --交易对手证件类型
      || ',OtherIdentifiedCardNo=>' || '''' || trim(OtherIdentifiedCardNo) || '''' --交易对手证件号码
      || ',OtherAccountType=>' || '''' || trim(OtherAccountType) || '''' --交易对手账号类型
      || ',OtherFutureAccount=>' || '''' || trim(OtherFutureAccount) || '''' --交易对手账号
      || ')';


    RETURN l_string;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN NULL;
  END;



END;
/

