create TYPE Ty_CheckSettleInvestor AS OBJECT
(
    BrokerID CHAR(10),  --经纪公司代码
    ExchangeID CHAR(8),  --交易所代码
    InvestorRange CHAR(1),  --投资者范围
    InvestorID CHAR(12),  --投资者代码
    BeginDate CHAR(8),  --开始日期
    EndDate CHAR(8),  --结束日期
    InstrumentID CHAR(30),  --合约代码
    HasSameData NUMBER(1),  --是否相同数据

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_CheckSettleInvestor RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

