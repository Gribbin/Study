create TYPE BODY Ty_AmlNiShReport IS

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_AmlNiShReport RETURN SELF AS RESULT IS
  BEGIN
    RETURN;
  END;

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2 IS
    l_string VARCHAR2(4000);
  BEGIN
    l_string:='ty_AmlNiShReport('
      || 'BrokerID=>' || '''' || trim(BrokerID) || '''' --经纪公司代码
      || ',ReportSeqNo=>' || '''' || trim(ReportSeqNo) || '''' --报告序号
      || ',Action=>' || '''' || trim(Action) || '''' --报告类别：新增，修改，删除
      || ',ReportName=>' || '''' || trim(ReportName) || '''' --报告文件名称
      || ',FilePath=>' || '''' || trim(FilePath) || '''' --报告文件存放路径
      || ',RICD=>' || '''' || trim(RICD) || '''' --报告机构编码
      || ',CTTN=>' || '''' || trim(CTTN) || '''' --大额交易客户总数
      || ',GenDate=>' || '''' || trim(GenDate) || '''' --生成日期
      || ',AttachFileOne=>' || '''' || trim(AttachFileOne) || '''' --附件
      || ',AttachFileTwo=>' || '''' || trim(AttachFileTwo) || '''' --附件
      || ',AttachFileThree=>' || '''' || trim(AttachFileThree) || '''' --附件
      || ',AttachFileFour=>' || '''' || trim(AttachFileFour) || '''' --附件
      || ',AttachFileFive=>' || '''' || trim(AttachFileFive) || '''' --附件
      || ',AttachFileSix=>' || '''' || trim(AttachFileSix) || '''' --附件
      || ',AttachFileSeven=>' || '''' || trim(AttachFileSeven) || '''' --附件
      || ',AttachFileEight=>' || '''' || trim(AttachFileEight) || '''' --附件
      || ')';


    RETURN l_string;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN NULL;
  END;



END;
/

