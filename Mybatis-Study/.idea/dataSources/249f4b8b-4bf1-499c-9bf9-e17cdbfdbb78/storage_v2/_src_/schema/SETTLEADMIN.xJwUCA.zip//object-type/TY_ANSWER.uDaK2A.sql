create TYPE Ty_Answer AS OBJECT
(
    BrokerID CHAR(10),  --经纪公司代码
    QuestionID NUMBER(8),  --题目编号
    OptionID CHAR(4),  --选项编号
    Answer VARCHAR2(4000),  --答案内容
    Score NUMBER(3),  --分数
    IsRefferenceAnswer NUMBER(1),  --答案内容
    OperatorID CHAR(64),  --操作员
    OperateDate CHAR(8),  --操作时间

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_Answer RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

