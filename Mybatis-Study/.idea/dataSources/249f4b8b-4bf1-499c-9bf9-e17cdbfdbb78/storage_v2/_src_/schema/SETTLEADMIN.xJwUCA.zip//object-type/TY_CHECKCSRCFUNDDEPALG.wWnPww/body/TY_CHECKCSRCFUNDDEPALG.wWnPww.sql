create TYPE BODY Ty_CheckCSRCFundDepAlg IS

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_CheckCSRCFundDepAlg RETURN SELF AS RESULT IS
  BEGIN
    RETURN;
  END;

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2 IS
    l_string VARCHAR2(4000);
  BEGIN
    l_string:='ty_CheckCSRCFundDepAlg('
      || 'IsSame=>' || '''' || trim(IsSame) || '''' --是否相同
      || ',TradingDay=>' || '''' || trim(TradingDay) || '''' --交易日
      || ',InvestorID=>' || '''' || trim(InvestorID) || '''' --投资者编码
      || ',InvestorName=>' || '''' || trim(InvestorName) || '''' --投资者名称
      || ',CurrencyID=>' || '''' || trim(CurrencyID) || '''' --币种
      || ',diffvalue=>' || NVL(to_char(diffvalue),'NULL')--差值
      || ',deposit=>' || NVL(to_char(deposit),'NULL')--本日结存
      || ',lastdepositbydate=>' || NVL(to_char(lastdepositbydate),'NULL')--上日结存(逐日盯市)
      || ',fundio=>' || NVL(to_char(fundio),'NULL')--出入金
      || ',profit=>' || NVL(to_char(profit),'NULL')--当日盈亏
      || ',fee=>' || NVL(to_char(fee),'NULL')--手续费
      || ',mortgage=>' || NVL(to_char(mortgage),'NULL')--质押金
      || ',fundmortgage=>' || NVL(to_char(fundmortgage),'NULL')--货币质押金额
      || ',delivery=>' || NVL(to_char(delivery),'NULL')--交割货款
      || ',other=>' || NVL(to_char(other),'NULL')--其他分项资金
      || ',optpremiummoney=>' || NVL(to_char(optpremiummoney),'NULL')--权利金
      || ')';


    RETURN l_string;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN NULL;
  END;



END;
/

