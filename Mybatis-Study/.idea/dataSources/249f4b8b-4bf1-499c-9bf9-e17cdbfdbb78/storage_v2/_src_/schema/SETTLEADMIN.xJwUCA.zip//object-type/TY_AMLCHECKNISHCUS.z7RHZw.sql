create TYPE Ty_AmlCheckNiShCus AS OBJECT
(
    TradingDay CHAR(8),  --交易日期
    ApplyNo NUMBER(8),  --流水号
    FlowID CHAR(1),  --流程ID
    ApplyOperate CHAR(1),  --触发流程操作
    AMLCheckStatus CHAR(1),  --审核状态
    BrokerID CHAR(10),  --经纪公司代码
    InvestorID CHAR(12),  --投资者代码
    CharacterID CHAR(4),  --大额交易特征码
    TouchDay CHAR(8),  --交易发生日期
    DrawDay CHAR(8),  --检查日期
    DataSource VARCHAR2(5),  --数据来源
    InvestorName VARCHAR2(30),  --客户名称
    CTNT CHAR(3),  --客户国籍
    IdCardType VARCHAR2(10),  --证件类型
    IdCardNo VARCHAR2(50),  --证件号码
    CTVC VARCHAR2(50),  --客户职业（对私）或客户行业（对公）
    CCTL VARCHAR2(50),  --客户联系电话
    CTAR VARCHAR2(200),  --客户住址/经营地址
    CCEI VARCHAR2(200),  --客户其他联系方式

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_AmlCheckNiShCus RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

