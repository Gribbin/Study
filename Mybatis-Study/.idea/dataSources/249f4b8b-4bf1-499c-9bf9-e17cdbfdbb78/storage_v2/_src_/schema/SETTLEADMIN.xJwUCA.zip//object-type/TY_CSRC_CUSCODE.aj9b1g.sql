create TYPE Ty_CSRC_CusCode AS OBJECT
(
    TradingDay CHAR(10),  --交易日
    ParticipantID CHAR(10),  --会员代码
    InvestorID CHAR(12),  --客户内部资金账户
    ExchangeFlag CHAR(1),  --交易所统一标识
    ClientID CHAR(10),  --客户编码

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_CSRC_CusCode RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

