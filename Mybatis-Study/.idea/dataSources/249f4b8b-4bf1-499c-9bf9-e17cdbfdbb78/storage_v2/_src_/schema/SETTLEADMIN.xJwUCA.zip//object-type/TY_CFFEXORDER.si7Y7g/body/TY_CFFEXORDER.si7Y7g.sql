create TYPE BODY Ty_CFFEXOrder IS

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_CFFEXOrder RETURN SELF AS RESULT IS
  BEGIN
    RETURN;
  END;

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2 IS
    l_string VARCHAR2(4000);
  BEGIN
    l_string:='ty_CFFEXOrder('
      || 'TradingDay=>' || '''' || trim(TradingDay) || '''' --交易日
      || ',ExchangeID=>' || '''' || trim(ExchangeID) || '''' --交易所代码
      || ',ParticipantID=>' || '''' || trim(ParticipantID) || '''' --会员代码
      || ',TradePartID=>' || '''' || trim(TradePartID) || '''' --交易会员
      || ',ClientID=>' || '''' || trim(ClientID) || '''' --客户编码
      || ',OrderID=>' || '''' || trim(OrderID) || '''' --报单号
      || ',ExchangeInstID=>' || '''' || trim(ExchangeInstID) || '''' --合约代码
      || ',OffsetFlag=>' || '''' || trim(OffsetFlag) || '''' --开平标志
      || ',Direction=>' || '''' || trim(Direction) || '''' --买卖
      || ',OrderStatus=>' || '''' || trim(OrderStatus) || '''' --报单状态
      || ',Status=>' || '''' || trim(Status) || '''' --状态
      || ',Volume=>' || NVL(to_char(Volume),'NULL')--申报量
      || ',Price=>' || NVL(to_char(Price),'NULL')--申报价
      || ',VolumeTraded=>' || NVL(to_char(VolumeTraded),'NULL')--成交量
      || ',InsertTime=>' || '''' || trim(InsertTime) || '''' --申报时间
      || ',OrderSysID=>' || '''' || trim(OrderSysID) || '''' --系统编号
      || ',TraderID=>' || '''' || trim(TraderID) || '''' --席位号
      || ')';


    RETURN l_string;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN NULL;
  END;



END;
/

