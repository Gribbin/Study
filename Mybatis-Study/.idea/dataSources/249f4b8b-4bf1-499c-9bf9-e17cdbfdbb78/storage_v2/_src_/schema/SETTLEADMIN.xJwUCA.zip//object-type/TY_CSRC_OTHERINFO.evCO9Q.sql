create TYPE Ty_CSRC_OtherInfo AS OBJECT
(
    TradingDay CHAR(10),  --交易日
    ParticipantID CHAR(10),  --会员代码
    InvestorID CHAR(12),  --客户内部资金账户
    Reason CHAR(2),  --事由
    Description VARCHAR2(4000),  --描述
    IsSettlement CHAR(1),  --是否为非结算会员

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_CSRC_OtherInfo RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

