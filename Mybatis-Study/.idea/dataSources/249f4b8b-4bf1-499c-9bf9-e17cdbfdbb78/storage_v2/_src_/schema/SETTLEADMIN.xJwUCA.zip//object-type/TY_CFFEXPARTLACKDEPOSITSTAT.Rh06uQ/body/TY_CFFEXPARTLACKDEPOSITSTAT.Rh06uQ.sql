create TYPE BODY Ty_CFFEXPartLackDepositStat IS

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_CFFEXPartLackDepositStat RETURN SELF AS RESULT IS
  BEGIN
    RETURN;
  END;

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2 IS
    l_string VARCHAR2(4000);
  BEGIN
    l_string:='ty_CFFEXPartLackDepositStat('
      || 'TradingDay=>' || '''' || trim(TradingDay) || '''' --交易日
      || ',ExchangeID=>' || '''' || trim(ExchangeID) || '''' --交易所代码
      || ',ParticipantID=>' || '''' || trim(ParticipantID) || '''' --会员代码
      || ',AccountID=>' || '''' || trim(AccountID) || '''' --资金账号
      || ',CurrencyID=>' || '''' || trim(CurrencyID) || '''' --资金账号币种
      || ',StatStyle=>' || '''' || trim(StatStyle) || '''' --强平统计类型
      || ',ForceCloseReason=>' || '''' || trim(ForceCloseReason) || '''' --强平原因
      || ',Remain=>' || NVL(to_char(Remain),'NULL')--结算准备金余额
      || ',ForceCloseSum=>' || NVL(to_char(ForceCloseSum),'NULL')--强平金额
      || ',ForceClosedSum=>' || NVL(to_char(ForceClosedSum),'NULL')--已强平金额
      || ',TransferFlag=>' || '''' || trim(TransferFlag) || '''' --处理标志
      || ',OperatorID=>' || '''' || trim(OperatorID) || '''' --操作员
      || ',OperationDate=>' || '''' || trim(OperationDate) || '''' --操作日期
      || ',OperationTime=>' || '''' || trim(OperationTime) || '''' --操作时间
      || ')';


    RETURN l_string;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN NULL;
  END;



END;
/

