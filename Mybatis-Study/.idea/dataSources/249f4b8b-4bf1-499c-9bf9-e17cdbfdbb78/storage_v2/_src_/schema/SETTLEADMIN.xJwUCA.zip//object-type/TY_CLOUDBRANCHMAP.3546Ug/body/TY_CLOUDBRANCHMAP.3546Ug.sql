create TYPE BODY Ty_CloudBranchMap IS

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_CloudBranchMap RETURN SELF AS RESULT IS
  BEGIN
    RETURN;
  END;

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2 IS
    l_string VARCHAR2(4000);
  BEGIN
    l_string:='ty_CloudBranchMap('
      || 'BrokerID=>' || '''' || trim(BrokerID) || '''' --经纪公司代码
      || ',CloudBranchCode=>' || '''' || trim(CloudBranchCode) || '''' --云平台营业部代码
      || ',CloudBranch=>' || '''' || trim(CloudBranch) || '''' --云平台营业部名称
      || ',Referrer=>' || '''' || trim(Referrer) || '''' --推荐人
      || ',CFFEXBranchCode=>' || '''' || trim(CFFEXBranchCode) || '''' --中金所营业部代码
      || ',DepartmentID=>' || '''' || trim(DepartmentID) || '''' --组织架构
      || ',PropertyIDs=>' || '''' || trim(PropertyIDs) || '''' --属性
      || ')';


    RETURN l_string;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN NULL;
  END;



END;
/

