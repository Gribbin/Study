create TYPE Ty_AmlInvestorchange AS OBJECT
(
    BrokerID CHAR(10),  --经纪公司代码
    InvestorID CHAR(12),  --投资者代码
    AmlinvstchangeDate CHAR(8),  --变更发生日期
    AmlinvstchangeTime CHAR(8),  --变更发生时间
    AmlinvstchangeChkParamID CHAR(32),  --识别身份变更参数代码
    AmlInvstChangeoldvalue VARCHAR2(4000),  --变更前内容
    AmlInvstChangenewvalue VARCHAR2(4000),  --变更后内容
    AmlInvstChangeCheckMethod CHAR(1),  --变更识别方法
    CheckOperator CHAR(64),  --操作员代码
    CheckOperateDate CHAR(8),  --识别日期
    CheckOperateTime CHAR(8),  --识别时间
    Memo CHAR(160),  --备注

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_AmlInvestorchange RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

