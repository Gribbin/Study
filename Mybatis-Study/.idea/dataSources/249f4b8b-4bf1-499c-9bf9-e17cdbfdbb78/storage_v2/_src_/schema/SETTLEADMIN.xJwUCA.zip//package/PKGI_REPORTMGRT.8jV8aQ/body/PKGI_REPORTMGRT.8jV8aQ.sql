create PACKAGE BODY PKGI_ReportMgrt  IS
  /*************************************************************************
  $spDesc 查询资金持仓明细
  *************************************************************************/
  PROCEDURE up_QryInvestorTradeSummary
  (
     i_TyInvestorTradeSummary IN TY_INVESTORTRADESUMMARY  --查询资金持仓明细
    ,i_tyPage IN TY_PAGE  --分页查询输入
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作员代码
    ,o_curInvestorTradeSummary OUT NOCOPY PKGS_DATATYPE.TYPEREFCURSOR  --返回游标
    ,o_nCount OUT NOCOPY INT  --返回页码
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回码
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_ReportMgrt.up_QryInvestorTradeSummary';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '查询资金持仓明细';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '报表管理', '查询资金持仓明细');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_ReportMgrt.up_QryInvestorTradeSummary(' ||
                           i_TyInvestorTradeSummary.uf_toString()
                      || ',' ||
                           i_tyPage.uf_toString()
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_curInvestorTradeSummary'
                      || ',' ||
                        'o_nCount'
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_ReportMgrt.up_QryInvestorTradeSummary(
                               i_TyInvestorTradeSummary
                              ,i_tyPage
                              ,i_chLanguage
                              ,o_curInvestorTradeSummary
                              ,o_nCount
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_QryInvestorTradeSummary;

  /*************************************************************************
  $spDesc 客户风险状况表
  *************************************************************************/
  PROCEDURE up_QryInvestorRisk
  (
     i_TyInvestorRisk IN TY_INVESTORRISK  --客户风险状况表
    ,i_tyPage IN TY_PAGE  --分页查询输入
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作员代码
    ,o_curInvestorRisk OUT NOCOPY PKGS_DATATYPE.TYPEREFCURSOR  --返回游标
    ,o_nCount OUT NOCOPY INT  --返回页码
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回码
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_ReportMgrt.up_QryInvestorRisk';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '客户风险状况表';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '报表管理', '客户风险状况表');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_ReportMgrt.up_QryInvestorRisk(' ||
                           i_TyInvestorRisk.uf_toString()
                      || ',' ||
                           i_tyPage.uf_toString()
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_curInvestorRisk'
                      || ',' ||
                        'o_nCount'
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_ReportMgrt.up_QryInvestorRisk(
                               i_TyInvestorRisk
                              ,i_tyPage
                              ,i_chLanguage
                              ,o_curInvestorRisk
                              ,o_nCount
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_QryInvestorRisk;

  /*************************************************************************
  $spDesc 费用顺序表
  *************************************************************************/
  PROCEDURE up_QryInvestorFeeSort
  (
     i_TyInvestorFeeSort IN TY_INVESTORFEESORT  --费用表
    ,i_tyPage IN TY_PAGE  --分页查询输入
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作员代码
    ,o_curInvestorFeeSort OUT NOCOPY PKGS_DATATYPE.TYPEREFCURSOR  --返回游标
    ,o_nCount OUT NOCOPY INT  --返回页码
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回码
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_ReportMgrt.up_QryInvestorFeeSort';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '费用顺序表';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '报表管理', '费用顺序表');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_ReportMgrt.up_QryInvestorFeeSort(' ||
                           i_TyInvestorFeeSort.uf_toString()
                      || ',' ||
                           i_tyPage.uf_toString()
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_curInvestorFeeSort'
                      || ',' ||
                        'o_nCount'
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_ReportMgrt.up_QryInvestorFeeSort(
                               i_TyInvestorFeeSort
                              ,i_tyPage
                              ,i_chLanguage
                              ,o_curInvestorFeeSort
                              ,o_nCount
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_QryInvestorFeeSort;

  /*************************************************************************
  $spDesc 追加强平表
  *************************************************************************/
  PROCEDURE up_QryInvestorMarginCall
  (
     i_TyInvestorMarginCall IN TY_INVESTORMARGINCALL  --强平汇总表
    ,i_tyPage IN TY_PAGE  --分页查询输入
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作员代码
    ,o_curInvestorMarginCall OUT NOCOPY PKGS_DATATYPE.TYPEREFCURSOR  --返回游标
    ,o_nCount OUT NOCOPY INT  --返回页码
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回码
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_ReportMgrt.up_QryInvestorMarginCall';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '追加强平表';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '报表管理', '追加强平表');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_ReportMgrt.up_QryInvestorMarginCall(' ||
                           i_TyInvestorMarginCall.uf_toString()
                      || ',' ||
                           i_tyPage.uf_toString()
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_curInvestorMarginCall'
                      || ',' ||
                        'o_nCount'
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_ReportMgrt.up_QryInvestorMarginCall(
                               i_TyInvestorMarginCall
                              ,i_tyPage
                              ,i_chLanguage
                              ,o_curInvestorMarginCall
                              ,o_nCount
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_QryInvestorMarginCall;

  /*************************************************************************
  $spDesc 结算单资金数据
  *************************************************************************/
  PROCEDURE up_QrySettlementBillFund
  (
     i_TySettlementBillFund IN TY_SETTLEMENTBILL  --结算单资金数据
    ,i_tyPage IN TY_PAGE  --分页查询输入
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作员代码
    ,o_curSettlementBillFund OUT NOCOPY PKGS_DATATYPE.TYPEREFCURSOR  --返回游标
    ,o_nCount OUT NOCOPY INT  --返回页码
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回码
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_ReportMgrt.up_QrySettlementBillFund';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '结算单资金数据';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '报表管理', '结算单资金数据');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_ReportMgrt.up_QrySettlementBillFund(' ||
                           i_TySettlementBillFund.uf_toString()
                      || ',' ||
                           i_tyPage.uf_toString()
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_curSettlementBillFund'
                      || ',' ||
                        'o_nCount'
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_ReportMgrt.up_QrySettlementBillFund(
                               i_TySettlementBillFund
                              ,i_tyPage
                              ,i_chLanguage
                              ,o_curSettlementBillFund
                              ,o_nCount
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_QrySettlementBillFund;

  /*************************************************************************
  $spDesc 交割明细
  *************************************************************************/
  PROCEDURE up_QrySettlementBillDeliv
  (
     i_TySettlementBillDeliv IN TY_SETTLEMENTBILL  --交割明细
    ,i_tyPage IN TY_PAGE  --分页查询输入
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作员代码
    ,o_curSettlementBillDeliv OUT NOCOPY PKGS_DATATYPE.TYPEREFCURSOR  --返回游标
    ,o_nCount OUT NOCOPY INT  --返回页码
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回码
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_ReportMgrt.up_QrySettlementBillDeliv';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '交割明细';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '报表管理', '交割明细');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_ReportMgrt.up_QrySettlementBillDeliv(' ||
                           i_TySettlementBillDeliv.uf_toString()
                      || ',' ||
                           i_tyPage.uf_toString()
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_curSettlementBillDeliv'
                      || ',' ||
                        'o_nCount'
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_ReportMgrt.up_QrySettlementBillDeliv(
                               i_TySettlementBillDeliv
                              ,i_tyPage
                              ,i_chLanguage
                              ,o_curSettlementBillDeliv
                              ,o_nCount
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_QrySettlementBillDeliv;

  /*************************************************************************
  $spDesc 交易结算单质押数据
  *************************************************************************/
  PROCEDURE up_QrySettlementBillMort
  (
     i_TySettlementBillMort IN TY_SETTLEMENTBILL  --交易结算单质押数据
    ,i_tyPage IN TY_PAGE  --分页查询输入
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作员代码
    ,o_curSettlementBillMort OUT NOCOPY PKGS_DATATYPE.TYPEREFCURSOR  --返回游标
    ,o_nCount OUT NOCOPY INT  --返回页码
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回码
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_ReportMgrt.up_QrySettlementBillMort';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '交易结算单质押数据';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '报表管理', '交易结算单质押数据');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_ReportMgrt.up_QrySettlementBillMort(' ||
                           i_TySettlementBillMort.uf_toString()
                      || ',' ||
                           i_tyPage.uf_toString()
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_curSettlementBillMort'
                      || ',' ||
                        'o_nCount'
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_ReportMgrt.up_QrySettlementBillMort(
                               i_TySettlementBillMort
                              ,i_tyPage
                              ,i_chLanguage
                              ,o_curSettlementBillMort
                              ,o_nCount
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_QrySettlementBillMort;

  /*************************************************************************
  $spDesc 交易结算单质押数据
  *************************************************************************/
  PROCEDURE up_QrySettlementBillFundMor
  (
     i_TySettlementBillFundMor IN TY_SETTLEMENTBILL  --交易结算单质押数据
    ,i_tyPage IN TY_PAGE  --分页查询输入
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作员代码
    ,o_curSettlementBillFundMor OUT NOCOPY PKGS_DATATYPE.TYPEREFCURSOR  --返回游标
    ,o_nCount OUT NOCOPY INT  --返回页码
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回码
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_ReportMgrt.up_QrySettlementBillFundMor';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '交易结算单质押数据';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '报表管理', '交易结算单质押数据');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_ReportMgrt.up_QrySettlementBillFundMor(' ||
                           i_TySettlementBillFundMor.uf_toString()
                      || ',' ||
                           i_tyPage.uf_toString()
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_curSettlementBillFundMor'
                      || ',' ||
                        'o_nCount'
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_ReportMgrt.up_QrySettlementBillFundMor(
                               i_TySettlementBillFundMor
                              ,i_tyPage
                              ,i_chLanguage
                              ,o_curSettlementBillFundMor
                              ,o_nCount
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_QrySettlementBillFundMor;

  /*************************************************************************
  $spDesc 交易结算单持仓明细
  *************************************************************************/
  PROCEDURE up_QrySettlementBillPosDtl
  (
     i_TySettlementBillPosDtl IN TY_SETTLEMENTBILL  --交易结算单持仓明细
    ,i_tyPage IN TY_PAGE  --分页查询输入
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作员代码
    ,o_curSettlementBillPosDtl OUT NOCOPY PKGS_DATATYPE.TYPEREFCURSOR  --返回游标
    ,o_nCount OUT NOCOPY INT  --返回页码
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回码
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_ReportMgrt.up_QrySettlementBillPosDtl';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '交易结算单持仓明细';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '报表管理', '交易结算单持仓明细');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_ReportMgrt.up_QrySettlementBillPosDtl(' ||
                           i_TySettlementBillPosDtl.uf_toString()
                      || ',' ||
                           i_tyPage.uf_toString()
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_curSettlementBillPosDtl'
                      || ',' ||
                        'o_nCount'
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_ReportMgrt.up_QrySettlementBillPosDtl(
                               i_TySettlementBillPosDtl
                              ,i_tyPage
                              ,i_chLanguage
                              ,o_curSettlementBillPosDtl
                              ,o_nCount
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_QrySettlementBillPosDtl;

  /*************************************************************************
  $spDesc 交易结算单出入金明细
  *************************************************************************/
  PROCEDURE up_QrySettlementBillMoneyIO
  (
     i_TySettlementBillMoneyIO IN TY_SETTLEMENTBILL  --交易结算单出入金明细
    ,i_tyPage IN TY_PAGE  --分页查询输入
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作员代码
    ,o_curSettlementBillMoneyIO OUT NOCOPY PKGS_DATATYPE.TYPEREFCURSOR  --返回游标
    ,o_nCount OUT NOCOPY INT  --返回页码
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回码
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_ReportMgrt.up_QrySettlementBillMoneyIO';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '交易结算单出入金明细';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '报表管理', '交易结算单出入金明细');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_ReportMgrt.up_QrySettlementBillMoneyIO(' ||
                           i_TySettlementBillMoneyIO.uf_toString()
                      || ',' ||
                           i_tyPage.uf_toString()
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_curSettlementBillMoneyIO'
                      || ',' ||
                        'o_nCount'
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_ReportMgrt.up_QrySettlementBillMoneyIO(
                               i_TySettlementBillMoneyIO
                              ,i_tyPage
                              ,i_chLanguage
                              ,o_curSettlementBillMoneyIO
                              ,o_nCount
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_QrySettlementBillMoneyIO;

  /*************************************************************************
  $spDesc 交易结算单平仓明细
  *************************************************************************/
  PROCEDURE up_QrySettlementBillCloDtl
  (
     i_TySettlementBillCloDtl IN TY_SETTLEMENTBILL  --交易结算单平仓明细
    ,i_tyPage IN TY_PAGE  --分页查询输入
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作员代码
    ,o_curSettlementBillCloDtl OUT NOCOPY PKGS_DATATYPE.TYPEREFCURSOR  --返回游标
    ,o_nCount OUT NOCOPY INT  --返回页码
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回码
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_ReportMgrt.up_QrySettlementBillCloDtl';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '交易结算单平仓明细';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '报表管理', '交易结算单平仓明细');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_ReportMgrt.up_QrySettlementBillCloDtl(' ||
                           i_TySettlementBillCloDtl.uf_toString()
                      || ',' ||
                           i_tyPage.uf_toString()
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_curSettlementBillCloDtl'
                      || ',' ||
                        'o_nCount'
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_ReportMgrt.up_QrySettlementBillCloDtl(
                               i_TySettlementBillCloDtl
                              ,i_tyPage
                              ,i_chLanguage
                              ,o_curSettlementBillCloDtl
                              ,o_nCount
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_QrySettlementBillCloDtl;

  /*************************************************************************
  $spDesc 交易结算单行权明细
  *************************************************************************/
  PROCEDURE up_QrySettlementBillStrike
  (
     i_TySettlementBillStrike IN TY_SETTLEMENTBILL  --交易结算单行权明细
    ,i_tyPage IN TY_PAGE  --分页查询输入
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作员代码
    ,o_curSettlementBillStrike OUT NOCOPY PKGS_DATATYPE.TYPEREFCURSOR  --返回游标
    ,o_nCount OUT NOCOPY INT  --返回页码
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回码
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_ReportMgrt.up_QrySettlementBillStrike';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '交易结算单行权明细';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '报表管理', '交易结算单行权明细');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_ReportMgrt.up_QrySettlementBillStrike(' ||
                           i_TySettlementBillStrike.uf_toString()
                      || ',' ||
                           i_tyPage.uf_toString()
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_curSettlementBillStrike'
                      || ',' ||
                        'o_nCount'
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_ReportMgrt.up_QrySettlementBillStrike(
                               i_TySettlementBillStrike
                              ,i_tyPage
                              ,i_chLanguage
                              ,o_curSettlementBillStrike
                              ,o_nCount
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_QrySettlementBillStrike;

  /*************************************************************************
  $spDesc 交易结算单成交记录
  *************************************************************************/
  PROCEDURE up_QrySettlementBillTrade
  (
     i_TySettlementBillTrade IN TY_SETTLEMENTBILL  --交易结算单成交记录
    ,i_tyPage IN TY_PAGE  --分页查询输入
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作员代码
    ,o_curSettlementBillTrade OUT NOCOPY PKGS_DATATYPE.TYPEREFCURSOR  --返回游标
    ,o_nCount OUT NOCOPY INT  --返回页码
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回码
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_ReportMgrt.up_QrySettlementBillTrade';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '交易结算单成交记录';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '报表管理', '交易结算单成交记录');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_ReportMgrt.up_QrySettlementBillTrade(' ||
                           i_TySettlementBillTrade.uf_toString()
                      || ',' ||
                           i_tyPage.uf_toString()
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_curSettlementBillTrade'
                      || ',' ||
                        'o_nCount'
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_ReportMgrt.up_QrySettlementBillTrade(
                               i_TySettlementBillTrade
                              ,i_tyPage
                              ,i_chLanguage
                              ,o_curSettlementBillTrade
                              ,o_nCount
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_QrySettlementBillTrade;

  /*************************************************************************
  $spDesc 交易结算单持仓汇总
  *************************************************************************/
  PROCEDURE up_QrySettlementBillPos
  (
     i_TySettlementBillPos IN TY_SETTLEMENTBILL  --交易结算单持仓汇总
    ,i_tyPage IN TY_PAGE  --分页查询输入
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作员代码
    ,o_curSettlementBillPos OUT NOCOPY PKGS_DATATYPE.TYPEREFCURSOR  --返回游标
    ,o_nCount OUT NOCOPY INT  --返回页码
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回码
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_ReportMgrt.up_QrySettlementBillPos';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '交易结算单持仓汇总';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '报表管理', '交易结算单持仓汇总');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_ReportMgrt.up_QrySettlementBillPos(' ||
                           i_TySettlementBillPos.uf_toString()
                      || ',' ||
                           i_tyPage.uf_toString()
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_curSettlementBillPos'
                      || ',' ||
                        'o_nCount'
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_ReportMgrt.up_QrySettlementBillPos(
                               i_TySettlementBillPos
                              ,i_tyPage
                              ,i_chLanguage
                              ,o_curSettlementBillPos
                              ,o_nCount
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_QrySettlementBillPos;

  /*************************************************************************
  $spDesc 查询结算明细
  *************************************************************************/
  PROCEDURE up_QryPositionInstrument
  (
     i_TyQryPositionInstrument IN TY_QRYPOSITIONINSTRUMENT  --结算明细类型
    ,i_tyPage IN TY_PAGE  --分页查询输入
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作员代码
    ,o_curQryPositionInstrument OUT NOCOPY PKGS_DATATYPE.TYPEREFCURSOR  --返回游标
    ,o_nCount OUT NOCOPY INT  --返回页码
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回码
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_ReportMgrt.up_QryPositionInstrument';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '查询结算明细';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '报表管理', '查询结算明细');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_ReportMgrt.up_QryPositionInstrument(' ||
                           i_TyQryPositionInstrument.uf_toString()
                      || ',' ||
                           i_tyPage.uf_toString()
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_curQryPositionInstrument'
                      || ',' ||
                        'o_nCount'
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_ReportMgrt.up_QryPositionInstrument(
                               i_TyQryPositionInstrument
                              ,i_tyPage
                              ,i_chLanguage
                              ,o_curQryPositionInstrument
                              ,o_nCount
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_QryPositionInstrument;

  /*************************************************************************
  $spDesc 查询结算单风险通知
  *************************************************************************/
  PROCEDURE up_QrySettlementBillRiskNote
  (
     i_BrokerID IN PKGS_DATATYPE.STY_BROKERID  --经纪公司代码
    ,i_SettlementBillType IN PKGS_DATATYPE.STY_SETTLEBILLTYPE  --结算类型
    ,i_investorID IN PKGS_DATATYPE.STY_INVESTORID  --投资者代码
    ,i_BeginDate IN PKGS_DATATYPE.STY_DATE  --开始日期
    ,i_EndDate IN PKGS_DATATYPE.STY_DATE  --结束日期
    ,i_AccountID IN PKGS_DATATYPE.STY_ACCOUNTID  --资金账号
    ,i_currencyid IN PKGS_DATATYPE.STY_CURRENCYID  --币种代码
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作员代码
    ,o_curRiskNote OUT NOCOPY PKGS_DATATYPE.TYPEREFCURSOR  --返回游标
    ,o_nCount OUT NOCOPY INT  --返回页码
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回码
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_ReportMgrt.up_QrySettlementBillRiskNote';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '查询结算单风险通知';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '报表管理', '查询结算单风险通知');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_ReportMgrt.up_QrySettlementBillRiskNote(' ||
                           '''' || trim(i_BrokerID) || ''''
                      || ',' ||
                           '''' || trim(i_SettlementBillType) || ''''
                      || ',' ||
                           '''' || trim(i_investorID) || ''''
                      || ',' ||
                           '''' || trim(i_BeginDate) || ''''
                      || ',' ||
                           '''' || trim(i_EndDate) || ''''
                      || ',' ||
                           '''' || trim(i_AccountID) || ''''
                      || ',' ||
                           '''' || trim(i_currencyid) || ''''
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_curRiskNote'
                      || ',' ||
                        'o_nCount'
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_ReportMgrt.up_QrySettlementBillRiskNote(
                               i_BrokerID
                              ,i_SettlementBillType
                              ,i_investorID
                              ,i_BeginDate
                              ,i_EndDate
                              ,i_AccountID
                              ,i_currencyid
                              ,i_chLanguage
                              ,o_curRiskNote
                              ,o_nCount
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_QrySettlementBillRiskNote;

  /*************************************************************************
  $spDesc 查询结算单统一接口
  *************************************************************************/
  PROCEDURE up_QrySettleBillUF
  (
     i_tySettlementBill IN TY_SETTLEMENTBILL  --结算单类型
    ,i_tyPage IN TY_PAGE  --分页
    ,i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE  --语种
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作员代码
    ,o_nCountFund OUT NOCOPY INT  --结算单资金数据返回页码
    ,o_nCountDeliv OUT NOCOPY INT  --结算单交割明细返回页码
    ,o_nCountMort OUT NOCOPY INT  --结算单质押数据返回页码
    ,o_nCountFundMor OUT NOCOPY INT  --结算单货币质押数据返回页码
    ,o_nCountPosDtl OUT NOCOPY INT  --结算单持仓明细返回页码
    ,o_nCountMoneyIO OUT NOCOPY INT  --结算单出入金明细返回页码
    ,o_nCountCloDtl OUT NOCOPY INT  --结算单平仓明细返回页码
    ,o_nCountPos OUT NOCOPY INT  --结算单持仓汇总返回页码
    ,o_nCountStrike OUT NOCOPY INT  --结算单行权明细返回页码
    ,o_nCountTrade OUT NOCOPY INT  --结算单成交记录返回页码
    ,o_curSettlementBillFund OUT NOCOPY PKGS_DATATYPE.TYPEREFCURSOR  --结算单资金数据游标
    ,o_curSettlementBillDeliv OUT NOCOPY PKGS_DATATYPE.TYPEREFCURSOR  --结算单交割明细游标
    ,o_curSettlementBillMort OUT NOCOPY PKGS_DATATYPE.TYPEREFCURSOR  --结算单质押数据游标
    ,o_curSettlementBillFundMor OUT NOCOPY PKGS_DATATYPE.TYPEREFCURSOR  --结算单货币质押数据游标
    ,o_curSettlementBillPosDtl OUT NOCOPY PKGS_DATATYPE.TYPEREFCURSOR  --结算单持仓明细游标
    ,o_curSettlementBillMoneyIO OUT NOCOPY PKGS_DATATYPE.TYPEREFCURSOR  --结算单出入金明细游标
    ,o_curSettlementBillCloDtl OUT NOCOPY PKGS_DATATYPE.TYPEREFCURSOR  --结算单平仓明细游标
    ,o_curSettlementBillPos OUT NOCOPY PKGS_DATATYPE.TYPEREFCURSOR  --结算单持仓汇总游标
    ,o_curSettlementBillStrike OUT NOCOPY PKGS_DATATYPE.TYPEREFCURSOR  --结算单行权明细游标
    ,o_curSettlementBillTrade OUT NOCOPY PKGS_DATATYPE.TYPEREFCURSOR  --结算单成交记录游标
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回码
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_ReportMgrt.up_QrySettleBillUF';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '查询结算单统一接口';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '报表管理', '查询结算单统一接口');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_ReportMgrt.up_QrySettleBillUF(' ||
                           i_tySettlementBill.uf_toString()
                      || ',' ||
                           i_tyPage.uf_toString()
                      || ',' ||
                           '''' || trim(i_chLanguage) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nCountFund'
                      || ',' ||
                        'o_nCountDeliv'
                      || ',' ||
                        'o_nCountMort'
                      || ',' ||
                        'o_nCountFundMor'
                      || ',' ||
                        'o_nCountPosDtl'
                      || ',' ||
                        'o_nCountMoneyIO'
                      || ',' ||
                        'o_nCountCloDtl'
                      || ',' ||
                        'o_nCountPos'
                      || ',' ||
                        'o_nCountStrike'
                      || ',' ||
                        'o_nCountTrade'
                      || ',' ||
                        'o_curSettlementBillFund'
                      || ',' ||
                        'o_curSettlementBillDeliv'
                      || ',' ||
                        'o_curSettlementBillMort'
                      || ',' ||
                        'o_curSettlementBillFundMor'
                      || ',' ||
                        'o_curSettlementBillPosDtl'
                      || ',' ||
                        'o_curSettlementBillMoneyIO'
                      || ',' ||
                        'o_curSettlementBillCloDtl'
                      || ',' ||
                        'o_curSettlementBillPos'
                      || ',' ||
                        'o_curSettlementBillStrike'
                      || ',' ||
                        'o_curSettlementBillTrade'
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_ReportMgrt.up_QrySettleBillUF(
                               i_tySettlementBill
                              ,i_tyPage
                              ,i_chLanguage
                              ,o_nCountFund
                              ,o_nCountDeliv
                              ,o_nCountMort
                              ,o_nCountFundMor
                              ,o_nCountPosDtl
                              ,o_nCountMoneyIO
                              ,o_nCountCloDtl
                              ,o_nCountPos
                              ,o_nCountStrike
                              ,o_nCountTrade
                              ,o_curSettlementBillFund
                              ,o_curSettlementBillDeliv
                              ,o_curSettlementBillMort
                              ,o_curSettlementBillFundMor
                              ,o_curSettlementBillPosDtl
                              ,o_curSettlementBillMoneyIO
                              ,o_curSettlementBillCloDtl
                              ,o_curSettlementBillPos
                              ,o_curSettlementBillStrike
                              ,o_curSettlementBillTrade
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_QrySettleBillUF;

END PKGI_ReportMgrt;
/

