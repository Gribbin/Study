create TYPE BODY Ty_CRACheckHis IS

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_CRACheckHis RETURN SELF AS RESULT IS
  BEGIN
    RETURN;
  END;

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2 IS
    l_string VARCHAR2(4000);
  BEGIN
    l_string:='ty_CRACheckHis('
      || 'BrokerID=>' || '''' || trim(BrokerID) || '''' --经纪公司代码
      || ',ApplyNo=>' || NVL(to_char(ApplyNo),'NULL')--流水号
      || ',CheckNo=>' || NVL(to_char(CheckNo),'NULL')--操作次数
      || ',FlowID=>' || '''' || trim(FlowID) || '''' --流程ID
      || ',RatingType=>' || '''' || trim(RatingType) || '''' --评级方式
      || ',CheckStatus=>' || '''' || trim(CheckStatus) || '''' --审核状态
      || ',CheckMemo=>' || '''' || trim(CheckMemo) || '''' --审核情况说明
      || ',CurrCheckLevel=>' || '''' || trim(CurrCheckLevel) || '''' --当前审核级别
      || ',MaxCheckLevel=>' || '''' || trim(MaxCheckLevel) || '''' --最高审核级别
      || ',UsedStatus=>' || '''' || trim(UsedStatus) || '''' --生效状态
      || ',Applier=>' || '''' || trim(Applier) || '''' --申请人
      || ',ApplyDate=>' || '''' || trim(ApplyDate) || '''' --申请日期
      || ',InvestorRange=>' || '''' || trim(InvestorRange) || '''' --投资者范围
      || ',InvestorID=>' || '''' || trim(InvestorID) || '''' --投资者代码
      || ',RiskScore=>' || NVL(to_char(RiskScore),'NULL')--评级系统得分
      || ',RiskLevel=>' || NVL(to_char(RiskLevel),'NULL')--风险等级
      || ',IsLatest=>' || '''' || trim(IsLatest) || '''' --是否最新
      || ',OperatorID=>' || '''' || trim(OperatorID) || '''' --审核员代码
      || ',OperateDate=>' || '''' || trim(OperateDate) || '''' --审核日期
      || ',OperateTime=>' || '''' || trim(OperateTime) || '''' --审核时间
      || ',CheckContent=>' || '''' || trim(CheckContent) || '''' --审核内容
      || ')';


    RETURN l_string;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN NULL;
  END;



END;
/

