create TYPE Ty_CFFEXCltOverLimitStat AS OBJECT
(
    TradingDay CHAR(8),  --交易日
    ExchangeID CHAR(8),  --交易所代码
    ParticipantID CHAR(10),  --会员代码
    TradePartID CHAR(10),  --交易会员代码
    ClientID CHAR(10),  --客户编码
    ExchangeInstID CHAR(30),  --合约代码
    StatStyle CHAR(160),  --强平统计类型
    TotalAmt NUMBER(20),  --合约总持仓量
    ForceCloseReason CHAR(160),  --强平原因
    BTotalAmt NUMBER(20),  --多头持仓量
    BForceCloseAmt NUMBER(20),  --多头强平量
    BForceClosedAmt NUMBER(20),  --多头已强平量
    STotalAmt NUMBER(20),  --空头持仓量
    SForceCloseAmt NUMBER(20),  --空头强平量
    SForceClosedAmt NUMBER(20),  --空头已强平量
    ForceCloseSum NUMBER(22,6),  --强平金额
    ForceClosedSum NUMBER(22,6),  --已强平金额
    TransferFlag CHAR(160),  --处理标志
    OperatorID CHAR(64),  --操作员
    OperationDate CHAR(8),  --操作日期
    OperationTime CHAR(8),  --操作时间

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_CFFEXCltOverLimitStat RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

