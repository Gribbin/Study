create TYPE Ty_AMLInstitutionParam AS OBJECT
(
    BrokerID CHAR(10),  --经纪公司代码
    InvestorRange CHAR(1),  --投资者范围
    InvestorID CHAR(12),  --投资者代码
    AMLInsParamID CHAR(20),  --参数代码
    AMLInsaramValue CHAR(255),  --参数代码值
    AMLInsParamDesc VARCHAR2(400),  --参数描述
    OperatorID CHAR(64),  --录入员代码
    OperateDate CHAR(8),  --录入日期
    OperateTime CHAR(8),  --录入时间

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_AMLInstitutionParam RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

