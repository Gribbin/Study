create TYPE Ty_CSRC_CusFund AS OBJECT
(
    TradingDay CHAR(10),  --交易日
    ParticipantID CHAR(10),  --会员代码
    InvestorID CHAR(12),  --客户内部资金账户
    Deposit NUMBER(15,3),  --资金权益总额
    Available NUMBER(15,3),  --可用资金
    CallMargin NUMBER(15,3),  --需追加保证金
    RiskRate NUMBER(15,3),  --风险度
    LastDepositByDate NUMBER(15,3),  --上日结存（逐日盯市）
    LastDepositByVolume NUMBER(15,3),  --上日结存（逐笔对冲）
    DepositByDate NUMBER(15,3),  --当日结存（逐日盯市）
    DepositByVolume NUMBER(15,3),  --当日结存（逐笔对冲）
    ActualByDate NUMBER(15,3),  --当日总盈亏（逐日盯市）
    ActualByVolume NUMBER(15,3),  --当日总盈亏（逐笔对冲）
    FloatActual NUMBER(15,3),  --浮动盈亏（逐笔对冲）
    Mortgage NUMBER(15,3),  --质押金
    IsSettlement CHAR(1),  --是否为非结算会员
    CurrencyID CHAR(3),  --币种
    RealDeposit NUMBER(15,3),  --实有货币资金
    FundMortgageIn NUMBER(15,3),  --货币质入金额
    FundMortgageOut NUMBER(15,3),  --货币质出金额
    FundMortgageMargin NUMBER(15,3),  --货币质押保证金占用
    TotalPremium NUMBER(15,3),  --当日总权利金
    FreezEMoney NUMBER(15,3),  --冻结资金
    InvoiceDeposit NUMBER(15,3),  --发票保证金

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_CSRC_CusFund RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

