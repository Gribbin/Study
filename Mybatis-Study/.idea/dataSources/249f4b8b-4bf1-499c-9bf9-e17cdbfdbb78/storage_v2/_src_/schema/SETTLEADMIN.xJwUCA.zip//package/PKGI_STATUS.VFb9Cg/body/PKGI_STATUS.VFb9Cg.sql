create PACKAGE BODY PKGI_Status  IS
  /*************************************************************************
  $spDesc 系统状态切换
  *************************************************************************/
  PROCEDURE up_SwitchSystemStatus
  (
     i_TradingDay IN PKGS_DATATYPE.STY_DATE  --交易日期
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作源代码
    ,i_chExchangeID IN PKGS_DATATYPE.STY_EXCHANGEID  --交易所ID
    ,i_CurrStatus IN PKGS_DATATYPE.STY_SYSTEMSTATUS  --当前系统状态
    ,i_NextStatus IN PKGS_DATATYPE.STY_SYSTEMSTATUS  --下一系统状态
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回码
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_Status.up_SwitchSystemStatus';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '系统状态切换';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '系统状态', '系统状态切换');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_Status.up_SwitchSystemStatus(' ||
                           '''' || trim(i_TradingDay) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                           '''' || trim(i_chExchangeID) || ''''
                      || ',' ||
                           '''' || trim(i_CurrStatus) || ''''
                      || ',' ||
                           '''' || trim(i_NextStatus) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_Status.up_SwitchSystemStatus(
                               i_TradingDay
                              ,i_chExchangeID
                              ,i_CurrStatus
                              ,i_NextStatus
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_SwitchSystemStatus;

  /*************************************************************************
  $spDesc 系统切换页面状态显示
  *************************************************************************/
  PROCEDURE up_GetSysStatus
  (
     i_ExchangeID IN PKGS_DATATYPE.STY_EXCHANGEID  --查询条件
    ,o_sysStatus OUT PKGS_DATATYPE.STY_SYSTEMSTATUS  --系统状态
    ,o_backupstatus OUT PKGS_DATATYPE.STY_SYSTEMSTATUS  --备份状态
    ,o_initsettlement OUT PKGS_DATATYPE.STY_SYSTEMSTATUS  --初始化状态
    ,o_reportstatus OUT PKGS_DATATYPE.STY_SYSTEMSTATUS  --报表数据生成状态
    ,o_savestatus OUT PKGS_DATATYPE.STY_SYSTEMSTATUS  --数据备份状态
    ,o_currTradingDay OUT PKGS_DATATYPE.STY_DATE  --当前交易日期
    ,o_preTradingDay OUT PKGS_DATATYPE.STY_DATE  --上一交易日期
    ,o_NextTradingDay OUT NOCOPY PKGS_DATATYPE.STY_DATE  --下一交易日期
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作人员
    ,o_nRetCode OUT PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG   --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_Status.up_GetSysStatus';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '系统切换页面状态显示';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '系统状态', '系统切换页面状态显示');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_Status.up_GetSysStatus(' ||
                           '''' || trim(i_ExchangeID) || ''''
                      || ',' ||
                        'o_sysStatus'
                      || ',' ||
                        'o_backupstatus'
                      || ',' ||
                        'o_initsettlement'
                      || ',' ||
                        'o_reportstatus'
                      || ',' ||
                        'o_savestatus'
                      || ',' ||
                        'o_currTradingDay'
                      || ',' ||
                        'o_preTradingDay'
                      || ',' ||
                        'o_NextTradingDay'
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_Status.up_GetSysStatus(
                               i_ExchangeID
                              ,o_sysStatus
                              ,o_backupstatus
                              ,o_initsettlement
                              ,o_reportstatus
                              ,o_savestatus
                              ,o_currTradingDay
                              ,o_preTradingDay
                              ,o_NextTradingDay
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_GetSysStatus;

  /*************************************************************************
  $spDesc 系统状态设置为结算初始化
  *************************************************************************/
  PROCEDURE up_InitSettlementExchange
  (
     i_TradingDay IN PKGS_DATATYPE.STY_DATE  --当前日期
    ,i_ExchangeID IN PKGS_DATATYPE.STY_EXCHANGEID  --交易所ID
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作人员
    ,o_nRetCode OUT PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_Status.up_InitSettlementExchange';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '系统状态设置为结算初始化';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '系统状态', '系统状态设置为结算初始化');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_Status.up_InitSettlementExchange(' ||
                           '''' || trim(i_TradingDay) || ''''
                      || ',' ||
                           '''' || trim(i_ExchangeID) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_Status.up_InitSettlementExchange(
                               i_TradingDay
                              ,i_ExchangeID
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_InitSettlementExchange;

  /*************************************************************************
  $spDesc 前台手工生成报表数据
  *************************************************************************/
  PROCEDURE up_AddReport
  (
     i_TradingDay IN PKGS_DATATYPE.STY_DATE  --当前日期
    ,i_ExchangeID IN PKGS_DATATYPE.STY_EXCHANGEID  --交易所ID
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作人员
    ,o_nRetCode OUT PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG   --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_Status.up_AddReport';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '前台手工生成报表数据';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '系统状态', '前台手工生成报表数据');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_Status.up_AddReport(' ||
                           '''' || trim(i_TradingDay) || ''''
                      || ',' ||
                           '''' || trim(i_ExchangeID) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_Status.up_AddReport(
                               i_TradingDay
                              ,i_ExchangeID
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_AddReport;

  /*************************************************************************
  $spDesc 前台回退到前一天结算
  *************************************************************************/
  PROCEDURE up_BackToSettlementExchange
  (
     i_TradingDay IN PKGS_DATATYPE.STY_DATE  --当前日期
    ,i_ExchangeID IN PKGS_DATATYPE.STY_EXCHANGEID  --交易所ID
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作人员
    ,o_nRetCode OUT PKGS_DATATYPE.STY_RETCODE  --返回值
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG   --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_Status.up_BackToSettlementExchange';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '前台回退到前一天结算';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '系统状态', '前台回退到前一天结算');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_Status.up_BackToSettlementExchange(' ||
                           '''' || trim(i_TradingDay) || ''''
                      || ',' ||
                           '''' || trim(i_ExchangeID) || ''''
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_Status.up_BackToSettlementExchange(
                               i_TradingDay
                              ,i_ExchangeID
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_BackToSettlementExchange;

  /*************************************************************************
  $spDesc 系统备份
  *************************************************************************/
  PROCEDURE up_UpdBackUpStatus
  (
     i_TytSettleDate IN TYT_SETTLEDATE  --结算对象
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作源代码
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回码
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_Status.up_UpdBackUpStatus';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '系统备份';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '系统状态', '系统备份');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_Status.up_UpdBackUpStatus(' ||
                           PKGS_Tyt2STRING.uf_Tyt2String(i_TytSettleDate)
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_Status.up_UpdBackUpStatus(
                               i_TytSettleDate
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_UpdBackUpStatus;

  /*************************************************************************
  $spDesc 数据归档统一入口
  *************************************************************************/
  PROCEDURE up_SaveFilesWhenSettFinished
  (
     i_tytSettledats IN TYT_SETTLEDATE  --输入参数
    ,i_chOperatorID IN PKGS_DATATYPE.STY_OPERATORID  --操作源代码
    ,o_nRetCode OUT NOCOPY PKGS_DATATYPE.STY_RETCODE  --返回码
    ,o_varRetMsg OUT NOCOPY PKGS_DATATYPE.STY_RETMSG  --返回信息
  )
  IS
    l_varLogMsg       PKGS_DataType.STY_OperationMemo;
    l_varSPName PKGS_DataType.STY_ProcessName := 'PKGI_Status.up_SaveFilesWhenSettFinished';
    l_varLogic  pkgs_datatype.STY_LOGIC    := '数据归档统一入口';
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    --在接口的入口设置日志环境
    PKGS_Log.up_SetEnv(i_chOperatorID, '系统状态', '数据归档统一入口');

    PKGS_Log.up_Info(l_varSPName, '开始。' || l_varLogic);

    --记录接口参数
    l_varLogMsg := SUBSTRB('PKGI_Status.up_SaveFilesWhenSettFinished(' ||
                           PKGS_Tyt2STRING.uf_Tyt2String(i_tytSettledats)
                      || ',' ||
                           '''' || trim(i_chOperatorID) || ''''
                      || ',' ||
                        'o_nRetCode'
                      || ',' ||
                        'o_varRetMsg'
                    || ')',1,4000);

    --/*框架生成的调试代码，请不要修改  >>>>>>>>>>>>
    PKGS_Log.up_Trace(l_varSPName, l_varLogMsg);
    --框架生成的调试代码，请不要修改  <<<<<<<<<<<<*/


    --/* 调用业务层代码，业务实现完毕后增加在行首增加行注释即可  >>>>>>>>>>>>
    PKGB_Status.up_SaveFilesWhenSettFinished(
                               i_tytSettledats
                              ,o_nRetCode
                              ,o_varRetMsg
                              );
    --调用业务层代码  <<<<<<<<<<<<*/

    IF o_nRetCode = PKGS_Constants.C_RET_SUCCESS THEN
    	IF o_varRetMsg IS NULL OR o_varRetMsg='' THEN
    		o_varRetMsg:=l_varLogic||'成功';
    	END IF
    	;


      PKGS_Log.up_Info(l_varSPName, '成功完成。' || l_varLogic);
    ELSE -- 业务处理失败
      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic || ':' || o_varRetMsg);
    END IF;

  EXCEPTION
    WHEN OTHERS THEN


      PKGS_Log.up_Error(l_varSPName, '异常结束。' || l_varLogic);
      o_varRetMsg := l_varLogic || '失败';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode, o_varRetMsg);
  END up_SaveFilesWhenSettFinished;

END PKGI_Status;
/

