create TYPE Ty_CRAInvestorRisk AS OBJECT
(
    BrokerID CHAR(10),  --经纪商代码
    InvestorID CHAR(12),  --投资者代码
    RiskScore NUMBER(8),  --评级系统得分
    RiskLevel NUMBER(8),  --风险等级
    RatingType CHAR(1),  --评级方式
    RatingDate CHAR(8),  --评级时间

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_CRAInvestorRisk RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

