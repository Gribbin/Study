create TYPE Ty_CopyTplCommRate AS OBJECT
(
    BrokerID CHAR(10),  --经纪公司代码
    InvestorRange CHAR(1),  --源投资者范围
    InvestorID CHAR(12),  --投资者代码
    InvestUnitID CHAR(16),  --投资单元代码
    DepartmentID CHAR(12),  --组织架构
    SourceRateTemplateID CHAR(8),  --源模型代码
    TargetRateTemplateID CHAR(8),  --目标模型代码
    ExchangeID CHAR(8),  --交易所
    InstrumentID CHAR(30),  --合约

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_CopyTplCommRate RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

