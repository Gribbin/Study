create TYPE BODY Ty_CheckCSRCFundAvailable IS

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_CheckCSRCFundAvailable RETURN SELF AS RESULT IS
  BEGIN
    RETURN;
  END;

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2 IS
    l_string VARCHAR2(4000);
  BEGIN
    l_string:='ty_CheckCSRCFundAvailable('
      || 'IsSame=>' || '''' || trim(IsSame) || '''' --是否相同
      || ',TradingDay=>' || '''' || trim(TradingDay) || '''' --交易日
      || ',InvestorID=>' || '''' || trim(InvestorID) || '''' --投资者编码
      || ',InvestorName=>' || '''' || trim(InvestorName) || '''' --投资者名称
      || ',CurrencyID=>' || '''' || trim(CurrencyID) || '''' --币种
      || ',diffvalue=>' || NVL(to_char(diffvalue),'NULL')--差额
      || ',available=>' || NVL(to_char(available),'NULL')--可用资金
      || ',margintotal=>' || NVL(to_char(margintotal),'NULL')--期货保证金
      || ',deliverymargin=>' || NVL(to_char(deliverymargin),'NULL')--交割保证金
      || ',optmargin=>' || NVL(to_char(optmargin),'NULL')--期权保证金
      || ',deposit=>' || NVL(to_char(deposit),'NULL')--总权益
      || ')';


    RETURN l_string;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN NULL;
  END;



END;
/

