create TYPE Ty_CFFEXTrade AS OBJECT
(
    ParticipantID CHAR(10),  --会员代码
    TradePartID CHAR(10),  --交易会员
    ClientID CHAR(10),  --客户编码
    ExchangeInstID CHAR(30),  --合约代码
    TradeID CHAR(20),  --合约编号
    Direction CHAR(1),  --买卖
    Volume NUMBER(20),  --成交量
    Price NUMBER(19,10),  --成交价
    TurnOver NUMBER(22,6),  --成交金额
    TradeTime CHAR(8),  --成交时间
    OffsetFlag CHAR(1),  --开平标志
    OrderSysID CHAR(20),  --报单号
    TraderID CHAR(20),  --交易所交易员代码
    TradingDay CHAR(8),  --交易日
    ExchangeID CHAR(8),  --交易所代码

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_CFFEXTrade RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

