create TYPE Ty_CSRCDataSendLog AS OBJECT
(
    ParticipantID CHAR(10),  --会员代码
    TradingDay CHAR(8),  --交易日
    SequenceNo NUMBER(12),  --序号
    TradingTime CHAR(8),  --发送时间
    LogLevel CHAR(32),  --日志级别
    Memo CHAR(160),  --备注

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_CSRCDataSendLog RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

