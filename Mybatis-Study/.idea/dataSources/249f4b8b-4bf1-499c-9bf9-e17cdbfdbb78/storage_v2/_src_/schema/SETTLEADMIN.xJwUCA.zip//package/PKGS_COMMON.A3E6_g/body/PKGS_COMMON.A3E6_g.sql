create PACKAGE BODY PKGS_COMMON IS

  ---- 验证用户是否为管理员
  PROCEDURE up_ValidateSuperUser
  (
    o_nRetCode      OUT     PKGS_DataType.STY_RETCODE,            ---- 返回码
    o_varRetMsg     OUT     PKGS_DataType.STY_RETMSG,           ---- 返回信息
    i_OperatorID    IN      PKGS_DataType.STY_OperatorID           ---- 操作员代码
  )
   AS
    l_Count           INT;
    l_ProcessName     PKGS_DataType.STY_SpName;               ---- 存储过程名称
    l_UserID          t_SuperUser.UserID%TYPE;
  BEGIN
    o_nRetCode := PKGS_Constants.C_RET_SUCCESS;
    l_ProcessName := 'PKGS_COMMON.up_ValidateSuperUser';
    pkgs_log.Debug(i_OperatorID,l_ProcessName,'i_OperatorID:'||trim(i_OperatorID));
    IF i_OperatorID IS NULL THEN
      o_nRetCode := PKGS_Constants.C_RET_FAIL;
      o_varRetMsg := '操作用户不能为空值';
    END IF;
    IF TRIM(SUBSTR(i_OperatorID, 1, INSTR(i_OperatorID, '.') - 1)) = TRIM(PKGS_Constants.DEFAULT_BROKERID) THEN
      BEGIN
        l_UserID := TRIM(SUBSTR(TRIM(i_OperatorID), INSTR(TRIM(i_OperatorID), '.') + 1));
        SELECT COUNT(UserID)
        INTO l_Count
        FROM t_SuperUser
        WHERE UserID = l_UserID;
        pkgs_log.Info(pkgs_log.g_chOperatorID,'0001',i_OperatorID);
        IF l_Count > 0 THEN
          o_nRetCode := PKGS_Constants.C_RET_SUCCESS;
          o_varRetMsg := '用户(' || TRIM(i_OperatorID) || ')是系统管理员';
          RETURN;
        END IF;
      EXCEPTION
        WHEN OTHERS THEN
          NULL;
      END;
    END IF;
    o_nRetCode := PKGS_Constants.C_RET_FAIL;
    o_varRetMsg := '您不是系统管理员,无权做以上操作';
  EXCEPTION
    WHEN OTHERS THEN
      o_nRetCode := PKGS_Constants.C_RET_FAIL;
      o_varRetMsg := '验证用户是否为管理员时出错';
      PKGS_Log.Fatal(i_OperatorID, l_ProcessName, o_varRetMsg);
  END up_ValidateSuperUser;

  --- 查询交易所
  PROCEDURE up_QryExchange
  (
    i_TypeExchange   IN      Ty_Exchange,                        ---- 交易所信息类型
    i_chSortName  	 IN			 PKGS_DataType.STY_SortName,						---- 排序字段信息
    i_chLanguage     IN 		 PKGS_DATATYPE.STY_LANGUAGE,					----语种
    i_chOperatorID   IN      PKGS_DataType.STY_OperatorID,          ---- 操作员代码
    o_ExchangeCursor OUT     g_TypeCursor,                        ---- 返回信息的游标
    o_PageCount      OUT     INT,                                ---- 页数
    o_nRetCode       OUT     PKGS_DataType.STY_RETCODE,            ---- 返回码
    o_varRetMsg      OUT     PKGS_DataType.STY_RETMSG           ---- 返回信息
  )
  AS
    l_sql             PKGS_DataType.STY_RETMSG;
    l_ProcessName     PKGS_DataType.STY_SpName;               ---- 存储过程名称
  BEGIN
    o_nRetCode := PKGS_Constants.C_RET_SUCCESS;
    l_ProcessName := 'PKGS_COMMON.up_QryExchanges';
    PKGS_Log.Info(i_chOperatorID, l_ProcessName, '查询交易所信息');

    IF i_TypeExchange IS NULL THEN
      o_nRetCode  := PKGS_Constants.C_RET_FAIL;
      o_varRetMsg := '输入的参数对象不允许为空值';
      RETURN;
    END IF;

    ---- 获取总条数
    SELECT COUNT(*)
    INTO o_PageCount
    FROM t_Exchange
    WHERE 1 = 1
    AND (i_TypeExchange.ExchangeID IS NULL OR NVL(LENGTH(TRIM(i_TypeExchange.ExchangeID)),0)=0 OR ExchangeID = i_TypeExchange.ExchangeID)
    AND (i_TypeExchange.ExchangeName IS NULL OR NVL(LENGTH(TRIM(i_TypeExchange.ExchangeName)),0)=0 OR ExchangeName LIKE '%' || TRIM(i_TypeExchange.ExchangeName) || '%')
    AND (i_TypeExchange.ExchangeAbbr IS NULL OR NVL(LENGTH(TRIM(i_TypeExchange.ExchangeAbbr)),0)=0 OR ExchangeAbbr LIKE '%' || TRIM(i_TypeExchange.ExchangeAbbr) || '%')
    ;

    OPEN o_ExchangeCursor FOR
      SELECT Ty_Exchange(ExchangeID,ExchangeName,ExchangeAbbr,ExchangeProperty)
      FROM t_Exchange
      WHERE 1 = 1
      AND (i_TypeExchange.ExchangeID IS NULL OR NVL(LENGTH(TRIM(i_TypeExchange.ExchangeID)),0)=0 OR ExchangeID = i_TypeExchange.ExchangeID)
      AND (i_TypeExchange.ExchangeName IS NULL OR NVL(LENGTH(TRIM(i_TypeExchange.ExchangeName)),0)=0 OR ExchangeName LIKE '%' || TRIM(i_TypeExchange.ExchangeName) || '%')
      AND (i_TypeExchange.ExchangeAbbr IS NULL OR NVL(LENGTH(TRIM(i_TypeExchange.ExchangeAbbr)),0)=0 OR ExchangeAbbr LIKE '%' || TRIM(i_TypeExchange.ExchangeAbbr) || '%')
      ORDER BY ExchangeID;

    --PKGS_Log.Info(i_chOperatorID, l_ProcessName, l_sql);
    o_varRetMsg := '查询交易所成功';
  EXCEPTION
    WHEN OTHERS THEN
      o_nRetCode := PKGS_Constants.C_RET_FAIL;
      o_varRetMsg := '查询交易所信息出错';
      PKGS_Log.Fatal(i_chOperatorID, l_ProcessName, o_varRetMsg);
  END up_QryExchange;

  ---- 验证用户是否为该经纪公司用户
  PROCEDURE up_ValidateBrokerUser
  (
    o_nRetCode      OUT     PKGS_DATATYPE.STY_RETCODE,             ---- 返回码
    o_varRetMsg     OUT     PKGS_DATATYPE.STY_RETMSG,              ---- 返回信息
    i_OperatorID    IN      PKGS_DATATYPE.STY_OperatorID,          ---- 操作员代码
    i_BrokerID      IN      PKGS_DATATYPE.STY_BrokerID             ---- 经纪公司代码
  )
  AS
    l_Count           INT;
    l_UserID          t_BrokerUser.UserID%TYPE;
    l_varSPName       t_Operationlog.ProcessName%TYPE;                ---- 存储过程名称
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;
    l_varSPName := 'PKGS_Common.up_ValidateBrokerUser';

    ---- 检查经纪公司代码是否为空
    IF i_BrokerID IS NULL THEN
      o_nRetCode  := PKGS_Constants.C_RET_FAIL;
      o_varRetMsg := '经纪公司代码不能为空值';
      RETURN;
    END IF;

    IF TRIM(SUBSTR(i_OperatorID, 1, INSTR(i_OperatorID, '.') - 1)) <> TRIM(PKGS_Constants.DEFAULT_BROKERID) THEN
      SELECT COUNT(*)
      INTO l_Count
      FROM t_broker
      WHERE TRIM(BrokerID) = TRIM(SUBSTR(i_OperatorID, 1, INSTR(i_OperatorID, '.') - 1));
      IF l_Count = 0 THEN
		o_nRetCode  := PKGS_Constants.C_RET_FAIL;
        o_varRetMsg := '操作员代码错误';
      END IF;
      l_UserID := TRIM(SUBSTR(TRIM(i_OperatorID), INSTR(TRIM(i_OperatorID), '.') + 1));
      SELECT COUNT(*)
      INTO l_Count
      FROM t_BrokerUser
      WHERE BrokerID = i_BrokerID
      AND   UserID   = l_UserID;
      IF l_Count = 0 THEN
        o_nRetCode  := PKGS_Constants.C_RET_FAIL;
        o_varRetMsg := '您不是经纪公司用户,无权做以上操作';
      ELSE
        SELECT COUNT(*)
        INTO l_Count
        FROM t_BrokerUser
        WHERE BrokerID = i_BrokerID
        AND   UserID   = l_UserID
        AND   Isactive = PKGS_Constants.C_Bool_True;
        IF l_Count = 0 THEN
          o_nRetCode  := PKGS_Constants.C_RET_FAIL;
          o_varRetMsg := '您已经销户,无权做以上操作';
        ELSE
        o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;
        o_varRetMsg := '验证经纪公司用户成功';
        END IF;
      END IF;
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      o_nRetCode  := PKGS_Constants.C_RET_FAIL;
      o_varRetMsg := '验证用户是否为经纪公司用户时出错';
      PKGS_Log.up_Error(l_varSPName,i_OperatorID||' '||o_varRetMsg);
  END up_ValidateBrokerUser;

  ---- 验证经纪公司用户代码,added by zhang.cb
  PROCEDURE up_ValidateBrokerUser
  (
    o_nRetCode      OUT     PKGS_DATATYPE.STY_RETCODE,             ---- 返回码
    o_varRetMsg     OUT     PKGS_DATATYPE.STY_RETMSG,              ---- 返回信息
    i_OperatorID    IN      PKGS_DATATYPE.STY_OperatorID,          ---- 操作员代码
    i_BrokerID      IN      PKGS_DATATYPE.STY_BrokerID,            ---- 经纪公司代码
    i_UserID        IN      t_BrokerUser.UserID%TYPE            ---- 用户代码
  )
  AS
    l_Count           INT;
    l_varSPName       t_Operationlog.ProcessName%TYPE;                ---- 存储过程名称
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;
    l_varSPName := 'PKGS_Common.up_ValidateBrokerUser';

    IF i_UserID IS NOT NULL THEN
      SELECT COUNT(*)
      INTO l_Count
      FROM t_BrokerUser
      WHERE BrokerID = i_BrokerID
      AND   UserID   = i_UserID;
      IF l_Count = 0 THEN
        o_nRetCode  := pkgs_constants.C_RET_FAIL;
        o_varRetMsg := '用户代码' || TRIM(i_UserID) || '不存在';
        RETURN;
      ELSE
        SELECT COUNT(*)
        INTO l_Count
        FROM t_BrokerUser
        WHERE BrokerID = i_BrokerID
        AND   UserID   = i_UserID
        AND   Isactive = pkgs_constants.C_BOOL_TRUE;
        IF l_Count = 0 THEN
          o_nRetCode  := pkgs_constants.C_RET_FAIL;
          o_varRetMsg := '用户代码' || TRIM(i_UserID) || '已销户';
        ELSE
          o_nRetCode  := pkgs_constants.C_RET_SUCCESS;
          o_varRetMsg := '验证经纪公司用户成功';
        END IF;
      END IF;
    END IF;
     o_nRetCode  := pkgs_constants.C_RET_SUCCESS;
    o_varRetMsg := '用户代码' || TRIM(i_UserID) || '存在';
  EXCEPTION
    WHEN OTHERS THEN
      o_nRetCode  := pkgs_constants.C_RET_FAIL;
      o_varRetMsg := '验证用户代码' || TRIM(i_UserID) || '是否存在出错';
       PKGS_Log.up_Error(l_varSPName,i_OperatorID||' '||o_varRetMsg);
  END up_ValidateBrokerUser;

  ----验证用户是否活跃 added by zhang.cb
 PROCEDURE up_ValidateUserState
  (
    o_nRetCode      OUT     PKGS_DATATYPE.STY_RETCODE,             ---- 返回码
    o_varRetMsg     OUT     PKGS_DATATYPE.STY_RETMSG,              ---- 返回信息
    i_OperatorID    IN      PKGS_DATATYPE.STY_OperatorID,          ---- 操作员代码
    i_BrokerID      IN      PKGS_DATATYPE.STY_BrokerID,            ---- 经纪公司代码
    i_UserID                IN      t_BrokerUser.UserID%TYPE            ---- 用户代码
  )
  AS
    l_Count           INT;
    l_varSPName       t_Operationlog.ProcessName%TYPE;                ---- 存储过程名称
  BEGIN
    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;
    l_varSPName := 'PKGS_Common.up_ValidateUserState';

    ---- 检查经纪公司代码是否为空
    IF i_BrokerID IS NULL THEN
      o_nRetCode  := pkgs_constants.C_RET_FAIL;
      o_varRetMsg := '经纪公司代码不能为空值';
      RETURN;
    END IF;

     ---- 检查用户是否有效
    IF TRIM(i_BrokerID) = TRIM(pkgs_constants.DEFAULT_BROKERID) THEN  ----如果是超级用户
      SELECT COUNT(*)
      INTO l_Count
      FROM t_SuperUser
      WHERE  UserID   = i_UserID;
      IF l_Count <= 0 THEN
       o_nRetCode  := pkgs_constants.C_RET_FAIL;
       o_varRetMsg := '超级用户' || TRIM(i_UserID) || '不存在';
       RETURN;
      END IF ;
      SELECT COUNT(*)
      INTO l_Count
      FROM t_SuperUser
      WHERE  UserID   = i_UserID
      AND   IsActive = PKGS_CONSTANTS.C_BOOL_TRUE;
    ELSE
     ---- 验证是否为经纪公司用户
     up_ValidateBrokerUser(o_nRetCode, o_varRetMsg, i_OperatorID, i_BrokerID);
    IF o_nRetCode <> pkgs_constants.C_RET_SUCCESS THEN
      RETURN;
    END IF;
    ---- 检查操作员代码是否存在
    up_ValidateBrokerUser(o_nRetCode, o_varRetMsg, i_OperatorID, i_BrokerID, i_UserID);
    IF o_nRetCode <> pkgs_constants.C_RET_SUCCESS THEN
      RETURN;
    END IF;
    ---- 检查操作员状态
      SELECT COUNT(*)
      INTO l_Count
      FROM t_BrokerUser
      WHERE BrokerID = i_BrokerID
      AND   UserID   = i_UserID
      AND   IsActive = pkgs_constants.C_BOOL_TRUE;
    END IF ;

    IF l_Count <= 0 THEN
       o_nRetCode  := pkgs_constants.C_RET_FAIL;
       o_varRetMsg := '用户' || TRIM(i_UserID) || '处于不活跃状态!';
     ELSE
       o_nRetCode  := pkgs_constants.C_RET_SUCCESS;
       o_varRetMsg := '用户' || TRIM(i_UserID) || '处于活跃状态';
     END IF ;
  EXCEPTION
    WHEN OTHERS THEN
      o_nRetCode  := pkgs_constants.C_RET_FAIL;
      o_varRetMsg := '验证用户代码' || TRIM(i_UserID) || '是否活跃出错';
       PKGS_Log.up_Error(l_varSPName,i_OperatorID||' '||o_varRetMsg);
  END up_ValidateUserState;

  --- 查询产品信息
  PROCEDURE up_QryProduct
  (
    i_chExchangeID  IN      PKGS_DataType.STY_ExchangeID,         ---- 交易所信息类型
    i_chSortName  	IN			PKGS_DataType.STY_SortName,						---- 排序字段信息
    i_chLanguage    IN 			PKGS_DATATYPE.STY_LANGUAGE,						----语种
    i_chOperatorID  IN      PKGS_DataType.STY_OperatorID,          	---- 操作员代码
    o_ProductCursor OUT   	g_TypeCursor,                        	---- 返回信息的游标
    o_nCount     		OUT     INT,                                	---- 记录数
    o_nRetCode      OUT     PKGS_DataType.STY_RETCODE,            	---- 返回码
    o_varRetMsg     OUT     PKGS_DataType.STY_RETMSG           		---- 返回信息
  )
  AS
    l_sql             PKGS_DataType.STY_RETMSG;
    l_ProcessName     PKGS_DataType.STY_SpName;               ---- 存储过程名称
  BEGIN
    o_nRetCode := PKGS_Constants.C_RET_SUCCESS;
    l_ProcessName := 'PKGS_COMMON.up_QryProduct';
    PKGS_Log.Info(i_chOperatorID, l_ProcessName, '查询产品信息');

    /*IF i_chExchangeID IS NULL THEN
      o_nRetCode  := PKGS_Constants.C_RET_FAIL;
      o_varRetMsg := '输入的参数对象不允许为空值';
      RETURN;
    END IF;*/

    ---- 获取总条数
    SELECT COUNT(*)
    INTO o_nCount
    FROM t_Product
    --WHERE EXCHANGEID = i_chExchangeID
    where (i_chExchangeID IS NULL OR NVL(LENGTH(TRIM(i_chExchangeID)),0)=0 OR ExchangeID = i_chExchangeID)
      ;

    OPEN o_ProductCursor FOR
      SELECT Ty_Product(ExchangeID, ProductID,CommodityID,ProductName,ProductClass,ProductLifePhase,CurrencyID,QUOTECURRENCYID,PositionMode,PositionDateType,PriceDecimal,DelivMode,DelivUnit,PctDelivType,StrikeMode,VersionNo)
			FROM t_Product
			--WHERE EXCHANGEID = i_chExchangeID
      where (i_chExchangeID IS NULL OR NVL(LENGTH(TRIM(i_chExchangeID)),0)=0 OR ExchangeID = i_chExchangeID)
       ;

    --PKGS_Log.Info(i_chOperatorID, l_ProcessName, l_sql);
    o_varRetMsg := '查询产品信息成功';
  EXCEPTION
    WHEN OTHERS THEN
      o_nRetCode := PKGS_Constants.C_RET_FAIL;
      o_varRetMsg := '查询产品信息出错';
      PKGS_Log.Fatal(i_chOperatorID, l_ProcessName, o_varRetMsg);
  END up_QryProduct;
  ---- 获取文件位置
  PROCEDURE up_QryFilePosition
  (
    i_FilePositionID              IN      t_SysSettleParam.SYSTEMPARAMID%TYPE,       ---- 文件位置代码
    i_OperatorID                  IN      PKGS_DataType.STY_OperatorID,                 ---- 操作员代码
    o_Path                        OUT     t_SysSettleParam.SYSTEMPARAMVALUE%TYPE,    ---- 文件位置
    o_nRetCode                    OUT     PKGS_DataType.STY_RETCODE,                   ---- 返回码
    o_varRetMsg                   OUT     PKGS_DataType.STY_RETMSG                   ---- 返回信息
  )
  AS
    l_ProcessName     PKGS_DataType.STY_SpName;                             ---- 存储过程名称

  BEGIN
    o_nRetCode := PKGS_Constants.C_RET_SUCCESS;
    l_ProcessName := 'PKGS_COMMON.up_QryFilePosition';

  /* CTP2-717
  ---- 检查系统状态
    Pkgs_Common.up_ValidateSystemStatus(o_nRetCode, o_varRetMsg, NULL,NULL);
    IF o_nRetCode <> PKGS_Constants.C_RET_SUCCESS THEN
      pkgs_Log.Error( SettleAdmin.pkgs_log.g_chOperatorID, l_ProcessName, o_varRetMsg);
      RETURN;
    END IF;*/
    SELECT SYSTEMPARAMVALUE
    INTO o_Path
    FROM t_SysSettleParam
    WHERE  BrokerID = PKGS_Constants.DEFAULT_BROKERID
    AND   SystemParamID = i_FilePositionID;
    PKGS_Log.Info(i_OperatorID, l_ProcessName, o_varRetMsg);
  EXCEPTION
    WHEN OTHERS THEN
      o_nRetCode := PKGS_Constants.C_RET_FAIL;
      o_varRetMsg := '获取文件位置出错';
      PKGS_Log.Fatal(i_OperatorID, l_ProcessName, o_varRetMsg);
  END up_QryFilePosition;
  ---- 获取文件位置
  PROCEDURE up_QryFilePosition1
  (
    i_FilePositionID              IN      t_SysSettleParam.SYSTEMPARAMID%TYPE,       ---- 文件位置代码
    i_BrokerID                    IN      t_SysSettleParam.Brokerid%TYPE,            ---- 经纪公司
    i_OperatorID                  IN      PKGS_DataType.STY_OperatorID,                 ---- 操作员代码
    o_Path                        OUT     t_SysSettleParam.SYSTEMPARAMVALUE%TYPE,    ---- 文件位置
    o_nRetCode                    OUT     PKGS_DataType.STY_RETCODE,                   ---- 返回码
    o_varRetMsg                   OUT     PKGS_DataType.STY_RETMSG                   ---- 返回信息
  )
  AS
    l_ProcessName     PKGS_DataType.STY_SpName;                             ---- 存储过程名称
    l_count  INT;
  BEGIN
    o_nRetCode := PKGS_Constants.C_RET_SUCCESS;
    l_ProcessName := 'PKGS_COMMON.up_QryFilePosition1';

    ---- 检查系统状态
    Pkgs_Common.up_ValidateSystemStatus(o_nRetCode, o_varRetMsg, NULL,NULL);
    IF o_nRetCode <> PKGS_Constants.C_RET_SUCCESS THEN
      pkgs_Log.Error( SettleAdmin.pkgs_log.g_chOperatorID, l_ProcessName, o_varRetMsg);
      RETURN;
    END IF;

    SELECT COUNT(*)
    INTO l_count
    FROM t_SysSettleParam
    WHERE  trim(BrokerID) = trim(i_BrokerID)
    AND   SystemParamID = i_FilePositionID;
    IF l_count >0 THEN
      SELECT SYSTEMPARAMVALUE
      INTO o_Path
      FROM t_SysSettleParam
      WHERE  trim(BrokerID) = trim(i_BrokerID)
      AND   SystemParamID = i_FilePositionID;
    ELSE
      o_nRetCode := PKGS_Constants.C_RET_FAIL;
      o_varRetMsg :='没有设置路径，请于系统参数设置页面进行设置';
      PKGS_Log.Fatal(i_OperatorID, l_ProcessName, o_varRetMsg);
      RETURN;
    END IF;

    PKGS_Log.Info(i_OperatorID, l_ProcessName, o_varRetMsg);
  EXCEPTION
    WHEN OTHERS THEN
      o_nRetCode := PKGS_Constants.C_RET_FAIL;
      o_varRetMsg := '获取文件位置出错';
      PKGS_Log.Fatal(i_OperatorID, l_ProcessName, o_varRetMsg);
  END up_QryFilePosition1;

  --- 查询系统交易日  add by Morgan.chen
  PROCEDURE up_GetSysTradingDay
  (
    i_chExchangeID IN  t_Exchange.EXCHANGEID%type,					----交易所代码
  	i_chOperatorID IN  PKGS_DataType.STY_OperatorID,						----操作员代码
  	i_chTradingDay OUT t_SettleDate.CurrTradingDay%type,			----系统交易日期
  	o_nRetCode      OUT     PKGS_DataType.STY_RETCODE,        ---- 返回码
    o_varRetMsg     OUT     PKGS_DataType.STY_RETMSG        ---- 返回信息
  )
  AS
  	l_ProcessName			PKGS_DataType.STY_SpName;
  BEGIN
    o_nRetCode :=PKGS_Constants.C_RET_SUCCESS;
    l_ProcessName :='PKGS_COMMON.up_GetSysTradingDay';
    --Pkgs_Log.Info(i_chOperatorID,l_ProcessName,'开始查询系统交易日');

    IF i_chExchangeID IS NULL THEN
      o_nRetCode :=PKGS_Constants.C_RET_FAIL;
      o_varRetMsg :='ExchangeID参数字段不允许为空值';
      Pkgs_Log.Error(i_chOperatorID,l_ProcessName,'ExchangeID参数字段不允许为空值');
      RETURN;
    END IF;

    SELECT T.CurrTradingDay
      INTO I_CHTRADINGDAY
      FROM t_SettleDate T
     WHERE UPPER(T.EXCHANGEID) = UPPER(I_CHEXCHANGEID)
       and rownum<2;

     --Pkgs_log.Info(i_chOperatorID,l_ProcessName,'结束查询系统交易日');
  EXCEPTION
    WHEN OTHERS THEN
      o_nRetCode :=PKGS_Constants.C_RET_FAIL;
      o_varRetMsg :='查询系统交易日出错';
      PKGS_Log.Fatal(i_chOperatorID, l_ProcessName, o_varRetMsg);
  END up_GetSysTradingDay;

  --- 查询上一交易日  add by marmot.zeng
  PROCEDURE up_GetPreTradingDay
  (
   	o_nRetCode      OUT     PKGS_DataType.STY_RETCODE,      ---- 返回码
    o_varRetMsg     OUT     PKGS_DataType.STY_RETMSG,        ---- 返回信息
    o_chPreTradingDay OUT t_SettleDate.CurrTradingDay%type,		----上一交易日期
  	i_chTradingDay IN t_SettleDate.CurrTradingDay%type				----当前交易日期
  )
  AS
  	l_ProcessName			PKGS_DataType.STY_SpName;
  BEGIN
    o_nRetCode :=PKGS_Constants.C_RET_SUCCESS;
    l_ProcessName :='PKGS_COMMON.up_GetPreTradingDay';
    --Pkgs_Log.Info(Pkgs_Log.g_chOperatorID,l_ProcessName,'开始查询上一交易日');

  	SELECT max(t.day)
       INTO o_chPreTradingDay
       FROM t_calendar t
       WHERE t.day < i_chTradingDay
       AND t.tra = '1';

     --Pkgs_log.Info(Pkgs_Log.g_chOperatorID,l_ProcessName,'结束查询上一交易日');

  EXCEPTION
    WHEN OTHERS THEN
      o_nRetCode :=PKGS_Constants.C_RET_FAIL;
      o_varRetMsg :='查询上一交易日出错';
      PKGS_Log.Fatal(Pkgs_Log.g_chOperatorID, l_ProcessName, o_varRetMsg);
  END up_GetPreTradingDay;

  --- 查询下一交易日  add by marmot.zeng
  PROCEDURE up_GetNextTradingDay
  (
   	o_nRetCode      OUT     PKGS_DataType.STY_RETCODE,      ---- 返回码
    o_varRetMsg     OUT     PKGS_DataType.STY_RETMSG,        ---- 返回信息
    o_chNextTradingDay OUT t_SettleDate.CurrTradingDay%type,		----下一交易日期
  	i_chTradingDay IN t_SettleDate.CurrTradingDay%type 			----当前交易日期
  )
  AS
  	l_ProcessName			PKGS_DataType.STY_SpName;
  BEGIN
    o_nRetCode :=PKGS_Constants.C_RET_SUCCESS;
    l_ProcessName :='PKGS_COMMON.up_GetPreTradingDay';
    --Pkgs_Log.Info(Pkgs_Log.g_chOperatorID,l_ProcessName,'开始查询下一交易日');

  	SELECT min(t.day)
       INTO o_chNextTradingDay
       FROM t_calendar t
       WHERE t.day > i_chTradingDay
       AND t.tra = '1';

     --Pkgs_log.Info(Pkgs_Log.g_chOperatorID,l_ProcessName,'结束查询下一交易日');

  EXCEPTION
    WHEN OTHERS THEN
      o_nRetCode :=PKGS_Constants.C_RET_FAIL;
      o_varRetMsg :='查询下一交易日出错';
      PKGS_Log.Fatal(Pkgs_Log.g_chOperatorID, l_ProcessName, o_varRetMsg);
  END up_GetNextTradingDay;

   ---- 获取结算日期c
  PROCEDURE up_QrySettleDate(i_BrokerID     IN PKGS_DataType.STY_BrokerID, ---- 经纪公司代码
                             i_chExchangeID IN PKGS_DataType.STY_ExchangeID, ---- 交易所信息类型
                             i_chOperatorID IN  PKGS_DataType.STY_OperatorID,						----操作员代码
                             o_SettleDate   OUT PKGS_DataType.STY_DATE, ---- 结算日期
                             o_nRetCode     OUT PKGS_DataType.STY_RETCODE, ---- 返回码
                             o_varRetMsg    OUT PKGS_DataType.STY_RETMSG ---- 返回信息
                             ) AS
    l_tradingday  PKGS_DataType.STY_DATE;
    l_ProcessName PKGS_DataType.STY_SpName; ---- 存储过程名称
    cursor c_QrySettleDate is
      select settlementDate
        from t_SettleDate
       WHERE trim(BrokerID) =  trim(i_BrokerID) OR (trim(BrokerID) = '0000')
         and trim(ExchangeID)  = nvl(trim(i_chExchangeID),trim(PKGS_Constants.DEFAULT_EXCHANGE)) ;
  BEGIN
    o_nRetCode    := PKGS_Constants.C_S_OK;
    l_ProcessName := 'PKGS_COMMON.up_QrySettleDate';
    --o_varRetMsg := '开始获取结算日期';
    PKGS_Log.info(i_chOperatorID, l_ProcessName, '开始获取结算日期');
    open c_QrySettleDate;
    fetch c_QrySettleDate
      into l_tradingday;
    if c_QrySettleDate%notfound then
      o_nRetCode  := PKGS_Constants.C_S_FAILED;
      o_varRetMsg := '无法找到结算日期';
       PKGS_Log.Error(i_chOperatorID, l_ProcessName,o_varRetMsg);
      close c_QrySettleDate;
      return;
    else
      o_SettleDate := l_tradingday;
    end if;
    close c_QrySettleDate;

    PKGS_Log.Info(i_chOperatorID, l_ProcessName, '成功获取结算日期');
  EXCEPTION
    WHEN OTHERS THEN
      o_nRetCode  := PKGS_Constants.C_RET_FAIL;
      o_varRetMsg := '获取结算日期出错';
      PKGS_Log.Fatal(i_chOperatorID, l_ProcessName, o_varRetMsg);
  END up_QrySettleDate;

  FUNCTION uf_QrySettleDate(i_BrokerID IN PKGS_DataType.STY_BrokerID,
													  i_chExchangeID IN PKGS_DataType.STY_ExchangeID)
    RETURN PKGS_DataType.STY_DATE DETERMINISTIC IS
    ---- 获取结算日期

    l_ProcessName PKGS_DataType.STY_SpName; ---- 存储过程名称
    l_tradingday PKGS_DataType.STY_DATE;
    cursor c_QrySettleDate is
      select settlementDate
        from t_SettleDate
       WHERE BrokerID =  i_BrokerID
         and ExchangeID  = nvl(i_chExchangeID,PKGS_Constants.DEFAULT_EXCHANGE);
  BEGIN

    l_ProcessName := 'PKGS_COMMON.uf_QrySettleDate';
    --PKGS_Log.info(i_chOperatorID, l_ProcessName, '开始获取结算日期');
    open c_QrySettleDate;
    fetch c_QrySettleDate
      into l_tradingday;
    close c_QrySettleDate;
    --PKGS_Log.info(i_chOperatorID, l_ProcessName, '成功获取结算日期');

    RETURN l_tradingday;
  EXCEPTION
    WHEN OTHERS THEN
      PKGS_Log.Fatal(PKGS_LOG.g_chOperatorID, l_ProcessName, '获取结算日期出错');
  END uf_QrySettleDate;

  ----查询结算上传文件信息
  PROCEDURE up_GetUploadFile(
            i_TypeUploadFile IN ty_uploadfile,        ---上传文件类型信息
            i_Ty_Page IN TY_PAGE,    ----排序字段信息
            i_chLanguage IN PKGS_DATATYPE.STY_LANGUAGE,		----语种
            i_chOperatorID IN PKGS_DataType.STY_OperatorID,   ----操作员代码
            o_UploadFileCursor OUT g_TypeCursor,     ----返回游标信息
            o_PageCount OUT INT,     ----页数
            o_nRetCode OUT PKGS_DataType.STY_RETCODE,    ----返回码
            o_varRetMsg OUT PKGS_DataType.STY_RETMSG    ----返回信息
    )
  AS
    l_ProcessName PKGS_DataType.STY_SpName;
  BEGIN
    o_nRetCode:=PKGS_Constants.C_RET_SUCCESS;
    l_ProcessName:='PKGS_COMMON.up_GetUploadFile';
    PKGS_LOG.Info(i_chOperatorID,l_ProcessName,'查询结算上传文件信息');

/*    IF i_TypeUploadFile IS NULL THEN
      o_nRetCode:= PKGS_Constants.C_RET_FAIL;
      o_varRetMsg:='输入的参数对象不允许为空值';
      RETURN;
     END IF;

     SELECT COUNT(*)
     INTO o_PageCount
     FROM t_uploadfile t
     WHERE 1=1
     AND (t.brokerid=i_TypeUploadFile.BrokerID)
     AND (t.exchangeid=i_TypeUploadFile.ExchangeID);

     OPEN o_UploadFileCursor FOR
     SELECT ty_uploadfile(t.tradingday,t.brokerid,t.exchangeid,t.participantid,t.filetype,t.fileid,t.fileformat,t.filename,t.fileuploadstatus,t.reason,t.operatorid,t.opdate,t.optime)
     FROM t_uploadfile t
     WHERE 1=1
     AND (t.brokerid=i_TypeUploadFile.BrokerID)
     AND (t.exchangeid=i_TypeUploadFile.ExchangeID);*/

    o_varRetMsg:='查询结算上传文件成功';
    EXCEPTION
       WHEN OTHERS THEN
         o_nRetCode:=PKGS_Constants.C_RET_FAIL;
         o_varRetMsg:='查询结算上传文件出错';
         PKGS_LOG.Fatal(i_chOperatorID,l_ProcessName,o_varRetMsg);
  END up_GetUploadFile;

  ---- 获取系统日期
  FUNCTION up_Get_SysDate RETURN PKGS_DataType.STY_DATE IS
    l_chsysDate PKGS_DataType.STY_DATE;
  BEGIN
	select to_char(sysdate,'yyyyMMdd') into l_chsysDate from dual;
	return l_chsysDate;
  END up_Get_SysDate;

  ---- 获取系统时间
  FUNCTION up_Get_SysTime RETURN PKGS_DataType.STY_Time IS
    l_chsysTime PKGS_DataType.STY_Time;
  BEGIN
  SELECT to_char(SYSDATE, 'HH24miss') INTO l_chsystime FROM dual;
  RETURN l_chsystime;
  END up_Get_SysTime;

  ---- 获取系统时间
  FUNCTION up_Get_SysTimeWithColon RETURN PKGS_DataType.STY_Time IS
    l_chsysTime PKGS_DataType.STY_Time;
  BEGIN
    SELECT to_char(SYSDATE, 'HH24:MI:SS') INTO l_chsystime FROM dual;
    RETURN l_chsystime;
  END up_Get_SysTimeWithColon;

    ---- 获取操作类型
  FUNCTION up_Get_OpType(i_chProcName IN t_Operationlog.ProcessName%TYPE) RETURN t_R_mortgage.OperationType%TYPE IS
    l_chOpType t_R_mortgage.OperationType%TYPE;
  BEGIN

    if INSTR(i_chProcName,'_Ins')>0
	then
		l_chOpType := '1';
    elsif INSTR(i_chProcName,'_Upd')>0
	then
		l_chOpType := '2';
	elsif INSTR(i_chProcName,'_Del')>0
	then
		l_chOpType := '3';
	elsif INSTR(i_chProcName,'_Chk')>0
	then
		l_chOpType := '4';
	else
		l_chOpType := '0';
	end if;

	return l_chOpType;
  END up_Get_OpType;


  ----获取业务流水号 add by liumz
  FUNCTION uf_GetBusinessNo
  (
    i_brokerID        IN  PKGS_DataType.STY_BrokerID ---- 经纪公司代码
   ,i_chBusiID        IN  t_businessseq.BUSINESSTYPE%TYPE ---- 业务名称
  ) RETURN t_businessseq.CURRENTSEQNO%TYPE AS
    PRAGMA AUTONOMOUS_TRANSACTION;
    l_CurrValue t_businessseq.CURRENTSEQNO%TYPE;
    l_CurrNextValue t_businessseq.CURRENTSEQNO%TYPE;
    l_MaxValue  t_businessseq.maxseqno%TYPE;
    l_nRetCode  PKGS_DATATYPE.STY_RetCode;
    o_nRetCode        PKGS_DATATYPE.STY_RETCODE;           ---- 返回码
    o_varRetMsg       PKGS_DATATYPE.STY_RETMSG;          ---- 返回信息
  BEGIN
    --更新流水号
    UPDATE t_businessseq t
      SET  t.CurrentDate=to_char(sysdate,'yyyymmdd'),
           t.CurrentSeqNo=t.MinSeqNo
     WHERE t.BrokerID  = i_brokerID
	     AND upper(t.BUSINESSTYPE) = upper(i_chBusiID)
	     AND t.IsRefreshByDate='1'
	     AND nvl(t.CurrentDate,'19000101')<> to_char(sysdate,'yyyymmdd');
	  COMMIT;

     -----修改成表中所有的类型取值时，都判断
     SELECT CURRENTSEQNO + 1,MAXSEQNO
     INTO   l_CurrNextValue,l_MaxValue
     FROM   t_businessseq
     WHERE  BrokerID  = i_brokerID
     AND upper(BUSINESSTYPE) = upper(i_chBusiID);

     IF l_CurrNextValue <= l_MaxValue THEN
       --获取流水号
       UPDATE t_businessseq
       SET CURRENTSEQNO = CURRENTSEQNO + 1
       WHERE BrokerID  = i_brokerID
       AND upper(BUSINESSTYPE) = upper(i_chBusiID) RETURN CURRENTSEQNO INTO l_CurrValue;
     ELSE
       o_nRetCode  := PKGS_Constants.E_USER_ERROR;
       o_varRetMsg := '流水号编号超过了最大值';
       PKGS_Log.up_Error('uf_GetBusinessNo',o_varRetMsg||  ',获取流水号失败');
     END IF;
    IF l_CurrValue IS NULL
    THEN
      o_nRetCode  := PKGS_Constants.E_USER_ERROR;
      o_varRetMsg := '获取流水号失败：引用的计数器不存在';
    END IF;
      COMMIT;
      RETURN l_CurrValue;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
	  PKGS_Log.up_Error('uf_GetBusinessNo', '异常结束。:' || '获取流水号失败');
  END uf_GetBusinessNo;


  ----获取业务流水号 add by liumz
  FUNCTION uf_GetBusinessNo
  (
    o_nRetCode              OUT    PKGS_DATATYPE.STY_RETCODE           ---- 返回码
   ,o_varRetMsg             OUT    PKGS_DATATYPE.STY_RETMSG          ---- 返回信息
   ,i_brokerID        IN  PKGS_DataType.STY_BrokerID ---- 经纪公司代码
   ,i_chBusiID        IN  t_businessseq.BUSINESSTYPE%TYPE ---- 业务名称
  ) RETURN t_businessseq.CURRENTSEQNO%TYPE AS
    PRAGMA AUTONOMOUS_TRANSACTION;
    l_CurrValue t_businessseq.CURRENTSEQNO%TYPE;
    l_nRetCode  PKGS_DATATYPE.STY_RetCode;
  BEGIN
	o_nRetCode := Pkgs_Constants.C_RET_SUCCESS;
    --更新流水号
    UPDATE t_businessseq t
      SET  t.CurrentDate=to_char(sysdate,'yyyymmdd'),
           t.CurrentSeqNo=t.MinSeqNo
     WHERE t.BrokerID  = i_brokerID
	     AND upper(t.BUSINESSTYPE) = upper(i_chBusiID)
	     AND t.IsRefreshByDate='1'
	     AND nvl(t.CurrentDate,'19000101')<> to_char(sysdate,'yyyymmdd');
	  COMMIT;
    --获取流水号
    UPDATE t_businessseq
       SET CURRENTSEQNO = CURRENTSEQNO + 1
	   WHERE BrokerID  = i_brokerID
	     AND upper(BUSINESSTYPE) = upper(i_chBusiID) RETURN CURRENTSEQNO INTO l_CurrValue;
	IF l_CurrValue IS NULL
	THEN
		o_nRetCode  := PKGS_Constants.E_USER_ERROR;
		o_varRetMsg := '获取流水号失败：引用的计数器不存在';
	END IF;
    COMMIT;
    RETURN l_CurrValue;
  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
	  o_varRetMsg := '获取流水号失败';
	  PKGS_Log.up_Error('uf_GetBusinessNo', '异常结束。:' || '获取流水号失败');
  END uf_GetBusinessNo;


  ---- 验证操作员对投资者是否有操作权限 老代码，逐步替换新代码，这里的效率过低；
  PROCEDURE up_ValidateOperatorInvestor
  (
    o_nRetCode      OUT     PKGS_DATATYPE.STY_RETCODE,             ---- 返回码
    o_varRetMsg     OUT     PKGS_DATATYPE.STY_RETMSG,              ---- 返回信息
    i_OperatorID    IN      PKGS_DATATYPE.STY_OperatorID,          ---- 操作员代码
    i_BrokerID      IN      PKGS_DATATYPE.STY_BrokerID,             ---- 经纪公司代码
    i_InvestorID    IN      t_Investor.InvestorID%TYPE    ---- 投资者代码
  )
  AS
    l_varSPName t_Operationlog.ProcessName%TYPE := 'PKGS_Common.up_ValidateOperatorInvestor';
    l_varLogic  PKGS_DataType.STY_LOGIC;
    l_varBusiDesc    PKGS_DataType.STY_LOGIC := '验证操作员对投资者是否有操作权限';
    l_UserID          t_brokeruser.UserID%Type;
    l_Count           INTEGER;
  BEGIN

    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

    IF TRIM(i_OperatorID) Is NULL THEN
       o_nRetCode := PKGS_CONSTANTS.C_RET_FAIL;
       o_varRetMsg := '操作员不能为空';
       pkgs_Log.Fatal(i_OperatorID, l_varSPName, o_varRetMsg);
       Return;
    END IF ;

    l_UserID := TRIM(SUBSTR(i_OperatorID, INSTR(i_OperatorID, '.') + 1));
		---排查是否在黑名单中
    SELECT COUNT(*)
      INTO l_count
      FROM t_Departmentuserblacklist t
     WHERE t.brokerid = i_brokerid
       AND t.userid = l_UserID
       AND t.investorid = i_investorid;
    IF l_count > 0 THEN
       o_nRetCode := PKGS_CONSTANTS.C_RET_FAIL;
       o_varRetMsg := '投资者(' || TRIM(i_InvestorID) || ')在操作员(' || TRIM(l_UserID)||')的黑名单中，没有权限';
       RETURN;
    END IF;
--------------------------------------------------------------------------------
    SELECT COUNT(*)
      INTO l_count
      FROM (
             SELECT BrokerID ,UserID,InvestorID AS DepartMentID
             FROM  t_departmentuser
             WHERE BrokerID = i_BrokerID
             AND InvestorRange = pkgs_enums.DR_Group
             --AND INVESTORID = i_Department
             UNION
             SELECT Brokerid,userID,PKGS_Constants.DEFAULT_BrokerDepartMentID AS DepartMentID
             FROM  t_brokeruser
             WHERE BrokerID = i_BrokerID
             AND Isadmin =  PKGS_Constants.C_Bool_True
             UNION
             SELECT i_BrokerID,userID,PKGS_Constants.DEFAULT_BrokerDepartMentID AS DepartMentID
              FROM  t_superuser
             )
     WHERE TRIM(DepartMentID) = TRIM(PKGS_Constants.DEFAULT_BrokerDepartMentID)
       AND TRIM(UserID)       = TRIM(l_UserID);

    IF l_count = 0 THEN--折中方案，先让有拥有组织架构组权限以上的人通过
----------------------------------------------------------------------------------
      DELETE FROM TMP_DepartMentInvestor
       WHERE BrokerID =  i_BrokerID ;

      pkgs_common.up_GenDepartmentInvestor(o_nRetCode,o_varRetMsg,i_OperatorID,i_BrokerID,i_InvestorID,null,null);
			IF o_nRetCode <> pkgs_constants.C_S_OK THEN
				RETURN;
			END IF;

      SELECT COUNT(*)
        INTO l_count
        FROM TMP_DepartMentInvestor t1
       WHERE t1.brokerid = i_BrokerID
         AND  t1.investorid = i_InvestorID;

      IF l_count = 0 THEN
         o_nRetCode := PKGS_CONSTANTS.C_RET_FAIL;
         o_varRetMsg := '操作员' || TRIM(l_UserID) || '对投资者' || TRIM(i_InvestorID) || '没有操作权限';
         pkgs_Log.Fatal(i_OperatorID, l_varSPName, o_varRetMsg);
         RETURN;
      END IF;
-----------------------------------------
    END IF;--折中方案，先让有拥有组织架构组权限以上的人通过
-----------------------------------------
    o_varRetMsg := '验证操作员对投资者权限成功';

  EXCEPTION
    WHEN OTHERS THEN
      o_nRetCode := pkgs_constants.C_RET_FAIL;
      o_varRetMsg := '检查操作员' || TRIM(l_UserID) || '对投资者' || TRIM(i_InvestorID) || '操作权限';
      pkgs_Log.Fatal(i_OperatorID, l_varSPName, o_varRetMsg);
  END up_ValidateOperatorInvestor;

  ---- 验证操作员对投资者是否有操作权限 新代码，新功能用新代码；
  PROCEDURE up_ValidateOperatorAccInvestor
  (
    o_nRetCode      OUT     PKGS_DATATYPE.STY_RETCODE,             ---- 返回码
    o_varRetMsg     OUT     PKGS_DATATYPE.STY_RETMSG,              ---- 返回信息
    i_OperatorID    IN      PKGS_DATATYPE.STY_OperatorID,          ---- 操作员代码
    i_BrokerID      IN      PKGS_DATATYPE.STY_BrokerID,             ---- 经纪公司代码
    i_InvestorID    IN      t_Investor.InvestorID%TYPE    ---- 投资者代码
  )
  AS
    l_varSPName t_Operationlog.ProcessName%TYPE := 'PKGS_Common.up_ValidateOperatorAccInvestor';
    l_varLogic  PKGS_DataType.STY_LOGIC;
    l_varBusiDesc    PKGS_DataType.STY_LOGIC := '验证操作员对投资者是否有操作权限';
    l_UserID          t_brokeruser.UserID%Type;
    l_Count           INTEGER;
  BEGIN

    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

     IF TRIM(i_OperatorID) Is NULL THEN
       o_nRetCode := PKGS_CONSTANTS.C_RET_FAIL;
       o_varRetMsg := '操作员不能为空';
       RETURN;
     END IF ;

    l_UserID := TRIM(SUBSTR(i_OperatorID, INSTR(i_OperatorID, '.') + 1));
    ---排查是否在黑名单中
    SELECT COUNT(*)
      INTO l_count
      FROM t_Departmentuserblacklist t
     WHERE t.brokerid = i_brokerid
       AND t.userid = l_UserID
       AND t.investorid = i_investorid;
    IF l_count > 0 THEN
       o_nRetCode := PKGS_CONSTANTS.C_RET_FAIL;
       o_varRetMsg := '投资者' || TRIM(i_InvestorID) || '在操作员' || TRIM(l_UserID)||'的黑名单中，没有权限';
       RETURN;
    END IF;
--------------------------------------------------------------------------------
     SELECT COUNT(*)
       INTO l_count
       FROM (
             SELECT BrokerID ,UserID,InvestorID AS DepartMentID
             FROM  t_departmentuser
             WHERE BrokerID = i_BrokerID
             AND InvestorRange = pkgs_enums.DR_Group
             --AND INVESTORID = i_Department
             UNION
             SELECT Brokerid,userID,PKGS_Constants.DEFAULT_BrokerDepartMentID AS DepartMentID
             FROM  t_brokeruser
             WHERE BrokerID = i_BrokerID
             AND Isadmin =  PKGS_Constants.C_Bool_True
             UNION
             SELECT i_BrokerID,userID,PKGS_Constants.DEFAULT_BrokerDepartMentID AS DepartMentID
              FROM  t_superuser
             )
       WHERE TRIM(DepartMentID) = TRIM(PKGS_Constants.DEFAULT_BrokerDepartMentID)
       AND TRIM(UserID)       = TRIM(l_UserID);

    IF l_count = 0 THEN--折中方案，先让有拥有组织架构组权限以上的人通过
----------------------------------------------------------------------------------
         SELECT COUNT(*)
           INTO l_count
           FROM t_departmentuser t0, t_investor t1
          WHERE t1.brokerid = i_brokerid
            AND t1.investorid = i_investorid
            AND t0.brokerid = t1.brokerid
            AND t0.userid = l_userid
            AND t0.investorrange = '2'
            AND t1.departmentid LIKE TRIM(t0.investorid) || '%';
         IF(l_count=0) THEN
           SELECT COUNT(*)
             INTO l_count
             FROM t_departmentuser t0, t_investor t1
            WHERE t1.brokerid = i_brokerid
              AND t1.investorid = i_investorid
              AND t0.brokerid = t1.brokerid
              AND t0.userid = l_userid
              AND t0.investorrange = '3'
              AND t1.investorid = t0.investorid;
         END IF;
         IF l_count = 0 THEN
           o_nRetCode := PKGS_CONSTANTS.C_RET_FAIL;
           o_varRetMsg := '操作员' || TRIM(l_UserID) || '对投资者' || TRIM(i_InvestorID) || '没有操作权限';
           RETURN;
         END IF;
-----------------------------------------
		END IF;--折中方案，先让有拥有组织架构组权限以上的人通过
-----------------------------------------
    o_varRetMsg := '验证操作员对投资者权限成功';

  EXCEPTION
    WHEN OTHERS THEN
      o_nRetCode := pkgs_constants.C_RET_FAIL;
      o_varRetMsg := '检查操作员' || TRIM(l_UserID) || '对投资者' || TRIM(i_InvestorID) || '操作权限';
      pkgs_Log.Fatal(i_OperatorID, l_varSPName, o_varRetMsg);
  END up_ValidateOperatorAccInvestor;

  ---- 验证操作员对投资者是否有操作权限
  PROCEDURE up_ValidateOperatorDepartment
  (
    o_nRetCode      OUT     PKGS_DATATYPE.STY_RETCODE,             ---- 返回码
    o_varRetMsg     OUT     PKGS_DATATYPE.STY_RETMSG,              ---- 返回信息
    i_OperatorID    IN      PKGS_DATATYPE.STY_OperatorID,          ---- 操作员代码
    i_BrokerID      IN      PKGS_DATATYPE.STY_BrokerID,             ---- 经纪公司代码
    i_Department    IN      t_department.departmentid%TYPE    ---- 投资者组代码
  )
    AS
    l_varSPName t_Operationlog.ProcessName%TYPE := 'PKGS_Common.up_ValidateOperatorDepartment';
    l_varLogic  PKGS_DataType.STY_LOGIC;
    l_varBusiDesc    PKGS_DataType.STY_LOGIC := '验证操作员对投资者组是否有操作权限';
    l_UserID          t_brokeruser.UserID%Type;
    l_Count           INTEGER;

  BEGIN

    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

     IF TRIM(i_OperatorID) Is NULL THEN
       o_nRetCode := PKGS_CONSTANTS.C_RET_FAIL;
       o_varRetMsg := '操作员不能为空';
       pkgs_Log.Fatal(i_OperatorID, l_varSPName, o_varRetMsg);
       Return;
     END IF ;

    l_UserID := TRIM(SUBSTR(i_OperatorID, INSTR(i_OperatorID, '.') + 1));

       SELECT COUNT(*)
       INTO l_count
       FROM (
             SELECT BrokerID ,UserID,InvestorID AS DepartMentID
             FROM  t_departmentuser
             WHERE BrokerID = i_BrokerID
             AND InvestorRange = pkgs_enums.DR_Group
             AND INVESTORID = i_Department
             UNION
             SELECT Brokerid,userID,PKGS_Constants.DEFAULT_BrokerDepartMentID AS DepartMentID
             FROM  t_brokeruser
             WHERE BrokerID = i_BrokerID
             AND Isadmin =  PKGS_Constants.C_Bool_True
             UNION
             SELECT i_BrokerID,userID,PKGS_Constants.DEFAULT_BrokerDepartMentID AS DepartMentID
              FROM  t_superuser
             )
       WHERE TRIM(DepartMentID) = TRIM(PKGS_Constants.DEFAULT_BrokerDepartMentID)
       AND TRIM(UserID)       = TRIM(l_UserID);

       IF l_count = 0 THEN
         o_nRetCode := PKGS_CONSTANTS.C_RET_FAIL;
         o_varRetMsg := '操作员' || TRIM(l_UserID) || '对组织架构' || TRIM(i_Department) || '没有操作权限';
         pkgs_Log.Fatal(i_OperatorID, l_varSPName, o_varRetMsg);
         RETURN;
       END IF;

    o_varRetMsg := '验证操作员组对组织架构权限成功';

  EXCEPTION
    WHEN OTHERS THEN
      o_nRetCode := pkgs_constants.C_RET_FAIL;
      o_varRetMsg := '检查操作员' || TRIM(l_UserID) || '对组织架构' || TRIM(i_Department) || '操作权限';
      pkgs_Log.Fatal(i_OperatorID, l_varSPName, o_varRetMsg);
  END up_ValidateOperatorDepartment;

  /*PROCEDURE up_ValidateOperatorGroup
  (
    o_nRetCode      OUT     PKGS_DATATYPE.STY_RETCODE,             ---- 返回码
    o_varRetMsg     OUT     PKGS_DATATYPE.STY_RETMSG,              ---- 返回信息
    i_OperatorID    IN      PKGS_DATATYPE.STY_OperatorID,          ---- 操作员代码
    i_BrokerID      IN      PKGS_DATATYPE.STY_BrokerID,             ---- 经纪公司代码
    i_GroupID       IN      t_investorgroup.investorgroupid%TYPE    ---- 投资者代码
  )
  AS
    l_varSPName t_Operationlog.ProcessName%TYPE := 'PKGS_Common.up_ValidateOperatorGroup';
    l_varLogic  PKGS_DataType.STY_LOGIC;
    l_varBusiDesc    PKGS_DataType.STY_LOGIC := '验证操作员对投资者组是否有操作权限';
    l_UserID          t_brokeruser.UserID%Type;
    l_Count           INTEGER;

  BEGIN

    o_nRetCode  := PKGS_Constants.C_RET_SUCCESS;

     IF TRIM(i_OperatorID) Is NULL THEN
       o_nRetCode := PKGS_CONSTANTS.C_RET_FAIL;
       o_varRetMsg := '操作员不能为空';
       pkgs_Log.Fatal(i_OperatorID, l_varSPName, o_varRetMsg);
       Return;
     END IF ;

    l_UserID := TRIM(SUBSTR(i_OperatorID, INSTR(i_OperatorID, '.') + 1));

      SELECT COUNT(*)
      INTO l_Count
      FROM t_InvestorGroup
      WHERE BrokerID        = i_BrokerID
      AND   InvestorGroupID = i_GroupID;

       IF l_count = 0 THEN
         o_nRetCode := PKGS_CONSTANTS.C_RET_FAIL;
         o_varRetMsg := '操作员' || TRIM(l_UserID) || '对投资者组' || TRIM(i_GroupID) || '没有操作权限';
         pkgs_Log.Fatal(i_OperatorID, l_varSPName, o_varRetMsg);
         RETURN;
       END IF;

    o_varRetMsg := '验证操作员组对投资者组权限成功';

  EXCEPTION
    WHEN OTHERS THEN
      o_nRetCode := pkgs_constants.C_RET_FAIL;
      o_varRetMsg := '检查操作员' || TRIM(l_UserID) || '对投资者组' || TRIM(i_GroupID) || '操作权限';
      pkgs_Log.Fatal(i_OperatorID, l_varSPName, o_varRetMsg);
  END up_ValidateOperatorGroup;*/

   ---- 验证操作员对投资者是否有操作权限
    PROCEDURE up_ValidateUserQueryRight
  (
    o_nRetCode                      OUT     PKGS_DATATYPE.STY_RETCODE,             ---- 返回码
    o_varRetMsg                     OUT     PKGS_DATATYPE.STY_RETMSG,            ---- 返回信息
    i_OperatorID                    IN      PKGS_DATATYPE.STY_OperatorID,            ---- 操作员代码
    i_BeginDate                     IN      PKGS_DATATYPE.STY_DATE,           ---- 查询时间段开始时间
    i_EndDate                       IN      PKGS_DATATYPE.STY_DATE,            ---- 查询时间段结束时间
    i_BrokerID                      IN      PKGS_DATATYPE.STY_BrokerID     ---- 经纪公司代码
  )
  AS
    l_Count           INT;
    l_varSPName       PKGS_DataType.STY_SpName;                                ---- 存储过程名称
    l_UserID          t_brokeruser.UserID%Type;
    l_TimeSpan        t_brokeruserqueryright.timespan%TYPE;
    l_TradingDay      pkgs_datatype.STY_DATE;
    l_BeginTime       t_investor.opendate%TYPE;
    l_endTime         t_investor.opendate%TYPE;
  BEGIN
    o_nRetCode := PKGS_Constants.C_S_OK;
    o_varRetMsg := '验证操作员查询权限成功';
    l_varSPName := 'PKGS_COMMON.up_ValidateUserQueryRight';

    IF i_EndDate < i_BeginDate THEN
       o_nRetCode := pkgs_constants.C_RET_FAIL;
       o_varRetMsg := '开始日期不能大于结束日期';
       pkgs_Log.Fatal(i_OperatorID, l_varSPName, o_varRetMsg);
       RETURN;
    END IF;

    IF i_BrokerID IS NULL OR i_OperatorID IS NULL THEN
       o_nRetCode := pkgs_constants.C_RET_FAIL;
       o_varRetMsg := '经纪公司代码，操作员不能为空';
       pkgs_Log.Fatal(i_OperatorID, l_varSPName, o_varRetMsg);
       RETURN;
    END IF;

    l_UserID := SUBSTR(TRIM(i_OperatorID), INSTR(TRIM(i_OperatorID), '.') + 1) ;

    ---- 管理员和超级用户无限制
    SELECT COUNT(*)
    INTO l_count
    FROM (
           SELECT userID
           FROM  t_brokeruser
           WHERE BrokerID = i_BrokerID
           AND Isadmin =  pkgs_constants.C_BOOL_TRUE
           UNION
           SELECT userID
           FROM  t_superuser
         )
    WHERE TRIM(UserID)   = TRIM(l_UserID);

    IF l_count > 0 THEN
      RETURN;
    END IF;

    ---- 获取当前交易日期
    /*SELECT TradingDay
    INTO l_TradingDay
    FROM t_SettleDate;*/
    l_TradingDay := uf_QrySettleDate(i_BrokerID, pkgs_log.g_chOperatorID,PKGS_Constants.DEFAULT_EXCHANGE);

    ---- 是否有针对操作员的单一设置
    SELECT COUNT(*)
    INTO l_count
    FROM t_brokeruserqueryright t
    WHERE t.brokerid = i_BrokerID
    AND   t.userid = l_UserID
    AND  t.Isactive = pkgs_constants.C_BOOL_TRUE
    AND  t.userrange = pkgs_constants.UR_Single;

    IF l_count > 0 THEN
       SELECT t.timespan,t.begintime,t.endtime
       INTO l_TimeSpan,l_BeginTime,l_endTime
       FROM t_brokeruserqueryright t
       WHERE t.brokerid = i_BrokerID
       AND   t.userid = l_UserID
       AND  t.Isactive = pkgs_constants.C_BOOL_TRUE
       AND  t.userrange = pkgs_constants.UR_Single;
    ELSE
       ----是否有针对所有操作员的设置
       SELECT COUNT(*)
       INTO l_count
       FROM t_brokeruserqueryright t
       WHERE t.brokerid = i_BrokerID
       AND  t.Isactive = pkgs_constants.C_BOOL_TRUE
       AND  t.userrange = pkgs_constants.UR_All;

       IF l_count > 0 THEN
          SELECT t.timespan,t.begintime,t.endtime
          INTO l_TimeSpan,l_BeginTime,l_endTime
          FROM t_brokeruserqueryright t
          WHERE t.brokerid = i_BrokerID
          AND  t.Isactive = pkgs_constants.C_BOOL_TRUE
          AND  t.userrange = pkgs_constants.UR_All;
       ELSE
          RETURN;
       END IF;
    END IF;

    ---- 验证查询时间限制
    IF TO_CHAR(SYSDATE, 'HH24MISS') >= nvl(regexp_replace(trim(l_BeginTime), '[^0-9]', ''),'000000') AND TO_CHAR(SYSDATE, 'HH24MISS') <= nvl(regexp_replace(trim(l_endTime), '[^0-9]', ''),'245959') THEN
       SELECT COUNT(*)
       INTO l_count
       FROM  t_Calendar t
       WHERE Day >= nvl(i_BeginDate,l_tradingday)
       AND DAY <= least(l_tradingday,nvl(i_EndDate,l_tradingday))
       AND Tra = pkgs_constants.C_BOOL_TRUE
       AND t.exchangeid = pkgs_constants.DEFAULT_EXCHANGE;----@chen.lan ctp2交易日历分了交易所，需根据默认交易所的来进行筛查；

       ---- 验证查询时间跨度
       IF (l_count >  l_TimeSpan) AND trim(l_TimeSpan) IS NOT NULL THEN
          o_nRetCode := pkgs_constants.C_RET_FAIL;
          o_varRetMsg := '操作员' || trim(l_UserID) || '在当前时段不能查询超过' || trim(l_TimeSpan) || '个交易日的数据';
          pkgs_Log.Fatal(i_OperatorID, l_varSPName, o_varRetMsg);
          RETURN;
       END IF;
    END IF;

  EXCEPTION
    WHEN OTHERS THEN
      o_nRetCode := pkgs_constants.C_RET_FAIL;
      o_varRetMsg := '检查操作员' || TRIM(l_UserID) || '查询权限出错';
      pkgs_Log.Fatal(i_OperatorID, l_varSPName, o_varRetMsg);
  END up_ValidateUserQueryRight;

  ----验证系统状态
   PROCEDURE up_ValidateSystemStatus
  (
    o_nRetCode      OUT     PKGS_DataType.STY_RETCODE,            ---- 返回码
    o_varRetMsg     OUT     PKGS_DataType.STY_RETMSG,           ---- 返回信息
    i_BrokerID      IN      PKGS_DataType.STY_BrokerID,            ---- 经纪公司代码
    i_chExchangeID  IN      PKGS_DataType.STY_ExchangeID  ---- 交易所信息类型
  )
  AS
    l_Count                 INT;
    l_ProcessName           PKGS_DataType.STY_SpName;         ---- 存储过程名称
  BEGIN
    o_nRetCode := PKGS_Constants.C_RET_SUCCESS;
    l_ProcessName := 'PKGS_COMMON.up_ValidateSystemStatus';
    --CTP2限制过严，暂时放开检查，如有项目确实需要检查，请另做处理

    IF(PKGS_Common.uf_GetSysParamValue(PKGS_Constants.DEFAULT_BROKERID,'Y', PKGS_LOG.g_chOperatorID) = PKGS_Constants.C_ST_CTP2)THEN
      NULL;
    ---- 在交易所不活跃状态和结算初始化完成状态之间不允许做任何操作
    --SELECT COUNT(*)
    --INTO l_Count
    --FROM   t_SettleDate
    --WHERE  (SystemStatus = PKGS_Enums.ES_NonActive
    --   OR InitSettlement <> PKGS_Enums.SIS_Initialized)
    --  and  ExchangeID =nvl(i_chExchangeID, ExchangeID );
    --
    --IF l_Count = 0 THEN
    --  ---- 检查交易是否在结算状态下
    --  IF i_BrokerID IS NOT NULL AND i_BrokerID <> PKGS_Constants.DEFAULT_BROKERID THEN
    --    SELECT COUNT(*)
    --    INTO l_Count
    --    FROM   t_SettleDate
    --    WHERE  SystemStatus = PKGS_Enums.ES_Settlement
    --    and    ExchangeID  =nvl(i_chExchangeID, ExchangeID );
    --    IF l_Count > 0 THEN
    --      SELECT COUNT(*)
    --      INTO  l_Count
    --      FROM  t_SettleDate
    --      WHERE BrokerID = i_BrokerID
    --      AND   SettlementStatus = PKGS_Enums.STS_Settlementing
    --      AND    ExchangeID   =nvl(i_chExchangeID, ExchangeID );
    --      IF l_Count = 1 THEN
    --        o_nRetCode  := PKGS_Constants.C_RET_FAIL;
    --        o_varRetMsg := '交易所'||i_chExchangeID||'当前系统正在结算,请稍后再试';
    --      END IF;
    --    END IF;
    --  END IF;
    --ELSE
    --  o_nRetCode  := PKGS_Constants.C_RET_FAIL;
    --  o_varRetMsg := '交易所'||i_chExchangeID||'交易启动开始或者结算未完成初始化状态下,不允许做查询以外的工作';
    --END IF;
    ELSE
      ---- 在交易所不活跃状态和结算初始化完成状态之间不允许做任何操作
      SELECT COUNT(*)
        INTO l_count
        FROM t_settledate
       WHERE (systemstatus = pkgs_enums.es_nonactive OR
             initsettlement <> pkgs_enums.sis_initialized)
         AND exchangeid = pkgs_constants.DEFAULT_EXCHANGE
         AND brokerid = pkgs_constants.DEFAULT_BROKERID;----add by chen.lan 20180528

      IF l_Count = 0 THEN
        ---- 检查交易是否在结算状态下 systemstatus 是一致的，如果是结算状态，那么所有交易所都是结算状态；结算子状态是可以不同交易所，状态不同；
        IF i_BrokerID IS NOT NULL AND i_BrokerID <> PKGS_Constants.DEFAULT_BROKERID THEN
          SELECT COUNT(*)
            INTO l_count
            FROM t_settledate t
           WHERE systemstatus = pkgs_enums.es_settlement
             AND t.brokerid = i_brokerid ----add by chen.lan 20180528
             AND exchangeid   = pkgs_constants.DEFAULT_EXCHANGE;
          IF l_Count > 0 THEN
            SELECT COUNT(*)
              INTO l_count
              FROM t_settledate
             WHERE brokerid = i_brokerid
               AND (exchangeid = i_chExchangeID OR i_chExchangeID IS NULL OR i_chExchangeID=pkgs_constants.DEFAULT_EXCHANGE) ----add by chen.lan 20180528
               AND settlementstatus = pkgs_enums.sts_settlementing
               ;
            IF l_count > 0 THEN
              o_nretcode  := pkgs_constants.c_ret_fail;
              o_varretmsg :=  '当前系统正在结算,请稍后再试';
            END IF;
          END IF;
        END IF;
      ELSE
        o_nRetCode  := PKGS_Constants.C_RET_FAIL;
        o_varRetMsg := '交易启动开始或者结算未完成初始化状态下,不允许做查询以外的工作';
      END IF;
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      o_nRetCode  := PKGS_Constants.C_RET_FAIL;
      o_varRetMsg := '检查交易所当前状态出错';
  END up_ValidateSystemStatus;

  ---- 验证系统结算状态
  PROCEDURE up_ValidateSettleStatus
  (
     o_nRetCode      OUT     PKGS_DataType.STY_RETCODE,            ---- 返回码
    o_varRetMsg     OUT     PKGS_DataType.STY_RETMSG,           ---- 返回信息
    i_BrokerID      IN      PKGS_DataType.STY_BrokerID,            ---- 经纪公司代码
    i_chExchangeID  IN      PKGS_DataType.STY_ExchangeID DEFAULT '0000'  ---- 交易所信息类型
  )
  AS
    l_Count                 INT;
    l_ProcessName           PKGS_DataType.STY_SpName;         ---- 存储过程名称
    l_ExchStatus            t_SettleDate.SystemStatus%Type ;
    l_SettleStatus          t_SettleDate.SettlementStatus%Type;
    l_Tradingday            t_SettleDate.Settlementdate%Type;
    l_exchangeid            PKGS_DataType.STY_ExchangeID;
  BEGIN
    o_nRetCode :=  PKGS_Constants.C_RET_SUCCESS;
    l_ProcessName := 'PKGS_COMMON.up_ValidateSettleStatus';
    IF i_chExchangeID IS NULL THEN
      l_exchangeid :=  pkgs_constants.DEFAULT_EXCHANGE;
    ELSE
      l_exchangeid := i_chExchangeID;
    END IF;
    IF(PKGS_Common.uf_GetSysParamValue(PKGS_Constants.DEFAULT_BROKERID,'Y', PKGS_LOG.g_chOperatorID) = PKGS_Constants.C_ST_CTP2)THEN
      NULL;
    ELSE
      ----获取交易所状态
      SELECT SystemStatus,settlementdate
        INTO l_ExchStatus,l_Tradingday
        FROM t_settledate t
       WHERE exchangeid = pkgs_constants.DEFAULT_EXCHANGE
         AND t.brokerid = pkgs_constants.DEFAULT_brokerid;

      IF(l_ExchStatus <> pkgs_enums.ES_Initialized  AND l_ExchStatus <> pkgs_enums.ES_Settlement) THEN
          o_nRetCode  := PKGS_Constants.C_RET_FAIL;
          o_varRetMsg := '系统状态 不处于 交易完成初始化或者结算状态';----交易完成初始化，指的是可以交易的时间段；也就是交易和结算状态可以；
          RETURN ;
      END IF 	;

      IF(l_ExchStatus = pkgs_enums.ES_Settlement) THEN
        IF i_BrokerID IS NOT NULL AND i_BrokerID <> pkgs_constants.DEFAULT_BROKERID THEN
           ----获取 经纪公司结算状态
           SELECT SettlementStatus
             INTO l_SettleStatus
             FROM t_SettleDate
            WHERE BrokerID   =  i_BrokerID
              AND settlementdate = l_TradingDay
              AND exchangeid = l_exchangeid
              ;

            IF (l_SettleStatus <> pkgs_enums.STS_Initialize) THEN
              o_nRetCode  := PKGS_Constants.C_RET_FAIL;
              o_varRetMsg := '结算中或结算已经完成，不允许操作';
              Return ;
            END IF ;

         ELSE
             o_nRetCode  := PKGS_Constants.C_RET_FAIL;
             o_varRetMsg := '校验交易所当前结算状态失败';
             Return ;
         END IF;
      END IF;
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      o_nRetCode  := PKGS_Constants.C_RET_FAIL;
      o_varRetMsg := '校验交易所当前结算状态异常';
      PKGS_Utility.up_ProcessOthersError(l_ProcessName, o_nRetCode, o_varRetMsg);
  END up_ValidateSettleStatus;

  ---- 验证系统是否是盘中可交易状态
  PROCEDURE up_ValidateTradetatus
  (
     o_nRetCode      OUT     PKGS_DataType.STY_RETCODE,            ---- 返回码
    o_varRetMsg     OUT     PKGS_DataType.STY_RETMSG,           ---- 返回信息
    i_BrokerID      IN      PKGS_DataType.STY_BrokerID,            ---- 经纪公司代码
    i_chExchangeID  IN      PKGS_DataType.STY_ExchangeID DEFAULT '0000'  ---- 交易所信息类型
  )
  AS
    l_Count                 INT;
    l_ProcessName           PKGS_DataType.STY_SpName;         ---- 存储过程名称
    l_ExchStatus            t_SettleDate.SystemStatus%Type ;
    l_SettleStatus          t_SettleDate.SettlementStatus%Type;
    l_Tradingday            t_SettleDate.Settlementdate%Type;
    l_exchangeid            PKGS_DataType.STY_ExchangeID;
    l_brokerid              pkgs_datatype.STY_BrokerID;
  BEGIN
    o_nRetCode :=  PKGS_Constants.C_RET_SUCCESS;
    l_ProcessName := 'PKGS_COMMON.up_ValidateTradetatus';
    IF i_chExchangeID IS NULL THEN
      l_exchangeid :=  pkgs_constants.DEFAULT_EXCHANGE;
    ELSE
      l_exchangeid := i_chExchangeID;
    END IF;
    IF i_BrokerID IS NULL THEN
      l_brokerid :=  pkgs_constants.DEFAULT_brokerid;
    ELSE
      l_brokerid := i_BrokerID;
    END IF;
    SELECT COUNT(1)
      INTO l_count
      FROM t_settledate t
     WHERE t.systemstatus>=pkgs_enums.ES_Initialized ----交易初始化完成
       AND t.systemstatus <= pkgs_enums.ES_Closed  ----收市完成
       AND t.exchangeid = l_exchangeid
       AND l_brokerid =i_brokerid
    ;
    IF(l_Count>0) THEN
      o_nRetCode :=  PKGS_Constants.C_RET_SUCCESS;
      o_varRetMsg := NVL(i_chExchangeID,'系统总状态')||'当前是盘中可交易状态!';
    ELSE
      o_nRetCode :=  PKGS_Constants.C_RET_FAIL;
      o_varRetMsg := NVL(i_chExchangeID,'系统总状态')||'当前为不可交易状态!';
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      o_nRetCode  := PKGS_Constants.C_RET_FAIL;
      o_varRetMsg := '校验交易所当前是否是盘中可交易状态异常';
      PKGS_Utility.up_ProcessOthersError(l_ProcessName, o_nRetCode, o_varRetMsg);
  END ;
  ---- 验证产品代码是否有效
  PROCEDURE up_ValidateProduct
  (
    o_nRetCode      OUT     PKGS_DataType.STY_RETCODE,            ---- 返回码
    o_varRetMsg     OUT     PKGS_DataType.STY_RETMSG,           ---- 返回信息
    i_OperatorID    IN      PKGS_DATATYPE.STY_OperatorID,          ---- 操作员代码
    i_chExchangeID  IN      PKGS_DATATYPE.STY_ExchangeID,         ---- 交易所代码
    i_ProductID     IN      PKGS_DATATYPE.STY_ProductID,          ---- 产品代码
    i_ProductClass  IN      PKGS_DATATYPE.STY_EnumChar            ---- 产品类型
  )
  AS
    l_Count           INT;
    l_ProcessName     PKGS_DataType.STY_SpName;                             ---- 存储过程名称
  BEGIN
     o_nRetCode   := PKGS_Constants.C_RET_SUCCESS;
    l_ProcessName := 'PKGS_COMMON.up_ValidateProduct';

    ---- 验证产品代码是否有效
    SELECT COUNT(*)
    INTO l_Count
    FROM t_Product
    WHERE ProductLifePhase = PKGS_ENUMS.PLP_Active
    AND   ExchangeID       = i_chExchangeID
    AND   ProductID        = i_ProductID;

    IF i_ProductClass IS NULL THEN
       ---- 验证产品代码是否有效
      SELECT COUNT(*)
      INTO l_Count
      FROM t_Product
      WHERE ProductLifePhase = PKGS_ENUMS.PLP_Active
      AND   ExchangeID       = i_chExchangeID
      AND   ProductID        = i_ProductID
      AND   (ProductClass IN (PKGS_ENUMS.PC_Options,PKGS_ENUMS.PC_SpotOption) OR TRIM(i_ProductClass) IS NULL);  --20150625 he.hh 使不传入ProductClass的页面复核检验规则
      ---- 验证产品代码是否有效
      SELECT COUNT(*)+l_Count
      INTO l_Count
      FROM t_Product
      WHERE ProductLifePhase = PKGS_ENUMS.PLP_Active
      AND   ExchangeID       = i_chExchangeID
      AND   ProductID        = i_ProductID
      AND   (ProductClass = PKGS_ENUMS.PC_Futures OR TRIM(i_ProductClass) IS NULL); --20150625 he.hh 使不传入ProductClass的页面复核检验规则
      IF l_Count = 0 THEN
        o_nRetCode  := PKGS_Constants.C_RET_FAIL;
        o_varRetMsg := '交易所' || TRIM(i_chExchangeID) || ',产品' || TRIM(i_ProductID) || '不存在(必须为当前活跃的产品)';
      END IF;
    ELSIF i_ProductClass IN (PKGS_ENUMS.PC_Options,PKGS_ENUMS.PC_SpotOption) THEN
      ---- 验证产品代码是否有效
      SELECT COUNT(*)
      INTO l_Count
      FROM t_Product
      WHERE ProductLifePhase = PKGS_ENUMS.PLP_Active
      AND   ExchangeID       = i_chExchangeID
      AND   ProductID        = i_ProductID
      AND   (ProductClass IN (PKGS_ENUMS.PC_Options,PKGS_ENUMS.PC_SpotOption) OR TRIM(i_ProductClass) IS NULL);  --20150625 he.hh 使不传入ProductClass的页面复核检验规则
      IF l_Count = 0 THEN
        o_nRetCode  := PKGS_Constants.C_RET_FAIL;
        o_varRetMsg := '交易所' || TRIM(i_chExchangeID) || ',期权产品' || TRIM(i_ProductID) || '不存在(必须为当前活跃的期权产品)';
      END IF;
    ELSE
      ---- 验证产品代码是否有效
      SELECT COUNT(*)
      INTO l_Count
      FROM t_Product
      WHERE ProductLifePhase = PKGS_ENUMS.PLP_Active
      AND   ExchangeID       = i_chExchangeID
      AND   ProductID        = i_ProductID
      AND   (ProductClass = PKGS_ENUMS.PC_Futures OR TRIM(i_ProductClass) IS NULL); --20150625 he.hh 使不传入ProductClass的页面复核检验规则
      IF l_Count = 0 THEN
        o_nRetCode  := PKGS_Constants.C_RET_FAIL;
        o_varRetMsg := '交易所' || TRIM(i_chExchangeID) || ',期货产品' || TRIM(i_ProductID) || '不存在(必须为当前活跃的期货产品)';
      END IF;
    END IF;

  EXCEPTION
    WHEN OTHERS THEN
      o_nRetCode  := PKGS_Constants.C_RET_FAIL;
      o_varRetMsg := '检查交易所' || TRIM(i_chExchangeID) || ',产品' || TRIM(i_ProductID) || '是否存在出错';
      PKGS_Log.Fatal(i_OperatorID, l_ProcessName, o_varRetMsg);
  END up_ValidateProduct;

 ---- 验证合约代码是否有效
  PROCEDURE up_ValidateInstrument
  (
    o_nRetCode      OUT     PKGS_DataType.STY_RETCODE,            ---- 返回码
    o_varRetMsg     OUT     PKGS_DataType.STY_RETMSG,           ---- 返回信息
    i_OperatorID    IN      PKGS_DATATYPE.STY_OperatorID,          ---- 操作员代码
    i_chExchangeID  IN      PKGS_DATATYPE.STY_ExchangeID,         ---- 交易所代码
    i_InstrumentID  IN      PKGS_DATATYPE.STY_InstrumentID      ---- 合约代码
  )
  AS
    l_Count           INT;
    l_futCount        INT;
    l_ProcessName     PKGS_DataType.STY_SpName;         ---- 存储过程名称
  BEGIN
    o_nRetCode := PKGS_Constants.C_RET_SUCCESS;
    l_ProcessName := 'PKGS_COMMON.up_ValidateInstrument';

    ---- 验证合约代码是否有效
    SELECT COUNT(*)
    INTO l_Count
    FROM t_optinstrument
    WHERE InstLifePhase <> PKGS_Enums.IP_Expired
    AND   ExchangeID   = i_chExchangeID
    AND   InstrumentID = i_InstrumentID;

    SELECT COUNT(*)
    INTO l_futCount
    FROM t_futinstrument
    WHERE InstLifePhase <> PKGS_Enums.IP_Expired
    AND   ExchangeID   = i_chExchangeID
    AND   InstrumentID = i_InstrumentID;
    IF l_Count + l_futCount = 0 THEN
      o_nRetCode := PKGS_Constants.C_RET_FAIL;
      o_varRetMsg := '交易所' || TRIM(i_chExchangeID) || ',合约' || TRIM(i_InstrumentID) || '不存在(必须为当前未过期的合约代码)';
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      o_nRetCode := PKGS_Constants.C_RET_FAIL;
      o_varRetMsg := '检查交易所' || TRIM(i_chExchangeID) || ',合约' || TRIM(i_InstrumentID) || '是否存在出错';
      PKGS_Log.Fatal(i_OperatorID, l_ProcessName, o_varRetMsg);
  END up_ValidateInstrument;

  ---- 验证合约代码是否有效
  PROCEDURE up_ValidateInstrument
  (
    o_nRetCode      OUT     PKGS_DataType.STY_RETCODE,            ---- 返回码
    o_varRetMsg     OUT     PKGS_DataType.STY_RETMSG,           ---- 返回信息
    i_OperatorID    IN      PKGS_DATATYPE.STY_OperatorID,          ---- 操作员代码
    i_chExchangeID  IN      PKGS_DATATYPE.STY_ExchangeID,         ---- 交易所代码
    i_InstrumentID  IN      PKGS_DATATYPE.STY_InstrumentID,      ---- 合约代码
    i_ProductClass  IN      PKGS_DATATYPE.STY_EnumChar            ---- 产品类型
  )
  AS
    l_Count           INT;
    l_ProcessName     PKGS_DataType.STY_SpName;         ---- 存储过程名称
  BEGIN
    o_nRetCode := PKGS_Constants.C_RET_SUCCESS;
    l_ProcessName := 'PKGS_COMMON.up_ValidateInstrument';

   IF i_ProductClass IN (PKGS_ENUMS.PC_Options,PKGS_ENUMS.PC_SpotOption) THEN

      ---- 验证合约代码是否有效
      SELECT COUNT(*)
      INTO l_Count
      FROM t_optinstrument
      WHERE InstLifePhase <> PKGS_Enums.IP_Expired
      AND   ExchangeID   = i_chExchangeID
         AND (InstrumentID = i_InstrumentID OR TargetInstrid = i_InstrumentID);
   ELSE
       SELECT COUNT(*)
      INTO l_Count
      FROM t_futinstrument
      WHERE InstLifePhase <> PKGS_Enums.IP_Expired
      AND   ExchangeID   = i_chExchangeID
      AND   InstrumentID = i_InstrumentID;

   END  IF;

    IF l_Count  = 0 THEN
      o_nRetCode := PKGS_Constants.C_RET_FAIL;
      o_varRetMsg := '交易所' || TRIM(i_chExchangeID) || ',合约' || TRIM(i_InstrumentID) || '不存在(必须为当前未过期的合约代码)';
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      o_nRetCode := PKGS_Constants.C_RET_FAIL;
      o_varRetMsg := '检查交易所' || TRIM(i_chExchangeID) || ',合约' || TRIM(i_InstrumentID) || '是否存在出错';
      PKGS_Log.Fatal(i_OperatorID, l_ProcessName, o_varRetMsg);
  END up_ValidateInstrument;

  --- 验证合约代码是否有效
  PROCEDURE up_ValidateInstrumentID
  ( o_nRetCode         OUT PKGS_DataType.STY_RETCODE, ---- 返回码
    o_varRetMsg        OUT PKGS_DataType.STY_RETMSG, ---- 返回信息
    i_OperatorID       IN PKGS_DATATYPE.STY_OperatorID, ---- 操作员代码
    i_chExchangeID     IN PKGS_DATATYPE.STY_ExchangeID, ---- 交易所代码
    i_InstrumentID     IN PKGS_DATATYPE.STY_InstrumentID, ---- 合约代码
    i_ProductClass     IN PKGS_DATATYPE.STY_EnumChar, --- 产品类型
    i_IsCompInstrument IN PKGS_DATATYPE.STY_Bool ----是否包含组合合约
   )
   AS
  l_Count       INT;
  l_ProcessName PKGS_DataType.STY_SpName; ---- 存储过程名称
BEGIN
  o_nRetCode    := PKGS_Constants.C_RET_SUCCESS;
  l_ProcessName := 'PKGS_COMMON.up_ValidateInstrumentID';

  SELECT COUNT(*) --- 查看 期货表中是否存在
    INTO l_count
    FROM t_futinstrument
   WHERE InstLifePhase <> PKGS_Enums.IP_Expired
     AND (i_chExchangeID IS NULL OR (length(TRIM(i_chExchangeID)) = 0) OR
         ExchangeID = i_chExchangeID)
     AND InstrumentID = i_InstrumentID
     AND (i_ProductClass = PKGS_ENUMS.PC_Futures OR i_ProductClass IS NULL); ---  当传入的产品类型为期货或者为空时
  IF l_count <> 0 -- 期货合约表中存在则返回
   THEN
    RETURN;
  END IF;

  SELECT COUNT(*) --- 查看期权表中是否存在
    INTO l_count
    FROM t_optinstrument
   WHERE InstLifePhase <> PKGS_Enums.IP_Expired
     AND (i_chExchangeID IS NULL OR (length(TRIM(i_chExchangeID)) = 0) OR
         ExchangeID = i_chExchangeID)
     AND InstrumentID = i_InstrumentID
     AND ((i_ProductClass IN
         (PKGS_ENUMS.PC_Options, PKGS_ENUMS.PC_SpotOption)) OR
         i_ProductClass IS NULL); ---  当传入的产品类型为期权或者为空时
  IF l_count <> 0 -- 期权合约表中存在则返回
   THEN
    RETURN;
  END IF;
   -- 查看产品表中是否有当前i_InstrumentID
   IF i_ProductClass =  PKGS_ENUMS.PC_Options  ---  传入的产品类型为期权时，可能分为现货期权或者期货期权
      THEN
        SELECT COUNT(1) --- 先查看产品表中是否存在当前产品
        INTO l_count
        FROM T_PRODUCT
        WHERE (i_chExchangeID IS NULL OR (length(TRIM(i_chExchangeID)) = 0) OR
            ExchangeID = i_chExchangeID)
        AND PRODUCTID = i_InstrumentID
        AND PRODUCTLIFEPHASE = PKGS_ENUMS.PLP_Active
        AND (PRODUCTCLASS IN (PKGS_ENUMS.PC_Options, PKGS_ENUMS.PC_SpotOption));
    ELSE   -- 传入的产品类型为空，或者为期货
        SELECT COUNT(1) --- 先查看产品表中是否存在当前产品
        INTO l_count
        FROM T_PRODUCT
        WHERE (i_chExchangeID IS NULL OR (length(TRIM(i_chExchangeID)) = 0) OR
            ExchangeID = i_chExchangeID)
        AND PRODUCTID = i_InstrumentID
        AND PRODUCTLIFEPHASE = PKGS_ENUMS.PLP_Active
        AND (i_ProductClass IS NULL OR (i_ProductClass=PKGS_ENUMS.PC_Futures AND PRODUCTCLASS = i_ProductClass ) );
    END IF ;
    IF l_count <> 0 -- 产品表中存在则返回
    THEN
       RETURN;
    END IF;
  IF i_IsCompInstrument = PKGS_CONSTANTS.C_BOOL_TRUE THEN
    ---- 验证是否组合产品
    SELECT COUNT(*)
      INTO l_Count
      FROM t_cominstrument
     WHERE (i_chExchangeID IS NULL OR (length(TRIM(i_chExchangeID)) = 0) OR
           ExchangeID = i_chExchangeID)
       AND productid = i_InstrumentID;
    IF l_Count <> 0 THEN
      RETURN;
    END IF;

    ---- 验证是否组合合约
    SELECT COUNT(*)
      INTO l_Count
      FROM t_cominstrument
     WHERE (i_chExchangeID IS NULL OR (length(TRIM(i_chExchangeID)) = 0) OR
           ExchangeID = i_chExchangeID)
       AND InstrumentID = i_InstrumentID;
    IF l_Count <> 0 THEN
      RETURN;
    END IF;
  END IF;
  o_nRetCode  := PKGS_Constants.C_RET_FAIL; --如果前面几个表中都没有 ，那么返回失败信息
  o_varRetMsg := '交易所' || TRIM(i_chExchangeID) || ',合约' ||
                 TRIM(i_InstrumentID) || '不存在(必须为当前未过期的合约代码)';
EXCEPTION
  WHEN OTHERS THEN
    o_nRetCode  := PKGS_Constants.C_RET_FAIL;
    o_varRetMsg := '检查交易所' || TRIM(i_chExchangeID) || ',合约' ||
                   TRIM(i_InstrumentID) || '是否存在出错';
    PKGS_Log.Fatal(i_OperatorID, l_ProcessName, o_varRetMsg);
END up_ValidateInstrumentID;

  --- 交易权限:验证产品、组合产品、合约、组合合约的有效性
  PROCEDURE up_ValidateInstrumentIDAll
  ( o_nRetCode         OUT PKGS_DataType.STY_RETCODE, ---- 返回码
    o_varRetMsg        OUT PKGS_DataType.STY_RETMSG, ---- 返回信息
    i_OperatorID       IN PKGS_DATATYPE.STY_OperatorID, ---- 操作员代码
    i_chExchangeID     IN PKGS_DATATYPE.STY_ExchangeID, ---- 交易所代码
    i_InstrumentID     IN PKGS_DATATYPE.STY_InstrumentID, ---- 合约代码
    i_ProductClass     IN PKGS_DATATYPE.STY_EnumChar, --- 产品类型
    i_IsCompInstrument IN PKGS_DATATYPE.STY_Bool ----是否包含组合合约
   )
   AS
  l_Count       INT;
  l_ProcessName PKGS_DataType.STY_SpName; ---- 存储过程名称
BEGIN
  o_nRetCode    := PKGS_Constants.C_RET_SUCCESS;
  l_ProcessName := 'PKGS_COMMON.up_ValidateInstrumentIDAll';

  SELECT COUNT(*) --- 查看 期货表中是否存在
    INTO l_count
    FROM t_futinstrument
   WHERE InstLifePhase <> PKGS_Enums.IP_Expired
     AND (i_chExchangeID IS NULL OR (length(TRIM(i_chExchangeID)) = 0) OR
         ExchangeID = i_chExchangeID)
     AND InstrumentID = i_InstrumentID
     AND (i_ProductClass = PKGS_ENUMS.PC_Futures OR i_ProductClass IS NULL); ---  当传入的产品类型为期货或者为空时
  IF l_count <> 0 -- 期货合约表中存在则返回
   THEN
    RETURN;
  END IF;

  SELECT COUNT(*) --- 查看期权表中是否存在
    INTO l_count
    FROM t_optinstrument
   WHERE InstLifePhase <> PKGS_Enums.IP_Expired
     AND (i_chExchangeID IS NULL OR (length(TRIM(i_chExchangeID)) = 0) OR
         ExchangeID = i_chExchangeID)
     AND InstrumentID = i_InstrumentID
     AND ((i_ProductClass IN
         (PKGS_ENUMS.PC_Options, PKGS_ENUMS.PC_SpotOption)) OR
         i_ProductClass IS NULL); ---  当传入的产品类型为期权或者为空时
  IF l_count <> 0 -- 期权合约表中存在则返回
   THEN
    RETURN;
  END IF;
   -- 查看产品表中是否有当前i_InstrumentID
   IF i_ProductClass =  PKGS_ENUMS.PC_Options  ---  传入的产品类型为期权时，可能分为现货期权或者期货期权
      THEN
        SELECT COUNT(1) --- 先查看产品表中是否存在当前产品
        INTO l_count
        FROM T_PRODUCT
        WHERE (i_chExchangeID IS NULL OR (length(TRIM(i_chExchangeID)) = 0) OR
            ExchangeID = i_chExchangeID)
        AND PRODUCTID = i_InstrumentID
        AND PRODUCTLIFEPHASE = PKGS_ENUMS.PLP_Active
        AND (PRODUCTCLASS IN (PKGS_ENUMS.PC_Options, PKGS_ENUMS.PC_SpotOption));
    ELSE   -- 传入的产品类型为空，或者为期货
        SELECT COUNT(1) --- 先查看产品表中是否存在当前产品
        INTO l_count
        FROM T_PRODUCT
        WHERE (i_chExchangeID IS NULL OR (length(TRIM(i_chExchangeID)) = 0) OR
            ExchangeID = i_chExchangeID)
        AND PRODUCTID = i_InstrumentID
        AND PRODUCTLIFEPHASE = PKGS_ENUMS.PLP_Active
        AND (i_ProductClass IS NULL OR (i_ProductClass=PKGS_ENUMS.PC_Futures AND PRODUCTCLASS = i_ProductClass ) );
    END IF ;
    IF l_count <> 0 -- 产品表中存在则返回
    THEN
       RETURN;
    END IF;
  IF i_IsCompInstrument = PKGS_CONSTANTS.C_BOOL_TRUE THEN
    ---- 郑商所STD和STG组合产品和组合合约t_cominstrument里不会回写，所有这里单独写出来
    IF (TRIM(i_chExchangeID) = TRIM(Pkgs_Constants.C_EXCHANGEID_CZCE) AND (TRIM(i_InstrumentID) LIKE 'STD%' OR TRIM(i_InstrumentID) LIKE 'STG%')) THEN
      SELECT COUNT(*)
        INTO l_Count
        FROM t_comproduct
       WHERE ExchangeID = i_chExchangeID
         AND TRIM(ComProductID) = TRIM(REGEXP_REPLACE(i_InstrumentID, '[[:digit:]]', '')） --判断组合合约，组合合约的产品类型与组合产品设置的类型应该一样
         AND (i_ProductClass IS NULL OR COMPRODUCTCLASS = i_ProductClass )--前台传入的类型与组合产品表中的类型应该要匹配
         ;
      IF l_Count <> 0 THEN
        RETURN;
      END IF;
    END IF;
    ---- 验证是否组合产品,新增了t_comproduct维护组合产品，这里校验取该表的数据
    SELECT COUNT(*)
      INTO l_Count
      FROM t_comproduct
     WHERE (i_chExchangeID IS NULL OR (length(TRIM(i_chExchangeID)) = 0) OR
           ExchangeID = i_chExchangeID)
       AND TRIM(ComProductID) = TRIM(i_InstrumentID)
       AND (i_ProductClass IS NULL OR COMPRODUCTCLASS = i_ProductClass ) --前台传的产品类型要与组合产品表中的设置匹配才允许
       ;
    IF l_Count <> 0 THEN
      RETURN;
    END IF;

    ---- 验证是否组合合约
    SELECT COUNT(*)
      INTO l_Count
      FROM t_cominstrument t
     WHERE (i_chExchangeID IS NULL OR (length(TRIM(i_chExchangeID)) = 0) OR
           ExchangeID = i_chExchangeID)
       AND TRIM(InstrumentID) = TRIM(i_InstrumentID)
       AND (i_ProductClass IS NULL
            OR (i_ProductClass =PKGS_ENUMS.PC_Options AND productclass IN (PKGS_ENUMS.PC_Options, PKGS_ENUMS.PC_SpotOption))
            OR (i_ProductClass =PKGS_ENUMS.PC_Futures AND productclass NOT IN (PKGS_ENUMS.PC_Options, PKGS_ENUMS.PC_SpotOption,PKGS_ENUMS.PC_Combination) )
            OR ( productclass =PKGS_ENUMS.PC_Combination  AND EXISTS(
                                                                      SELECT 1
                                                                      FROM   t_comproduct t1
                                                                      WHERE  t1.exchangeid = i_chExchangeID
                                                                      AND    TRIM(t1.comproductid)  = TRIM(REGEXP_REPLACE(i_InstrumentID, '[[:digit:]]', ''))
                                                                      AND    t1.comproductclass = i_ProductClass
                                                                      )
              )
        );
    IF l_Count <> 0 THEN
      RETURN;
    END IF;
  END IF;
  o_nRetCode  := PKGS_Constants.C_RET_FAIL; --如果前面几个表中都没有 ，那么返回失败信息
  o_varRetMsg := '交易所' || TRIM(i_chExchangeID) || ',合约' ||
                 TRIM(i_InstrumentID) || '不存在(必须为当前未过期的合约代码)';
EXCEPTION
  WHEN OTHERS THEN
    o_nRetCode  := PKGS_Constants.C_RET_FAIL;
    o_varRetMsg := '检查交易所' || TRIM(i_chExchangeID) || ',合约' ||
                   TRIM(i_InstrumentID) || '是否存在出错';
    PKGS_Log.Fatal(i_OperatorID, l_ProcessName, o_varRetMsg);
END up_ValidateInstrumentIDAll;


   ---- 验证组合合约代码是否有效（中金所），added by zhang.cb
  PROCEDURE up_ValidateCombInstrument
  (
    o_nRetCode                    OUT     PKGS_DataType.STY_RETCODE,            ---- 返回码
    o_varRetMsg                   OUT     PKGS_DataType.STY_RETMSG,           ---- 返回信息
    i_OperatorID                  IN      PKGS_DATATYPE.STY_OperatorID,         ---- 操作员代码
    i_chExchangeID                IN      PKGS_DATATYPE.STY_ExchangeID,         ---- 交易所代码
    i_InstrumentID                IN      PKGS_DATATYPE.STY_InstrumentID      ---- 合约代码
  )
  AS
    l_FutCount           INT;
    l_OptCount           INT;
    l_Count              INT;
    l_varSPName      t_Operationlog.ProcessName%TYPE := 'PKGS_Common.up_ValidateCombInstrument';                            ---- 存储过程名称
    l_ComInstr        CHAR(30);
    l_FutInstrument      t_FutInstrument%ROWTYPE;
    l_OptInstrument      t_OptInstrument%ROWTYPE;
    l_End             INT;
  BEGIN
    o_nRetCode := PKGS_Constants.C_RET_SUCCESS;

    l_ComInstr := i_InstrumentID;
    l_End   := INSTR(l_ComInstr, '&', 1, 1);
    IF l_End <= 0 THEN
      o_nRetCode := pkgs_constants.C_RET_FAIL;
      o_varRetMsg := '不存在中金所组合合约' || TRIM(i_InstrumentID);
      RETURN;
    END IF;

    WHILE l_ComInstr IS NOT NULL LOOP
      l_End   := INSTR(l_ComInstr, '&', 1, 1);
      IF l_End > 0 THEN
        l_FutInstrument.Instrumentid := SUBSTR(l_ComInstr,0,l_End - 1);
        l_OptInstrument.Instrumentid := SUBSTR(l_ComInstr,0,l_End - 1);
        l_ComInstr := SUBSTR(l_ComInstr,l_End + 1);
      ELSE
        l_FutInstrument.Instrumentid := l_ComInstr;
        l_OptInstrument.Instrumentid := l_ComInstr;
        l_ComInstr := NULL;
      END IF;

      ---- 验证中金所组合单腿代码是否为合约代码
      SELECT COUNT(*)
      INTO l_FutCount
      FROM t_FutInstrument
      WHERE ExchangeID   = i_chExchangeID
      AND   InstrumentID = l_FutInstrument.Instrumentid
      AND   InstLifePhase <> PKGS_Constants.IP_Expired;

      SELECT COUNT(*)
      INTO l_OptCount
      FROM t_OptInstrument
      WHERE ExchangeID   = i_chExchangeID
      AND   InstrumentID = l_FutInstrument.Instrumentid
      AND   InstLifePhase <> PKGS_Constants.IP_Expired;

      IF (l_OptCount+l_FutCount) = 0 THEN ---- 产品组合
         ----- 验证中金所组合单腿代码是否为产品代码
    	   SELECT COUNT(*)
    	   INTO l_Count
    	   FROM t_Product
    	   WHERE ExchangeID   = i_chExchangeID
    	   AND   ProductID = l_FutInstrument.Instrumentid;
         IF l_Count = 0 THEN
            o_nRetCode := pkgs_constants.C_RET_FAIL;
            o_varRetMsg := '不存在中金所组合合约' || TRIM(i_InstrumentID);
            RETURN;
         END IF;
      END IF;
    END LOOP;

  EXCEPTION
    WHEN OTHERS THEN
      o_nRetCode := pkgs_constants.C_RET_FAIL;
      o_varRetMsg := '检查中金所组合合约' || TRIM(i_InstrumentID) || '出错';
      pkgs_Log.Fatal(pkgs_log.g_chOperatorID, l_varSPName, o_varRetMsg);
  END up_ValidateCombInstrument;

  PROCEDURE up_CheckNull
  (
    o_nRetCode      OUT    PKGS_DataType.STY_RETCODE,             ---- 返回码
    o_varRetMsg     OUT    PKGS_DataType.STY_RETMSG,           ---- 返回信息
    i_FieldValue    IN      NUMBER                              ---- 字段值
  )
  AS
  BEGIN
    o_nRetCode := PKGS_Constants.C_RET_SUCCESS;
    IF i_FieldValue IS NULL THEN
      o_varRetMsg :=  PKGS_Constants.C_RET_FAIL;
    END IF;
  END up_CheckNull;


  PROCEDURE up_CheckNull
  (
    o_nRetCode      OUT    PKGS_DataType.STY_RETCODE,             ---- 返回码
    o_varRetMsg     OUT    PKGS_DataType.STY_RETMSG,           ---- 返回信息
    i_FieldValue    IN      VARCHAR2                              ---- 字段值
  )
  AS
  BEGIN
    o_nRetCode := PKGS_Constants.C_RET_SUCCESS;
    IF i_FieldValue IS NULL THEN
      o_varRetMsg :=  PKGS_Constants.C_RET_FAIL;
    END IF;
  END up_CheckNull;

  ---- 获取系统参数
  PROCEDURE up_QrySysSettleParam
  (
    i_ExchangeID 	  						  IN  		PKGS_DataType.STY_BrokerID,								 ----交易所代码
    i_BrokerID      							IN      PKGS_DATATYPE.STY_BrokerID,             	 ---- 经纪公司代码
    i_SysSettleParamID            IN      t_SysSettleParam.SYSTEMPARAMID%TYPE,       ---- 系统参数代码
    i_OperatorID                  IN      PKGS_DATATYPE.STY_OperatorID,              ---- 操作员代码
    o_nCount     									OUT     INT,                                			 ---- 记录数
    o_SysSettleParamValue         OUT     t_SysSettleParam.SYSTEMPARAMVALUE%TYPE,    ---- 文件位置
    o_nRetCode                    OUT     PKGS_DataType.STY_RETCODE,                 ---- 返回码
    o_varRetMsg                   OUT     PKGS_DataType.STY_RETMSG                   ---- 返回信息
  )AS
    l_ProcessName     PKGS_DataType.STY_SpName;                             ---- 存储过程名称
  BEGIN
    o_nRetCode := PKGS_Constants.C_RET_SUCCESS;
    l_ProcessName := 'PKGS_COMMON.up_QrySysSettleParam';

		SELECT COUNT(1)
    INTO o_nCount
    FROM t_exchangesettleparam
    WHERE  EXCHANGEID= i_ExchangeID
    AND BrokerID = i_BrokerID
    AND   SETTLEMENTPARAMID = i_SysSettleParamID;

		IF o_nCount=1 THEN
      SELECT SETTLEMENTPARAMVALUE
      INTO o_SysSettleParamValue
      FROM t_exchangesettleparam
      WHERE  EXCHANGEID= i_ExchangeID
      AND BrokerID = i_BrokerID
      AND   SETTLEMENTPARAMID = i_SysSettleParamID;
    ELSE
    	o_nRetCode := PKGS_Constants.C_RET_FAIL;
      o_varRetMsg := '获取系统参数出错！';
  	END IF;

    PKGS_Log.Info(i_OperatorID, l_ProcessName, o_varRetMsg);
  EXCEPTION
    WHEN OTHERS THEN
      o_nRetCode := PKGS_Constants.C_RET_FAIL;
      o_varRetMsg := '获取系统参数';
      PKGS_Log.Fatal(i_OperatorID, l_ProcessName, o_varRetMsg);
  END up_QrySysSettleParam;

    PROCEDURE up_ValidateInvestor
  (
    o_ReturnNo              OUT     PKGS_DataType.STY_RETCODE,            ---- 返回码
    o_ReturnMsg             OUT     PKGS_DataType.STY_RETMSG,           ---- 返回信息
    i_OperatorID            IN      PKGS_DataType.STY_OperatorID,          ---- 操作员代码
    i_BrokerID              IN      t_Broker.BrokerID%TYPE,             ---- 经纪公司代码
    i_InvestorID            IN      t_Investor.InvestorID%TYPE,         ---- 投资者代码
    I_InvestUnitID          in       PKGS_DataType.STY_InvestUnitID default NULL       ----投资单元代码
  )
  AS
    l_Count           INT;
    l_ProcessName     PKGS_DataType.STY_ProcessName;                       ---- 存储过程名称
  BEGIN
    l_ProcessName := 'pkg_Validate.up_ValidateInvestor';

    IF i_InvestorID IS NOT NULL THEN
      SELECT COUNT(*)
      INTO l_Count
      FROM t_Investor
      WHERE BrokerID   = i_BrokerID
      AND   InvestorID = i_InvestorID;
      IF l_Count = 0 THEN
        o_ReturnNo  := PKGS_Constants.C_RET_FAIL;
        o_ReturnMsg := '投资者代码' || TRIM(i_InvestorID) || '不存在';
        RETURN;
      ELSIF   i_InvestUnitID IS NOT NULL AND i_InvestUnitID != i_InvestorID THEN
         SELECT COUNT(*)
		      INTO l_Count
		      FROM t_investunit
		      WHERE BrokerID   = i_BrokerID
		      AND   InvestorID = i_InvestorID
		      AND   InvestUnitID=i_InvestUnitID;
         IF l_Count = 0 THEN
			        o_ReturnNo  := PKGS_Constants.C_RET_FAIL;
			        o_ReturnMsg := '投资单元代码' || TRIM(i_InvestUnitID) || '不存在';
			        RETURN;
			   END IF;
      END IF;
    END IF;
    o_ReturnNo  := PKGS_Constants.C_S_OK;
    o_ReturnMsg := '投资者代码' || TRIM(i_InvestorID) || '，投资单元代码' || TRIM(i_InvestUnitID) || '存在';
  EXCEPTION
    WHEN OTHERS THEN
      o_ReturnNo  := PKGS_Constants.C_RET_FAIL;
      o_ReturnMsg := '验证投资者' || TRIM(i_InvestorID) || '是否存在出错';
      pkgs_Log.up_info(i_OperatorID, l_ProcessName);
  END up_ValidateInvestor;

  ---- 获取操作员有权限的单一投资者及投资单元
  PROCEDURE up_GenDepartmentInvestor
  (
    o_ReturnNo           OUT     PKGS_DataType.STY_RETCODE,            ---- 返回码
    o_ReturnMsg          OUT     PKGS_DataType.STY_RETMSG,           ---- 返回信息
    i_OperatorID         IN      PKGS_DATATYPE.STY_OPERATORID,       ---- 操作员代码
    i_BrokerID           IN      PKGS_DATATYPE.STY_BROKERID,         ---- 经纪公司代码
    i_InvestorID         IN      t_Investor.InvestorID%TYPE,         ---- 投资者代码
    i_InvestorType       IN      t_Investor.investorType%Type,       ---- 投资者类型
    i_partyString        IN      PKGS_DATATYPE.STY_InvstParty        ---- 投资者属性
  )
  AS
   l_ProcessName     PKGS_DataType.STY_SpName;
   l_count           NUMBER;
   l_UserID          t_brokeruser.UserID%TYPE;
  BEGIN
    o_ReturnNo := PKGS_Constants.C_S_OK ;
    l_ProcessName := 'PKGS_COMMON.up_GenDepartmentInvestor';

    IF TRIM(i_OperatorID) IS NULL THEN
       o_ReturnNo := PKGS_Constants.C_RET_FAIL;
       o_ReturnMsg := '操作员不能为空';
       PKGS_Log.Fatal(i_OperatorID, l_ProcessName, o_ReturnMsg);
       RETURN;
    END IF ;

    l_UserID := SUBSTR(TRIM(i_OperatorID), INSTR(TRIM(i_OperatorID), '.') + 1) ;

    DELETE FROM TMP_DepartMentInvestor
    WHERE BrokerID =  i_BrokerID ;

    IF PKGS_Common.uf_GetIsDefaultDepartMent(i_BrokerID,i_OperatorID) = PKGS_Constants.C_BOOL_TRUE THEN
       ---- user对所有数据都有权限
       INSERT INTO TMP_DepartMentInvestor(BrokerID ,UserID ,InvestorRange,InvestorID )
       SELECT BrokerID,l_UserID,PKGS_Enums.DR_Single,InvestorID
       FROM  t_Investor
       WHERE  BrokerID = i_BrokerID
       AND (TRIM(i_INvestorID) IS NULL OR investorid = i_InvestorID)
       AND (TRIM(i_INvestorType) IS NULL OR investorType = i_INvestorType)
       /*UNION -- bug CTP2-2421
       SELECT BrokerID,l_UserID,PKGS_Enums.DR_Single,InvestorID
       FROM  t_O_Investor
       WHERE  BrokerID = i_BrokerID
       AND (TRIM(i_INvestorID) IS NULL OR investorid = i_InvestorID)
       AND (TRIM(i_INvestorType) IS NULL OR investorType = i_INvestorType)*/;
    ELSE
    	  ---- 单一投资单元
       INSERT INTO TMP_DepartMentInvestor(BrokerID ,UserID,InvestorRange,InvestorID,InvestUnitID)
       SELECT BrokerID,UserID,PKGS_Enums.DR_Single,InvestorID,t.InvestUnitID
       FROM t_departmentuser t
       WHERE t.Brokerid = i_BrokerID
       AND   t.Userid = l_UserID
       AND   InvestorRange = PKGS_Enums.DR_Single
       AND   t.investorid <> t.investunitid
       AND   (TRIM(i_INvestorID) IS NULL OR investorid = i_InvestorID);
       ---- 单一投资者
       INSERT INTO TMP_DepartMentInvestor(BrokerID ,UserID  ,InvestorRange,InvestorID )
       SELECT BrokerID,UserID,PKGS_Enums.DR_Single,InvestorID
       FROM  t_departmentuser t
       WHERE  BrokerID = i_BrokerID
       AND  UserID   = l_UserID
       AND  InvestorRange = PKGS_Enums.DR_Single
       AND  t.investorid = t.investunitid
       AND (TRIM(i_INvestorID) IS NULL OR investorid = i_InvestorID)
       UNION  ---- 非'00'组织架构
       SELECT BrokerID,l_UserID,PKGS_Enums.DR_Single,InvestorID
       FROM  t_Investor  a
       WHERE  BrokerID = i_BrokerID
       AND (TRIM(i_InvestorID) IS NULL OR InvestorID = i_InvestorID)
       AND (TRIM(i_investorType) IS NULL OR investorType = i_investorType)
       AND  EXISTS ( SELECT 1 FROM t_departmentuser b
                     WHERE a.BrokerID = b.BrokerID
                     AND TRIM(a.DepartMentID)LIKE TRIM(b.InvestorID)||'%'
                     AND b.UserID        = l_userID
                     AND b.InvestorRange = PKGS_Enums.DR_Group
                     AND b.InvestorID   != PKGS_Constants.DEFAULT_BrokerDepartMentID
                    )
       /*UNION  ---- 非'00'组织架构
       SELECT BrokerID,l_UserID,PKGS_Enums.DR_Single,InvestorID
       FROM  t_O_Investor  a
       WHERE  BrokerID = i_BrokerID
       AND (TRIM(i_InvestorID) IS NULL OR InvestorID = i_InvestorID)
       AND (TRIM(i_investorType) IS NULL OR investorType = i_investorType)
       AND  EXISTS ( SELECT 1 FROM t_departmentuser b
                     WHERE a.BrokerID = b.BrokerID
                     AND TRIM(a.DepartMentID)LIKE TRIM(b.InvestorID)||'%'
                     AND b.UserID        = l_userID
                     AND b.InvestorRange = PKGS_Enums.DR_Group
                     AND b.InvestorID   != PKGS_Constants.DEFAULT_BrokerDepartMentID
                    )*/ ;
       IF i_InvestorType IS NOT NULL THEN
           DELETE FROM TMP_DepartMentInvestor a
           WHERE NOT EXISTS(SELECT 1 FROM t_investor b
                            WHERE a.brokerid = b.brokerid
                            AND a.investorid = b.investorid
                            AND investorType = i_INvestorType);
       END IF;
    END IF ;

    ---- 按属性剔除投资者
    IF TRIM(i_PartyString) IS NOT NULL THEN
       Pkgs_Common.up_GenPartyInvestor(o_ReturnNo, o_ReturnMsg ,pkgs_log.g_chOperatorID ,i_BrokerID,i_PartyString);
    END IF;
    ---- 剔除黑名单投资者
    up_DelBlacklist(i_BrokerID,l_UserID);

    o_ReturnMsg := '获取操作员查询权限的投资者到临时表成功';
  EXCEPTION
    WHEN OTHERS THEN
      o_ReturnNo := PKGS_Constants.C_RET_FAIL;
      o_ReturnMsg := '获取操作员查询权限的投资者到临时表失败';
      PKGS_Log.Fatal(i_OperatorID, l_ProcessName, o_ReturnMsg);
  END up_GenDepartmentInvestor;


  /* 与up_GenDepartmentInvestor不同之处:
     补足了TMP_DepartMentInvestor.propertyID和TMP_DepartMentInvestor.propertyName两个字段
     CTPII00293 20190514
  */
  PROCEDURE up_GenDepartmentInvestor2
  (
    o_ReturnNo           OUT     PKGS_DataType.STY_RETCODE,            ---- 返回码
    o_ReturnMsg          OUT     PKGS_DataType.STY_RETMSG,           ---- 返回信息
    i_OperatorID         IN      PKGS_DATATYPE.STY_OPERATORID,       ---- 操作员代码
    i_BrokerID           IN      PKGS_DATATYPE.STY_BROKERID,         ---- 经纪公司代码
    i_InvestorID         IN      t_Investor.InvestorID%TYPE,         ---- 投资者代码
    i_InvestorType       IN      t_Investor.investorType%Type,       ---- 投资者类型
    i_partyString        IN      PKGS_DATATYPE.STY_InvstParty        ---- 投资者属性
  )
  AS
   l_ProcessName     PKGS_DataType.STY_SpName;
   l_UserID          t_brokeruser.UserID%TYPE;
  BEGIN
    o_ReturnNo := PKGS_Constants.C_S_OK ;
    l_ProcessName := 'PKGS_COMMON.up_GenDepartmentInvestor2';

    IF TRIM(i_OperatorID) IS NULL THEN
       o_ReturnNo := PKGS_Constants.C_RET_FAIL;
       o_ReturnMsg := '操作员不能为空';
       PKGS_Log.Fatal(i_OperatorID, l_ProcessName, o_ReturnMsg);
       RETURN;
    END IF ;

    l_UserID := SUBSTR(TRIM(i_OperatorID), INSTR(TRIM(i_OperatorID), '.') + 1) ;

    DELETE FROM TMP_DepartMentInvestor
    WHERE BrokerID =  i_BrokerID ;

    IF PKGS_Common.uf_GetIsDefaultDepartMent(i_BrokerID,i_OperatorID) = PKGS_Constants.C_BOOL_TRUE THEN
       ---- user对所有数据都有权限(00、经纪公司管理员、超管)
       INSERT INTO tmp_departmentinvestor
         (brokerid,
          userid,
          investorrange,
          investorid,
          propertyid,
          propertyname)
         SELECT i_brokerid,
                l_userid,
                pkgs_enums.dr_single,
                t.investorid,
                listagg(TRIM(t2.partyid), ',') WITHIN GROUP (ORDER BY t2.partyid),
                listagg(TRIM(t2.partyname), ',') WITHIN GROUP (ORDER BY t2.partyname)
                --Modified by wang.chao 2019/07/08 优化查询速度
                --wmsys.wm_concat(TRIM(t2.partyid)),
                --wmsys.wm_concat(TRIM(t2.partyname))
           FROM (SELECT brokerid AS brokerid, investorid AS investorid
                   FROM t_investor
                  WHERE brokerid = i_brokerid
                    AND (TRIM(i_investorid) IS NULL OR
                        investorid = i_investorid)
                    AND (TRIM(i_investortype) IS NULL OR
                        investortype = i_investortype)
                 /*UNION bug CTP2-2421
                 SELECT brokerid AS brokerid, investorid AS investorid
                   FROM t_o_investor
                  WHERE brokerid = i_brokerid
                    AND (TRIM(i_investorid) IS NULL OR
                        investorid = i_investorid)
                    AND (TRIM(i_investortype) IS NULL OR
                        investortype = i_investortype)*/) t
           LEFT JOIN (SELECT tm.brokerid   AS brokerid,
                             tm.investorid AS investorid,
                             tm.partyid    AS partyid,
                             tp.partyname  AS partyname
                        FROM t_investorpartymap tm, t_party tp
                       WHERE tm.brokerid = tp.brokerid
                         AND tm.partyid = tp.partyid) t2
             ON t.brokerid = t2.brokerid
            AND t.investorid = t2.investorid
          GROUP BY t.brokerid, t.investorid;
    ELSE
       ---- 单一投资单元
       INSERT INTO tmp_departmentinvestor
         (brokerid,
          userid,
          investorrange,
          investorid,
          investunitid,
          propertyid,
          propertyname)
         SELECT i_brokerid,
                l_userid,
                pkgs_enums.dr_single,
                t1.investorid,
                t1.investunitid,
                listagg(TRIM(t2.partyid), ',') WITHIN GROUP (ORDER BY t2.partyid),
                listagg(TRIM(t2.partyname), ',') WITHIN GROUP (ORDER BY t2.partyname)
                --Modified by wang.chao 2019/07/08 优化查询速度
                --wmsys.wm_concat(TRIM(t2.partyid)),
                --wmsys.wm_concat(TRIM(t2.partyname))
           FROM (SELECT t.brokerid     AS brokerid,
                        t.investorid   AS investorid,
                        t.investunitid AS investunitid
                   FROM t_departmentuser t
                  WHERE t.brokerid = i_brokerid
                    AND t.userid = l_userid
                    AND investorrange = pkgs_enums.dr_single
                    AND t.investorid <> t.investunitid
                    AND (TRIM(i_investorid) IS NULL OR
                        investorid = i_investorid)) t1
           LEFT JOIN (SELECT tm.brokerid   AS brokerid,
                             tm.investorid AS investorid,
                             tm.partyid    AS partyid,
                             tp.partyname  AS partyname
                        FROM t_investorpartymap tm, t_party tp
                       WHERE tm.brokerid = tp.brokerid
                         AND tm.partyid = tp.partyid) t2
             ON t1.brokerid = t2.brokerid
            AND t1.investorid = t2.investorid
          GROUP BY t1.brokerid, t1.investorid, t1.investunitid;

       ---- 单一投资者
       INSERT INTO tmp_departmentinvestor
         (brokerid,
          userid,
          investorrange,
          investorid,
          propertyid,
          propertyname)
         SELECT t1.brokerid,
                l_userid,
                pkgs_enums.dr_single,
                t1.investorid,
                wmsys.wm_concat(TRIM(t2.partyid)),
                wmsys.wm_concat(TRIM(t2.partyname))
           FROM (SELECT t.brokerid AS brokerid, t.investorid AS investorid
                   FROM t_departmentuser t
                  WHERE t.brokerid = i_brokerid
                    AND t.userid = l_userid
                    AND t.investorrange = pkgs_enums.dr_single
                    AND t.investorid = t.investunitid
                    AND (TRIM(i_investorid) IS NULL OR
                        t.investorid = i_investorid)
                 UNION
                 SELECT a.brokerid AS brokerid, a.investorid AS investorid
                   FROM t_investor a
                  WHERE a.brokerid = i_brokerid
                    AND (TRIM(i_investorid) IS NULL OR
                        a.investorid = i_investorid)
                    AND (TRIM(i_investortype) IS NULL OR
                        a.investortype = i_investortype)
                    AND EXISTS
                  (SELECT 1
                           FROM t_departmentuser b
                          WHERE a.brokerid = b.brokerid
                            AND TRIM(a.departmentid) LIKE
                                TRIM(b.investorid) || '%'
                            AND b.userid = l_userid
                            AND b.investorrange = pkgs_enums.dr_group
                            AND b.investorid !=
                                pkgs_constants.default_brokerdepartmentid)
                 /*UNION
                 SELECT c.brokerid AS brokerid, c.investorid AS investorid
                   FROM t_o_investor c
                  WHERE c.brokerid = i_brokerid
                    AND (TRIM(i_investorid) IS NULL OR
                        c.investorid = i_investorid)
                    AND (TRIM(i_investortype) IS NULL OR
                        c.investortype = i_investortype)
                    AND EXISTS
                  (SELECT 1
                           FROM t_departmentuser d
                          WHERE c.brokerid = d.brokerid
                            AND TRIM(c.departmentid) LIKE
                                TRIM(d.investorid) || '%'
                            AND d.userid = l_userid
                            AND d.investorrange = pkgs_enums.dr_group
                            AND d.investorid !=
                                pkgs_constants.default_brokerdepartmentid)*/) t1
           LEFT JOIN (SELECT tm.brokerid   AS brokerid,
                             tm.investorid AS investorid,
                             tm.partyid    AS partyid,
                             tp.partyname  AS partyname
                        FROM t_investorpartymap tm, t_party tp
                       WHERE tm.brokerid = tp.brokerid
                         AND tm.partyid = tp.partyid) t2
             ON t1.brokerid = t2.brokerid
            AND t1.investorid = t2.investorid
          GROUP BY t1.brokerid, t1.investorid;

       IF i_InvestorType IS NOT NULL THEN
           DELETE FROM TMP_DepartMentInvestor a
           WHERE NOT EXISTS(SELECT 1 FROM t_investor b
                            WHERE a.brokerid = b.brokerid
                            AND a.investorid = b.investorid
                            AND b.investorType = i_InvestorType);
       END IF;
    END IF ;

    ---- 按属性剔除投资者
    IF TRIM(i_PartyString) IS NOT NULL THEN
       Pkgs_Common.up_GenPartyInvestor(o_ReturnNo, o_ReturnMsg ,pkgs_log.g_chOperatorID ,i_BrokerID,i_PartyString);
    END IF;
    ---- 剔除黑名单投资者
    up_DelBlacklist(i_BrokerID,l_userid);

    o_ReturnMsg := '获取操作员查询权限的投资者到临时表成功';
  EXCEPTION
    WHEN OTHERS THEN
      o_ReturnNo := PKGS_Constants.C_RET_FAIL;
      o_ReturnMsg := '获取操作员查询权限的投资者到临时表失败';
      PKGS_Log.Fatal(i_OperatorID, l_ProcessName, o_ReturnMsg);
  END up_GenDepartmentInvestor2;


  ---- 获取操作员权限：已成功开户的单一投资者(ID+Name)及投资单元

  PROCEDURE up_GenDepartmentInvestorName
  (
    o_ReturnNo           OUT     PKGS_DataType.STY_RETCODE,            ---- 返回码
    o_ReturnMsg          OUT     PKGS_DataType.STY_RETMSG,           ---- 返回信息
    i_OperatorID         IN      PKGS_DATATYPE.STY_OPERATORID,       ---- 操作员代码
    i_BrokerID           IN      PKGS_DATATYPE.STY_BROKERID,         ---- 经纪公司代码
    i_InvestorID         IN      t_Investor.InvestorID%TYPE,         ---- 投资者代码
    i_InvestorType       IN      t_Investor.investorType%Type,       ---- 投资者类型
    i_partyString        IN      PKGS_DATATYPE.STY_InvstParty        ---- 投资者属性
  )
  AS
   l_ProcessName     PKGS_DataType.STY_SpName;
   l_count           NUMBER;
   l_UserID          t_brokeruser.UserID%TYPE;
  BEGIN
    o_ReturnNo := PKGS_Constants.C_S_OK ;
    l_ProcessName := 'PKGS_COMMON.up_GenDepartmentInvestorName';

    IF TRIM(i_OperatorID) IS NULL THEN
       o_ReturnNo := PKGS_Constants.C_RET_FAIL;
       o_ReturnMsg := '操作员不能为空';
       PKGS_Log.Fatal(i_OperatorID, l_ProcessName, o_ReturnMsg);
       RETURN;
    END IF ;

    l_UserID := SUBSTR(TRIM(i_OperatorID), INSTR(TRIM(i_OperatorID), '.') + 1) ;

    DELETE FROM TMP_DepartMentInvestor
    WHERE BrokerID =  i_BrokerID ;

    IF PKGS_Common.uf_GetIsDefaultDepartMent(i_BrokerID,i_OperatorID) = PKGS_Constants.C_BOOL_TRUE THEN
       ---- user对所有数据都有权限 ，涉及investorName，只考虑已成功开户投资者，不能同up_GenDepartmentInvestor一样考虑t_o_investor
       INSERT INTO tmp_departmentinvestor
         (brokerid, userid, investorrange, investorid, investorname)
         SELECT brokerid,
                l_userid,
                pkgs_enums.dr_single,
                investorid,
                investorname
           FROM t_investor
          WHERE brokerid = i_brokerid
            AND (i_investorid IS NULL OR investorid = i_investorid)
            AND (i_investortype IS NULL OR investortype = i_investortype)
         ;
    ELSE
    	  ---- 单一投资单元
       INSERT INTO TMP_DepartMentInvestor(BrokerID ,UserID,InvestorRange,InvestorID,InvestUnitID,InvestorName)
       SELECT t.brokerid,
              userid,
              pkgs_enums.dr_single,
              t.investorid,
              t.investunitid,
              investorname
         FROM t_departmentuser t,t_investor t1
        WHERE t.brokerid = i_brokerid
          AND t.userid = l_userid
          AND investorrange = pkgs_enums.dr_single
          AND t.investorid <> t.investunitid
          AND t.brokerid = t1.brokerid
          AND t.investorid = t1.investorid
          AND (TRIM(i_investorid) IS NULL OR t.investorid = i_investorid);
       ---- 单一投资者
       INSERT INTO TMP_DepartMentInvestor(BrokerID ,UserID  ,InvestorRange,InvestorID,InvestorName )
       SELECT t.brokerid,
              userid,
              pkgs_enums.dr_single,
              t.investorid,
              investorname
         FROM t_departmentuser t,t_investor t1
        WHERE t.brokerid = i_brokerid
          AND userid = l_userid
          AND investorrange = pkgs_enums.dr_single
          AND t.investorid = t.investunitid
          AND t.brokerid = t1.brokerid
          AND t.investorid = t1.investorid
          AND (TRIM(i_investorid) IS NULL OR t.investorid = i_investorid)
       UNION  ---- 非'00'组织架构，只考虑已成功开户投资者，不能同up_GenDepartmentInvestor一样考虑t_o_investor
       SELECT brokerid,
              l_userid,
              pkgs_enums.dr_single,
              investorid,
              investorname
         FROM t_investor a
        WHERE brokerid = i_brokerid
          AND (TRIM(i_investorid) IS NULL OR investorid = i_investorid)
          AND (TRIM(i_investortype) IS NULL OR investortype = i_investortype)
          AND EXISTS
        (SELECT 1
                 FROM t_departmentuser b
                WHERE a.brokerid = b.brokerid
                  AND TRIM(a.departmentid) LIKE TRIM(b.investorid) || '%'
                  AND b.userid = l_userid
                  AND b.investorrange = pkgs_enums.dr_group
                  AND b.investorid !=
                      pkgs_constants.default_brokerdepartmentid)
       ;
       IF i_InvestorType IS NOT NULL THEN
           DELETE FROM TMP_DepartMentInvestor a
           WHERE NOT EXISTS(SELECT 1 FROM t_investor b
                            WHERE a.brokerid = b.brokerid
                            AND a.investorid = b.investorid
                            AND investorType = i_INvestorType);
       END IF;
    END IF ;

    ---- 按属性剔除投资者
    IF TRIM(i_PartyString) IS NOT NULL THEN
       Pkgs_Common.up_GenPartyInvestor(o_ReturnNo, o_ReturnMsg ,pkgs_log.g_chOperatorID ,i_BrokerID,i_PartyString);
    END IF;
    ---- 剔除黑名单投资者
    up_DelBlacklist(i_BrokerID,l_userid);

    o_ReturnMsg := '获取操作员查询权限的投资者到临时表成功';
  EXCEPTION
    WHEN OTHERS THEN
      o_ReturnNo := PKGS_Constants.C_RET_FAIL;
      o_ReturnMsg := '获取操作员查询权限的投资者到临时表失败';
      PKGS_Log.Fatal(i_OperatorID, l_ProcessName, o_ReturnMsg);
  END up_GenDepartmentInvestorName;
	/*
	add by chen.lan 20190708
	根据投资者查询资金账户的报表，可在获取权限时就过滤掉不必要的投资者信息；
	*/
  PROCEDURE up_GenDepartmentAccountName
  (
    o_ReturnNo           OUT     PKGS_DataType.STY_RETCODE,            ---- 返回码
    o_ReturnMsg          OUT     PKGS_DataType.STY_RETMSG,           ---- 返回信息
    i_OperatorID         IN      PKGS_DATATYPE.STY_OPERATORID,       ---- 操作员代码
    i_BrokerID           IN      PKGS_DATATYPE.STY_BROKERID,         ---- 经纪公司代码
    i_InvestorID         IN      t_Investor.InvestorID%TYPE,         ---- 投资者代码
    i_InvestorType       IN      t_Investor.investorType%Type,       ---- 投资者类型
    i_AccountID          IN      T_ACCOUNT.ACCOUNTID%TYPE,
    i_CurrencyID         IN      T_ACCOUNT.CURRENCYID%TYPE,
    i_partyString        IN      PKGS_DATATYPE.STY_InvstParty,        ---- 投资者属性
    i_StatPropertyString IN      PKGS_DATATYPE.STY_InvstParty    ---- 投资者属性统计
  )
  AS
   l_ProcessName     PKGS_DataType.STY_SpName;
   l_count           NUMBER;
   l_UserID          t_brokeruser.UserID%TYPE;
   l_propertyid      VARCHAR2(2000);
   l_propertyname    VARCHAR2(2000);
  BEGIN
    o_ReturnNo := PKGS_Constants.C_S_OK ;
    l_ProcessName := 'PKGS_COMMON.up_GenDepartmentAccountName';
    ----输入参数检查
    IF TRIM(i_OperatorID) IS NULL THEN
       o_ReturnNo := PKGS_Constants.C_RET_FAIL;
       o_ReturnMsg := '操作员不能为空';
       PKGS_Log.Fatal(i_OperatorID, l_ProcessName, o_ReturnMsg);
       RETURN;
    END IF ;

    l_UserID := SUBSTR(TRIM(i_OperatorID), INSTR(TRIM(i_OperatorID), '.') + 1) ;

    DELETE FROM TMP_DepartMentAccount
    WHERE BrokerID =  i_BrokerID ;

    IF PKGS_Common.uf_GetIsDefaultDepartMent(i_BrokerID,i_OperatorID) = PKGS_Constants.C_BOOL_TRUE THEN
       ---- user对所有数据都有权限 ，涉及investorName，只考虑已成功开户投资者，不能同up_GenDepartmentInvestor一样考虑t_o_investor
       INSERT INTO TMP_DepartMentAccount NOLOGGING
         (brokerid, userid, investorrange,accountid,currencyid， investorid, investorname,INVESTORGROUPID)
         SELECT t1.brokerid,
                l_userid,
                pkgs_enums.dr_single,
                t1.accountid,
                t1.currencyid,
                t2.investorid,
                t2.investorname
                ,t2.INVESTORGROUPID
           FROM t_accountownership t1, t_investor t2
          WHERE t1.brokerid = i_brokerid
            AND t1.brokerid = t2.brokerid
            AND t1.accountowner = t2.investorid
            AND (i_investorid IS NULL OR investorid = i_investorid)
            AND (i_investortype IS NULL OR investortype = i_investortype)
            AND (TRIM(i_accountid) IS NULL OR accountid = i_accountid)
            AND (TRIM(i_currencyid) IS NULL OR currencyid = i_currencyid)
         ;
    ELSE
        ---- 单一投资单元 todo 投资单元的资金账户，如果界定？？？
       INSERT INTO TMP_DepartMentAccount(brokerid, userid, investorrange,accountid,currencyid， investorid, investunitid,investorname,INVESTORGROUPID)
       SELECT t.brokerid,
              userid,
              pkgs_enums.dr_single,
              t2.accountid,
              t2.currencyid,
              t.investorid,
              t.investunitid,
              investorname
              ,t1.INVESTORGROUPID
         FROM t_departmentuser t,t_investor t1,t_investunit t2
        WHERE t.brokerid = i_brokerid
          AND t.userid = l_userid
          AND investorrange = pkgs_enums.dr_single
          AND t.investorid <> t.investunitid
          AND t.brokerid = t1.brokerid
          AND t.investorid = t1.investorid
          AND t.brokerid = t2.brokerid
          AND t.investorid = t2.investorid
          AND t.investunitid = t2.investunitid
          AND (TRIM(i_investorid) IS NULL OR t.investorid = i_investorid)
          AND (TRIM(i_investortype) IS NULL OR investortype = i_investortype)
          AND (TRIM(i_accountid) IS NULL OR accountid = i_accountid)
          AND (TRIM(i_currencyid) IS NULL OR currencyid = i_currencyid)
          ;
       ---- 单一投资者
       INSERT INTO TMP_DepartMentAccount(brokerid, userid, investorrange,accountid,currencyid， investorid, investorname,INVESTORGROUPID)
       SELECT t.brokerid,
              userid,
              pkgs_enums.dr_single,
              t2.accountid,
              t2.currencyid，
              t.investorid,
              investorname
              ,t1.investorgroupid
         FROM t_departmentuser t,t_investor t1,t_accountownership t2
        WHERE t.brokerid = i_brokerid
          AND userid = l_userid
          AND investorrange = pkgs_enums.dr_single
          AND t.investorid = t.investunitid
          AND t.brokerid = t1.brokerid
          AND t.investorid = t1.investorid
          AND t.brokerid = t2.brokerid
          AND t.investorid = t2.accountowner
          AND (TRIM(i_investorid) IS NULL OR t.investorid = i_investorid)
          AND (TRIM(i_investortype) IS NULL OR investortype = i_investortype)
          AND (TRIM(i_accountid) IS NULL OR accountid = i_accountid)
          AND (TRIM(i_currencyid) IS NULL OR currencyid = i_currencyid)
       UNION  ---- 非'00'组织架构，只考虑已成功开户投资者，不能同up_GenDepartmentInvestor一样考虑t_o_investor
       SELECT a.brokerid,
              l_userid,
              pkgs_enums.dr_single,
              c.accountid,
              c.currencyid,
              a.investorid,
              a.investorname
              ,a.INVESTORGROUPID
         FROM t_investor a,t_departmentuser b,t_accountownership c
        WHERE a.brokerid = i_brokerid
          AND (TRIM(i_investorid) IS NULL OR a.investorid = i_investorid)
          AND (TRIM(i_investortype) IS NULL OR a.investortype = i_investortype)
          AND  a.brokerid = b.brokerid
          AND a.departmentid LIKE TRIM(b.investorid) || '%'
          AND b.userid = l_userid
          AND b.investorrange = pkgs_enums.dr_group
          AND b.investorid !=pkgs_constants.default_brokerdepartmentid
          AND a.brokerid = c.brokerid
          AND a.investorid = c.accountowner
          AND (TRIM(i_accountid) IS NULL OR accountid = i_accountid)
          AND (TRIM(i_currencyid) IS NULL OR currencyid = i_currencyid)
       ;

    END IF ;

    ---- 按属性剔除投资者
    IF TRIM(i_PartyString) IS NOT NULL THEN
      IF TRIM(i_PartyString) IS NOT NULL THEN
        DELETE FROM tmp_party;
        INSERT INTO tmp_party(brokerid, partyid, partyname)
        SELECT brokerid ,partyid, partyname
          FROM t_party
         WHERE brokerid = i_BrokerID
           AND instr( ',' || TRIM(i_PartyString) || ',', ',' || trim(partyid) || ',') > 0;

        FOR l_tmpparty
         IN ( SELECT brokerid ,partyid, partyname
               FROM t_party
              WHERE brokerid = i_BrokerID
                AND instr( ',' || TRIM(i_PartyString) || ',', ',' || trim(partyid) || ',') > 0
          )
        LOOP
          DELETE FROM TMP_DepartMentAccount a
           WHERE NOT EXISTS (SELECT 1
                                 FROM t_investorpartymap b
                                WHERE b.brokerid = l_tmpparty.brokerid
                                  AND   b.partyid  = l_tmpparty.partyid
                                  AND   a.brokerid = b.brokerid
                                  AND   a.investorid = b.investorid
                              );
        END LOOP;
      END IF;
    END IF;



    IF TRIM(i_StatPropertyString) IS NOT NULL THEN
       FOR c_result IN (SELECT * FROM TMP_DepartMentAccount)
       LOOP
         FOR c_investorproperty IN
             (SELECT investorid, a.partyid,b.partyname, b.parentpartyid
              FROM  t_investorpartymap a , t_party b
              WHERE a.partyid = b.partyid
              AND   a.brokerid = b.brokerid
              AND   (TRIM(i_StatPropertyString) IS NULL OR instr(',' || TRIM(i_StatPropertyString) || ',' , ',' || TRIM(b.parentpartyid) || ',') > 0)
              AND   a.brokerid = i_BrokerID
              AND   a.investorid = i_investorid
              ORDER BY a.partyid
             )
         LOOP
               IF (TRIM(l_propertyID) IS NOT NULL) THEN
                  l_propertyID := nvl(TRIM(l_propertyID),'') || '-' || TRIM(c_investorproperty.Partyid);
                  l_propertyname := nvl(TRIM(l_propertyname),'') || '--' || TRIM(c_investorproperty.partyname);
               ELSE
                  l_propertyID := TRIM(c_investorproperty.Partyid);
                  l_propertyname := TRIM(c_investorproperty.partyname);
               END IF;
         END LOOP;


          UPDATE/*+ index(t IDX_TMP_DEPARTMENTACCOUNT )*/  TMP_DepartMentAccount t
             SET t.propertyid   = TRIM(l_propertyID),
                t.propertyname = TRIM(l_propertyname)
            WHERE t.brokerid = c_result.brokerid
            AND t.investorrange = PKGS_Constants.DR_Single
            AND t.investorid = c_result.investorid;

      END LOOP;

    END IF;
    ---- 剔除黑名单投资者
    DELETE FROM TMP_DepartMentAccount a
    WHERE EXISTS (SELECT 1
    FROM t_departmentuserblacklist b
    WHERE a.brokerid = b.brokerid
    AND   a.userid = b.userid
    AND   a.investorid = b.investorid
    AND   b.userid  = l_UserID
    AND   b.brokerid = i_BrokerID
    );
    o_ReturnMsg := '获取操作员查询权限的投资者的资金账户到临时表成功';

  EXCEPTION
    WHEN OTHERS THEN
      o_ReturnNo := PKGS_Constants.C_RET_FAIL;
      o_ReturnMsg := '获取操作员查询权限的投资者的资金账户到临时表失败';
      PKGS_Log.Fatal(i_OperatorID, l_ProcessName, o_ReturnMsg);
  END up_GenDepartmentAccountName;


	/*
	add by chen.lan 20190708
	根据投资者查询资金账户的报表，可在获取权限时就过滤掉不必要的投资者信息；
	补充组织架构id；,含对应投资者名称，组织架构名称
	*/
  PROCEDURE up_GenDepartAccountDepName
  (
    o_ReturnNo           OUT     PKGS_DataType.STY_RETCODE,            ---- 返回码
    o_ReturnMsg          OUT     PKGS_DataType.STY_RETMSG,           ---- 返回信息
    i_OperatorID         IN      PKGS_DATATYPE.STY_OPERATORID,       ---- 操作员代码
    i_BrokerID           IN      PKGS_DATATYPE.STY_BROKERID,         ---- 经纪公司代码
    i_InvestorID         IN      PKGS_DATATYPE.STY_InvestorID,         ---- 投资者代码
    i_InvestorType       IN      PKGS_DATATYPE.STY_InvestorType,       ---- 投资者类型
    i_AccountID          IN      PKGS_DATATYPE.STY_AccountID,
    i_CurrencyID         IN      PKGS_DATATYPE.STY_CurrencyID,
    i_partyString        IN      PKGS_DATATYPE.STY_InvstParty,        ---- 投资者属性
    i_StatPropertyString IN      PKGS_DATATYPE.STY_InvstParty,    ---- 投资者属性统计
		i_departmentid       IN      t_department.departmentid%TYPE
  )
  AS
   l_ProcessName     PKGS_DataType.STY_SpName;
   l_count           NUMBER;
   l_UserID          t_brokeruser.UserID%TYPE;
   l_propertyid      VARCHAR2(2000);
   l_propertyname    VARCHAR2(2000);
  BEGIN
    o_ReturnNo := PKGS_Constants.C_S_OK ;
    l_ProcessName := 'PKGS_COMMON.up_GenDepartAccountDepName';
    ----输入参数检查
    IF TRIM(i_OperatorID) IS NULL THEN
       o_ReturnNo := PKGS_Constants.C_RET_FAIL;
       o_ReturnMsg := '操作员不能为空';
       PKGS_Log.Fatal(i_OperatorID, l_ProcessName, o_ReturnMsg);
       RETURN;
    END IF ;

    l_UserID := SUBSTR(TRIM(i_OperatorID), INSTR(TRIM(i_OperatorID), '.') + 1) ;

    DELETE FROM TMP_DepartMentAccount
    WHERE BrokerID =  i_BrokerID ;

    IF PKGS_Common.uf_GetIsDefaultDepartMent(i_BrokerID,i_OperatorID) = PKGS_Constants.C_BOOL_TRUE THEN
       ---- user对所有数据都有权限 ，涉及investorName，只考虑已成功开户投资者，不能同up_GenDepartmentInvestor一样考虑t_o_investor
       INSERT INTO TMP_DepartMentAccount NOLOGGING
         (brokerid, userid, investorrange,accountid,currencyid， investorid, investorname,departmentid,departmentname)
         SELECT t1.brokerid,
                l_userid,
                pkgs_enums.dr_single,
                t1.accountid,
                t1.currencyid,
                t2.investorid,
                t2.investorname
                ,t2.departmentid
                ,t3.departmentname
           FROM t_accountownership t1, t_investor t2,t_department t3
          WHERE t1.brokerid = i_brokerid
            AND t1.brokerid = t2.brokerid
            AND t1.accountowner = t2.investorid
            AND (i_investorid IS NULL OR investorid = i_investorid)
            AND (i_investortype IS NULL OR investortype = i_investortype)
            AND (TRIM(i_accountid) IS NULL OR accountid = i_accountid)
            AND (TRIM(i_currencyid) IS NULL OR currencyid = i_currencyid)
						AND t2.brokerid = t3.brokerid
						AND t2.departmentid = t3.departmentid
						AND (TRIM(i_departmentid) IS NULL OR TRIM(i_Departmentid) = TRIM(pkgs_constants.DEFAULT_BrokerDepartMentID) OR t2.departmentid LIKE trim(i_Departmentid) || '%')
         ;
    ELSE
       ---- 单一投资者
       INSERT INTO TMP_DepartMentAccount(brokerid, userid, investorrange,accountid,currencyid， investorid, investorname,departmentid,departmentname)
       SELECT t.brokerid,
              userid,
              pkgs_enums.dr_single,
              t2.accountid,
              t2.currencyid，
              t.investorid,
              investorname
              ,t1.departmentid
              ,t3.departmentname
         FROM t_departmentuser t,t_investor t1,t_accountownership t2,t_department t3
        WHERE t.brokerid = i_brokerid
          AND userid = l_userid
          AND investorrange = pkgs_enums.dr_single
          AND t.investorid = t.investunitid
          AND t.brokerid = t1.brokerid
          AND t.investorid = t1.investorid
          AND t.brokerid = t2.brokerid
          AND t.investorid = t2.accountowner
          AND (TRIM(i_investorid) IS NULL OR t.investorid = i_investorid)
          AND (TRIM(i_investortype) IS NULL OR investortype = i_investortype)
          AND (TRIM(i_accountid) IS NULL OR accountid = i_accountid)
          AND (TRIM(i_currencyid) IS NULL OR currencyid = i_currencyid)
					AND t1.brokerid = t3.brokerid
				  AND t1.departmentid = t3.departmentid
					AND (TRIM(i_departmentid) IS NULL OR TRIM(i_Departmentid) = TRIM(pkgs_constants.DEFAULT_BrokerDepartMentID) OR t1.departmentid LIKE trim(i_Departmentid) || '%')
       UNION  ---- 非'00'组织架构，只考虑已成功开户投资者，不能同up_GenDepartmentInvestor一样考虑t_o_investor
       SELECT a.brokerid,
              l_userid,
              pkgs_enums.dr_single,
              c.accountid,
              c.currencyid,
              a.investorid,
              a.investorname
              ,a.departmentid
              ,t3.departmentname
         FROM t_investor a,t_departmentuser b,t_accountownership c,t_department t3
        WHERE a.brokerid = i_brokerid
          AND (TRIM(i_investorid) IS NULL OR a.investorid = i_investorid)
          AND (TRIM(i_investortype) IS NULL OR a.investortype = i_investortype)
          AND  a.brokerid = b.brokerid
          AND a.departmentid LIKE TRIM(b.investorid) || '%'
          AND b.userid = l_userid
          AND b.investorrange = pkgs_enums.dr_group
          AND b.investorid !=pkgs_constants.default_brokerdepartmentid
          AND a.brokerid = c.brokerid
          AND a.investorid = c.accountowner
          AND (TRIM(i_accountid) IS NULL OR accountid = i_accountid)
          AND (TRIM(i_currencyid) IS NULL OR currencyid = i_currencyid)
					AND a.brokerid = t3.brokerid
				  AND a.departmentid = t3.departmentid
					AND (TRIM(i_departmentid) IS NULL OR TRIM(i_Departmentid) = TRIM(pkgs_constants.DEFAULT_BrokerDepartMentID) OR a.departmentid LIKE trim(i_Departmentid) || '%')
       ;

    END IF ;

    ---- 按属性剔除投资者
    IF TRIM(i_PartyString) IS NOT NULL THEN
      IF TRIM(i_PartyString) IS NOT NULL THEN
        DELETE FROM tmp_party;
        INSERT INTO tmp_party(brokerid, partyid, partyname)
        SELECT brokerid ,partyid, partyname
          FROM t_party
         WHERE brokerid = i_BrokerID
           AND instr( ',' || TRIM(i_PartyString) || ',', ',' || trim(partyid) || ',') > 0;

        FOR l_tmpparty
         IN ( SELECT brokerid ,partyid, partyname
               FROM t_party
              WHERE brokerid = i_BrokerID
                AND instr( ',' || TRIM(i_PartyString) || ',', ',' || trim(partyid) || ',') > 0
          )
        LOOP
          DELETE FROM TMP_DepartMentAccount a
           WHERE NOT EXISTS (SELECT 1
                                 FROM t_investorpartymap b
                                WHERE b.brokerid = l_tmpparty.brokerid
                                  AND   b.partyid  = l_tmpparty.partyid
                                  AND   a.brokerid = b.brokerid
                                  AND   a.investorid = b.investorid
                              );
        END LOOP;
      END IF;
    END IF;



    IF TRIM(i_StatPropertyString) IS NOT NULL THEN
       FOR c_result IN (SELECT * FROM TMP_DepartMentAccount)
       LOOP
         FOR c_investorproperty IN
             (SELECT investorid, a.partyid,b.partyname, b.parentpartyid
              FROM  t_investorpartymap a , t_party b
              WHERE a.partyid = b.partyid
              AND   a.brokerid = b.brokerid
              AND   (TRIM(i_StatPropertyString) IS NULL OR instr(',' || TRIM(i_StatPropertyString) || ',' , ',' || TRIM(b.parentpartyid) || ',') > 0)
              AND   a.brokerid = i_BrokerID
              AND   a.investorid = i_investorid
              ORDER BY a.partyid
             )
         LOOP
               IF (TRIM(l_propertyID) IS NOT NULL) THEN
                  l_propertyID := nvl(TRIM(l_propertyID),'') || '-' || TRIM(c_investorproperty.Partyid);
                  l_propertyname := nvl(TRIM(l_propertyname),'') || '--' || TRIM(c_investorproperty.partyname);
               ELSE
                  l_propertyID := TRIM(c_investorproperty.Partyid);
                  l_propertyname := TRIM(c_investorproperty.partyname);
               END IF;
         END LOOP;


          UPDATE/*+ index(t IDX_TMP_DEPARTMENTACCOUNT )*/  TMP_DepartMentAccount t
             SET t.propertyid   = TRIM(l_propertyID),
                t.propertyname = TRIM(l_propertyname)
            WHERE t.brokerid = c_result.brokerid
            AND t.investorrange = PKGS_Constants.DR_Single
            AND t.investorid = c_result.investorid;

      END LOOP;

    END IF;
    ---- 剔除黑名单投资者
    DELETE FROM TMP_DepartMentAccount a
    WHERE EXISTS (SELECT 1
    FROM t_departmentuserblacklist b
    WHERE a.brokerid = b.brokerid
    AND   a.userid = b.userid
    AND   a.investorid = b.investorid
    AND   b.userid  = l_UserID
    AND   b.brokerid = i_BrokerID
    );
    o_ReturnMsg := '获取操作员查询权限的投资者的资金账户到临时表成功';

  EXCEPTION
    WHEN OTHERS THEN
      o_ReturnNo := PKGS_Constants.C_RET_FAIL;
      o_ReturnMsg := '获取操作员查询权限的投资者的资金账户到临时表失败';
      PKGS_Log.Fatal(i_OperatorID, l_ProcessName, o_ReturnMsg);
  END up_GenDepartAccountDepName;

  ---- 获取操作员有权限的单一投资者及投资单元
  PROCEDURE up_GenDepartmentInvestor1
  (
    o_ReturnNo           OUT     PKGS_DataType.STY_RETCODE,            ---- 返回码
    o_ReturnMsg          OUT     PKGS_DataType.STY_RETMSG,           ---- 返回信息
    i_OperatorID         IN      PKGS_DATATYPE.STY_OPERATORID,       ---- 操作员代码
    i_BrokerID           IN      PKGS_DATATYPE.STY_BROKERID,         ---- 经纪公司代码
    i_InvestorID         IN      t_Investor.InvestorID%TYPE,         ---- 投资者代码
    i_InvestorType       IN      t_Investor.investorType%Type,       ---- 投资者类型
    i_partyString        IN      PKGS_DATATYPE.STY_InvstParty,        ---- 投资者属性
    i_StatPropertyString IN      PKGS_DATATYPE.STY_InvstParty
  )
  AS
   l_ProcessName     PKGS_DataType.STY_SpName;
   l_count           NUMBER;
   l_UserID          t_brokeruser.UserID%TYPE;
  BEGIN
    o_ReturnNo := PKGS_Constants.C_S_OK ;
    l_ProcessName := 'PKGS_COMMON.up_GenDepartmentInvestor';

    IF TRIM(i_OperatorID) IS NULL THEN
       o_ReturnNo := PKGS_Constants.C_RET_FAIL;
       o_ReturnMsg := '操作员不能为空';
       PKGS_Log.Fatal(i_OperatorID, l_ProcessName, o_ReturnMsg);
       RETURN;
    END IF ;

    l_UserID := SUBSTR(TRIM(i_OperatorID), INSTR(TRIM(i_OperatorID), '.') + 1) ;

    DELETE FROM TMP_DepartMentInvestor
    WHERE BrokerID =  i_BrokerID ;

    IF PKGS_Common.uf_GetIsDefaultDepartMent(i_BrokerID,i_OperatorID) = PKGS_Constants.C_BOOL_TRUE THEN
       ---- user对所有数据都有权限
       INSERT INTO TMP_DepartMentInvestor(BrokerID ,UserID ,InvestorRange,InvestorID )
       SELECT BrokerID,l_UserID,PKGS_Enums.DR_Single,InvestorID
       FROM  t_Investor
       WHERE  BrokerID = i_BrokerID
       AND (TRIM(i_INvestorID) IS NULL OR investorid = i_InvestorID)
       AND (TRIM(i_INvestorType) IS NULL OR investorType = i_INvestorType)
       /*UNION bug CTP2-2421
       SELECT BrokerID,l_UserID,PKGS_Enums.DR_Single,InvestorID
       FROM  t_O_Investor
       WHERE  BrokerID = i_BrokerID
       AND (TRIM(i_INvestorID) IS NULL OR investorid = i_InvestorID)
       AND (TRIM(i_INvestorType) IS NULL OR investorType = i_INvestorType)*/;
    ELSE
    	  ---- 单一投资单元
       INSERT INTO TMP_DepartMentInvestor(BrokerID ,UserID,InvestorRange,InvestorID,InvestUnitID)
       SELECT BrokerID,UserID,PKGS_Enums.DR_Single,InvestorID,t.InvestUnitID
       FROM t_departmentuser t
       WHERE t.Brokerid = i_BrokerID
       AND   t.Userid = l_UserID
       AND   InvestorRange = PKGS_Enums.DR_Single
       AND   t.investorid <> t.investunitid
       AND   (TRIM(i_INvestorID) IS NULL OR investorid = i_InvestorID);
       ---- 单一投资者
       INSERT INTO TMP_DepartMentInvestor(BrokerID ,UserID  ,InvestorRange,InvestorID )
       SELECT BrokerID,UserID,PKGS_Enums.DR_Single,InvestorID
       FROM  t_departmentuser t
       WHERE  BrokerID = i_BrokerID
       AND  UserID   = l_UserID
       AND  InvestorRange = PKGS_Enums.DR_Single
       AND  t.investorid = t.investunitid
       AND (TRIM(i_INvestorID) IS NULL OR investorid = i_InvestorID)
       UNION  ---- 非'00'组织架构
       SELECT BrokerID,l_UserID,PKGS_Enums.DR_Single,InvestorID
       FROM  t_Investor  a
       WHERE  BrokerID = i_BrokerID
       AND (TRIM(i_InvestorID) IS NULL OR InvestorID = i_InvestorID)
       AND (TRIM(i_investorType) IS NULL OR investorType = i_investorType)
       AND  EXISTS ( SELECT 1 FROM t_departmentuser b
                     WHERE a.BrokerID = b.BrokerID
                     AND TRIM(a.DepartMentID)LIKE TRIM(b.InvestorID)||'%'
                     AND b.UserID        = l_userID
                     AND b.InvestorRange = PKGS_Enums.DR_Group
                     AND b.InvestorID   != PKGS_Constants.DEFAULT_BrokerDepartMentID
                    )
       /*UNION  ---- 非'00'组织架构
       SELECT BrokerID,l_UserID,PKGS_Enums.DR_Single,InvestorID
       FROM  t_O_Investor  a
       WHERE  BrokerID = i_BrokerID
       AND (TRIM(i_InvestorID) IS NULL OR InvestorID = i_InvestorID)
       AND (TRIM(i_investorType) IS NULL OR investorType = i_investorType)
       AND  EXISTS ( SELECT 1 FROM t_departmentuser b
                     WHERE a.BrokerID = b.BrokerID
                     AND TRIM(a.DepartMentID)LIKE TRIM(b.InvestorID)||'%'
                     AND b.UserID        = l_userID
                     AND b.InvestorRange = PKGS_Enums.DR_Group
                     AND b.InvestorID   != PKGS_Constants.DEFAULT_BrokerDepartMentID
                    )*/ ;
       IF i_InvestorType IS NOT NULL THEN
           DELETE FROM TMP_DepartMentInvestor a
           WHERE NOT EXISTS(SELECT 1 FROM t_investor b
                            WHERE a.brokerid = b.brokerid
                            AND a.investorid = b.investorid
                            AND investorType = i_INvestorType);
       END IF;
    END IF ;

    ---- 按属性剔除投资者
    IF TRIM(i_PartyString) IS NOT NULL OR TRIM(i_StatPropertyString) IS NOT NULL THEN
       Pkgs_Common.up_GenPartyInvestor1(o_ReturnNo, o_ReturnMsg ,pkgs_log.g_chOperatorID ,i_BrokerID,i_PartyString,i_StatPropertyString);
    END IF;
    up_DelBlacklist(i_BrokerID,l_userid);

    o_ReturnMsg := '获取操作员查询权限的投资者到临时表成功';
  EXCEPTION
    WHEN OTHERS THEN
      o_ReturnNo := PKGS_Constants.C_RET_FAIL;
      o_ReturnMsg := '获取操作员查询权限的投资者到临时表失败';
      PKGS_Log.Fatal(i_OperatorID, l_ProcessName, o_ReturnMsg);
  END up_GenDepartmentInvestor1;

  ---- 验证手续费率中投资者代码与投资者范围匹配是否有效
  PROCEDURE up_ValidateCommInvestorRange
  (
    o_nRetCode                    OUT     PKGS_DataType.STY_RETCODE,                 ---- 返回码
    o_varRetMsg                   OUT     PKGS_DataType.STY_RETMSG,                   ---- 返回信息
    i_OperatorID                  IN      PKGS_DATATYPE.STY_OPERATORID,              ---- 操作员代码
    i_BrokerID                    IN      PKGS_DATATYPE.STY_BROKERID,                ---- 经纪公司代码
    i_InvestorRange               IN      PKGS_DATATYPE.STY_InvestorRange,           ---- 投资者范围
    i_InvestorID                  IN      PKGS_DATATYPE.STY_InvestorID,              ---- 投资者代码
    i_InvestUnitID                IN      PKGS_DATATYPE.STY_InvestUnitID             ---- 投资单元代码
  )
  AS
    l_Count           INT;
    l_ProcessName     PKGS_DataType.STY_SpName;                                ---- 存储过程名称
  BEGIN
    o_nRetCode := PKGS_Constants.C_RET_SUCCESS;
    l_ProcessName := 'pkg_Validate.up_ValidateCommInvestorRange';

    ---- 检查投资者代码是否与投资者范围匹配
    IF i_InvestorRange = PKGS_Enums.RIR_All THEN                   ---- 公司标准

      IF i_InvestorID <> PKGS_Constants.DEFAULT_INVESTORID THEN
        o_nRetCode := PKGS_Constants.C_RET_FAIL;
        o_varRetMsg := '当投资者范围使用所有类型时,投资者代码必须采用缺省代码(' || PKGS_Constants.DEFAULT_INVESTORID || ')';
        RETURN;
      END IF;
      IF i_InvestUnitID <> PKGS_Constants.DEFAULT_INVESTORID THEN
        o_nRetCode := PKGS_Constants.C_RET_FAIL;
        o_varRetMsg := '当投资者范围使用所有类型时,投资单元代码必须采用缺省代码(' || PKGS_Constants.DEFAULT_INVESTORID || ')';
        RETURN;
      END IF;

     ---验证操作员权限
     pkgb_commratemgrt.up_GenCommRateInvestor(i_BrokerID,i_InvestorRange,i_InvestorID,NULL,NULL,NULL,o_nRetCode,o_varRetMsg);
     IF o_nRetCode <> pkgs_constants.C_RET_SUCCESS THEN
        pkgs_log.up_Error(l_ProcessName,o_varRetMsg);
        RETURN;
     END IF;

  	  SELECT COUNT(*)
      INTO l_count
      FROM TMP_DepartMentInvestor t1
      WHERE t1.brokerid = i_BrokerID
      AND   t1.investorid = i_InvestorID
      AND   t1.investorrange = i_Investorrange;
      IF l_count = 0 THEN
         o_nRetCode := PKGS_Constants.C_RET_FAIL;
        o_varRetMsg := '当投资者范围使用公司标准时,登录用户必须为admin用户或具有所有数据权限';
        RETURN;
      END IF;

    ELSIF i_InvestorRange = PKGS_Enums.RIR_Model THEN              ---- 手续费率率模板

      SELECT COUNT(*)
      INTO l_Count
      FROM t_invstcommmodel
      WHERE BrokerID        = i_BrokerID
      AND   CommmodelID   = i_InvestorID;
      IF l_Count = 0 THEN
        o_nRetCode  := PKGS_Constants.C_RET_FAIL;
        o_varRetMsg := '当投资者范围使用模板时,投资者代码必须为投资者手续费模板,但输入的手续费模板(' || TRIM(i_InvestorID) || ')不存在';
        RETURN;
      END IF;
      IF i_InvestUnitID <> i_InvestorID THEN
        o_nRetCode := PKGS_Constants.C_RET_FAIL;
        o_varRetMsg := '当投资者范围使用模板时,投资单元代码必须为投资者手续费模板';
        RETURN;
      END IF;

       ---验证操作员对模板是否有权限
     pkgb_commratemgrt.up_GenCommRateInvestor(i_BrokerID,i_InvestorRange,i_InvestorID,NULL,NULL,NULL,o_nRetCode,o_varRetMsg);
     IF o_nRetCode <> pkgs_constants.C_RET_SUCCESS THEN
        pkgs_log.up_Error(l_ProcessName,o_varRetMsg);
        RETURN;
     END IF;

  	  SELECT COUNT(*)
      INTO l_count
      FROM TMP_DepartMentInvestor t1
      WHERE t1.brokerid = i_BrokerID
      AND   t1.investorid = i_InvestorID
      AND   t1.investorrange = i_Investorrange;
      IF l_count = 0 THEN
         o_nRetCode := PKGS_Constants.C_RET_FAIL;
        o_varRetMsg := '当投资者范围使用模板时,登录用户必须有模板('||TRIM(i_InvestorID)||')的操作权限';
        RETURN;
      END IF;

    ELSIF i_InvestorRange = PKGS_Enums.RIR_Single THEN             ---- 单一投资者
        SELECT COUNT(*)
          INTO l_Count
          FROM t_Investor
         WHERE BrokerID = i_BrokerID
           AND InvestorID = i_InvestorID
					 AND ISACTIVE = pkgs_constants.C_BOOL_TRUE ---modifie by zhang.cb 20161201
					 ;
        IF l_Count = 0 THEN
          o_nRetCode  := PKGS_Constants.C_RET_FAIL ;
          o_varRetMsg := '当投资者范围使用客户类型时,投资者代码必须为活跃投资者,但输入的投资者(' || TRIM(i_InvestorID) || ')不存在或者不活跃';
          RETURN;
        END IF;
        IF TRIM(i_InvestUnitID) <> TRIM(i_InvestorID) THEN                 --投资单元
          SELECT COUNT(*)
            INTO l_Count
            FROM t_investunit t
           WHERE  t.brokerid   = i_BrokerID
             AND  t.investorid = i_InvestorID
             AND  t.investunitid = i_InvestUnitID
             AND  t.ISACTIVE = pkgs_constants.C_BOOL_TRUE ---modifie by zhang.cb 20171221;
            ;
          IF l_Count = 0 THEN
            o_nRetCode  := PKGS_Constants.C_RET_FAIL;
            o_varRetMsg := '当投资者范围为单一投资者且投资单元不为空时，投资者(' || TRIM(i_InvestorID) || ')下面的投资单元(' || TRIM(i_InvestUnitID) || ')不存在或不活跃';
            RETURN;
          END IF;
        END IF;

        -- 验证对投资者是否有权限
         Pkgs_Common.up_GenDepartmentInvestor(o_nRetCode,o_varRetMsg,i_OperatorID,i_BrokerID,i_InvestorID,NULL,NULL);
         IF o_nRetCode <> PKGS_Constants.C_RET_SUCCESS THEN
            RETURN;
         END IF;

         SELECT COUNT(*)
        INTO l_count
        FROM TMP_DepartMentInvestor t1
        WHERE t1.brokerid = i_BrokerID
        AND   t1.investorid = i_InvestorID
        AND   t1.investorrange = i_Investorrange;
        IF l_count = 0 THEN
           o_nRetCode := PKGS_Constants.C_RET_FAIL;
          o_varRetMsg := '登录用户必须有投资者('||TRIM(i_InvestorID)||')的操作权限';
          RETURN;
        END IF;

    ELSE                                                          ---- 其他
      o_nRetCode  := PKGS_Constants.C_RET_FAIL;
      o_varRetMsg := '投资者范围枚举值不在定义的范围之内';
      RETURN;
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      o_nRetCode  := PKGS_Constants.C_RET_FAIL;
      o_varRetMsg := '检查投资者范围' || TRIM(i_InvestorRange) || ',投资者' || TRIM(i_InvestorID) || '是否匹配出错';
      PKGS_Log.up_Error(l_ProcessName, '验证手续费率中投资者代码与投资者范围匹配是否有效' || '失败:' || o_varRetMsg );
  END up_ValidateCommInvestorRange;

  ---- 验证保证金率中投资者代码与投资者范围匹配是否有效
  PROCEDURE up_ValidateMarginInvestorRange
  (
    o_nRetCode                    OUT     PKGS_DataType.STY_RETCODE,                 ---- 返回码
    o_varRetMsg                   OUT     PKGS_DataType.STY_RETMSG,                   ---- 返回信息
    i_OperatorID                  IN      PKGS_DATATYPE.STY_OPERATORID,              ---- 操作员代码
    i_BrokerID                    IN      PKGS_DATATYPE.STY_BROKERID,                ---- 经纪公司代码
    i_InvestorRange               IN      PKGS_DATATYPE.STY_InvestorRange,           ---- 投资者范围
    i_InvestorID                  IN      PKGS_DATATYPE.STY_InvestorID,              ---- 投资者代码
    i_InvestUnitID                IN      PKGS_DATATYPE.STY_InvestUnitID             ---- 投资单元代码
  )
  AS
    l_Count           INT;
    l_ProcessName     PKGS_DataType.STY_SpName;                                ---- 存储过程名称
  BEGIN
    o_nRetCode := PKGS_Constants.C_RET_SUCCESS;
    l_ProcessName := 'pkg_Validate.up_ValidateMarginInvestorRange';

    ---- 检查投资者代码是否与投资者范围匹配
    IF i_InvestorRange = PKGS_Enums.RIR_All THEN                   ---- 公司标准
      IF i_InvestorID <> PKGS_Constants.DEFAULT_INVESTORID THEN
        o_nRetCode := PKGS_Constants.C_RET_FAIL;
        o_varRetMsg := '当投资者范围使用所有类型时,投资者代码必须采用缺省代码(' || PKGS_Constants.DEFAULT_INVESTORID || ')';
      END IF;
      IF i_InvestUnitID <> PKGS_Constants.DEFAULT_INVESTORID THEN
        o_nRetCode := PKGS_Constants.C_RET_FAIL;
        o_varRetMsg := '当投资者范围使用所有类型时,投资单元代码必须采用缺省代码(' || PKGS_Constants.DEFAULT_INVESTORID || ')';
      END IF;
    ELSIF i_InvestorRange = PKGS_Enums.RIR_Model THEN              ---- 保证金率率模板
      SELECT COUNT(*)
      INTO l_Count
      FROM t_invstmarginmodel
      WHERE BrokerID        = i_BrokerID
      AND   MarginmodelID   = i_InvestorID;
      IF l_Count = 0 THEN
        o_nRetCode  := PKGS_Constants.C_RET_FAIL;
        o_varRetMsg := '当投资者范围使用模板时,投资者代码必须为投资者保证金模板,但输入的保证金模板(' || TRIM(i_InvestorID) || ')不存在';
      END IF;
      IF i_InvestUnitID <> i_InvestorID THEN
        o_nRetCode := PKGS_Constants.C_RET_FAIL;
        o_varRetMsg := '当投资者范围使用模板时,投资单元代码必须为投资者保证金模板';
      END IF;
    ELSIF i_InvestorRange = PKGS_Enums.RIR_Single THEN             ---- 单一投资者
        SELECT COUNT(*)
          INTO l_Count
          FROM t_Investor
         WHERE BrokerID = i_BrokerID
           AND InvestorID = i_InvestorID
					 AND ISACTIVE = pkgs_constants.C_BOOL_TRUE   ---modifie by zhang.cb 20161201
					 ;
        IF l_Count = 0 THEN
          o_nRetCode  := PKGS_Constants.C_RET_FAIL ;
          o_varRetMsg := '当投资者范围使用客户类型时,投资者代码必须为活跃投资者,但输入的投资者(' || TRIM(i_InvestorID) || ')不存在或者不活跃';
        END IF;
        IF TRIM(i_InvestUnitID) <> TRIM(i_InvestorID) THEN                 --投资单元
          SELECT COUNT(*)
            INTO l_Count
            FROM t_investunit t
           WHERE  t.brokerid   = i_BrokerID
             AND  t.investorid = i_InvestorID
             AND  t.investunitid = i_InvestUnitID
						 AND  t.isactive = pkgs_constants.C_BOOL_TRUE;
          IF l_Count = 0 THEN
            o_nRetCode  := PKGS_Constants.C_RET_FAIL;
            o_varRetMsg := '当投资者范围为单一投资者且投资单元不为空时，投资者(' || TRIM(i_InvestorID) || ')下面的投资单元(' || TRIM(i_InvestUnitID) || ')不存在';
          END IF;
        END IF;
    ELSE                                                          ---- 其他
      o_nRetCode  := PKGS_Constants.C_RET_FAIL;
      o_varRetMsg := '投资者范围枚举值不在定义的范围之内';
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      o_nRetCode  := PKGS_Constants.C_RET_FAIL;
      o_varRetMsg := '检查投资者范围' || TRIM(i_InvestorRange) || ',投资者' || TRIM(i_InvestorID) || '是否匹配出错';
      PKGS_Log.up_Error(l_ProcessName, '验证保证金率中投资者代码与投资者范围匹配是否有效' || '失败:' || o_varRetMsg );
  END up_ValidateMarginInvestorRange;

  ---- 验证保证金率中投资者代码与投资者范围匹配是否有效(包含不活跃)
  PROCEDURE up_ValidateMarginInvstRangeAll
  (
    o_nRetCode                    OUT     PKGS_DataType.STY_RETCODE,                 ---- 返回码
    o_varRetMsg                   OUT     PKGS_DataType.STY_RETMSG,                   ---- 返回信息
    i_OperatorID                  IN      PKGS_DATATYPE.STY_OPERATORID,              ---- 操作员代码
    i_BrokerID                    IN      PKGS_DATATYPE.STY_BROKERID,                ---- 经纪公司代码
    i_InvestorRange               IN      PKGS_DATATYPE.STY_InvestorRange,           ---- 投资者范围
    i_InvestorID                  IN      PKGS_DATATYPE.STY_InvestorID,              ---- 投资者代码
    i_InvestUnitID                IN      PKGS_DATATYPE.STY_InvestUnitID             ---- 投资单元代码
  )
  AS
    l_Count           INT;
    l_ProcessName     PKGS_DataType.STY_SpName;                                ---- 存储过程名称
  BEGIN
    o_nRetCode := PKGS_Constants.C_RET_SUCCESS;
    l_ProcessName := 'pkg_Validate.up_ValidateMarginInvstRangeAll';

    ---- 检查投资者代码是否与投资者范围匹配
    IF i_InvestorRange = PKGS_Enums.RIR_All THEN                   ---- 公司标准
      IF i_InvestorID <> PKGS_Constants.DEFAULT_INVESTORID THEN
        o_nRetCode := PKGS_Constants.C_RET_FAIL;
        o_varRetMsg := '当投资者范围使用所有类型时,投资者代码必须采用缺省代码(' || PKGS_Constants.DEFAULT_INVESTORID || ')';
      END IF;
      IF i_InvestUnitID <> PKGS_Constants.DEFAULT_INVESTORID THEN
        o_nRetCode := PKGS_Constants.C_RET_FAIL;
        o_varRetMsg := '当投资者范围使用所有类型时,投资单元代码必须采用缺省代码(' || PKGS_Constants.DEFAULT_INVESTORID || ')';
      END IF;
    ELSIF i_InvestorRange = PKGS_Enums.RIR_Model THEN              ---- 保证金率率模板
      SELECT COUNT(*)
      INTO l_Count
      FROM t_invstmarginmodel
      WHERE BrokerID        = i_BrokerID
      AND   MarginmodelID   = i_InvestorID;
      IF l_Count = 0 THEN
        o_nRetCode  := PKGS_Constants.C_RET_FAIL;
        o_varRetMsg := '当投资者范围使用模板时,投资者代码必须为投资者保证金模板,但输入的保证金模板(' || TRIM(i_InvestorID) || ')不存在';
      END IF;
      IF i_InvestUnitID <> i_InvestorID THEN
        o_nRetCode := PKGS_Constants.C_RET_FAIL;
        o_varRetMsg := '当投资者范围使用模板时,投资单元代码必须为投资者保证金模板';
      END IF;
    ELSIF i_InvestorRange = PKGS_Enums.RIR_Single THEN             ---- 单一投资者
        SELECT COUNT(*)
          INTO l_Count
          FROM t_Investor
         WHERE BrokerID = i_BrokerID
           AND InvestorID = i_InvestorID
           ;
        IF l_Count = 0 THEN
          o_nRetCode  := PKGS_Constants.C_RET_FAIL ;
          o_varRetMsg := '当投资者范围使用客户类型时,投资者代码必须为活跃投资者,但输入的投资者(' || TRIM(i_InvestorID) || ')不存在';
        END IF;
        IF TRIM(i_InvestUnitID) <> TRIM(i_InvestorID) THEN                 --投资单元
          SELECT COUNT(*)
            INTO l_Count
            FROM t_investunit t
           WHERE  t.brokerid   = i_BrokerID
             AND  t.investorid = i_InvestorID
             AND  t.investunitid = i_InvestUnitID;
          IF l_Count = 0 THEN
            o_nRetCode  := PKGS_Constants.C_RET_FAIL;
            o_varRetMsg := '当投资者范围为单一投资者且投资单元不为空时，投资者(' || TRIM(i_InvestorID) || ')下面的投资单元(' || TRIM(i_InvestUnitID) || ')不存在';
          END IF;
        END IF;
    ELSE                                                          ---- 其他
      o_nRetCode  := PKGS_Constants.C_RET_FAIL;
      o_varRetMsg := '投资者范围枚举值不在定义的范围之内';
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      o_nRetCode  := PKGS_Constants.C_RET_FAIL;
      o_varRetMsg := '检查投资者范围' || TRIM(i_InvestorRange) || ',投资者' || TRIM(i_InvestorID) || '是否匹配出错';
      PKGS_Log.up_Error(l_ProcessName, '验证保证金率中投资者代码与投资者范围匹配是否有效' || '失败:' || o_varRetMsg );
  END up_ValidateMarginInvstRangeAll;

  ---- 验证投资者代码与投资者范围匹配是否有效(组织架构),added by zhang.cb
  PROCEDURE up_ValidateDepartInvestorRange
  (
   o_nRetCode                    OUT     PKGS_DataType.STY_RETCODE,                 ---- 返回码
    o_varRetMsg                   OUT     PKGS_DataType.STY_RETMSG,                   ---- 返回信息
    i_OperatorID                  IN      PKGS_DATATYPE.STY_OPERATORID,              ---- 操作员代码
    i_BrokerID                    IN      PKGS_DATATYPE.STY_BROKERID,                ---- 经纪公司代码
    i_InvestorRange               IN      PKGS_DATATYPE.STY_InvestorRange,           ---- 投资者范围
    i_InvestorID                  IN      PKGS_DATATYPE.STY_InvestorID              ---- 投资者代码
  )
  AS
    l_Count           INT;
    l_ProcessName      PKGS_DataType.STY_SpName;                                     ---- 存储过程名称
  BEGIN
    o_nRetCode := pkgs_constants.C_RET_SUCCESS;
    l_ProcessName := 'pkg_Validate.up_ValidateDepartInvestorRange';

    ---- 检查投资者代码是否与组织架构投资者范围匹配
    IF i_InvestorRange = PKGS_Constants.DR_ALL THEN                   ---- 所有
      IF i_InvestorID <> PKGS_Constants.DEFAULT_INVESTORID THEN
        o_nRetCode :=  PKGS_Constants.C_RET_FAIL;
        o_varRetMsg := '当投资者范围使用所有类型时,投资者代码必须采用缺省代码(' || pkgs_constants.DEFAULT_INVESTORID || ')';
      END IF;
    ELSIF i_InvestorRange = PKGS_Constants.DR_Group THEN                ----  组织架构
      SELECT COUNT(*)
      INTO l_Count
      FROM t_DepartMent
      WHERE BrokerID            = i_BrokerID
      AND   TRIM(DepartMentID)  = TRIM(i_InvestorID);
      IF l_Count = 0 THEN
        o_nRetCode :=  PKGS_Constants.C_RET_FAIL;
        o_varRetMsg := '当投资者范围使用组织架构类型时,投资者代码必须为组织架构,但输入的组织架构(' || TRIM(i_InvestorID) || ')不存在';
      END IF;
    ELSIF i_InvestorRange = PKGS_Constants.DR_Single THEN             ---- 客户
      SELECT COUNT(*)
      INTO l_Count
      FROM t_Investor
      WHERE BrokerID 　= i_BrokerID
      AND   InvestorID = i_InvestorID;
      IF l_Count = 0 THEN
        o_nRetCode := PKGS_Constants.C_RET_FAIL;
        o_varRetMsg := '当投资者范围使用单一客户类型时,投资者代码必须为投资者,但输入的投资者(' || TRIM(i_InvestorID) || ')不存在';
      END IF;
    ELSE                                                          ---- 其他
      o_nRetCode :=  PKGS_Constants.C_RET_FAIL;
      o_varRetMsg := '投资者范围枚举值不在定义的范围之内';
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      o_nRetCode  := PKGS_Constants.C_RET_FAIL;
      o_varRetMsg := '检查投资者范围' || TRIM(i_InvestorRange) || ',投资者' || TRIM(i_InvestorID) || '是否匹配出错';
      PKGS_Log.up_Error(l_ProcessName, '验证投资者代码与投资者范围匹配是否有效(组织架构)' || '失败:' || o_varRetMsg );
  END up_ValidateDepartInvestorRange;

  ---- 按属性剔除投资者
  PROCEDURE up_GenPartyInvestor
  (
    o_ReturnNo       OUT     PKGS_DataType.STY_RETCODE,               ---- 返回码
    o_ReturnMsg      OUT     PKGS_DataType.STY_RETMSG,              ---- 返回信息
    i_OperatorID     IN      PKGS_DATATYPE.STY_OPERATORID,          ---- 操作员代码
    i_BrokerID       IN      PKGS_DATATYPE.STY_BROKERID,            ---- 经纪公司代码
    i_PartyString    IN      PKGS_DATATYPE.STY_InvstParty           ---- 投资者属性
  )
  AS
   l_ProcessName     PKGS_DataType.STY_ProcessName;
   l_UserID          t_brokeruser.UserID%TYPE;
   l_tmpparty        tmp_party%ROWTYPE;
   l_CursorParty     PKGS_DataType.TypeRefCursor;
   L_CNT INTEGER;
  BEGIN
    o_ReturnNo := PKGS_Constants.C_S_OK ;
    l_ProcessName := 'PKGS_Common.up_GenPartyInvestor';

    ---- 按属性剔除投资者
    IF TRIM(i_PartyString) IS NOT NULL THEN
       DELETE FROM tmp_party;
       INSERT INTO tmp_party(brokerid, partyid, partyname)
       SELECT brokerid ,partyid, partyname
       FROM t_party
       WHERE brokerid = i_BrokerID
       AND instr( ',' || TRIM(i_PartyString) || ',', ',' || trim(partyid) || ',') > 0;

       OPEN l_CursorParty FOR SELECT * FROM tmp_party;
       LOOP
          FETCH l_CursorParty INTO l_tmpparty ;
          EXIT WHEN l_CursorParty%NOTFOUND;
          DELETE FROM TMP_DepartMentInvestor a
          WHERE NOT EXISTS (SELECT 1
          FROM t_investorpartymap b
          WHERE b.brokerid = l_tmpparty.brokerid
          AND   b.partyid  = l_tmpparty.partyid
          AND   a.brokerid = b.brokerid
          AND   a.investorid = b.investorid);
       END LOOP;
    END IF;

    SELECT COUNT(1) INTO L_CNT FROM TMP_DepartMentInvestor T;

    PKGS_LOG.up_Info(l_ProcessName,L_CNT);


    o_ReturnMsg := '按属性剔除投资者成功';
  EXCEPTION
    WHEN OTHERS THEN
      o_ReturnNo := PKGS_Constants.C_RET_FAIL;
      o_ReturnMsg := '按属性剔除投资者失败';
      PKGS_Log.Fatal(i_OperatorID, l_ProcessName, o_ReturnMsg);
  END up_GenPartyInvestor;

 ---- 按属性剔除投资者
  PROCEDURE up_GenPartyInvestor1
  (
    o_ReturnNo       OUT     PKGS_DataType.STY_RETCODE,               ---- 返回码
    o_ReturnMsg      OUT     PKGS_DataType.STY_RETMSG,              ---- 返回信息
    i_OperatorID     IN      PKGS_DATATYPE.STY_OPERATORID,          ---- 操作员代码
    i_BrokerID       IN      PKGS_DATATYPE.STY_BROKERID,            ---- 经纪公司代码
    i_PartyString    IN      PKGS_DATATYPE.STY_InvstParty,           ---- 投资者属性
    i_StatPropertyString IN   PKGS_DATATYPE.STY_InvstParty           ---- 投资者属性
  )
  AS
   l_ProcessName     PKGS_DataType.STY_ProcessName;
   l_UserID          t_brokeruser.UserID%TYPE;
   l_tmpparty        tmp_party%ROWTYPE;
   l_CursorParty     PKGS_DataType.TypeRefCursor;
   L_CNT INTEGER;
    l_propertyID   PKGS_DATATYPE.STY_RETMSG;
    l_propertyname PKGS_DATATYPE.STY_RETMSG;
  BEGIN
    o_ReturnNo := PKGS_Constants.C_S_OK ;
    l_ProcessName := 'PKGS_Common.up_GenPartyInvestor';
    ---- 按属性剔除投资者
    IF TRIM(i_PartyString) IS NOT NULL THEN
       DELETE FROM tmp_party;
       INSERT INTO tmp_party(brokerid, partyid, partyname)
       SELECT brokerid ,partyid, partyname
       FROM t_party
       WHERE brokerid = i_BrokerID
       AND instr( ',' || TRIM(i_PartyString) || ',', ',' || trim(partyid) || ',') > 0;

       OPEN l_CursorParty FOR SELECT * FROM tmp_party;
       LOOP
          FETCH l_CursorParty INTO l_tmpparty ;
          EXIT WHEN l_CursorParty%NOTFOUND;
          DELETE FROM TMP_DepartMentInvestor a
          WHERE NOT EXISTS (SELECT 1
          FROM t_investorpartymap b
          WHERE b.brokerid = l_tmpparty.brokerid
          AND   b.partyid  = l_tmpparty.partyid
          AND   a.brokerid = b.brokerid
          AND   a.investorid = b.investorid);
       END LOOP;
    END IF;

    ---- 如果需要统计,获取投资者属性
    IF TRIM(i_StatPropertyString) IS NOT NULL THEN
       FOR c_result IN (SELECT * FROM TMP_DepartMentInvestor)
       LOOP
          up_GetInvestorProperty(o_ReturnNo,o_ReturnMsg,i_OperatorID,i_BrokerID,c_result.investorid, i_StatPropertyString,l_propertyID, l_propertyname);
          IF o_ReturnNo <> pkgs_constants.C_RET_SUCCESS THEN
             o_ReturnMsg := '获取操作员查询权限的投资者到临时表失败';
             RETURN;
          END IF;

       UPDATE/*+ index(t idx_tmp_departmentinvestor )*/  TMP_DepartMentInvestor t
          SET t.propertyid   = TRIM(l_propertyID),
              t.propertyname = TRIM(l_propertyname)
          WHERE t.brokerid = c_result.brokerid
          AND t.investorrange = PKGS_Enums.DR_Single
          AND t.investorid = c_result.investorid;
      END LOOP;
    END IF;


    SELECT COUNT(1) INTO L_CNT FROM TMP_DepartMentInvestor T;

    PKGS_LOG.up_Info(l_ProcessName,L_CNT);


    o_ReturnMsg := '按属性剔除投资者成功';
  EXCEPTION
    WHEN OTHERS THEN
      o_ReturnNo := PKGS_Constants.C_RET_FAIL;
      o_ReturnMsg := '按属性剔除投资者失败';
      PKGS_Log.Fatal(i_OperatorID, l_ProcessName, o_ReturnMsg);
  END up_GenPartyInvestor1;

  ----获取操作员是否有所有数据权限
  FUNCTION uf_GetIsDefaultDepartMent
  (
    i_BrokerID     IN      PKGS_DATATYPE.STY_BROKERID,           ---- 经纪公司代码
    i_OperatorID   IN      PKGS_DATATYPE.STY_OPERATORID          ---- 操作员代码
  )
  RETURN PKGS_DataType.STY_Bool
  AS
    l_count           NUMBER;
    l_UserID          t_brokeruser.UserID%TYPE;
  BEGIN

    l_UserID := SUBSTR(TRIM(i_OperatorID), INSTR(TRIM(i_OperatorID), '.') + 1) ;

    ---- 检测user对应的分组级别 对'00'级别的有所有权限
    SELECT COUNT(*)
    INTO l_count
    FROM (
           SELECT BrokerID ,UserID,InvestorID AS DepartMentID
           FROM   t_departmentuser
           WHERE  BrokerID      = i_BrokerID
           AND    InvestorRange = PKGS_Enums.DR_Group
           UNION
           SELECT Brokerid,userID,PKGS_Constants.DEFAULT_BrokerDepartMentID/*PKGS_Constants.DEFAULT_BrokerDepartMentID*/ AS DepartMentID
           FROM   t_brokeruser
           WHERE  BrokerID = i_BrokerID
           AND    Isadmin  =  PKGS_Constants.C_BOOL_TRUE
           UNION
           SELECT i_BrokerID,userID,PKGS_Constants.DEFAULT_BrokerDepartMentID AS DepartMentID
           FROM   t_superuser
          )
    WHERE TRIM(DepartMentID) = TRIM(PKGS_Constants.DEFAULT_BrokerDepartMentID)
    AND TRIM(UserID)         = TRIM(l_UserID);

    IF l_count > 0 THEN
       RETURN PKGS_Constants.C_BOOL_TRUE;
    ELSE
       RETURN PKGS_Constants.C_BOOL_FALSE;
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      RAISE_APPLICATION_ERROR(-20001, '获取操作员是否有所有数据权限出错---'|| SQLCODE || '---' || SQLERRM);
  END uf_GetIsDefaultDepartMent;

  ----获取操作员是否是管理员权限
  FUNCTION uf_GetIsAdmin
  (
    i_BrokerID     IN      PKGS_DATATYPE.STY_BROKERID,           ---- 经纪公司代码
    i_OperatorID   IN      PKGS_DATATYPE.STY_OPERATORID          ---- 操作员代码
  )
  RETURN PKGS_DataType.STY_Bool
  AS
    l_count           NUMBER;
    l_UserID          t_brokeruser.UserID%TYPE;
  BEGIN

    l_UserID := SUBSTR(TRIM(i_OperatorID), INSTR(TRIM(i_OperatorID), '.') + 1) ;

    ---- 检测user对应的分组级别 对'00'级别的有所有权限
    SELECT COUNT(*)
    INTO l_count
    FROM (
           SELECT Brokerid,userID,PKGS_Constants.DEFAULT_BrokerDepartMentID AS DepartMentID
           FROM   t_brokeruser
           WHERE  BrokerID = i_BrokerID
           AND    Isadmin  =  PKGS_Constants.C_BOOL_TRUE
           UNION
           SELECT i_BrokerID,userID,PKGS_Constants.DEFAULT_BrokerDepartMentID AS DepartMentID
           FROM   t_superuser
          )
    WHERE TRIM(DepartMentID) = TRIM(PKGS_Constants.DEFAULT_BrokerDepartMentID)
    AND TRIM(UserID)         = TRIM(l_UserID);

    IF l_count > 0 THEN
       RETURN PKGS_Constants.C_BOOL_TRUE;
    ELSE
       RETURN PKGS_Constants.C_BOOL_FALSE;
    END IF;
  EXCEPTION
   WHEN OTHERS THEN
      RAISE_APPLICATION_ERROR(-20001, '获取操作员是否是管理员权限---'|| SQLCODE || '---' || SQLERRM);
  END uf_GetIsAdmin;

  ----获取当前最新的结算任务号function
  FUNCTION uf_QryLatestSettleTaskID(i_BrokerID  IN PKGS_DataType.STY_BrokerID,
                                    i_chOperatorID IN  PKGS_DataType.STY_OperatorID,						----操作员代码
                                    i_chExchangeID IN PKGS_DataType.STY_ExchangeID)
  RETURN PKGS_DataType.STY_SettleTaskID DETERMINISTIC
  AS
    ---- 获取最新的结算任务号

    l_ProcessName PKGS_DataType.STY_SpName; ---- 存储过程名称
    v_opdate T_SETTLETASKRECORD.opdate%type;
		l_SettleTaskID PKGS_DataType.STY_SettleTaskID;
		v_maxID number(4);
  BEGIN

    l_ProcessName := 'PKGS_COMMON.uf_QryLatestSettleTaskID';
    PKGS_Log.info(i_chOperatorID, l_ProcessName, '开始获取最新的结算任务号');

    select max(opDate)
      into v_opdate
	    from T_SETTLETASKRECORD
	  WHERE i_brokerID = BrokerID
	    and (ExchangeID = i_chExchangeID or
	        trim(i_chExchangeID) = trim(PKGS_Constants.DEFAULT_EXCHANGE));

    select Max(to_number(substr(SettleTaskID, 13, 4)))
      into v_maxID
	    from T_SETTLETASKRECORD
	   WHERE i_brokerID = BrokerID
	     and (ExchangeID= i_chExchangeID or
	       trim(i_chExchangeID) =trim( PKGS_Constants.DEFAULT_EXCHANGE))
	     and opdate=v_opdate;

    select a.SETTLETASKID
       into l_SettleTaskID
	      from T_SETTLETASKRECORD a
	     where ( a.ExchangeID  = i_chExchangeID  or
	           trim(i_chExchangeID) =trim( PKGS_Constants.DEFAULT_EXCHANGE))
	       AND a.brokerID = i_brokerID
	       and a.opdate=v_opdate
	       and to_number(substr(a.SettleTaskID, 13, 4)) =v_maxID
	       and rownum<2;

    PKGS_Log.info(i_chOperatorID, l_ProcessName, '成功获取最新的结算任务号');

    RETURN l_SettleTaskID;
  EXCEPTION
    WHEN OTHERS THEN
      PKGS_Log.Fatal(i_chOperatorID, l_ProcessName, '获取结算任务号出错');
  END uf_QryLatestSettleTaskID;


    PROCEDURE up_GetInvestorAccountID
  (
    o_nRetCode              OUT    PKGS_DATATYPE.STY_RETCODE,            ---- 返回码
    o_varRetMsg             OUT    PKGS_DATATYPE.STY_RETMSG,           ---- 返回信息
    o_AccountID             OUT     t_account.accountid%TYPE,
    i_BrokerID              IN      t_Broker.BrokerID%TYPE,             ---- 经纪公司代码
    i_InvestorID            IN      t_Investor.InvestorID%TYPE,          ---- 投资者代码
    i_CurrencyID            IN      t_account.currencyid%TYPE           ---- 币种
  )
  AS
    l_Count           INT;
    l_ProcessName      PKGS_DataType.STY_SpName;                      ---- 存储过程名称
  BEGIN
    o_nRetCode := PKGS_Constants.C_RET_SUCCESS;
    l_ProcessName := 'up_GetInvestorAccountID';
    ---- 取投资者的资金账户
    SELECT COUNT(*)
      INTO l_count
      FROM t_accountownership o, t_account a
     WHERE o.brokerid   = a.brokerid
       AND o.accountid  = a.accountid
       AND o.currencyid = a.currencyid
       AND o.brokerid   = i_brokerid
       AND o.accountowner = i_investorid
       AND o.currencyid   = i_CurrencyID
       AND o.accountownermode = '1'
       AND o.isactive = pkgs_constants.c_bool_true
       AND a.isactive = pkgs_constants.c_bool_true;
    IF   l_count = 0   THEN
        o_nRetCode := Pkgs_Constants.C_RET_FAIL;
        o_varRetMsg := '投资者币种为'||i_CurrencyID||'的资金账户不存在或者不活跃';
        RETURN;
    ELSE
        ---- 读取投资者帐号
        SELECT o.accountid
          INTO o_accountid
          FROM t_accountownership o, t_account a
         WHERE o.brokerid = a.brokerid
           AND o.accountid = a.accountid
           AND o.currencyid = a.currencyid
           AND o.brokerid = i_brokerid
           AND o.accountowner = i_investorid
           AND o.currencyid = i_CurrencyID
           AND o.accountownermode = '1'
           AND o.isactive = pkgs_constants.c_bool_true
           AND a.isactive = pkgs_constants.c_bool_true
           AND rownum < 2;
    END IF;
    PKGS_Log.up_Info(l_ProcessName, o_varRetMsg);
  EXCEPTION
    WHEN OTHERS THEN
      o_nRetCode := PKGS_Constants.C_RET_FAIL;
      o_varRetMsg := '获取投资者账户失败';
      PKGS_Log.up_Fatal(l_ProcessName, o_varRetMsg);
 END up_GetInvestorAccountID;

	----获取系统结算参数（不写日志）
	FUNCTION uf_GetSysParamValue
	(
		i_BrokerID      							IN      PKGS_DATATYPE.STY_BrokerID,             	 ---- 经纪公司代码
		i_SystemParamID               IN      t_SysSettleParam.SYSTEMPARAMID%TYPE,       ---- 系统参数代码
		i_OperatorID   IN      PKGS_DATATYPE.STY_OPERATORID          ---- 操作员代码
	) return t_SysSettleParam.SYSTEMPARAMVALUE%TYPE   AS
		l_ProcessName PKGS_DataType.STY_SpName; ---- 函数名称
		l_SysParamValue t_SysSettleParam.SYSTEMPARAMVALUE%TYPE;
		CURSOR c_GetSysParamValue IS
															SELECT SystemParamValue
																FROM t_syssettleparam
															 WHERE TRIM(BrokerID) = TRIM(i_BrokerID)
																 AND TRIM(SystemParamID)=TRIM(i_SystemParamID);
	 BEGIN
	    l_ProcessName := 'PKGS_COMMON.uf_GetSysParamValue';
			----modified by zhang.cb 20170113 ,
			----该函数循环调用时写日志会造成额外开销，影响性能，故改为不写日志
			----如果需要写日志请调uf_GetSysParamValue2
	    OPEN c_GetSysParamValue;
	    FETCH c_GetSysParamValue
	      INTO l_SysParamValue;
	    CLOSE c_GetSysParamValue;
	    RETURN l_SysParamValue;
	  EXCEPTION
	    WHEN OTHERS THEN
	      PKGS_Log.Fatal(i_OperatorID, l_ProcessName, '获取系统结算参数出错');
	  END uf_GetSysParamValue;
	----获取系统结算参数 (写日志)
	FUNCTION uf_GetSysParamValue2
	(
		i_BrokerID      							IN      PKGS_DATATYPE.STY_BrokerID,             	 ---- 经纪公司代码
		i_SystemParamID               IN      t_SysSettleParam.SYSTEMPARAMID%TYPE,       ---- 系统参数代码
		i_OperatorID   IN      PKGS_DATATYPE.STY_OPERATORID          ---- 操作员代码
	) return t_SysSettleParam.SYSTEMPARAMVALUE%TYPE   AS
		l_ProcessName PKGS_DataType.STY_SpName; ---- 函数名称
		l_SysParamValue t_SysSettleParam.SYSTEMPARAMVALUE%TYPE;
		CURSOR c_GetSysParamValue IS
															SELECT SystemParamValue
																FROM t_syssettleparam
															 WHERE TRIM(BrokerID) = TRIM(i_BrokerID)
																 AND TRIM(SystemParamID)=TRIM(i_SystemParamID);
	 BEGIN
	    l_ProcessName := 'PKGS_COMMON.uf_GetSysParamValue2';
			----modified by zhang.cb 20170113
			----写日志会造成额外开销，若涉及循环请调uf_GetSysParamValue
	    PKGS_Log.info(i_OperatorID, l_ProcessName, '开始获取系统结算参数');
	    OPEN c_GetSysParamValue;
	    FETCH c_GetSysParamValue
	      INTO l_SysParamValue;
	    CLOSE c_GetSysParamValue;
	    PKGS_Log.info(i_OperatorID, l_ProcessName, '成功获取系统结算参数');
	    RETURN l_SysParamValue;
	  EXCEPTION
	    WHEN OTHERS THEN
	      PKGS_Log.Fatal(i_OperatorID, l_ProcessName, '获取系统结算参数出错');
	  END uf_GetSysParamValue2;

  PROCEDURE up_ifExistsAccountID
  (
    o_nRetCode              OUT    PKGS_DATATYPE.STY_RETCODE,            ---- 返回码
    o_varRetMsg             OUT    PKGS_DATATYPE.STY_RETMSG,           ---- 返回信息
    i_AccountID             IN     t_account.accountid%TYPE,
    i_BrokerID              IN      t_Broker.BrokerID%TYPE,             ---- 经纪公司代码
    i_InvestorID            IN      t_Investor.InvestorID%TYPE,          ---- 投资者代码
    i_CurrencyID            IN      t_account.currencyid%TYPE           ---- 币种
  )
  AS
    l_Count           INT;
    l_ProcessName      PKGS_DataType.STY_SpName;                      ---- 存储过程名称
    l_accntid        t_account.accountid%TYPE;
       CURSOR c_AccntIDs is
       SELECT o.AccountID
        FROM   t_AccountOwnerShip o, t_account a
        WHERE o.brokerid = a.brokerid
        AND   o.accountid = a.accountid
        AND   a.accountid = i_AccountID
        AND   a.currencyid = i_CurrencyID
        AND   o.BrokerID   = i_BrokerID
        AND   o.AccountOwner = i_InvestorID
        AND   o.AccountOwnerMode = '1'
        AND   o.IsActive = PKGS_CONSTANTS.C_BOOL_TRUE
        AND   a.isactive = PKGS_CONSTANTS.C_BOOL_TRUE;

  BEGIN
    o_nRetCode := PKGS_Constants.C_RET_FAIL;
    l_ProcessName := 'up_GetInvestorAccountID';
    o_varRetMsg := '开始判断资金账户是否存在';

    open c_AccntIDs;
    loop
      fetch c_AccntIds into l_accntid;
      if c_AccntIDs%NOTFOUND
      then
        o_varRetMsg :='对应币种的资金账户不存在或不活跃';
        o_nRetCode := Pkgs_Constants.C_RET_FAIL;
        exit;
      end if;
      if l_accntid=i_AccountID then
	      o_varRetMsg :='对应币种的资金账户存在';
        o_nRetCode := Pkgs_Constants.C_RET_SUCCESS;
        exit;
      end if;
    end loop;
    close c_AccntIDs;

    PKGS_Log.up_Info(l_ProcessName, '判断资金账户是否存在完成');
  EXCEPTION
    WHEN OTHERS THEN
      o_nRetCode := PKGS_Constants.C_RET_FAIL;
      o_varRetMsg := '获取投资者账户失败';
      PKGS_Log.up_Fatal(l_ProcessName, o_varRetMsg);
 END up_ifExistsAccountID;
 FUNCTION uf_QrySettleDate(i_BrokerID IN PKGS_DataType.STY_BrokerID,
													  i_chOperatorID IN  PKGS_DataType.STY_OperatorID,
													  i_chExchangeID IN PKGS_DataType.STY_ExchangeID)
    RETURN PKGS_DataType.STY_DATE DETERMINISTIC IS
    ---- 获取结算日期

    l_ProcessName PKGS_DataType.STY_SpName; ---- 存储过程名称
    l_tradingday PKGS_DataType.STY_DATE;
    cursor c_QrySettleDate is
      select settlementDate
        from t_SettleDate
       WHERE BrokerID =  i_BrokerID
         and trim(ExchangeID)  = trim(nvl(i_chExchangeID,PKGS_Constants.DEFAULT_EXCHANGE));
  BEGIN

    l_ProcessName := 'PKGS_COMMON.uf_QrySettleDate';
    PKGS_Log.info(i_chOperatorID, l_ProcessName, '开始获取结算日期');
    open c_QrySettleDate;
    fetch c_QrySettleDate
      into l_tradingday;
    close c_QrySettleDate;
    PKGS_Log.info(i_chOperatorID, l_ProcessName, '成功获取结算日期');

    RETURN l_tradingday;
  EXCEPTION
    WHEN OTHERS THEN
      PKGS_Log.Fatal(i_chOperatorID, l_ProcessName, '获取结算日期出错');
  END uf_QrySettleDate;
  ---- 判断string 是否一致
  FUNCTION uf_StringIsSame
  (
    i_Str1        IN      varchar2,
    i_Str2        IN      varchar2
  )
  RETURN Boolean
  AS
  BEGIN
    IF TRIM(i_Str1) IS NULL AND TRIM(i_Str2) IS NULL THEN
      RETURN TRUE;
    ELSIF TRIM(i_Str1) IS NOT NULL AND TRIM(i_Str2) IS NOT NULL THEN
      RETURN  TRIM(i_Str1) = TRIM(i_Str2);
    ELSE
      RETURN FALSE;
    END IF;
  END uf_StringIsSame;
  ---- 判断Number 是否一致
   FUNCTION uf_NumberIsSame
  (
    i_number1     IN      NUMBER,
    i_number2     IN      NUMBER
  )
  RETURN Boolean
  AS
  BEGIN
    IF i_number1 IS NULL AND i_number2 IS NULL THEN
      RETURN TRUE;
    ELSIF i_number1 IS NOT NULL AND i_number2 IS NOT NULL THEN
      RETURN i_number1 = i_number2;
    ELSE
      RETURN FALSE;
    END IF;
  END uf_NumberIsSame;
  ---- 创建系统日志记录
  PROCEDURE up_CrtSysOperateLog
  (
    o_nRetCode              OUT         PKGS_DATATYPE.STY_RETCODE         ---- 返回码
    ,o_varRetMsg             IN OUT      PKGS_DATATYPE.STY_RETMSG           ---- 返回信息
    ,i_OperatorID            IN          PKGS_DATATYPE.STY_OPERATORID           ---- 操作员代码
     ,io_TySysOperateLog    IN OUT      Ty_SysOperateLog                   ---- 系统日志记录信息类型
  )
  AS
  	l_TradingDay      PKGS_DataType.STY_DATE;
    l_varSPName t_Operationlog.ProcessName%TYPE := 'pkgs_common.up_CrtSysOperateLog';                            ---- 存储过程名称
    l_ReturnMsg       PKGS_DATATYPE.STY_RETMSG;          ---- 返回信息
  BEGIN
		pkgs_Log.up_Debug(l_varSPName, SubStr(io_TySysOperateLog.uf_toString,1,3000));

    -- 检查非空字段
    IF trim(io_TySysOperateLog.BrokerID) IS NULL THEN -- 经纪公司代码
      o_nRetCode := PKGS_Constants.E_USER_ERROR;
      o_varRetMsg := '【经纪公司代码】不允许为空';
      RETURN;
    END IF;
    IF trim(io_TySysOperateLog.OperationMemo) IS NULL THEN -- 操作摘要
      o_nRetCode := PKGS_Constants.E_USER_ERROR;
      o_varRetMsg := '【操作摘要】不允许为空';
      RETURN;
    END IF;

		/* --TODO:临时注释 by marmot.zeng.20150702.begin
    ---- 检查系统状态
    pkgs_common.up_ValidateSystemStatus(o_nRetCode, o_varRetMsg, NULL,null);
    IF o_nRetCode <> pkgs_constants.C_RET_SUCCESS THEN
      pkgs_Log.up_Error( l_varSPName, o_varRetMsg);
      RETURN;
    END IF;
    --TODO:临时注释 by marmot.zeng.20150702.end
    */

    ---- 获取结算日期
    PKGS_COMMON.up_QrySettleDate(io_TySysOperateLog.BrokerID,NULL,i_OperatorID,l_TradingDay,o_nRetCode,o_varRetMsg);
    IF o_nRetCode <> pkgs_constants.C_RET_SUCCESS THEN
      pkgs_Log.up_Error( l_varSPName, o_varRetMsg);
      RETURN;
    END IF;

    io_TySysOperateLog.TradingDay				:= l_TradingDay;
    io_TySysOperateLog.OperatorID       := TRIM(SUBSTR(i_OperatorID, INSTR(i_OperatorID, '.') + 1));
    io_TySysOperateLog.OperateDate      := TO_CHAR(SYSDATE, 'YYYYMMDD');
    io_TySysOperateLog.OperateTime      := TO_CHAR(SYSDATE, 'HH24:MI:SS');

    IF TRIM(io_TySysOperateLog.OperationMemo) IS NOT NULL THEN
      io_TySysOperateLog.SequenceNo := pkgs_common.uf_GetSysOperateLogSeq;
      --PKGD_Insert.up_InsSysOperateLog(io_TySysOperateLog,o_nRetCode,o_varRetMsg);
      INSERT INTO t_SysOperateLog(
      	TradingDay,SequenceNo,BrokerID
      	,SysOperType,SysOperMode,OperationMemo
      	,OperatorID,OperateDate,OperateTime
      )
      VALUES(
      	io_TySysOperateLog.TradingDay,io_TySysOperateLog.SequenceNo,io_TySysOperateLog.BrokerID
      	,io_TySysOperateLog.SysOperType,io_TySysOperateLog.SysOperMode,io_TySysOperateLog.OperationMemo
      	,io_TySysOperateLog.OperatorID,io_TySysOperateLog.OperateDate,io_TySysOperateLog.OperateTime
      );

    	IF o_nRetCode <> pkgs_constants.C_RET_SUCCESS THEN
    	  pkgs_Log.up_Error( l_varSPName, o_varRetMsg);
    	  RETURN;
    	END IF;
    END IF;

    pkgs_Log.up_info(l_varSPName, o_varRetMsg);
    o_varRetMsg := l_ReturnMsg;
  EXCEPTION
    WHEN OTHERS THEN
      o_nRetCode := PKGS_Constants.C_RET_FAIL;
      o_varRetMsg := '创建日志信息出错';
      pkgs_Log.up_Fatal( l_varSPName, o_varRetMsg);
  END up_CrtSysOperateLog;

  ----获取序列号
  FUNCTION uf_GetSysOperateLogSeq
    RETURN  t_SysOperateLog.Sequenceno%type
    AS
      l_SequenceNo   t_SysOperateLog.Sequenceno%type;
    BEGIN
      SELECT  SEQ_SysOperateLog.NEXTVAL
      INTO l_SequenceNo
      FROM DUAL;

      RETURN l_SequenceNo;
    EXCEPTION
      WHEN OTHERS THEN
        RAISE_APPLICATION_ERROR(-20002, '获取序列号---'|| SQLCODE || '---' || SQLERRM);
   END uf_GetSysOperateLogSeq;
   ---- 检查枚举值
  PROCEDURE up_CheckEnumChar
  (
   o_nRetCode  OUT NOCOPY PKGS_DATATYPE.STY_RETCODE
    ,o_varRetMsg  OUT NOCOPY PKGS_DATATYPE.STY_RETMSG
    ,i_EnumType      IN      pkgs_datatype.STY_EnumName            ---- 类型名称
    ,i_EnumValue     IN      pkgs_datatype.STY_EnumChar             ---- 类型值
  )
  AS
    l_Count         INT;
  BEGIN
    o_nRetCode := pkgs_constants.C_RET_SUCCESS;

    IF i_EnumValue IS NULL  OR LENGTH(TRIM(i_EnumValue)) = 0 THEN
      RETURN;
    END IF;

    SELECT COUNT(*)
    INTO l_Count
    FROM t_EnumMetadata
    WHERE EnumValueType   = i_EnumType
    AND   EnumValueResult = i_EnumValue;
    IF l_Count > 0 THEN
      RETURN;
    ELSE
      o_nRetCode := pkgs_constants.C_RET_FAIL;
        end if;
  EXCEPTION
    WHEN OTHERS THEN
      o_nRetCode := pkgs_constants.C_RET_FAIL;


  END up_CheckEnumChar;

  ---- Md5加密
  FUNCTION uf_EncryptMd5Password
  (
    i_password   IN  t_investorloginaccount.loginaccountpassword%TYPE           ---- 经纪公司代码
  )
  RETURN  VarChar2
  AS PRAGMA AUTONOMOUS_TRANSACTION;
    md5_out CHAR(32);
    random_string CHAR(5);
    l_password t_investorloginaccount.loginaccountpassword%TYPE;
  BEGIN
      -- 如果存在加密，就直接返回
      IF i_password IS NOT NULL AND length(i_password) > 1 THEN
          IF '1' = substr(i_password,1,1) AND 1 = ascii(substr(i_password,2,1)) THEN
              RETURN i_password;
          END IF;
      END IF;
      -- 取得随机5位字符串
      random_string := dbms_random.string('x',5);
      -- 加密
      md5_out := LOWER(Utl_Raw.Cast_To_Raw(DBMS_OBFUSCATION_TOOLKIT.MD5(input_string =>random_string||trim(i_password))));
      -- 更新到t_investor表上
      l_password := '1'||CHR(1)||random_string||CHR(1)||md5_out;
    RETURN l_password;

  EXCEPTION
    WHEN OTHERS THEN
      RAISE_APPLICATION_ERROR(-20001, '密码加密出错---'|| SQLCODE || '---' || SQLERRM);
  END uf_EncryptMd5Password;


  ---- 获取投资者属性
  PROCEDURE up_GetInvestorProperty
  (
    o_nRetCode              OUT NOCOPY PKGS_DATATYPE.STY_RETCODE,         ---- 返回码
    o_varRetMsg             OUT NOCOPY PKGS_DATATYPE.STY_RETMSG,          ---- 返回信息
    i_OperatorID            IN         PKGS_DATATYPE.STY_OPERATORID,      ---- 操作员代码
    i_BrokerID              IN      PKGS_DATATYPE.STY_BrokerID,           ---- 经纪公司代码
    i_InvestorID            IN      PKGS_DATATYPE.STY_InvestorID,
    i_StatPropertyString    IN      PKGS_DATATYPE.STY_PropertyString,     ---- 投资者属性
    o_propertyID            OUT     PKGS_DATATYPE.STY_RETMSG,
    o_propertyname          OUT     PKGS_DATATYPE.STY_RETMSG
  )
  AS
    l_varSPName             t_Operationlog.ProcessName%TYPE := 'pkgs_common.up_GetInvestorProperty'; ---- 存储过程名称
    l_count           NUMBER;
  BEGIN
    l_varSPName := 'pkgs_common.up_GetInvestorProperty';

    FOR c_investorproperty IN
       (SELECT investorid, a.partyID,b.partyname, b.PARENTPARTYID
        FROM t_investorpartymap a , t_party b
        WHERE a.partyid = b.partyid
        AND   a.brokerid = b.brokerid
        AND   instr(',' || TRIM(i_StatPropertyString) || ',' , ',' || TRIM(b.PARENTPARTYID) || ',') > 0
        AND   a.brokerid = i_BrokerID
        AND   a.investorid = i_investorid
        ORDER BY a.partyid
       )
    LOOP
         IF (TRIM(o_propertyID) IS NOT NULL) THEN
            o_propertyID := nvl(TRIM(o_propertyID),'') || '-' || TRIM(c_investorproperty.partyID);
            o_propertyname := nvl(TRIM(o_propertyname),'') || '--' || TRIM(c_investorproperty.partyname);
         ELSE
            o_propertyID := TRIM(c_investorproperty.partyID);
            o_propertyname := TRIM(c_investorproperty.partyname);
         END IF;
    END LOOP;

  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      o_nRetCode := pkgs_constants.C_S_FAILED;
      pkgs_Log.up_Fatal( l_varSPName, '获取投资者属性失败');
  END up_GetInvestorProperty;
  ---- 验证经纪公司
  PROCEDURE up_Validatebrokerid
  (
    o_nRetCode             OUT NOCOPY PKGS_DATATYPE.STY_RETCODE,            ---- 返回码
    o_varRetMsg             OUT NOCOPY PKGS_DATATYPE.STY_RETMSG,           ---- 返回信息
     i_BrokerID              IN      PKGS_DATATYPE.STY_BrokerID             ---- 经纪公司代码
  )
   AS
    l_Count           INT;
    l_varSPName       t_Operationlog.ProcessName%TYPE := 'pkgs_common.up_Validatebrokerid'; ---- 存储过程名称
    l_isactive        t_broker.isactive%type;
  BEGIN

    IF i_brokerid IS NULL THEN
      o_nRetCode := PKGS_Constants.C_RET_FAIL;
      o_varRetMsg := '经纪公司代码不能为空值';
      RETURN;
    END IF;
        SELECT COUNT(*)
        INTO l_Count
        FROM t_broker
        WHERE TRIM(brokerid) = TRIM(i_brokerid);
        IF l_Count > 0 THEN
          SELECT isactive
          INTO   l_isactive
          FROM   t_broker
          WHERE TRIM(brokerid) = TRIM(i_brokerid);
          IF l_isactive = PKGS_Constants.C_RET_FAIL  THEN
             o_nRetCode := PKGS_Constants.C_RET_FAIL;
             o_varRetMsg := '经纪公司('||TRIM(i_brokerid)||')不是活跃状态';
            RETURN;
          END IF;
        ELSE
            o_nRetCode := PKGS_Constants.C_RET_FAIL;
             o_varRetMsg := '经纪公司('||TRIM(i_brokerid)||')不存在';
            RETURN;
        END IF;
  EXCEPTION
    WHEN OTHERS THEN
      o_nRetCode := PKGS_Constants.C_RET_FAIL;
      o_varRetMsg := '验证经纪公司时出错';
      pkgs_Log.up_Fatal(l_varSPName,o_varRetMsg);
  END up_Validatebrokerid;

    ---- 获取操作员查询权限的投资者
  PROCEDURE up_GenDepartPropertyInvestor
  (
    o_nRetCode            OUT     PKGS_DATATYPE.STY_RETCODE,            ---- 返回码
    o_varRetMsg           OUT     PKGS_DATATYPE.STY_RETMSG,           ---- 返回信息
    i_OperatorID          IN      PKGS_DATATYPE.STY_OPERATORID,          ---- 操作员代码
    i_BrokerID            IN      PKGS_DATATYPE.STY_BrokerID,            ---- 经纪公司代码
    i_InvestorID          IN      PKGS_DATATYPE.STY_InvestorID,          ---- 投资者代码
    i_InvestUnitID        IN      PKGS_DATATYPE.STY_InvestUnitID,     ----投资单元代码
    i_InvestorType        IN      t_Investor.InvestorType%Type,       ---- 投资者类型
    i_PropertyString      IN      PKGS_DATATYPE.STY_PropertyString,      ---- 操作员代码
    i_StatPropertyString  IN      PKGS_DATATYPE.STY_PropertyString,      ---- 操作员代码
    i_IsDepartmentRight   IN      PKGS_DATATYPE.STY_Bool                 ---- 是否过滤数据权限
  )
  AS
   l_ProcessName     PKGS_DataType.STY_SpName;               ---- 存储过程名称
   l_propertyID      PKGS_DataType.STY_RETMSG;
   l_propertyname    PKGS_DataType.STY_RETMSG;
   l_tmpproperty     tmp_property%ROWTYPE;
   type CursorProperty is REF CURSOR;
   l_CursorProperty  CursorProperty;
	 l_InvestorCount   INT;
  BEGIN
    o_nRetCode := PKGS_Constants.C_S_OK ;
    l_ProcessName := 'pkgs_common.up_GenDepartPropertyInvestor';
		IF TRIM(i_InvestorID) IS NOT NULL THEN
      SELECT COUNT(*)
        INTO l_InvestorCount
        FROM t_Investor
       WHERE BrokerID   = i_BrokerID
         AND InvestorID = i_InvestorID;
      IF l_InvestorCount < 1 THEN
        o_nRetCode := PKGS_Constants.C_RET_FAIL;
        o_varRetMsg := '投资者代码(' || TRIM(i_investorid) || ')为空或不存在';
        RETURN;
      END IF ;
    END IF ;
    ---- 根据操作员权限获取投资者
    IF i_IsDepartmentRight = PKGS_Constants.C_BOOL_TRUE THEN
       up_GenDepartmentInvestor(o_nRetCode, o_varRetMsg, i_OperatorID, i_BrokerID, i_InvestoriD , i_InvestorType , i_PropertyString);
       IF o_nRetCode <> PKGS_Constants.C_S_OK THEN
         RETURN;
       END IF;
    ELSE
       delete from  TMP_DepartMentInvestor where brokerid = i_BrokerID;
       INSERT INTO TMP_DepartMentInvestor(BrokerID ,UserID ,InvestorRange,InvestorID/*,InvestunitID*/ )
       SELECT BrokerID,SUBSTR(i_OperatorID, INSTR(i_OperatorID, '.') + 1),pkgs_constants.DR_Single,InvestorID/*,InvestunitID*/
       FROM  t_Investor
       WHERE  BrokerID = i_BrokerID
         AND (trim(i_InvestorID) IS NULL OR investorid = i_InvestorID)
         AND (trim(i_InvestorType) IS NULL OR investorType = i_InvestorType);
    END IF;

    ---- 按属性剔除投资者
    IF TRIM(i_PropertyString) IS NOT NULL THEN
       DELETE FROM tmp_property;
       INSERT INTO tmp_property(brokerid, propertyid, propertyname)
       SELECT brokerid ,PARTYID, PARTYNAME
       FROM t_party
       WHERE brokerid = i_BrokerID
       AND instr( ',' || TRIM(i_PropertyString) || ',', ',' || trim(PARTYID) || ',') > 0;

       OPEN l_CursorProperty FOR SELECT * FROM tmp_property;
       LOOP
          FETCH l_CursorProperty INTO l_tmpproperty ;
          EXIT WHEN l_CursorProperty%NOTFOUND;
          DELETE FROM TMP_DepartMentInvestor a
          WHERE NOT EXISTS (SELECT 1
          FROM t_investorpartymap b
          WHERE b.brokerid = l_tmpproperty.brokerid
          AND b.PARTYID = l_tmpproperty.propertyid
          AND a.brokerid = b.brokerid
          AND a.investorid = b.investorid);
       END LOOP;

       /*DELETE FROM TMP_DepartMentInvestor a
       WHERE NOT EXISTS (SELECT 1 FROM (SELECT b.brokerid,b.investorid,COUNT(*) AS propertyamt
                                        FROM t_investorproperty b
                                        GROUP BY b.brokerid,b.investorid) c,
                                       (SELECT brokerid, COUNT(*) AS propertyamt
                                        FROM tmp_property
                                        GROUP BY brokerid) d
                         WHERE a.brokerid = c.brokerid
                         AND   a.investorid = c.investorid
                         AND   d.propertyamt = c.propertyamt);*/
    END IF;

    ---- 如果需要统计,获取投资者属性
    IF TRIM(i_StatPropertyString) IS NOT NULL THEN
       FOR c_result IN (SELECT * FROM TMP_DepartMentInvestor)
       LOOP
          up_GetInvestorProperty(o_nRetCode,o_varRetMsg,i_OperatorID,i_BrokerID,c_result.investorid,i_StatPropertyString,l_propertyID, l_propertyname);
          IF o_nRetCode <> PKGS_Constants.C_S_OK  THEN
             o_varRetMsg := '获取操作员查询权限的投资者到临时表失败';
             RETURN;
          END IF;

       UPDATE/*+ index(t idx_tmp_departmentinvestor )*/  TMP_DepartMentInvestor t
          SET t.propertyid   = TRIM(l_propertyID),
              t.propertyname = TRIM(l_propertyname)
          WHERE t.brokerid = c_result.brokerid
          AND t.investorrange = pkgs_constants.DR_Single
          AND t.investorid = c_result.investorid;
      END LOOP;
    END IF;
    o_varRetMsg := '获取操作员查询权限的投资者到临时表成功';
  EXCEPTION
    WHEN OTHERS THEN
      o_nRetCode := PKGS_Constants.C_S_FAILED;
      o_varRetMsg := '获取操作员查询权限的投资者到临时表失败';
      PKGS_Log.Fatal(i_OperatorID, l_ProcessName, o_varRetMsg);
  END up_GenDepartPropertyInvestor;
  ----验证系统状态
   PROCEDURE up_CheckExchangeStatus
  (
    o_nRetCode      OUT     PKGS_DataType.STY_RETCODE,            ---- 返回码
    o_varRetMsg     OUT     PKGS_DataType.STY_RETMSG,           ---- 返回信息
    i_BrokerID      IN      PKGS_DataType.STY_BrokerID,            ---- 经纪公司代码
    i_chExchangeID  IN       PKGS_DataType.STY_ExchangeID  ---- 交易所信息类型
  )
  AS
    l_Count                 INT;
    l_ProcessName           PKGS_DataType.STY_SpName;         ---- 存储过程名称
  BEGIN
    o_nRetCode := PKGS_Constants.C_RET_SUCCESS;
    l_ProcessName := 'PKGS_COMMON.up_CheckExchangeStatus';
    -- 在交易所不活跃状态和结算初始化完成状态之间不允许做任何操作
    SELECT COUNT(*)
    INTO l_Count
    FROM   t_SettleDate
    WHERE  (SystemStatus = PKGS_Enums.ES_NonActive
       OR InitSettlement <> PKGS_Enums.SIS_Initialized)
      and  (ExchangeID = i_chExchangeID
       OR TRIM(i_chExchangeID)=trim(PKGS_Constants.DEFAULT_EXCHANGE));

    IF l_Count = 0 THEN
      ---- 检查交易是否在结算状态下
        SELECT COUNT(*)
        INTO l_Count
        FROM   t_SettleDate
        WHERE  SystemStatus = PKGS_Enums.ES_Settlement
        and  SettlementStatus = PKGS_Enums.STS_Settlementing
        and  (brokerID=i_brokerID or trim(i_BrokerID)=trim(PKGS_Constants.DEFAULT_BROKERID))
        and  (ExchangeID = i_chExchangeID  OR TRIM(i_chExchangeID)=trim(PKGS_Constants.DEFAULT_EXCHANGE));
        IF l_Count > 0 THEN
            o_nRetCode  := PKGS_Constants.C_RET_FAIL;
            o_varRetMsg := '交易所'||trim(i_chExchangeID)||'正在结算,请稍后再试';
        END IF;
    ELSE
      o_nRetCode  := PKGS_Constants.C_RET_FAIL;
      o_varRetMsg := '交易所'||trim(i_chExchangeID)||'未完成结算初始化操作,不允许做查询以外的工作';
    END IF;

  EXCEPTION
    WHEN OTHERS THEN
      o_nRetCode  := PKGS_Constants.C_RET_FAIL;
      o_varRetMsg := '检查交易所当前状态出错';
  END up_CheckExchangeStatus;

  ---- 通过操作员获取用户代码
  PROCEDURE up_GetUserID
  (
    o_nRetCode      OUT     PKGS_DataType.STY_RETCODE,            ---- 返回码
    o_varRetMsg     OUT     PKGS_DataType.STY_RETMSG,           	---- 返回信息
    o_UserID				OUT 		PKGS_DataType.STY_UserID,							---- 用户ID
    i_OperatorID    IN      PKGS_DataType.STY_OperatorID          ---- 操作员代码
  )
   AS
    l_Count           INT;
    l_ProcessName     PKGS_DataType.STY_SpName;               ---- 存储过程名称
  BEGIN
    o_nRetCode := PKGS_Constants.C_RET_SUCCESS;
    l_ProcessName := 'pkg_Validate.up_GetUserID';
    pkgs_log.Debug(i_OperatorID,l_ProcessName,'i_OperatorID:'||trim(i_OperatorID));
    IF i_OperatorID IS NULL THEN
      o_nRetCode := PKGS_Constants.C_RET_FAIL;
      o_varRetMsg := '操作员代码不能为空值';
    END IF;

    o_UserID := TRIM(SUBSTR(TRIM(i_OperatorID), INSTR(TRIM(i_OperatorID), '.') + 1));
  EXCEPTION
    WHEN OTHERS THEN
      o_nRetCode := PKGS_Constants.C_RET_FAIL;
      o_varRetMsg := '通过操作员获取用户代码出错';
      PKGS_Log.Fatal(i_OperatorID, l_ProcessName, o_varRetMsg);
  END up_GetUserID;

--校验投资者联系人校验
  PROCEDURE up_Validatelinkman
  (
    o_nRetCode      OUT     PKGS_DATATYPE.STY_RETCODE,             ---- 返回码
    o_varRetMsg     OUT     PKGS_DATATYPE.STY_RETMSG,              ---- 返回信息
    i_OperatorID    IN      PKGS_DATATYPE.STY_OperatorID,          ---- 操作员代码
    i_BrokerID      IN      PKGS_DATATYPE.STY_BrokerID,            ---- 经纪公司代码
    i_OperateNo     IN      NUMBER,                                ---- 操作序号
    i_applydate     IN      PKGS_DATATYPE.STY_DATE
  ) IS

    l_Count                       INT;
    L_CLIENTREGION                T_INVESTOR.CLIENTREGION%TYPE;
    L_INVESTORTYPE                T_INVESTOR.INVESTORTYPE%TYPE;
    L_ASSETMGRCLIENTTYPE          T_INVESTOR.ASSETMGRCLIENTTYPE%TYPE;
    L_CNT1                        INT;
    L_CNT2                        INT;
    l_varSPName varchar2(100) := 'up_Validatelinkman';
    l_ProcessName varchar2(100) := 'up_Validatelinkman';

    BEGIN

    o_nRetCode := PKGS_Constants.C_RET_SUCCESS;

    SELECT T.INVESTORTYPE, T.ASSETMGRCLIENTTYPE
      INTO L_INVESTORTYPE, L_ASSETMGRCLIENTTYPE
      FROM t_o_Investor T
     WHERE t.operateno = i_OperateNo
       AND t.brokerid = i_BrokerID
       AND t.applydate = i_applydate;

    IF L_INVESTORTYPE = pkgs_enums.CT_Person OR L_ASSETMGRCLIENTTYPE = pkgs_enums.AMCT_Person
      THEN
       SELECT COUNT(DISTINCT PERSONTYPE)
         INTO L_COUNT
         FROM T_O_INVESTORLINKMAN T
        WHERE T.OPERATENO = i_OperateNo
          AND T.APPLYDATE = i_applydate
          AND T.BROKERID = i_BrokerID
          --AND T.INVESTORID = IO_TYO_INVESTORLINKMAN.INVESTORID
          AND T.ISMAIN = PKGS_CONSTANTS.C_BOOL_TRUE
          AND T.PERSONTYPE IN (PKGS_ENUMS.PST_ORDER,
                               PKGS_ENUMS.PST_FUND,
                               PKGS_ENUMS.PST_SETTLEMENT);
      IF L_COUNT != 3 THEN
         o_nRetCode  :=  pkgs_constants.C_S_FAILED;
         o_varRetMsg := '必填联系人种类不全';
         pkgs_Log.up_Error(l_varSPName, o_varRetMsg);
         RETURN;
      END IF;
     ELSE
       SELECT COUNT(DISTINCT PERSONTYPE)
         INTO L_COUNT
         FROM T_O_INVESTORLINKMAN T
        WHERE T.OPERATENO = i_OperateNo
          AND T.APPLYDATE = i_applydate
          AND T.BROKERID = i_BrokerID
          --AND T.INVESTORID = IO_TYO_INVESTORLINKMAN.INVESTORID
          AND T.ISMAIN = PKGS_CONSTANTS.C_BOOL_TRUE
          AND T.PERSONTYPE IN (PKGS_ENUMS.PST_ORDER,
                               PKGS_ENUMS.PST_FUND,
                               PKGS_ENUMS.PST_SETTLEMENT,
                               PKGS_ENUMS.PST_OPEN);
      IF L_COUNT != 4 THEN
         o_nRetCode  :=  pkgs_constants.C_S_FAILED;
         o_varRetMsg := '上报联系人种类不全';
         pkgs_Log.up_Error(l_varSPName, o_varRetMsg);
         RETURN;
      END IF;
     END IF;


      SELECT MAX(COUNT(1)),MIN(COUNT(1))
        INTO L_CNT1,L_CNT2
        FROM T_O_INVESTORLINKMAN T
       WHERE T.OPERATENO = i_OperateNo
         AND T.APPLYDATE = i_applydate
         AND T.BROKERID = i_BrokerID
         --AND T.INVESTORID = IO_TYO_INVESTORLINKMAN.INVESTORID
         AND T.ISMAIN = PKGS_CONSTANTS.C_BOOL_TRUE
      /*AND T.PERSONTYPE IN
      ('PKGS_ENUMS.PST_ORDER',
       'PKGS_ENUMS.PST_FUND',
       'PKGS_ENUMS.PST_SETTLEMENT')*/
       GROUP BY T.PERSONTYPE;

     IF L_CNT1 != 1 OR L_CNT2 != 1 THEN
         o_nRetCode  :=  pkgs_constants.C_S_FAILED;
         o_varRetMsg := '上报联系人不唯一';
         pkgs_Log.up_Error(l_varSPName, o_varRetMsg);
         RETURN;
     END IF;

  EXCEPTION
    WHEN OTHERS THEN
      o_nRetCode := PKGS_Constants.C_RET_FAIL;
      --o_varRetMsg := '校验投资者联系人校验出错';
      PKGS_Log.Fatal(i_OperatorID, l_ProcessName, o_varRetMsg);
  END up_Validatelinkman;

  ---- 根据查询条件获取产品合约列表
  PROCEDURE up_QryInstrument
  (
    o_nRetCode      OUT     PKGS_DATATYPE.STY_RETCODE,            ---- 返回码
    o_varRetMsg     OUT     PKGS_DATATYPE.STY_RETMSG,             ---- 返回信息
    i_OperatorID    IN      PKGS_DATATYPE.STY_OperatorID,         ---- 操作员代码
    i_ExchangeID    IN      PKGS_DATATYPE.STY_ExchangeID,         ---- 交易所代码
    i_InstrumentID  IN      PKGS_DATATYPE.STY_InstrumentID,       ---- 合约代码
    i_ProductClass  IN      PKGS_DATATYPE.STY_EnumChar,           ---- 产品类型 (入参类型只有1-期货，2-期权，但是入参为期权时，查询结果需包含6-现货期权)
    i_ContainProd   IN      PKGS_DATATYPE.STY_Bool,               ---- 是否包含产品
    i_TradingDay    IN      PKGS_DATATYPE.STY_DATE                ---- 交易日
  ) IS
    l_ProcessName   t_Operationlog.ProcessName%TYPE;
    l_count         INT;
  BEGIN
    o_nRetCode := PKGS_Constants.C_RET_SUCCESS;
    l_ProcessName := 'PKGS_COMMON.up_QryInstrument';
    DELETE FROM tmp_instrumentquery;
		--如果合约代码不为空，并且输入的不是正确的4位交割期，则报错
    IF regexp_replace(TRIM(i_InstrumentID), '[0-9]', '') IS NULL AND TRIM(i_InstrumentID) IS NOT NULL THEN
      IF length(TRIM(i_InstrumentID)) <> 4 THEN
        o_nRetCode  := PKGS_Constants.C_RET_FAIL;
        o_varRetMsg := '输入的交割期('||i_InstrumentID||')有误，请在合约代码中输入4位正确的交割期！';
        RETURN;
      END IF;
    END IF;

    IF i_InstrumentID IS NULL OR LENGTH(TRIM(i_InstrumentID)) = 0 THEN
      -- InstrumentID为空，查询所有合约及产品
      IF i_ProductClass IS NULL OR i_ProductClass = PKGS_ENUMS.PC_Futures THEN --期货
        INSERT INTO tmp_instrumentquery
          (ExchangeID,
           InstrumentID,
           ProductID)
        SELECT t1.exchangeid,
               t1.instrumentid,
               t1.productid       ---- ProductID字段是合约费率不存在时往上查产品费率用的
          FROM t_futinstrument t1
         WHERE (i_ExchangeID IS NULL OR LENGTH(TRIM(i_ExchangeID)) = 0 OR t1.exchangeid = i_ExchangeID)
           AND (i_TradingDay IS NULL OR t1.expiredate >= i_TradingDay)
         UNION
        SELECT t2.exchangeid,
               t2.productid AS InstrumentID,
               NULL AS ProductID  ---- 产品作为查询对象时ProductID填到InstrumentID字段
          FROM t_product t2
         WHERE (i_ExchangeID IS NULL OR LENGTH(TRIM(i_ExchangeID)) = 0 OR t2.exchangeid = i_ExchangeID)
           AND t2.productclass = PKGS_ENUMS.PC_Futures
           AND i_ContainProd = PKGS_CONSTANTS.C_BOOL_TRUE;
      END IF;

      IF i_ProductClass IS NULL OR i_ProductClass = PKGS_ENUMS.PC_Options THEN --期权
        INSERT INTO tmp_instrumentquery
          (ExchangeID,
           InstrumentID,
           ProductID)
        SELECT t1.exchangeid,
               t1.instrumentid,
               t1.productid
          FROM t_optinstrument t1
         WHERE (i_ExchangeID IS NULL OR LENGTH(TRIM(i_ExchangeID)) = 0 OR t1.exchangeid = i_ExchangeID)
           AND (i_TradingDay IS NULL OR t1.expiredate >= i_TradingDay)
         UNION
        SELECT t2.exchangeid,
               t2.productid AS InstrumentID,
               NULL AS ProductID
          FROM t_product t2
         WHERE (i_ExchangeID IS NULL OR LENGTH(TRIM(i_ExchangeID)) = 0 OR t2.exchangeid = i_ExchangeID)
           AND (t2.productclass = PKGS_ENUMS.PC_Options OR t2.ProductClass = PKGS_ENUMS.PC_SpotOption)
           AND i_ContainProd = PKGS_CONSTANTS.C_BOOL_TRUE;
      END IF;

    ELSIF LENGTH(TRIM(i_InstrumentID)) = 4 AND REGEXP_REPLACE(TRIM(i_InstrumentID), '[0-9]', '') IS NULL THEN
      INSERT INTO tmp_instrumentquery
        (ExchangeID,
         InstrumentID,
         ProductID)
      SELECT t1.exchangeid,
             t1.instrumentid,
             t1.productid
        FROM t_futinstrument t1
       WHERE (i_ExchangeID IS NULL OR LENGTH(TRIM(i_ExchangeID)) = 0 OR t1.exchangeid = i_ExchangeID)
         AND SUBSTR(TO_CHAR(t1.deliveryyear), -2) = SUBSTR(TRIM(i_InstrumentID), 1, 2)
         AND t1.deliverymonth = SUBSTR(TRIM(i_InstrumentID), 3)
         AND (i_ProductClass IS NULL OR i_ProductClass = PKGS_ENUMS.PC_Futures)
         AND (i_TradingDay IS NULL OR t1.expiredate >= i_TradingDay)
       UNION
      SELECT t2.exchangeid,
             t2.instrumentid,
             t2.productid
        FROM t_optinstrument t2
       WHERE (i_ExchangeID IS NULL OR LENGTH(TRIM(i_ExchangeID)) = 0 OR t2.exchangeid = i_ExchangeID)
         AND SUBSTR(TO_CHAR(t2.deliveryyear), -2) = SUBSTR(TRIM(i_InstrumentID), 1, 2)
         AND t2.deliverymonth = SUBSTR(TRIM(i_InstrumentID), 3)
         AND (i_ProductClass IS NULL OR i_ProductClass = PKGS_ENUMS.PC_Options)
         AND (i_TradingDay IS NULL OR t2.expiredate >= i_TradingDay);

    ELSE
      -- 其他情况，按产品或合约代码精确查找
      -- 先检查是否为产品代码，若是的话将产品和所属合约都加入临时表，不是产品的话，按合约代码精确查询
      -- 理论上不会出现两家交易所用相同的产品代码，但还是防一手

      SELECT COUNT(1)
        INTO l_count
        FROM t_product t
       WHERE (i_ExchangeID IS NULL OR LENGTH(TRIM(i_ExchangeID)) = 0 OR t.exchangeid = i_ExchangeID)
         --AND (i_ProductClass IS NULL OR t.productclass = i_ProductClass) 入参为2-期权产品时，需包含6-现货期权，所以此处不能加ProductClass过滤
         AND t.productid = i_InstrumentID;

      IF l_count > 0 THEN  --按产品
        -- 将产品插入临时表，因为i_ExchangeID可能为空，所以用这种写法
        INSERT INTO tmp_instrumentquery
          (ExchangeID,
           InstrumentID)
        SELECT t.exchangeid,
               t.productid AS InstrumentID
          FROM t_product t
         WHERE (i_ExchangeID IS NULL OR LENGTH(TRIM(i_ExchangeID)) = 0 OR t.exchangeid = i_ExchangeID)
           --AND (i_ProductClass IS NULL OR t.productclass = i_ProductClass)
           AND t.productid = i_InstrumentID;

        -- 将产品所属合约全部插入临时表
        INSERT INTO tmp_instrumentquery
          (ExchangeID,
           InstrumentID,
           ProductID)
        SELECT t1.exchangeid,
               t1.instrumentid,
               t1.productid
          FROM t_futinstrument t1
          JOIN tmp_instrumentquery tt
            ON t1.exchangeid = tt.exchangeid
           AND t1.productid  = tt.instrumentid
         WHERE i_TradingDay IS NULL
            OR t1.expiredate >= i_TradingDay
         UNION
        SELECT t2.exchangeid,
               t2.instrumentid,
               t2.productid
          FROM t_optinstrument t2
          JOIN tmp_instrumentquery tt
            ON t2.exchangeid = tt.exchangeid
           AND t2.productid  = tt.instrumentid
         WHERE i_TradingDay IS NULL
            OR t2.expiredate >= i_TradingDay;

        -- 部分界面只要合约
        IF i_ContainProd = PKGS_CONSTANTS.C_BOOL_FALSE THEN
          DELETE FROM tmp_instrumentquery t
           WHERE EXISTS (SELECT 1
                           FROM t_product tt
                          WHERE tt.exchangeid = t.exchangeid
                            AND tt.productid  = t.instrumentid)
          ;
        END IF;

      ELSE  --按合约
        INSERT INTO tmp_instrumentquery
          (ExchangeID,
           InstrumentID,
           ProductID)
        SELECT t1.exchangeid,
               t1.instrumentid,
               t1.productid
          FROM t_futinstrument t1
         WHERE (i_ExchangeID IS NULL OR LENGTH(TRIM(i_ExchangeID)) = 0 OR t1.exchangeid = i_ExchangeID)
           AND (i_ProductClass IS NULL OR i_ProductClass = PKGS_ENUMS.PC_Futures)
           AND t1.instrumentid = i_InstrumentID
           AND (i_TradingDay IS NULL OR t1.expiredate >= i_TradingDay)
         UNION
        SELECT t2.exchangeid,
               t2.instrumentid,
               t2.productid
          FROM t_optinstrument t2
         WHERE (i_ExchangeID IS NULL OR LENGTH(TRIM(i_ExchangeID)) = 0 OR t2.exchangeid = i_ExchangeID)
           AND (i_ProductClass IS NULL OR i_ProductClass = PKGS_ENUMS.PC_Options)
           AND t2.instrumentid = i_InstrumentID
           AND (i_TradingDay IS NULL OR t2.expiredate >= i_TradingDay);
      END IF;
    END IF;

    PKGS_LOG.Info(i_OperatorID, l_ProcessName, '根据查询条件获取产品合约列表完成');
  EXCEPTION
    WHEN OTHERS THEN
      o_nRetCode := PKGS_Constants.C_RET_FAIL;
      o_varRetMsg := '根据查询条件获取产品合约列表出错';
      PKGS_Log.Fatal(i_OperatorID, l_ProcessName, o_varRetMsg);
  END up_QryInstrument;

  PROCEDURE up_DeleteRapid
  (
    o_nRetCode      OUT     PKGS_DataType.STY_RETCODE,            ---- 返回码
    o_varRetMsg     OUT     PKGS_DataType.STY_RETMSG,           	---- 返回信息
    i_OperatorID    IN      PKGS_DATATYPE.STY_OperatorID,          ---- 操作员代码
    p_TableName in varchar2, 								--The TableName which you want to delete from
    p_Condition in varchar2 default '1=1', 	--Delete condition, such as "id>=100000"
    p_Count in varchar2 default '10000'     --Commit after delete How many records
  )
  AS PRAGMA AUTONOMOUS_TRANSACTION;
     n_deleteCount NUMBER(20):=0;
     l_varSPName varchar2(100) := 'up_DeleteRapid';
  BEGIN
     WHILE 1=1
     LOOP
         EXECUTE IMMEDIATE 'delete from '||p_TableName||' WHERE '||p_Condition||' and rownum <= :rn'
         USING p_Count;
     IF SQL%NOTFOUND THEN
         EXIT;
     ELSE
         n_deleteCount:=n_DeleteCount+SQL%ROWCOUNT;
     END IF;
     END LOOP;
     COMMIT;
     o_nRetCode:=Pkgs_Constants.C_RET_SUCCESS;
     o_varRetMsg:='Detele Success!';
     Pkgs_Log.up_Info(l_varSPName,o_varRetMsg);
  EXCEPTION
     WHEN OTHERS THEN
         o_nRetCode:=Pkgs_Constants.C_RET_SUCCESS;
         o_varRetMsg:='Detele Exception!';
         Pkgs_Log.Fatal(i_OperatorID,l_varSPName,o_varRetMsg);
  END up_DeleteRapid;

  FUNCTION uf_ValidateTradingCode
  (
    i_OperatorID    IN      PKGS_DATATYPE.STY_OperatorID,          ---- 操作员代码
    i_BrokerID      IN      PKGS_DATATYPE.STY_BrokerID,            ---- 经纪公司代码
    i_InvestorID    IN      PKGS_DATATYPE.STY_InvestorID,          ---- 投资者代码
    i_InvestUnitID  IN      PKGS_DATATYPE.STY_InvestUnitID,        ---- 投资单元代码
    i_ExchangeID    IN      PKGS_DATATYPE.STY_ExchangeID,          ---- 交易所信息类型
    i_ClientMode    IN      T_TRADINGCODEMAP.CLIENTIDMODE%TYPE,    ---- 投机套保标志
    i_ApplyAction   IN      T_O_OPENINVESTOR.APPLYACTION%TYPE DEFAULT PKGS_ENUMS.AA_ApplyTradingCode  ----申请动作
  )
  RETURN INTEGER
  IS
  L_ClientMode T_TRADINGCODEMAP.CLIENTIDMODE%TYPE;
  L_COUNT INTEGER;

  BEGIN

    PKGS_Log.info('0000.0000_admin', 'uf_ValidateTradingCode', '开始');

    PKGS_Log.info('0000.0000_admin', 'uf_ValidateTradingCode',i_OperatorID||','||i_BrokerID||','||i_InvestorID||','||i_InvestUnitID||','||i_ExchangeID||','||i_ClientMode||','||i_ApplyAction);

    IF i_ExchangeID != PKGS_CONSTANTS.C_EXCHANGEID_CFFEX THEN
       L_ClientMode := PKGS_ENUMS.CIDM_Speculation;
    ELSE
       L_ClientMode := i_ClientMode;
    END IF;

    SELECT COUNT(1)
      INTO L_COUNT
      FROM T_TRADINGCODEMAP T
     WHERE T.BROKERID = i_BrokerID
       AND T.EXCHANGEID = i_ExchangeID
       --AND T.CLIENTID = IO_TYTRADINGCODEMAP.CLIENTID
       AND T.CLIENTIDMODE = L_ClientMode
       --AND T.ISACTIVE = PKGS_CONSTANTS.C_BOOL_TRUE
       AND T.INVESTORID = i_InvestorID
       AND NVL(TRIM(T.INVESTUNITID),'-99999999') = NVL(TRIM(i_InvestUnitID),'-99999999')
        AND t.isactive = pkgs_constants.C_BOOL_TRUE;

    PKGS_Log.info('0000.0000_admin', 'uf_ValidateTradingCode', '结束');

    IF i_ApplyAction = PKGS_ENUMS.AA_CancelTradingCode
      THEN L_COUNT := ABS(1-L_COUNT);
    END IF;

    RETURN L_COUNT;

  END;

  ----判断是否为单经纪公司
  FUNCTION uf_IsSingleBroke RETURN  pkgs_datatype.STY_Bool IS
    l_Bool pkgs_datatype.STY_Bool;
    l_SysUser               CHAR(1);
  BEGIN
    ----判断是否为单经纪公司
    SELECT nvl(TRIM (t.systemparamvalue),'1')
    INTO l_SysUser
    FROM t_syssettleparam t
    WHERE t.brokerid = '0000'
    AND   t.systemparamid = 'b'
    ;
    IF l_SysUser = pkgs_constants.Sys_SingleBroker THEN
      l_Bool := pkgs_constants.C_BOOL_TRUE;--单经纪公司
    ELSE
      l_Bool := pkgs_constants.C_BOOL_FALSE;--多经纪公司
    END IF;

    RETURN l_Bool;
  END uf_IsSingleBroke;

  ---- 获取操作员权限的投资者
  PROCEDURE up_GetDepartmentInvestor
  (
    o_nRetCode      OUT     PKGS_DataType.STY_RETCODE,          ---- 返回码
    o_varRetMsg     OUT     PKGS_DataType.STY_RETMSG,           ---- 返回信息
    i_OperatorID    IN      PKGS_DataType.STY_OperatorID,       ---- 操作员代码
    i_BrokerID      IN      PKGS_DATATYPE.STY_BrokerID,         ---- 经纪公司代码
    i_InvestorID    IN      t_Investor.InvestorID%TYPE,         ---- 投资者代码
    i_InvestorType  IN      t_Investor.Investortype%TYPE,
    i_Departmentid  IN      t_department.departmentid%TYPE      ---- 组织架构代码
  )
  AS
   l_ProcessName     PKGS_DataType.STY_SpName;
   l_count           NUMBER;
   l_UserID          t_brokeruser.UserID%TYPE;
   l_brokerid        PKGS_DATATYPE.STY_BrokerID;
  BEGIN
    o_nRetCode := PKGS_Constants.C_S_OK ;
    l_ProcessName := 'PKGS_COMMON.up_GetDepartmentInvestor';

    IF TRIM(i_OperatorID) IS NULL THEN
       o_nRetCode := PKGS_Constants.C_S_FAILED;
       o_varRetMsg := '操作员不能为空';
       pkgs_Log.Fatal(i_OperatorID, l_ProcessName, o_varRetMsg);
       RETURN;
    END IF ;
    l_UserID := TRIM(SUBSTR(i_OperatorID, INSTR(i_OperatorID, '.') + 1)) ;
    l_brokerid :=  SUBSTR(i_OperatorID, 1, INSTR(i_OperatorID, '.') - 1) ;
    DELETE FROM TMP_DepartMentInvestor
    WHERE BrokerID =  i_BrokerID ;

    ---- 检测user对应的分组级别 对'00'级别的有所有权限
    SELECT COUNT(*)
    INTO l_count
    FROM (
           SELECT BrokerID ,UserID,InvestorID AS DepartMentID
           FROM   t_departmentuser
           WHERE  BrokerID      = i_BrokerID
           AND    InvestorRange = pkgs_enums.DR_Group
           -- AND    i_InvestorID  IS NULL
           UNION
           SELECT Brokerid,userID,PKGS_Constants.DEFAULT_BrokerDepartMentID AS DepartMentID
           FROM   t_brokeruser
           WHERE  BrokerID = i_BrokerID
           AND    Isadmin  =  PKGS_Constants.C_Bool_True
           -- AND    i_InvestorID  IS NULL
           UNION
           SELECT i_BrokerID,userID,PKGS_Constants.DEFAULT_BrokerDepartMentID AS DepartMentID
           FROM   t_superuser
           WHERE  l_brokerid = PKGS_Constants.DEFAULT_BROKERID
           -- where  i_InvestorID  IS NULL
          )
    WHERE TRIM(DepartMentID) = TRIM(PKGS_Constants.DEFAULT_BrokerDepartMentID)
    AND TRIM(UserID)         = TRIM(l_UserID);

    IF l_count > 0 THEN
       ---- user对所有数据都有权限
       INSERT INTO TMP_DepartMentInvestor(BrokerID ,UserID ,InvestorRange,InvestorID )
       SELECT BrokerID,l_UserID,pkgs_enums.DR_Single,InvestorID
       FROM  t_Investor
       WHERE  BrokerID = i_BrokerID
         AND (trim(i_INvestorID) IS NULL OR investorid = i_InvestorID)
         AND (trim(i_INvestorType) IS NULL OR investorType = i_INvestorType)
         AND (trim(i_departmentid) IS NULL
              OR TRIM(i_departmentid) = TRIM(PKGS_Constants.DEFAULT_BrokerDepartMentID)
              OR departmentid LIKE trim(i_Departmentid) || '%');
    ELSE
    	 ---- 单一投资在者
       INSERT INTO TMP_DepartMentInvestor(BrokerID ,UserID  ,InvestorRange,InvestorID )
       SELECT BrokerID,UserID,pkgs_enums.DR_Single,InvestorID
       FROM  t_departmentuser
       WHERE  BrokerID = i_BrokerID
       AND  UserID   = l_UserID
       AND  InvestorRange = pkgs_enums.DR_Single
       AND (trim(i_INvestorID) IS NULL OR investorid = i_InvestorID)
       UNION  ---- 非'00'组织架构
       SELECT BrokerID,l_UserID,pkgs_enums.DR_Single,InvestorID
       FROM  t_Investor  a
       WHERE  BrokerID = i_BrokerID
       AND  EXISTS ( SELECT 1 FROM t_departmentuser b
                     WHERE a.BrokerID = b.BrokerID
                     AND TRIM(a.DepartMentID)like TRIM(b.InvestorID)||'%'
                     AND b.UserID        = l_userID
                     AND b.InvestorRange = pkgs_enums.DR_Group
                     AND b.InvestorID   <> PKGS_Constants.DEFAULT_BrokerDepartMentID
                    )
         AND (trim(i_INvestorID) IS NULL OR investorid = i_InvestorID)
         AND (trim(i_INvestorType) IS NULL OR investorType = i_INvestorType)
         AND (trim(i_departmentid) IS NULL OR TRIM(i_departmentid) = TRIM(PKGS_Constants.DEFAULT_BrokerDepartMentID) OR departmentid LIKE trim(i_Departmentid) || '%');
       IF trim(i_InvestorType) IS NOT NULL THEN
          DELETE FROM TMP_DepartMentInvestor a
           WHERE NOT EXISTS(SELECT 1 from t_investor b where a.brokerid = b.brokerid and a.investorid = b.investorid and investorType = i_INvestorType);
       END IF;
       IF trim(i_departmentid) IS NOT NULL AND TRIM(i_departmentid) <> TRIM(PKGS_Constants.DEFAULT_BrokerDepartMentID) THEN
          DELETE FROM TMP_DepartMentInvestor a
           WHERE NOT EXISTS(SELECT 1 from t_investor b where a.brokerid = b.brokerid and a.investorid = b.investorid and departmentid LIKE trim(i_Departmentid) || '%');
       END IF;
    END IF ;
    up_DelBlacklist(i_BrokerID,l_userid);

    o_varRetMsg := '获取操作员查询权限的投资者到临时表成功';
  EXCEPTION
    WHEN OTHERS THEN
      o_nRetCode := PKGS_Constants.C_S_FAILED;
      o_varRetMsg := '获取操作员查询权限的投资者到临时表失败';
      pkgs_Log.Fatal(i_OperatorID, l_ProcessName, o_varRetMsg);
  END up_GetDepartmentInvestor;

  PROCEDURE up_GetAll_Investor
  (
    io_tyInvestor  IN OUT TY_INVESTOR
   ,o_nRetCode       OUT NOCOPY PKGS_DATATYPE.STY_RETCODE
   ,o_varRetMsg      OUT NOCOPY PKGS_DATATYPE.STY_RETMSG
  ) IS
    l_varSPName   t_Operationlog.ProcessName%TYPE := 'PKGS_COMMON.up_GetAll_Investor';
    l_varLogic    PKGS_DataType.STY_LOGIC;
    l_varBusiDesc PKGS_DataType.STY_LOGIC := '查询投资者审核信息';
  BEGIN
    o_nRetCode := PKGS_Constants.C_RET_SUCCESS;
    --输入检查
    l_varLogic := l_varBusiDesc || '-参数校验';
    PKGS_Log.up_Info(l_varSPName, l_varLogic || '开始');


    SELECT TY_INVESTOR(BROKERID,
                   INVESTORID,
                   INVESTORNAME,
                   NULL,
                   NULL,
                   NULL,
                   NULL,
                   NULL,
                   NULL,
                   NULL,
                   NULL,
                   NULL,
                   NULL,
                   NULL,
                   NULL,
                   NULL,
                   NULL,
                   NULL,
                   NULL,
                   NULL)
     INTO io_tyInvestor
     FROM (SELECT *
          FROM (SELECT T.BROKERID, T.INVESTORID, T.INVESTORNAME, T.OPENDATE
                  FROM T_INVESTOR T
                 WHERE T.BROKERID = io_tyInvestor.BrokerID
                   AND T.INVESTORID = io_tyInvestor.InvestorID
                UNION ALL
                SELECT T.BROKERID, T.INVESTORID, T.INVESTORNAME, T.APPLYDATE
                  FROM T_O_INVESTOR T
                 WHERE T.BROKERID = io_tyInvestor.BrokerID
                   AND T.INVESTORID = io_tyInvestor.InvestorID

                )
         ORDER BY OPENDATE DESC)
      WHERE ROWNUM = 1;

    --业务处理
    --Pkgd_Select.up_SelO_Investor(io_tyO_Investor, o_nRetCode, o_varRetMsg);
    l_varLogic := l_varBusiDesc;
    --业务处理结束.

  EXCEPTION
    WHEN OTHERS THEN
      o_varRetMsg := '执行' || l_varBusiDesc || '业务失败。';
      PKGS_Utility.up_ProcessOthersError(l_varSPName, o_nRetCode,
                                         o_varRetMsg);

  END up_GetAll_Investor;

  ---- 验证操作员对投资者手续费率是否有操作权限
  PROCEDURE up_ValidateCommRateInvestor
  (
    o_nRetCode                      OUT     PKGS_DataType.STY_RETCODE,              ---- 返回码
    o_varRetMsg                     OUT     PKGS_DataType.STY_RETMSG,             ---- 返回信息
    i_OperatorID                    IN      PKGS_DataType.STY_OperatorID,            ---- 操作员代码
    i_BrokerID                      IN      t_Investor.BrokerID%TYPE,             ---- 经纪公司代码
    i_Investorrange                 IN      PKGS_DATATYPE.STY_InvestorRange,    ---- 投资者代码
    i_InvestorID                    IN      t_Investor.InvestorID%TYPE            ---- 投资者代码
  )
  AS
    l_Count           INT;
    l_ProcessName     PKGS_DataType.STY_ProcessName;                                 ---- 存储过程名称
    l_UserID          t_brokeruser.UserID%Type;
  BEGIN
    o_nRetCode := PKGS_Constants.C_RET_SUCCESS;
    l_ProcessName := 'PKGS_COMMON.up_ValidateCommRateInvestor';

    IF i_InvestorID IS NULL OR i_BrokerID IS NULL OR i_OperatorID IS NULL THEN
       o_nRetCode := PKGS_Constants.C_S_FAILED;
       o_varRetMsg := '经纪公司代码，投资者代码，操作员不能为空';
      pkgs_Log.Fatal(i_OperatorID, l_ProcessName, o_varRetMsg);
       RETURN;
    END IF;

    l_UserID := TRIM(SUBSTR(TRIM(i_OperatorID), INSTR(TRIM(i_OperatorID), '.') + 1));

    ---- 检查操作员对投资者是否有操作权限
    PKGB_CommRateMgrt.up_GenCommRateInvestor(i_BrokerID,i_InvestorRange,i_InvestorID,NULL,NULL,NULL,o_nRetCode,o_varRetMsg);
    IF o_nRetCode <> PKGS_Constants.C_RET_SUCCESS THEN
       RETURN;
    END IF;

    SELECT COUNT(*)
    INTO l_count
    FROM TMP_DepartMentInvestor t1
    WHERE t1.brokerid = i_BrokerID
    AND   t1.investorid = i_InvestorID
    AND   t1.investorrange = i_Investorrange;

    IF l_count = 0 THEN
      o_nRetCode := PKGS_Constants.C_S_FAILED;
      o_varRetMsg := '操作员' || TRIM(l_UserID) || '对投资者范围' || TRIM(i_InvestorRange) || '投资者' || TRIM(i_InvestorID) || '没有操作权限';
      PKGS_Log.Fatal(i_OperatorID, l_ProcessName, o_varRetMsg);
      RETURN;
    END IF;

    o_varRetMsg := '验证操作员对投资者权限成功';
  EXCEPTION
    WHEN OTHERS THEN
      o_nRetCode := PKGS_Constants.C_S_FAILED;
      o_varRetMsg := '检查操作员' || TRIM(l_UserID) || '对投资者范围' || TRIM(i_InvestorRange) || '投资者' || TRIM(i_InvestorID) || '操作权限出错';
      pkgs_Log.Fatal(i_OperatorID, l_ProcessName, o_varRetMsg);
  END up_ValidateCommRateInvestor;

  ---- 验证操作员对投资者保证金率是否有操作权限
  PROCEDURE up_ValidateMarginRateInvestor
  (
    o_nRetCode                      OUT     PKGS_DataType.STY_RETCODE,              ---- 返回码
    o_varRetMsg                     OUT     PKGS_DataType.STY_RETMSG,             ---- 返回信息
    i_OperatorID                    IN      PKGS_DataType.STY_OperatorID,            ---- 操作员代码
    i_BrokerID                      IN      t_Investor.BrokerID%TYPE,             ---- 经纪公司代码
    i_Investorrange                 IN      PKGS_DATATYPE.STY_InvestorRange,    ---- 投资者代码
    i_InvestorID                    IN      t_Investor.InvestorID%TYPE            ---- 投资者代码
  )
  AS
    l_Count           INT;
    l_ProcessName     PKGS_DataType.STY_ProcessName;                                 ---- 存储过程名称
    l_UserID          t_brokeruser.UserID%Type;
  BEGIN
    o_nRetCode := PKGS_Constants.C_RET_SUCCESS;
    l_ProcessName := 'PKGS_COMMON.up_ValidateMarginRateInvestor';

    IF i_InvestorID IS NULL OR i_BrokerID IS NULL OR i_OperatorID IS NULL THEN
       o_nRetCode := PKGS_Constants.C_S_FAILED;
       o_varRetMsg := '经纪公司代码，投资者代码，操作员不能为空';
       pkgs_Log.Fatal(i_OperatorID, l_ProcessName, o_varRetMsg);
       RETURN;
    END IF;

    l_UserID := TRIM(SUBSTR(TRIM(i_OperatorID), INSTR(TRIM(i_OperatorID), '.') + 1));

    ---- 检查操作员对投资者是否有操作权限
    Pkgb_Marginratemgrt.up_GenMarginRateInvestor(i_BrokerID,i_InvestorRange,i_InvestorID,NULL,NULL,NULL,o_nRetCode,o_varRetMsg);
    IF o_nRetCode <> PKGS_Constants.C_RET_SUCCESS THEN
       RETURN;
    END IF;

    SELECT COUNT(*)
    INTO l_count
    FROM TMP_DepartMentInvestor t1
    WHERE t1.brokerid = i_BrokerID
    AND   t1.investorid = i_InvestorID
    AND   t1.investorrange = i_Investorrange;

    IF l_count = 0 THEN
      o_nRetCode := PKGS_Constants.C_S_FAILED;
      o_varRetMsg := '操作员' || TRIM(l_UserID) || '对投资者范围' || TRIM(i_InvestorRange) || '投资者' || TRIM(i_InvestorID) || '没有操作权限';
      pkgs_Log.Fatal(i_OperatorID, l_ProcessName, o_varRetMsg);
      RETURN;
    END IF;

    o_varRetMsg := '验证操作员对投资者权限成功';
  EXCEPTION
    WHEN OTHERS THEN
      o_nRetCode := PKGS_Constants.C_S_FAILED;
      o_varRetMsg := '检查操作员' || TRIM(l_UserID) || '对投资者范围' || TRIM(i_InvestorRange) || '投资者' || TRIM(i_InvestorID) || '操作权限出错';
      pkgs_Log.Fatal(i_OperatorID, l_ProcessName, o_varRetMsg);
  END up_ValidateMarginRateInvestor;

  ---- 区别操作员有权限和无权限的投资者
  PROCEDURE up_DistDepartmentInvestor
  (
    o_ReturnNo           OUT     PKGS_DataType.STY_RETCODE,            ---- 返回码
    o_ReturnMsg          OUT     PKGS_DataType.STY_RETMSG,           ---- 返回信息
    i_OperatorID         IN      PKGS_DATATYPE.STY_OPERATORID,       ---- 操作员代码
    i_BrokerID           IN      PKGS_DATATYPE.STY_BROKERID,         ---- 经纪公司代码
    i_TytInvestor        IN      TYT_INVESTOR,                      ---- 投资者列表
    o_nCountAuthInvst  OUT PKGS_DATATYPE.STY_COUNT,                 ---- 有权限的投资者记录数
    o_nCountUnAuthInvst  OUT PKGS_DATATYPE.STY_COUNT,               ---- 无权限的投资者记录数
    o_AuthInvstCursor OUT     g_TypeCursor,                        ---- 有权限的投资者游标
    o_UnAuthInvstCursor OUT     g_TypeCursor                        ---- 无权限的投资者游标
  )
  AS
   l_ProcessName     PKGS_DataType.STY_SpName;
   l_count           NUMBER;
  BEGIN
    o_ReturnNo := PKGS_Constants.C_S_OK ;
    l_ProcessName := 'PKGS_COMMON.up_DistDepartmentInvestor';

    l_count := i_TytInvestor.Count;
    o_nCountAuthInvst := 0;
    o_nCountUnAuthInvst := 0;
    IF l_count > 0 THEN
      DELETE FROM TMP_Investor;

      FORALL i IN 1..i_TytInvestor.Count
      INSERT INTO TMP_Investor(BROKERID,INVESTORID,INVESTORNAME,INVESTORTYPE,INVESTORGROUPID,DEPARTMENTID,INVESTORFLAG,OPENDATE,CANCELDATE,
      ISEMAIL,ISSMS,ISUSINGOTP,COMMMODELID,MARGINMODELID,CLIENTREGION,CLIENTMODE,ASSETMGRCLIENTTYPE,RISKLEVEL,CONTRACTCODE,ISACTIVE)
      VALUES (i_TytInvestor(i).brokerid,i_TytInvestor(i).investorid,i_TytInvestor(i).investorname,i_TytInvestor(i).investortype,i_TytInvestor(i).investorgroupid,
      i_TytInvestor(i).departmentid,i_TytInvestor(i).investorflag,i_TytInvestor(i).opendate,i_TytInvestor(i).canceldate,i_TytInvestor(i).isemail,i_TytInvestor(i).issms,
      i_TytInvestor(i).isusingotp,i_TytInvestor(i).commmodelid,i_TytInvestor(i).marginmodelid,i_TytInvestor(i).clientregion,i_TytInvestor(i).clientmode,i_TytInvestor(i).assetmgrclienttype,
      i_TytInvestor(i).risklevel,i_TytInvestor(i).contractcode,i_TytInvestor(i).isactive);

      up_GenDepartmentInvestorName(o_ReturnNo, o_ReturnMsg, i_OperatorID, i_BrokerID, null, null, null);
      IF o_ReturnNo <> PKGS_Constants.C_RET_SUCCESS THEN
        RETURN;
      END IF;

      SELECT COUNT(*)
        INTO o_nCountAuthInvst
        FROM TMP_Investor t, tmp_departmentinvestor t1
       WHERE t.brokerid = t1.brokerid
         AND t.investorid = t1.investorid;

      OPEN o_AuthInvstCursor for
      SELECT ty_investor(BrokerID,
                         InvestorID,
                         InvestorName,
                         InvestorType,
                         InvestorGroupID,
                         DepartmentID,
                         InvestorFlag,
                         OpenDate,
                         CancelDate,
                         IsEmail,
                         IsSMS,
                         IsUsingOTP,
                         CommModelID,
                         MarginModelID,
                         ClientRegion,
                         ClientMode,
                         AssetmgrClientType,
                         RiskLevel,
                         ContractCode,
                         IsActive)
        FROM (SELECT t.BrokerID,
                     t.InvestorID,
                     t1.investorname,
                     t.InvestorType,
                     t.InvestorGroupID,
                     t.DepartmentID,
                     t.InvestorFlag,
                     t.OpenDate,
                     t.CancelDate,
                     t.IsEmail,
                     t.IsSMS,
                     t.IsUsingOTP,
                     t.CommModelID,
                     t.MarginModelID,
                     t.ClientRegion,
                     t.ClientMode,
                     t.AssetmgrClientType,
                     t.RiskLevel,
                     t.ContractCode,
                     t.IsActive
                FROM TMP_Investor t, tmp_departmentinvestor t1
                WHERE t.brokerid = t1.brokerid
                AND t.investorid = t1.investorid);

        SELECT COUNT(*)
          INTO o_nCountUnAuthInvst
          FROM TMP_Investor t
         WHERE NOT EXISTS (SELECT 1
                  FROM tmp_departmentinvestor t1
                 WHERE t.brokerid = t1.brokerid
                   AND t.investorid = t1.investorid);

        OPEN o_UnAuthInvstCursor for
        SELECT ty_investor(BrokerID,
                           InvestorID,
                           InvestorName,
                           InvestorType,
                           InvestorGroupID,
                           DepartmentID,
                           InvestorFlag,
                           OpenDate,
                           CancelDate,
                           IsEmail,
                           IsSMS,
                           IsUsingOTP,
                           CommModelID,
                           MarginModelID,
                           ClientRegion,
                           ClientMode,
                           AssetmgrClientType,
                           RiskLevel,
                           ContractCode,
                           IsActive)
          FROM (SELECT t.BrokerID,
                       t.InvestorID,
                       t.InvestorName,
                       t.InvestorType,
                       t.InvestorGroupID,
                       t.DepartmentID,
                       t.InvestorFlag,
                       t.OpenDate,
                       t.CancelDate,
                       t.IsEmail,
                       t.IsSMS,
                       t.IsUsingOTP,
                       t.CommModelID,
                       t.MarginModelID,
                       t.ClientRegion,
                       t.ClientMode,
                       t.AssetmgrClientType,
                       t.RiskLevel,
                       t.ContractCode,
                       t.IsActive
                  FROM TMP_Investor t
                  WHERE NOT EXISTS (SELECT 1 FROM tmp_departmentinvestor t1 WHERE t.brokerid = t1.brokerid AND t.investorid = t1.investorid));
    END IF;


    o_ReturnMsg := '区别操作员有权限和无权限的投资者成功';
  EXCEPTION
    WHEN OTHERS THEN
      o_ReturnNo := PKGS_Constants.C_RET_FAIL;
      o_ReturnMsg := '区别操作员有权限和无权限的投资者失败';
      PKGS_Log.Fatal(i_OperatorID, l_ProcessName, o_ReturnMsg);
  END up_DistDepartmentInvestor;
	---- 获取需要查询的期货产品/合约列表
	PROCEDURE up_GenInstrumentCurrency
  (
    o_ReturnNo           OUT     PKGS_DataType.STY_RETCODE,          ---- 返回码
    o_ReturnMsg          OUT     PKGS_DataType.STY_RETMSG,           ---- 返回信息
		i_ExchangeID         IN      PKGS_DataType.STY_ExchangeID,       ---- 交易所代码
    i_InstrumentID       IN      PKGS_DataType.STY_InstrumentID,     ---- 合约代码
		i_ProductType        IN      PKGS_DataType.STY_ProductType,      ---- 产品类型
		i_YearMonth          IN      PKGS_DataType.STY_nYearMonth,       ---- 交割年月
		i_OptionStype        IN      PKGS_DataType.STY_OptionStype,      ---- 期权类型
		i_StrikePrice        IN      PKGS_DataType.STY_StrikePrice       ---- 行权价格
  )
  AS
   l_ProcessName     PKGS_DataType.STY_SpName;
	 l_DeliveryYear    Pkgs_Datatype.STY_nYear;
	 l_DeliveryMonth   Pkgs_Datatype.STY_nMonth;
  BEGIN
    o_ReturnNo := PKGS_Constants.C_S_OK ;
    l_ProcessName := 'PKGS_COMMON.up_GenInstrumentCurrency';

		--如果合约代码不为空，并且输入的是正确的4位交割期，则可以直接按照交割期进行查询
		IF regexp_replace(TRIM(i_InstrumentID), '[0-9]', '') IS NULL AND TRIM(i_InstrumentID) IS NOT NULL THEN
			IF length(TRIM(i_InstrumentID)) <> 4 THEN
				o_ReturnNo  := PKGS_Constants.C_RET_FAIL;
				o_ReturnMsg := '输入的交割期('||i_InstrumentID||')有误，请在合约代码中输入4位正确的交割期！';
				RETURN;
			ELSE
				l_DeliveryYear  := To_Number('20'||SUBSTR(i_InstrumentID,1,2));
				l_DeliveryMonth := To_Number(SUBSTR(i_InstrumentID,3));
			END IF;
		END IF;

		--按照现在的接口设计，默认费率模块下面的界面查询条件都不带单独的交割期，都放在i_InstrumentID产品合约代码里面
		--只有在信息查询模块下的部分界面，查询条件才带有单独交割期查询条件的，i_YearMonth才可能会不为空
		--因此，如果即从i_InstrumentID传入了交割期，又从i_YearMonth传入了交割期，则以i_YearMonth传入的交割期为准，进行查询
		--xu.shilin 20200302
		IF TRIM(i_YearMonth) IS NOT NULL THEN
			l_DeliveryYear  := To_Number(SUBSTR(i_YearMonth,1,4));
			l_DeliveryMonth := To_Number(SUBSTR(i_YearMonth,5));
		END IF;

		---- 1.如果合约代码不为空，并且输入的是正确的4位交割期，则按照交割期进行查询指定交易所的全部合约和产品
		---- 2.如果输入的是正常的产品代码或者合约代码或者为空，则根据产品代码和合约代码查询指定交易所的合约或者产品或查询全部记录
		---- 3.如果输入的是产品代码，则还需要查出产品下所有合约
		---- xu.shilin 20200302

		IF TRIM(i_ProductType) IS NULL OR i_ProductType = PKGS_Enums.PTE_Futures THEN

			INSERT INTO Tmp_InstrumentCurrency
				SELECT a.ExchangeID,
							 te.ExchangeAbbr,
							 a.ProductID,
							 tp.ProductName,
							 a.InstrumentID,
							 a.InstrumentName,
							 NVL(tp.CurrencyID, PKGS_Constants.C_CURRENCY_CNY) AS CURRENCYID,
							 a.VolumeMultiple,
							 a.ExpireDate,
							 a.DeliveryYear || LPAD(a.DeliveryMonth, 2, 0) AS Delivdate,
							 a.InstrumentID AS ExchangeInstID,
							 tp.ProductClass,
							 NULL AS OptionsType,
							 NULL AS StrikePrice,
							 NULL AS Underlyinginstrid,
							 NULL AS Underlyingproductid,
							 a.DeliveryYear,
							 a.DeliveryMonth
					FROM t_FutInstrument a
					JOIN t_Exchange te
						ON a.ExchangeID = te.ExchangeID
					JOIN t_Product tp
					  ON a.ExchangeID = tp.ExchangeID
					 AND a.ProductID = tp.ProductID
				 WHERE tp.ProductClass = PKGS_Enums.PC_Futures
				   AND (a.ExchangeID = i_ExchangeID OR NVL(LENGTH(TRIM(i_ExchangeID)), 0) = 0 OR i_ExchangeID IS NULL)
					 AND (a.InstrumentID = i_InstrumentID OR a.ProductID = i_InstrumentID OR NVL(LENGTH(TRIM(i_InstrumentID)), 0) = 0 OR i_InstrumentID IS NULL OR regexp_replace(TRIM(i_InstrumentID), '[0-9]', '') IS NULL)
					 AND (a.DeliveryYear = l_DeliveryYear OR NVL(LENGTH(TRIM(l_DeliveryYear)), 0) = 0 OR l_DeliveryYear IS NULL)
					 AND (a.DeliveryMonth= l_DeliveryMonth OR NVL(LENGTH(TRIM(l_DeliveryMonth)), 0) = 0 OR l_DeliveryMonth IS NULL)
					 AND NOT EXISTS (SELECT 1 FROM Tmp_InstrumentCurrency tt WHERE a.ExchangeID = tt.ExchangeID AND a.InstrumentID = tt.InstrumentID)
				 UNION ALL
			  SELECT a.ExchangeID,
               te.ExchangeAbbr,
               a.ProductID,
               a.ProductName,
               a.ProductID AS InstrumentID,
               a.ProductName AS InstrumentName,
               PKGS_Constants.C_CURRENCY_CNY AS CURRENCYID,
               NULL AS VolumeMultiple,
               NULL AS ExpireDate,
               NULL AS Delivdate,
               a.ProductID AS ExchangeInstID,
               a.ProductClass,
               NULL AS OptionsType,
               NULL AS StrikePrice,
               NULL AS Underlyinginstrid,
               NULL AS Underlyingproductid,
               NULL AS DeliveryYear,
               NULL AS DeliveryMonth
          FROM t_product a
          JOIN t_Exchange te
            ON a.exchangeid = te.Exchangeid
				 WHERE a.ProductClass = PKGS_Enums.PC_Futures
				   AND (a.ExchangeID = i_ExchangeID OR NVL(LENGTH(TRIM(i_ExchangeID)), 0) = 0 OR i_ExchangeID IS NULL)
           AND (a.ProductID = i_InstrumentID OR NVL(LENGTH(TRIM(i_InstrumentID)), 0) = 0 OR i_InstrumentID IS NULL)
           AND NOT EXISTS(SELECT 1 FROM Tmp_InstrumentCurrency tt WHERE a.ExchangeID = tt.ExchangeID AND a.ProductID = tt.InstrumentID)
					;

		END IF;

		IF TRIM(i_ProductType) IS NULL OR i_ProductType = PKGS_Enums.PTE_Options THEN

			INSERT INTO Tmp_InstrumentCurrency
        SELECT a.ExchangeID,
               te.ExchangeAbbr,
               a.ProductID,
               tp.ProductName,
               a.InstrumentID,
               a.InstrumentName,
               NVL(tp.CurrencyID, PKGS_Constants.C_CURRENCY_CNY) AS CURRENCYID,
               a.VolumeMultiple,
               a.ExpireDate,
               a.DeliveryYear || LPAD(a.DeliveryMonth, 2, 0) AS Delivdate,
               a.InstrumentID AS ExchangeInstID,
               tp.ProductClass,
               a.OptionsType,
               a.StrikePrice,
               NULL AS Underlyinginstrid,
               NULL AS Underlyingproductid,
               a.DeliveryYear,
               a.DeliveryMonth
          FROM t_OptInstrument a
          JOIN t_Exchange te
            ON a.exchangeid = te.Exchangeid
					JOIN t_Product tp
					  ON a.ExchangeID = tp.ExchangeID
					 AND a.ProductID = tp.ProductID
         WHERE tp.ProductClass IN(PKGS_Enums.PC_Options,PKGS_Enums.PC_SpotOption)
           AND (a.ExchangeID = i_ExchangeID OR NVL(LENGTH(TRIM(i_ExchangeID)), 0) = 0 OR i_ExchangeID IS NULL)
           AND (a.InstrumentID = i_InstrumentID OR a.ProductID = i_InstrumentID OR NVL(LENGTH(TRIM(i_InstrumentID)), 0) = 0 OR i_InstrumentID IS NULL OR regexp_replace(TRIM(i_InstrumentID), '[0-9]', '') IS NULL)
           AND (a.DeliveryYear = l_DeliveryYear OR NVL(LENGTH(TRIM(l_DeliveryYear)), 0) = 0 OR l_DeliveryYear IS NULL)
           AND (a.DeliveryMonth = l_DeliveryMonth OR NVL(LENGTH(TRIM(l_DeliveryMonth)), 0) = 0 OR l_DeliveryMonth IS NULL)
					 AND (a.OptionsType = i_OptionStype OR NVL(LENGTH(TRIM(i_OptionStype)), 0) = 0 OR i_OptionStype IS NULL)
           AND (a.Strikeprice = i_StrikePrice OR NVL(LENGTH(TRIM(i_StrikePrice)), 0) = 0 OR i_StrikePrice IS NULL)
           AND NOT EXISTS (SELECT 1 FROM Tmp_InstrumentCurrency tt WHERE a.ExchangeID = tt.ExchangeID AND a.InstrumentID = tt.InstrumentID)
         UNION ALL
        SELECT a.ExchangeID,
               te.ExchangeAbbr,
               a.ProductID,
               a.ProductName,
               a.ProductID AS InstrumentID,
               a.ProductName AS InstrumentName,
               PKGS_Constants.C_CURRENCY_CNY AS CURRENCYID,
               NULL AS VolumeMultiple,
               NULL AS ExpireDate,
               NULL AS Delivdate,
               a.ProductID AS ExchangeInstID,
               a.ProductClass,
               NULL AS OptionsType,
               NULL AS StrikePrice,
               NULL AS Underlyinginstrid,
               NULL AS Underlyingproductid,
               NULL AS DeliveryYear,
               NULL AS DeliveryMonth
          FROM t_product a
          JOIN t_Exchange te
            ON a.exchangeid = te.Exchangeid
         WHERE a.ProductClass IN(PKGS_Enums.PC_Options,PKGS_Enums.PC_SpotOption)
           AND (a.ExchangeID = i_ExchangeID OR NVL(LENGTH(TRIM(i_ExchangeID)), 0) = 0 OR i_ExchangeID IS NULL)
           AND (a.ProductID = i_InstrumentID OR NVL(LENGTH(TRIM(i_InstrumentID)), 0) = 0 OR i_InstrumentID IS NULL)
					 AND (NVL(LENGTH(TRIM(i_StrikePrice)), 0) = 0 OR i_StrikePrice IS NULL) -- xu.shilin 20200302 如果行权价格不为空的话，则需要查询指定的期权合约，此时期权产品就不应该能被查出来
           AND NOT EXISTS(SELECT 1 FROM Tmp_InstrumentCurrency tt WHERE a.ExchangeID = tt.ExchangeID AND a.ProductID = tt.InstrumentID)
          ;

		END IF;

  EXCEPTION
    WHEN OTHERS THEN
      o_ReturnNo := PKGS_Constants.C_RET_FAIL;
      o_ReturnMsg := '获取需要查询的合约到临时表失败';
			PKGS_Log.up_Fatal(l_ProcessName, '获取需要查询的合约到临时表失败');
			PKGS_Utility.up_ProcessOthersError(l_ProcessName, o_ReturnNo, o_ReturnMsg);
  END up_GenInstrumentCurrency;

	-----------！！！！！！！！！此方法仅适用仅查询持仓这类有粒度到投资单元的场景！！！！！！！！！--------------------------------
	-----------！！！！！！！！！假如查询既有持仓，又有资金，则不适合使用此方法！！！！！！！！！！--------------------------------
  PROCEDURE up_GenDepartPropertyInvstUnit
  (
    o_nRetCode            OUT     PKGS_DATATYPE.STY_RETCODE,            ---- 返回码
    o_varRetMsg           OUT     PKGS_DATATYPE.STY_RETMSG,           ---- 返回信息
    i_OperatorID          IN      PKGS_DATATYPE.STY_OPERATORID,          ---- 操作员代码
    i_BrokerID            IN      PKGS_DATATYPE.STY_BrokerID,            ---- 经纪公司代码
    i_InvestorID          IN      PKGS_DATATYPE.STY_InvestorID,          ---- 投资者代码
    i_InvestUnitID        IN      PKGS_DATATYPE.STY_InvestUnitID,     ----投资单元代码
    i_InvestorType        IN      t_Investor.InvestorType%Type,       ---- 投资者类型
    i_PropertyString      IN      PKGS_DATATYPE.STY_PropertyString,      ---- 操作员代码
    i_StatPropertyString  IN      PKGS_DATATYPE.STY_PropertyString,      ---- 操作员代码
    i_IsDepartmentRight   IN      PKGS_DATATYPE.STY_Bool                 ---- 是否过滤数据权限
  )
  AS
   l_ProcessName     PKGS_DataType.STY_SpName;               ---- 存储过程名称
   l_propertyID      PKGS_DataType.STY_RETMSG;
   l_propertyname    PKGS_DataType.STY_RETMSG;
	 l_UserID          PKGS_DataType.STY_UserID;
	 l_InvestorCount   INT;
  BEGIN
    o_nRetCode := PKGS_Constants.C_S_OK ;
    l_ProcessName := 'pkgs_common.up_GenDepartPropertyInvestor';

	  DELETE FROM TMP_DepartMentInvestor
     WHERE BrokerID =  i_BrokerID ;
		---- 根据操作员权限获取投资者
		---- 当为单个客户时检查投资者
    IF TRIM(i_InvestorID) IS NOT NULL THEN
      SELECT COUNT(*)
        INTO l_InvestorCount
        FROM t_Investor
       WHERE BrokerID   = i_BrokerID
         AND InvestorID = i_InvestorID;
      IF l_InvestorCount < 1 THEN
        o_nRetCode := PKGS_Constants.C_RET_FAIL;
        o_varRetMsg := '投资者代码(' || TRIM(i_investorid) || ')为空或不存在';
        RETURN;
      END IF ;
    END IF ;
    IF i_IsDepartmentRight = PKGS_Constants.C_BOOL_TRUE THEN
			IF TRIM(i_OperatorID) IS NULL THEN
					 o_nRetCode := PKGS_Constants.C_RET_FAIL;
					 o_varRetMsg := '操作员不能为空';
					 PKGS_Log.Fatal(i_OperatorID, l_ProcessName, o_varRetMsg);
					 RETURN;
			END IF ;
			l_UserID := SUBSTR(TRIM(i_OperatorID), INSTR(TRIM(i_OperatorID), '.') + 1) ;

			IF PKGS_Common.uf_GetIsDefaultDepartMent(i_BrokerID,i_OperatorID) = PKGS_Constants.C_BOOL_TRUE THEN
				 ---- user对所有数据都有权限
				 INSERT INTO TMP_DepartMentInvestor(BrokerID ,UserID ,InvestorRange,InvestorID,Investorname,Investunitid )
         SELECT t1.brokerid, l_userid, pkgs_enums.dr_single, t1.investorid,t1.investorname,NVL(t2.investunitid,t1.investorid)
           FROM t_investor t1
           LEFT JOIN t_investunit t2
					   ON t1.brokerid = t2.brokerid
            AND t1.investorid = t2.investorid
          WHERE t1.brokerid = i_brokerid
            AND (TRIM(i_investorid) IS NULL OR t1.investorid = i_investorid)
            AND (TRIM(i_InvestUnitID) IS NULL OR t2.investunitid = i_InvestUnitID)
            AND (TRIM(i_investortype) IS NULL OR t1.investortype = i_investortype)
				 ;
			ELSE
					---- 单一投资单元 暂时不考虑这个场景；结算目前即使设置了单一投资单元，也是给交易区分使用。结算暂不需要区分；
				 /*INSERT INTO TMP_DepartMentInvestor(BrokerID ,UserID,InvestorRange,InvestorID,Investorname,InvestUnitID)
         SELECT brokerid,
                userid,
                pkgs_enums.dr_single,
                investorid,
                t2.investorname,
                t1.investunitid
           FROM t_departmentuser t1, t_investor t2
          WHERE t.brokerid = i_brokerid
            AND t.userid = l_userid
            AND investorrange = pkgs_enums.dr_single
            AND t1.brokerid = t2.brokerid
            AND t1.investorid = t2.investorid
						AND (TRIM(i_investortype) IS NULL OR  investortype = i_investortype)
            AND t1.investorid <> t1.investunitid
            AND (TRIM(i_investorid) IS NULL OR investorid = i_investorid)
            AND (TRIM(i_investunitid) IS NULL OR t1.investunitid = i_investunitid)
						;*/
				 ---- 单一投资者
				 INSERT INTO TMP_DepartMentInvestor(BrokerID ,UserID  ,InvestorRange,InvestorID,Investorname,InvestUnitID )
         SELECT t.brokerid, t.userid, pkgs_enums.dr_single, t.investorid,Investorname,NVL(t2.InvestUnitID,t.investorid)
           FROM t_departmentuser t
					 JOIN t_investor t1
					   ON t.brokerid = t1.brokerid
						AND t.investorid = t1.investorid
					 LEFT JOIN t_investunit t2
									 ON t1.brokerid = t2.brokerid
									AND t1.investorid = t2.investorid
          WHERE t.brokerid = i_brokerid
            AND t.userid = l_userid
            AND investorrange = pkgs_enums.dr_single
            AND t.investorid = t.investunitid
						AND (TRIM(i_investortype) IS NULL OR  t1.investortype = i_investortype)
						AND (TRIM(i_InvestUnitID) IS NULL OR t2.investunitid = i_InvestUnitID)
            AND (TRIM(i_investorid) IS NULL OR t1.investorid = i_investorid)
				 UNION  ---- 非'00'组织架构
         SELECT a.brokerid, l_userid, pkgs_enums.dr_single, a.investorid,investorname,NVL(investunitid,a.investorid)
           FROM t_investor a
					 LEFT JOIN t_investunit b
									 ON a.brokerid = b.brokerid
									AND a.investorid = b.investunitid
          WHERE a.brokerid = i_brokerid
            AND (TRIM(i_investorid) IS NULL OR a.investorid = i_investorid)
            AND (TRIM(i_investortype) IS NULL OR  investortype = i_investortype)
            AND EXISTS
                (SELECT 1
                   FROM t_departmentuser b
                  WHERE a.brokerid = b.brokerid
                    AND TRIM(a.departmentid) LIKE TRIM(b.investorid) || '%'
                    AND b.userid = l_userid
                    AND b.investorrange = pkgs_enums.dr_group
                    AND b.investorid !=  pkgs_constants.default_brokerdepartmentid)
				;
			END IF ;
      up_DelBlacklist(i_BrokerID,l_userid);
    ELSE
      INSERT INTO TMP_DepartMentInvestor(BrokerID ,UserID ,InvestorRange,InvestorID,investorname,InvestunitID )
      SELECT t1.brokerid,
              substr(i_operatorid, instr(i_operatorid, '.') + 1),
              pkgs_constants.dr_single,
              t1.investorid ,
							investorname,
							nvl(InvestunitID,t1.investorid)
         FROM t_investor t1
				 LEFT JOIN t_investunit t2
				   ON t1.brokerid = t2.brokerid
					AND t1.investorid = t2.investorid
        WHERE t1.brokerid = i_brokerid
          AND (TRIM(i_investorid) IS NULL OR t1.investorid = i_investorid)
          AND (TRIM(i_investortype) IS NULL OR investortype = i_investortype)
					;
    END IF;
    ---- 按属性剔除投资者
		IF TRIM(i_PropertyString) IS NOT NULL THEN
			 Pkgs_Common.up_GenPartyInvestor(o_nRetCode, o_varRetMsg ,pkgs_log.g_chOperatorID ,i_BrokerID,i_PropertyString);
		END IF;
    ---- 如果需要统计,获取投资者属性
    IF TRIM(i_StatPropertyString) IS NOT NULL THEN
       FOR c_result IN (SELECT * FROM TMP_DepartMentInvestor)
       LOOP
          up_GetInvestorProperty(o_nRetCode,o_varRetMsg,i_OperatorID,i_BrokerID,c_result.investorid,i_StatPropertyString,l_propertyID, l_propertyname);
          IF o_nRetCode <> PKGS_Constants.C_S_OK  THEN
             o_varRetMsg := '获取操作员查询权限的投资者到临时表失败';
             RETURN;
          END IF;
          UPDATE /*+ index(t idx_tmp_departmentinvestor )*/ tmp_departmentinvestor t
             SET t.propertyid   = TRIM(l_propertyid),
                 t.propertyname = TRIM(l_propertyname)
           WHERE t.brokerid = c_result.brokerid
             AND t.investorrange = pkgs_constants.dr_single
             AND t.investorid = c_result.investorid;
       END LOOP;
    END IF;
    o_varRetMsg := '获取操作员查询权限的投资者到临时表成功';
  EXCEPTION
    WHEN OTHERS THEN
      o_nRetCode := PKGS_Constants.C_S_FAILED;
      o_varRetMsg := '获取操作员查询权限的投资者到临时表失败';
      PKGS_Log.Fatal(i_OperatorID, l_ProcessName, o_varRetMsg);
			PKGS_Utility.up_ProcessOthersError(l_ProcessName, o_nRetCode, o_varRetMsg);
  END up_GenDepartPropertyInvstUnit;

  ---- 剔除TMP_DepartMentInvestor中的黑名单投资者
  PROCEDURE up_DelBlacklist
  (
    i_BrokerID      IN      PKGS_DATATYPE.STY_BrokerID,             ---- 经纪公司代码
    i_OperatorID    IN      PKGS_DATATYPE.STY_OperatorID          ---- 操作员代码
  )
  AS
  BEGIN
    ---- 剔除黑名单投资者
    DELETE FROM TMP_DepartMentInvestor a
    WHERE EXISTS (SELECT 1
    FROM t_departmentuserblacklist b
    WHERE a.brokerid = b.brokerid
    AND   a.userid = b.userid
    AND   a.investorid = b.investorid
    AND   b.userid  = i_OperatorID
    AND   b.brokerid = i_BrokerID
    );
  END up_DelBlacklist;
	/*
  工具调用，校验会员代码及交易日
  */
  PROCEDURE up_chkPartIDTradingDay(o_ReturnNo       OUT  PKGS_DataType.STY_RETCODE,     ---- 导入返回码
                                    o_ReturnMsg      OUT  PKGS_DataType.STY_RETMSG,            ---- 返回信息
                                    i_BrokerID       IN PKGS_DATATYPE.STY_BrokerID,
                                    i_ParticipantID  IN PKGS_DATATYPE.STY_ParticipantID,
                                    i_TradingDay     IN pkgs_datatype.STY_DATE,
                                    i_ExchangeID     IN pkgs_datatype.STY_ExchangeID
  )
  AS
    l_ParticipantID     PKGS_DATATYPE.STY_ParticipantID;
    l_CTPTradingday     PKGS_DATATYPE.STY_DATE;
    l_ProcessName       PKGS_DataType.STY_RETMSG;
  BEGIN
    l_ProcessName:='PKGS_COMMON.up_chkPartIDTradingDay';
    pkgs_log.Info('0000.SettleTools',l_ProcessName,'BrokerID='||i_BrokerID||',ParticipantID='||i_ParticipantID||',TradingDay='||i_TradingDay||',ExchangeID='||i_ExchangeID);
    BEGIN
      SELECT MAX(T.ParticipantID)
        INTO l_ParticipantID
        FROM vw_partbroker t
       WHERE t.ExchangeID = i_exchangeid
         AND t.BrokerID = i_BrokerID
         AND t.IsActive = pkgs_constants.C_BOOL_TRUE
         AND T.ParticipantID  = i_ParticipantID
      ;
      IF(i_ParticipantID IS NULL OR l_ParticipantID IS NULL OR l_ParticipantID<>i_ParticipantID) THEN
        o_ReturnNo  := PKGS_Constants.C_RET_FAIL;
        o_ReturnMsg := o_ReturnMsg|| '无法识别的会员代码。'||'CTP系统会员代码为：'||TRIM(l_ParticipantID)||' 文件会员代码为：'||i_ParticipantID;
      END IF;
    EXCEPTION
      WHEN no_data_found THEN
        o_ReturnNo  := PKGS_Constants.C_RET_FAIL;
        o_ReturnMsg := '经纪公司'||TRIM(i_BrokerID)||'交易所'||TRIM(i_ExchangeID)||'会员代码不存在或不活跃。';
      WHEN OTHERS THEN
        o_ReturnNo  := PKGS_Constants.C_RET_FAIL;
        o_ReturnMsg := '经纪公司'||TRIM(i_BrokerID)||'交易所'||TRIM(i_ExchangeID)||'会员代码查询异常。';
    END;
    IF (o_ReturnNo IS NULL ) THEN
      o_ReturnNo  := PKGS_Constants.C_RET_SUCCESS;
      o_ReturnMsg := '会员代码校验通过。';
    END IF;
    BEGIN
      SELECT MAX(settlementdate)
        INTO l_CTPTradingday
        FROM t_settledate  t
       WHERE t.ExchangeID = i_exchangeid
         AND t.brokerid = i_BrokerID
      ;
      IF(i_TradingDay IS NULL OR l_CTPTradingday IS NULL OR l_CTPTradingday<> i_TradingDay)THEN
        o_ReturnNo  := PKGS_Constants.C_RET_FAIL;
        o_ReturnMsg := o_ReturnMsg|| '    日期不一致。CTP系统日期为：'||TRIM(l_CTPTradingday)||' 文件日期为：'||i_TradingDay;
      ELSE
        o_ReturnMsg := o_ReturnMsg|| '    日期校验通过。';

      END IF;
    EXCEPTION
      WHEN OTHERS THEN
        o_ReturnNo  := PKGS_Constants.C_RET_FAIL;
        o_ReturnMsg := o_ReturnMsg||'经纪公司'||TRIM(i_BrokerID)||'交易所'||TRIM(i_ExchangeID)|| '日期查询异常。';
    END;
    IF (o_ReturnNo IS NULL ) THEN
      o_ReturnNo  := PKGS_Constants.C_RET_SUCCESS;
      o_ReturnMsg := '交易日校验通过。';
    END IF;

  EXCEPTION
    WHEN OTHERS THEN
      ROLLBACK;
      o_ReturnNo  := PKGS_Constants.C_RET_FAIL;
      o_ReturnMsg := '工具会员代码及交易日校验异常';
      PKGS_Utility.up_ProcessOthersError(l_ProcessName,o_ReturnNo,o_ReturnMsg);
  END up_chkPartIDTradingDay;

END PKGS_COMMON;
/

