create TYPE Ty_CSRC_CurrencyMortgage AS OBJECT
(
    TradingDay CHAR(10),  --交易日
    ParticipantID CHAR(10),  --会员代码
    InvestorID CHAR(12),  --客户内部资金账户
    SourceCurrencyID CHAR(3),  --被折抵币种
    SourceDeposit NUMBER(15,3),  --被折抵金额
    TargetCurrencyID CHAR(3),  --折抵目标币种
    TargetDeposit NUMBER(15,3),  --折抵金额
    ExchangeRate NUMBER(16,8),  --折抵汇率
    DiscountRate NUMBER(19,8),  --货币质押折扣率
    Memo VARCHAR2(400),  --备注

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_CSRC_CurrencyMortgage RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

