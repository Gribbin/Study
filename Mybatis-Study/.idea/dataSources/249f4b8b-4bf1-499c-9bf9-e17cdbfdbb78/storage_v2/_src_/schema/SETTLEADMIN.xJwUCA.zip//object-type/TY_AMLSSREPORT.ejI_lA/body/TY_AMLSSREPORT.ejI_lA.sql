create TYPE BODY Ty_AMLSSReport IS

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_AMLSSReport RETURN SELF AS RESULT IS
  BEGIN
    RETURN;
  END;

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2 IS
    l_string VARCHAR2(4000);
  BEGIN
    l_string:='ty_AMLSSReport('
      || 'BrokerID=>' || '''' || trim(BrokerID) || '''' --经纪公司代码
      || ',InvestorID=>' || '''' || trim(InvestorID) || '''' --投资者代码
      || ',AMLGenStatus=>' || '''' || trim(AMLGenStatus) || '''' --数据来源
      || ',CharacterID=>' || '''' || trim(CharacterID) || '''' --可疑特征代码
      || ',TouchDay=>' || '''' || trim(TouchDay) || '''' --可疑交易发生日期
      || ',DrawDay=>' || '''' || trim(DrawDay) || '''' --检查日期
      || ',InvestorType=>' || '''' || trim(InvestorType) || '''' --投资者类型
      || ',InvestorName=>' || '''' || trim(InvestorName) || '''' --投资者名称
      || ',IdentifiedCardType=>' || '''' || trim(IdentifiedCardType) || '''' --证件类型
      || ',IdentifiedCardNo=>' || '''' || trim(IdentifiedCardNo) || '''' --证件号码
      || ',Telephone=>' || '''' || trim(Telephone) || '''' --联系电话
      || ',Address=>' || '''' || trim(Address) || '''' --通讯地址
      || ',FutureAccount=>' || '''' || trim(FutureAccount) || '''' --期货账号
      || ',FutureCurrency=>' || '''' || trim(FutureCurrency) || '''' --期货账号币种
      || ',AccountID=>' || '''' || trim(AccountID) || '''' --投资者账号
      || ',CurrencyID=>' || '''' || trim(CurrencyID) || '''' --投资者账号币种
      || ',BankAccount=>' || '''' || trim(BankAccount) || '''' --银行账户
      || ',OpenBank=>' || '''' || trim(OpenBank) || '''' --银行账户的开户行
      || ',Corporation=>' || '''' || trim(Corporation) || '''' --法人代表
      || ',CorporationIDCardType=>' || '''' || trim(CorporationIDCardType) || '''' --法人证件类型
      || ',CorporationIDCardNo=>' || '''' || trim(CorporationIDCardNo) || '''' --法人证件号码
      || ',IsReport=>' || '''' || trim(IsReport) || '''' --是否报送
      || ')';


    RETURN l_string;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN NULL;
  END;



END;
/

