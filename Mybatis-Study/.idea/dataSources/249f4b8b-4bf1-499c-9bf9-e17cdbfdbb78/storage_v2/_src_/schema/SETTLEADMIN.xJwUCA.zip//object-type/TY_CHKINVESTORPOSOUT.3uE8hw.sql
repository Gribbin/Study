create TYPE Ty_ChkInvestorPosOUT AS OBJECT
(
    BrokerID CHAR(10),  --经纪公司代码
    ExchangeID CHAR(8),  --交易所代码
    InvestorID CHAR(12),  --投资者代码
    InstrumentID CHAR(30),  --合约代码
    Actual NUMBER(22,6),  --当日盈亏
    ExchTransFee NUMBER(22,6),  --交易所交易手续费
    ExchSettlementFee NUMBER(22,6),  --交易所结算手续费
    ExchDelivFee NUMBER(22,6),  --交易所交割手续费
    ExchTransferPosFee NUMBER(22,6),  --交易所移仓手续费

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_ChkInvestorPosOUT RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

