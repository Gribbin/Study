create TYPE BODY Ty_CombinationLeg IS

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_CombinationLeg RETURN SELF AS RESULT IS
  BEGIN
    RETURN;
  END;

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2 IS
    l_string VARCHAR2(4000);
  BEGIN
    l_string:='ty_CombinationLeg('
      || 'ExchangeID=>' || '''' || trim(ExchangeID) || '''' --交易所代码
      || ',CombInstrumentID=>' || '''' || trim(CombInstrumentID) || '''' --组合合约代码
      || ',LegID=>' || '''' || trim(LegID) || '''' --单腿编号
      || ',LegInstrumentID=>' || '''' || trim(LegInstrumentID) || '''' --单腿合约代码
      || ',Direction=>' || '''' || trim(Direction) || '''' --买卖方向
      || ',LegMultiple=>' || '''' || trim(LegMultiple) || '''' --单腿乘数
      || ',ImplyLevel=>' || NVL(to_char(ImplyLevel),'NULL')--派生层数
      || ',Ratio=>' || NVL(to_char(Ratio),'NULL')--保证金比率
      || ')';


    RETURN l_string;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN NULL;
  END;



END;
/

