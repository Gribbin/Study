create TYPE BODY Ty_CRAPersonBlackList IS

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_CRAPersonBlackList RETURN SELF AS RESULT IS
  BEGIN
    RETURN;
  END;

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2 IS
    l_string VARCHAR2(4000);
  BEGIN
    l_string:='ty_CRAPersonBlackList('
      || 'BrokerID=>' || '''' || trim(BrokerID) || '''' --经纪商代码
      || ',PersonName=>' || '''' || trim(PersonName) || '''' --姓名
      || ',PersonBlackListType=>' || '''' || trim(PersonBlackListType) || '''' --人员类型
      || ',IdentifiedCardType=>' || '''' || trim(IdentifiedCardType) || '''' --证件类型
      || ',IdentifiedCardNo=>' || '''' || trim(IdentifiedCardNo) || '''' --证件号码
      || ',Area=>' || '''' || trim(Area) || '''' --地址
      || ')';


    RETURN l_string;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN NULL;
  END;



END;
/

