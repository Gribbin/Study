create TYPE Ty_CopyInvstCommRateExch AS OBJECT
(
    BrokerID CHAR(10),  --经纪公司代码
    InvestorRange CHAR(1),  --投资者范围
    InvestorID CHAR(12),  --投资者代码
    InvestUnitID CHAR(16),  --投资单元代码
    SourceExchangeID CHAR(8),  --源交易所
    SourceInstrumentID CHAR(30),  --源合约
    TargetExchangeID CHAR(8),  --目标交易所
    TargetInstrumentID CHAR(30),  --目标合约
    HedgeFlag CHAR(1),  --投机套保标志

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_CopyInvstCommRateExch RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

