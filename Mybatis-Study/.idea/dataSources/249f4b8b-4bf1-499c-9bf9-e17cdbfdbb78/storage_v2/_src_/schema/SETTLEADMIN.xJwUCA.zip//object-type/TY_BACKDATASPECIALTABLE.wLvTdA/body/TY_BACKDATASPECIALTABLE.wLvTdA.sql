create TYPE BODY Ty_BackDataSpecialTable IS

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_BackDataSpecialTable RETURN SELF AS RESULT IS
  BEGIN
    RETURN;
  END;

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2 IS
    l_string VARCHAR2(4000);
  BEGIN
    l_string:='ty_BackDataSpecialTable('
      || 'SpecialTableName=>' || '''' || trim(SpecialTableName) || '''' --表名
      || ',SchemaName=>' || '''' || trim(SchemaName) || '''' --Shcema
      || ',Status=>' || NVL(to_char(Status),'NULL')--特殊备份类型
      || ',KeyColumn=>' || '''' || trim(KeyColumn) || '''' --特殊字段名
      || ',OperationType=>' || '''' || trim(OperationType) || '''' --流水号表中对应操作类型
      || ')';


    RETURN l_string;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN NULL;
  END;



END;
/

