create TYPE Ty_CommRateTemplate AS OBJECT
(
    BrokerID CHAR(10),  --经纪公司代码
    RateTemplateID CHAR(8),  --模型代码
    RateTemplateName CHAR(60),  --模型名称
    ExchangeID CHAR(8),  --交易所代码
    ProductID CHAR(30),  --产品代码
    RateTemplateMemo CHAR(160),  --模型说明
    IsActive NUMBER(1),  --是否启用
    OperatorID CHAR(64),  --录入员代码
    OperateDate CHAR(8),  --录入日期
    OperateTime CHAR(8),  --录入时间
    TemplateType CHAR(1),  --模型类型
    VersionNo NUMBER(10),  --版本号

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_CommRateTemplate RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

