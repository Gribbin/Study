create TYPE Ty_CSRCOtherInfo AS OBJECT
(
    BrokerID CHAR(10),  --经纪公司代码
    TradingDay CHAR(8),  --交易日
    SequenceNo NUMBER(8),  --序号
    InvestorID CHAR(12),  --投资者代码
    Reason CHAR(1),  --事由
    Description VARCHAR2(400),  --描述

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_CSRCOtherInfo RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

