create TYPE Ty_CAPInvestUnit AS OBJECT
(
    BrokerID CHAR(10),  --经纪公司代码
    InvestorID CHAR(12),  --投资者代码
    InvestUnitID CHAR(16),  --投资单元代码
    AccountID CHAR(14),  --投资单元默认资金账号
    CurrencyID CHAR(3),  --投资单元默认资金账号币种
    InvestUnitName VARCHAR2(80),  --投资单元名称
    IsActive NUMBER(1),  --是否活跃
    ClientRegion CHAR(1),  --开户客户地域
    InvestorType CHAR(1),  --投资者类型
    ClientMode CHAR(2),  --开户模式
    OpenDate CHAR(8),  --开户日期
    CancelDate CHAR(8),  --销户日期

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_CAPInvestUnit RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

