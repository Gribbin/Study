create TYPE Ty_CombInstrumentMap AS OBJECT
(
    InstrumentID CHAR(80),  --合约代码
    Direction CHAR(1),  --买卖
    ExchangeInstID CHAR(80),  --交易所合约代码

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_CombInstrumentMap RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

