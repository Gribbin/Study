create TYPE BODY Ty_AssetInvestor IS

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_AssetInvestor RETURN SELF AS RESULT IS
  BEGIN
    RETURN;
  END;

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2 IS
    l_string VARCHAR2(4000);
  BEGIN
    l_string:='ty_AssetInvestor('
      || 'BrokerID=>' || '''' || trim(BrokerID) || '''' --经纪公司代码
      || ',InvestorID=>' || '''' || trim(InvestorID) || '''' --投资者代码(资管资金账号)
      || ',ClientName=>' || '''' || trim(ClientName) || '''' --客户姓名
      || ',Gender=>' || '''' || trim(Gender) || '''' --客户性别
      || ',BranchCode=>' || '''' || trim(BranchCode) || '''' --营业部编号
      || ',ClientRegion=>' || '''' || trim(ClientRegion) || '''' --开户客户地域
      || ',IDKind=>' || '''' || trim(IDKind) || '''' --证件类型
      || ',IDNo=>' || '''' || trim(IDNo) || '''' --证件号码
      || ',InstitutionExtraCode=>' || '''' || trim(InstitutionExtraCode) || '''' --组织机构代码附加码
      || ',IDBeginDate=>' || '''' || trim(IDBeginDate) || '''' --证件开始日期
      || ',IDEndDate=>' || '''' || trim(IDEndDate) || '''' --证件结束日期
      || ',IDTerm=>' || '''' || trim(IDTerm) || '''' --证件期限
      || ',IDAddr=>' || '''' || trim(IDAddr) || '''' --身份证地址
      || ',AddrCountry=>' || '''' || trim(AddrCountry) || '''' --联系地址中的国家
      || ',AddrProvince=>' || '''' || trim(AddrProvince) || '''' --联系地址中的省/自治区/直辖市
      || ',AddrCity=>' || '''' || trim(AddrCity) || '''' --联系地址中的市/县/区
      || ',AddrAddress=>' || '''' || trim(AddrAddress) || '''' --联系地址中的地址
      || ',Birthday=>' || '''' || trim(Birthday) || '''' --出生日期
      || ',AddrZipcode=>' || '''' || trim(AddrZipcode) || '''' --邮政编码
      || ',Email=>' || '''' || trim(Email) || '''' --电子信箱
      || ',PhoneCountryCode=>' || '''' || trim(PhoneCountryCode) || '''' --联系电话中的国家代码
      || ',PhoneAreaCode=>' || '''' || trim(PhoneAreaCode) || '''' --联系电话中的区号
      || ',PhoneTel=>' || '''' || trim(PhoneTel) || '''' --联系电话中的电话号码
      || ',ContactMoblie=>' || '''' || trim(ContactMoblie) || '''' --联系手机
      || ',ProfessionCode=>' || '''' || trim(ProfessionCode) || '''' --职业类别
      || ',IndustyCode=>' || '''' || trim(IndustyCode) || '''' --行业
      || ',ClientMode=>' || '''' || trim(ClientMode) || '''' --开户模式
      || ',Classify=>' || '''' || trim(Classify) || '''' --期货客户类型
      || ',DegreeCode=>' || '''' || trim(DegreeCode) || '''' --学历代码
      || ',WorkProperty=>' || '''' || trim(WorkProperty) || '''' --个人客户所在单位的单位性质
      || ',TerminalType=>' || '''' || trim(TerminalType) || '''' --终端类型
      || ',DevelopSource=>' || '''' || trim(DevelopSource) || '''' --客户来源
      || ',Val1=>' || '''' || trim(Val1) || '''' --扩展字段1
      || ',Val2=>' || '''' || trim(Val2) || '''' --扩展字段2
      || ',Val3=>' || '''' || trim(Val3) || '''' --扩展字段3
      || ',TaxType=>' || '''' || trim(TaxType) || '''' --税收类型
      || ',PlatformType=>' || '''' || trim(PlatformType) || '''' --政要关系
      || ',BadRecord=>' || '''' || trim(BadRecord) || '''' --不良记录
      || ',Terminvestment=>' || '''' || trim(Terminvestment) || '''' --投资期限
      || ',Investmentvariety=>' || '''' || trim(Investmentvariety) || '''' --投资品种
      || ',Proceedstype=>' || '''' || trim(Proceedstype) || '''' --收益类型
      || ',Conrelation=>' || '''' || trim(Conrelation) || '''' --控制关系
      || ',Beneficiary=>' || '''' || trim(Beneficiary) || '''' --受益人
      || ',Opendate=>' || '''' || trim(Opendate) || '''' --开立日期
      || ',Status=>' || '''' || trim(Status) || '''' --状态
      || ',ProdName=>' || '''' || trim(ProdName) || '''' --产品名称
      || ',DealType=>' || '''' || trim(DealType) || '''' --交易类型
      || ')';


    RETURN l_string;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN NULL;
  END;



END;
/

