create TYPE Ty_AssetInvestor AS OBJECT
(
    BrokerID CHAR(10),  --经纪公司代码
    InvestorID CHAR(12),  --投资者代码(资管资金账号)
    ClientName VARCHAR2(100),  --客户姓名
    Gender CHAR(1),  --客户性别
    BranchCode CHAR(12),  --营业部编号
    ClientRegion CHAR(1),  --开户客户地域
    IDKind CHAR(2),  --证件类型
    IDNo CHAR(50),  --证件号码
    InstitutionExtraCode CHAR(50),  --组织机构代码附加码
    IDBeginDate VARCHAR2(30),  --证件开始日期
    IDEndDate VARCHAR2(30),  --证件结束日期
    IDTerm VARCHAR2(30),  --证件期限
    IDAddr VARCHAR2(200),  --身份证地址
    AddrCountry CHAR(15),  --联系地址中的国家
    AddrProvince CHAR(50),  --联系地址中的省/自治区/直辖市
    AddrCity CHAR(50),  --联系地址中的市/县/区
    AddrAddress CHAR(100),  --联系地址中的地址
    Birthday VARCHAR2(30),  --出生日期
    AddrZipcode CHAR(10),  --邮政编码
    Email CHAR(100),  --电子信箱
    PhoneCountryCode CHAR(10),  --联系电话中的国家代码
    PhoneAreaCode CHAR(10),  --联系电话中的区号
    PhoneTel CHAR(40),  --联系电话中的电话号码
    ContactMoblie CHAR(40),  --联系手机
    ProfessionCode CHAR(3),  --职业类别
    IndustyCode VARCHAR2(30),  --行业
    ClientMode CHAR(2),  --开户模式
    Classify CHAR(40),  --期货客户类型
    DegreeCode CHAR(1),  --学历代码
    WorkProperty CHAR(15),  --个人客户所在单位的单位性质
    TerminalType CHAR(1),  --终端类型
    DevelopSource VARCHAR2(100),  --客户来源
    Val1 VARCHAR2(100),  --扩展字段1
    Val2 VARCHAR2(100),  --扩展字段2
    Val3 VARCHAR2(100),  --扩展字段3
    TaxType CHAR(1),  --税收类型
    PlatformType CHAR(1),  --政要关系
    BadRecord VARCHAR2(30),  --不良记录
    Terminvestment CHAR(1),  --投资期限
    Investmentvariety VARCHAR2(20),  --投资品种
    Proceedstype CHAR(1),  --收益类型
    Conrelation CHAR(1),  --控制关系
    Beneficiary CHAR(1),  --受益人
    Opendate CHAR(8),  --开立日期
    Status VARCHAR2(3),  --状态
    ProdName VARCHAR2(100),  --产品名称
    DealType VARCHAR2(20),  --交易类型

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_AssetInvestor RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

