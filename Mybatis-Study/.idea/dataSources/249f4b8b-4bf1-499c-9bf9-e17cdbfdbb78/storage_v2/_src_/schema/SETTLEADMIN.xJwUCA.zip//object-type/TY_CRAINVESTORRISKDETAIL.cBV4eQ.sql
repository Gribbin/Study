create TYPE Ty_CRAInvestorRiskDetail AS OBJECT
(
    BrokerID CHAR(10),  --经纪商代码
    InvestorID CHAR(12),  --投资者代码
    RiskIndexID NUMBER(8),  --风险指标ID
    RiskIndexOptionID NUMBER(8),  --风险指标选项ID
    RiskIndexOptionScore NUMBER(8),  --分类评分

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_CRAInvestorRiskDetail RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

