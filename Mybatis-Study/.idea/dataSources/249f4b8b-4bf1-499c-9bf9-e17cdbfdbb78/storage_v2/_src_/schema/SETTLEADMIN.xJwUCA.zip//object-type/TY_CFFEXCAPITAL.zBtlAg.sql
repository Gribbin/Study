create TYPE Ty_CFFEXCapital AS OBJECT
(
    TradingDay CHAR(8),  --交易日
    ExchangeID CHAR(8),  --交易所代码
    ParticipantID CHAR(10),  --会员代码
    LastDeposit NUMBER(22,6),  --上一交易日人民币实有货币资金余额
    FundIn NUMBER(22,6),  --当日收入资金
    Actual NUMBER(22,6),  --当日盈亏
    FundOut NUMBER(22,6),  --当日付出资金
    Fee NUMBER(22,6),  --手续费
    TransFee NUMBER(22,6),  --交易手续费
    SettlementFee NUMBER(22,6),  --结算手续费
    DelivFee NUMBER(22,6),  --交割手续费
    TransposFee NUMBER(22,6),  --移仓手续费
    Deposit NUMBER(22,6),  --当日人民币资金余额
    ForeCurrMortgage NUMBER(22,6),  --当日外汇实际可用金额
    Margin NUMBER(22,6),  --交易保证金
    Remain NUMBER(22,6),  --结算准备金
    Margin1 NUMBER(22,6),  --交易保证金1
    CurrreMain NUMBER(22,6),  --当日结算准备金余额
    DeclareFundIn NUMBER(22,6),  --申报划入金额
    DeclareFundOut NUMBER(22,6),  --申报划出金额
    Prepa NUMBER(22,6),  --下一交易日开仓准备金
    PayFee NUMBER(22,6),  --支付手续费
    ActualFundChange NUMBER(22,6),  --人民币资金变动
    MarginChange NUMBER(22,6),  --交易保证金变动
    RemainChange NUMBER(22,6),  --结算准备金变动
    DelivMargin NUMBER(22,6),  --交割保证金
    OPTPremiumMoney NUMBER(22,6),  --权利金
    Mortgage NUMBER(22,6),  --当日有价证券实际可用金额

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_CFFEXCapital RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

