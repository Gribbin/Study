create TYPE Ty_CRACheckHis AS OBJECT
(
    BrokerID CHAR(10),  --经纪公司代码
    ApplyNo NUMBER(8),  --流水号
    CheckNo NUMBER(5),  --操作次数
    FlowID CHAR(1),  --流程ID
    RatingType CHAR(1),  --评级方式
    CheckStatus CHAR(1),  --审核状态
    CheckMemo CHAR(160),  --审核情况说明
    CurrCheckLevel CHAR(1),  --当前审核级别
    MaxCheckLevel CHAR(1),  --最高审核级别
    UsedStatus CHAR(1),  --生效状态
    Applier CHAR(64),  --申请人
    ApplyDate CHAR(8),  --申请日期
    InvestorRange CHAR(1),  --投资者范围
    InvestorID CHAR(12),  --投资者代码
    RiskScore NUMBER(8),  --评级系统得分
    RiskLevel NUMBER(8),  --风险等级
    IsLatest NUMBER(1),  --是否最新
    OperatorID CHAR(64),  --审核员代码
    OperateDate CHAR(8),  --审核日期
    OperateTime CHAR(8),  --审核时间
    CheckContent VARCHAR2(4000),  --审核内容

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_CRACheckHis RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

