create TYPE BODY Ty_AmlCheckNiShTrade IS

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_AmlCheckNiShTrade RETURN SELF AS RESULT IS
  BEGIN
    RETURN;
  END;

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2 IS
    l_string VARCHAR2(4000);
  BEGIN
    l_string:='ty_AmlCheckNiShTrade('
      || 'TradingDay=>' || '''' || trim(TradingDay) || '''' --交易日期
      || ',FlowID=>' || '''' || trim(FlowID) || '''' --流程ID
      || ',ApplyOperate=>' || '''' || trim(ApplyOperate) || '''' --触发流程操作
      || ',DataStatus=>' || '''' || trim(DataStatus) || '''' --数据状态
      || ',BrokerID=>' || '''' || trim(BrokerID) || '''' --经纪公司代码
      || ',CharacterID=>' || '''' || trim(CharacterID) || '''' --大额交易特征码
      || ',TouchDay=>' || '''' || trim(TouchDay) || '''' --大额交易发生日期
      || ',DrawDay=>' || '''' || trim(DrawDay) || '''' --检查日期
      || ',InvestorID=>' || '''' || trim(InvestorID) || '''' --投资者代码
      || ',DataSource=>' || '''' || trim(DataSource) || '''' --数据来源
      || ',CTNM=>' || '''' || trim(CTNM) || '''' --客户姓名
      || ',CITP=>' || '''' || trim(CITP) || '''' --客户身份证件/证明文件类型
      || ',CTID=>' || '''' || trim(CTID) || '''' --客户身份证件/证明文件号码
      || ',FINC=>' || '''' || trim(FINC) || '''' --金融机构网点代码
      || ',RLFC=>' || '''' || trim(RLFC) || '''' --金融机构与客户的关系
      || ',CATP=>' || '''' || trim(CATP) || '''' --客户账户类型
      || ',CTAC=>' || '''' || trim(CTAC) || '''' --客户账号
      || ',OATM=>' || '''' || trim(OATM) || '''' --客户账户开立时间
      || ',CBCT=>' || '''' || trim(CBCT) || '''' --客户银行卡类型
      || ',CBCN=>' || '''' || trim(CBCN) || '''' --客户银行卡号码
      || ',TBNM=>' || '''' || trim(TBNM) || '''' --交易代办人姓名
      || ',TBIT=>' || '''' || trim(TBIT) || '''' --交易代办人身份证件/证明文件类型
      || ',TBID=>' || '''' || trim(TBID) || '''' --交易代办人身份证件/证明文件号码
      || ',TBNT=>' || '''' || trim(TBNT) || '''' --交易代办人国籍
      || ',TSTM=>' || '''' || trim(TSTM) || '''' --交易时间
      || ',TRCD=>' || '''' || trim(TRCD) || '''' --交易发生地
      || ',TICD=>' || '''' || trim(TICD) || '''' --业务标识号
      || ',RPMT=>' || '''' || trim(RPMT) || '''' --收付款方匹配号类型
      || ',RPMN=>' || '''' || trim(RPMN) || '''' --收付款方匹配号
      || ',TSTP=>' || '''' || trim(TSTP) || '''' --交易方式
      || ',OCTT=>' || '''' || trim(OCTT) || '''' --非柜台交易方式
      || ',OOCT=>' || '''' || trim(OOCT) || '''' --其他非柜台交易方式
      || ',OCEC=>' || '''' || trim(OCEC) || '''' --非柜台交易方式的设备代码
      || ',BPTC=>' || '''' || trim(BPTC) || '''' --银行与支付机构之间的业务交易编码
      || ',TSCT=>' || '''' || trim(TSCT) || '''' --涉外收支交易分类与代码
      || ',TSDR=>' || '''' || trim(TSDR) || '''' --资金收付标志
      || ',CRPP=>' || '''' || trim(CRPP) || '''' --资金用途
      || ',CRTP=>' || '''' || trim(CRTP) || '''' --交易币种
      || ',CRAT=>' || '''' || trim(CRAT) || '''' --交易金额
      || ',CRMB=>' || '''' || trim(CRMB) || '''' --交易金额（折人民币）
      || ',CUSD=>' || '''' || trim(CUSD) || '''' --交易金额（折美元）
      || ',CFIN=>' || '''' || trim(CFIN) || '''' --对方金融机构网点名称
      || ',CFCT=>' || '''' || trim(CFCT) || '''' --对方金融机构网点代码类型
      || ',CFIC=>' || '''' || trim(CFIC) || '''' --对方金融机构网点代码
      || ',CFRC=>' || '''' || trim(CFRC) || '''' --对方金融机构网点行政区划代码
      || ',TCNM=>' || '''' || trim(TCNM) || '''' --交易对手姓名/名称
      || ',TCIT=>' || '''' || trim(TCIT) || '''' --交易对手身份证件/证明文件类型
      || ',OITP=>' || '''' || trim(OITP) || '''' --其他身份证件/证明文件类型
      || ',TCID=>' || '''' || trim(TCID) || '''' --交易对手身份证件/证明文件号码
      || ',TCAT=>' || '''' || trim(TCAT) || '''' --交易对手账户类型
      || ',TCAC=>' || '''' || trim(TCAC) || '''' --交易对手账号
      || ',ROTF=>' || '''' || trim(ROTF) || '''' --交易信息备注
      || ')';


    RETURN l_string;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN NULL;
  END;



END;
/

