create TYPE Ty_CloudOpenLog AS OBJECT
(
    TradingDay CHAR(8),  --交易日
    SequenceNo NUMBER(12),  --序号
    BrokerID CHAR(10),  --经纪公司代码
    LogLevel CHAR(32),  --日志级别
    requestURL VARCHAR2(256),  --请求地址
    requestBody VARCHAR2(4000),  --请求参数
    operationMemo VARCHAR2(4000),  --日志信息
    OperationDate CHAR(8),  --日期
    OperationTime CHAR(8),  --时间

  --构造空对象
  CONSTRUCTOR FUNCTION Ty_CloudOpenLog RETURN SELF AS RESULT,

  --将对象的成员转换成字符串(仅为日志使用)
  MEMBER FUNCTION uf_toString RETURN VARCHAR2
)
/

