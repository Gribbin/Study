create PACKAGE BODY PKGS_Utility IS
  /*************************************************************************
  $spDesc 封装 Oracle 开发框架的 开始处理
  $param  i_varAPIName 传入 API 的名称
  $param  o_nRetCode 返回编码
  $param  i_varRetMsg 返回信息
  $exception 捕获所有异常
    ALTER PACKAGE PKGS_Utility COMPILE PLSQL_CCFLAGS='bHook:true' REUSE SETTINGS;
    dbms_preprocessor.print_post_processed_source('PACKAGE BODY', user, 'PKGS_Utility');
  *************************************************************************/
  PROCEDURE up_SPF_begin
  (
    i_varAPIName    VARCHAR2
   ,i_varAPIComment VARCHAR2
   ,o_nRetCode      OUT NUMBER
   ,o_varRetMsg     OUT VARCHAR2
  ) IS
    l_nCount BINARY_INTEGER := 0;
  BEGIN
    o_nRetCode := pkgs_constants.C_RET_SUCCESS;

    $IF $$bHook $THEN
    o_nRetCode := SPF.PKGF_SPHOOK.uf_StartHook(TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS'),
                                               i_varAPIComment,
                                               l_nCount);
    IF o_nRetCode <> 0
    THEN
      --  pkgs_logmanager.up_Debug(i_varAPIName, 'Start SPHook OK.' || l_nCount);
      --ELSE
      o_varRetMsg := '开始解析代码失败.';
      pkgs_logmanager.up_Debug(i_varAPIName, 'Start SPHook failed.' || o_nRetCode);
      --  RETURN;
    END IF;
    $END

  EXCEPTION
    WHEN OTHERS THEN
      o_varRetMsg := 'Oracle 开发框架初始化出现异常。';
      PKGS_Utility.up_ProcessOthersError(i_varAPIName, o_nRetCode, o_varRetMsg);
  END up_SPF_begin;

  /*************************************************************************
  $spDesc 封装 Oracle 开发框架的 结束处理
  $param  i_varAPIName 传入 API 的名称
  $param  o_nRetCode 返回编码
  $param  i_varRetMsg 返回信息
  $exception 捕获所有异常
  *************************************************************************/
  PROCEDURE up_SPF_End
  (
    i_varAPIName    VARCHAR2
   ,i_varAPIComment VARCHAR2
  ) IS
    l_nRetCode BINARY_INTEGER;
  BEGIN
    l_nRetCode := 0;
    $IF $$bHook $THEN
    l_nRetCode := SPF.PKGF_SPHOOK.uf_StopHook();
    IF l_nRetCode <> 0
    THEN
      --  pkgs_logmanager.up_Debug(i_varAPIName, 'Stop SPHook OK.');
      --ELSE
      pkgs_logmanager.up_Debug(i_varAPIName, 'Stop SPHook failed.' || l_nRetCode);
    END IF;
    $END

  EXCEPTION
    WHEN OTHERS THEN
      PKGS_Utility.up_ProcessOthersError(i_varAPIName,
                                         l_nRetCode,
                                         i_varAPIComment || 'Oracle 开发框架 结束时出现异常。');
  END up_SPF_End;
  /*************************************************************************
  $spDesc 控制事务的提交，一般在接口SP内使用
  $param  i_chCommit '1':即执行commit提交事务，其它值不进行提交
  $exception 不捕获异常
  *************************************************************************/
  PROCEDURE up_Commit(i_chCommit IN PKGS_DataType.STY_COMMIT_FLAG) IS
  BEGIN
    IF i_chCommit = '1'
    THEN
      COMMIT;
    END IF;
  END;

  /*************************************************************************
  $spDesc 控制事务的回滚，一般在接口SP内使用
  $param  i_chRollback '1':即执行 ROLLBACK 回滚事务，其它值不进行回滚
  $exception 不捕获异常
  *************************************************************************/
  PROCEDURE up_Rollback(i_chRollback IN PKGS_DataType.STY_COMMIT_FLAG) IS
  BEGIN
    IF i_chRollback = '1'
    THEN
      ROLLBACK;
    END IF;
  END up_Rollback;

  /*************************************************************************
  $spDesc 处理 不可预知的异常
  $param  i_varSPName 传入SP的名称
  $param  o_nRetCode 返回编码
  $param  o_nRetCode 返回信息
  $exception 不捕获异常
  *************************************************************************/
  PROCEDURE up_ProcessOthersError
  (
    i_varSPName IN VARCHAR2
   ,o_nRetCode  OUT NUMBER
   ,i_varRetMsg IN VARCHAR2
  ) IS
    -- l_varSPName t_operationlog.spname%TYPE := 'PKGS_Utility.up_ProcessOthersError';
  BEGIN
    o_nRetCode := pkgs_constants.C_RET_SUCCESS;
    IF SQLCODE > -20000
    THEN
      IF SQLCODE IN (-6508) -- 需要重新连接数据库的错误列表
      THEN
        o_nRetCode := pkgs_constants.E_RECONNECT_ERROR;
      ELSE
        o_nRetCode := pkgs_constants.E_RUNTIME_ERROR;
      END IF;

      --pkgs_log.up_Error(i_varSPName, i_varRetMsg || '::' || SQLERRM);
      pkgs_log.up_Error(i_varSPName, SUBSTR(i_varRetMsg||'::'||SQLERRM||'::'||DBMS_Utility.FORMAT_ERROR_BACKTRACE(),1,4000));
    ELSE
      --本系统的异常机制决定不会到此分支，如果运行到此分支说明异常处理机制出现问题
      o_nRetCode := pkgs_constants.E_RUNTIME_ERROR;

      pkgs_log.up_Error(i_varSPName,
                               '处理Oracle异常时，抛出了自定义的异常。::' || SQLERRM);
    END IF;
  END;

END PKGS_Utility;
/

